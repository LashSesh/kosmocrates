# Periodensystem der Graphen — Empirische Befunde (n ≤ 8)

Katalog: **13598 Graphen**.

## OEIS-Crosscheck (6 unabhängige Sequenzen, 48 Werte ✓)

| n | alle (A000088) | zusamm. (A001349) | bipartit (A033995) | Bäume (A000055) | Threshold (A005840) | planar (A005470) |
|---|----------------|-------------------|--------------------|-----------------|---------------------|------------------|
| 1 | 1 | 1 | 1 | 1 | 1 | 1 |
| 2 | 2 | 1 | 2 | 1 | 2 | 2 |
| 3 | 4 | 2 | 3 | 1 | 4 | 4 |
| 4 | 11 | 6 | 7 | 2 | 8 | 11 |
| 5 | 34 | 21 | 13 | 3 | 16 | 33 |
| 6 | 156 | 112 | 35 | 6 | 32 | 142 |
| 7 | 1044 | 853 | 88 | 11 | 64 | 822 |
| 8 | 12346 | 11117 | 303 | 23 | 128 | 6966 |

## Q2 — Kospektrale Paare, Tripel, höhere Gruppen

- Insgesamt **829 Paare**, **54 Tripel**, **6 Gruppen ≥ 4**.

| n | Graphen | Nicht-singleton-Klassen | Graphen darin | größte Klasse |
|---|---------|------------------------|---------------|---------------|
| 1 | 1 | 0 | 0 | 0 |
| 2 | 2 | 0 | 0 | 0 |
| 3 | 4 | 0 | 0 | 0 |
| 4 | 11 | 0 | 0 | 0 |
| 5 | 34 | 1 | 2 | 2 |
| 6 | 156 | 5 | 10 | 2 |
| 7 | 1044 | 54 | 110 | 3 |
| 8 | 12346 | 829 | 1722 | 4 |

**Tripel+-Gruppen (größte 10):**
- n=7, |class|=3, spec=[-2.000, -1.778, -1.000, 0.000, -0.000, 1.289, 3.489], members=G7-11-107, G7-11-142, G7-11-57
- n=7, |class|=3, spec=[-2.000, -1.000, 0.000, 0.000, 0.000, 1.000, 2.000], members=G7-5-10, G7-5-5, G7-5-8
- n=8, |class|=4, spec=[-2.536, -1.393, -1.000, -0.736, 0.444, 1.000, 1.116, 3.105], members=G8-11-433, G8-11-573, G8-11-892, G8-11-921
- n=8, |class|=4, spec=[-2.000, -1.618, -1.275, -1.000, 0.300, 0.618, 1.510, 3.465], members=G8-12-1249, G8-12-141, G8-12-875, G8-12-989
- n=8, |class|=4, spec=[-2.296, -1.618, -1.242, -0.779, 0.420, 0.618, 1.143, 3.755], members=G8-13-1485, G8-13-234, G8-13-267, G8-13-909
- n=8, |class|=4, spec=[-2.210, -2.000, -1.476, -0.611, -0.000, 0.296, 1.508, 4.495], members=G8-17-342, G8-17-357, G8-17-743, G8-17-953
- n=8, |class|=4, spec=[-2.000, -1.000, -1.000, 0.000, 0.000, 1.000, 1.000, 2.000], members=G8-6-12, G8-6-38, G8-6-46, G8-6-56
- n=8, |class|=4, spec=[-1.935, -1.618, -1.000, 0.000, 0.000, 0.618, 1.463, 2.473], members=G8-8-17, G8-8-55, G8-8-64, G8-8-86
- n=8, |class|=3, spec=[-2.000, -2.000, -1.000, 0.000, -0.000, 1.000, 1.000, 3.000], members=G8-10-112, G8-10-464, G8-10-575
- n=8, |class|=3, spec=[-2.372, -1.000, -1.000, 0.000, 0.000, 0.000, 1.000, 3.372], members=G8-10-118, G8-10-209, G8-10-504

## Q5 — Matrixpotenzen vs. Spektrum als Iso-Vorfilter

Stärke eines Invarianten = Anzahl distinkter Werte (Maximum = 13598 = Anzahl Graphen).

| Invariant | Distinkte Werte | Lücke zu 13598 |
|-----------|-----------------|--------------|
| (n, m=tr(A²)/2) | 92 | 13506 |
| (n, tr A², tr A³) | 424 | 13174 |
| (n, tr A²..A⁴) | 3536 | 10062 |
| (n, tr A²..A⁵) | 8574 | 5024 |
| (n, tr A²..A⁶) | 12194 | 1404 |
| (n, Spektrum) | 12643 | 955 |
| (n, Gradfolge) | 1706 | 11892 |

**Pro n:**

| n | Graphen | tr A²,A³ | tr A²..A⁴ | tr A²..A⁵ | Spektrum |
|---|---------|----------|-----------|-----------|----------|
| 1 | 1 | 1 | 1 | 1 | 1 |
| 2 | 2 | 2 | 2 | 2 | 2 |
| 3 | 4 | 4 | 4 | 4 | 4 |
| 4 | 11 | 9 | 11 | 11 | 11 |
| 5 | 34 | 21 | 33 | 33 | 33 |
| 6 | 156 | 49 | 136 | 147 | 151 |
| 7 | 1044 | 110 | 625 | 886 | 988 |
| 8 | 12346 | 228 | 2724 | 7490 | 11453 |

_Theoretischer Hintergrund (Newton-Identitäten): `tr A^k` für k=1..n bestimmt das Spektrum eindeutig. Für symmetrische 0/1-Matrizen mit festem n sollten die Spalten bei k=n übereinstimmen._

## Q4 — Selbstkomplementäre Graphen

- Insgesamt **14 selbstkomplementäre Graphen** im Katalog.

| n | Anzahl |
|---|--------|
| 1 | 1 |
| 4 | 1 |
| 5 | 2 |
| 8 | 10 |

**Liste (id, n, m, Grad, Δ, |Stab|):**

- G1-0-1 (n=1, m=0, degs=[0], Δ=0, |Stab|=5040)
- G4-3-2 (n=4, m=3, degs=[1,1,2,2], Δ=0, |Stab|=12)
- G5-5-1 (n=5, m=5, degs=[1,1,2,3,3], Δ=1, |Stab|=4)
- G5-5-6 (n=5, m=5, degs=[2,2,2,2,2], Δ=0, |Stab|=20)
- G8-14-1080 (n=8, m=14, degs=[3,3,3,3,4,4,4,4], Δ=4, |Stab|=8)
- G8-14-1273 (n=8, m=14, degs=[2,2,3,3,4,4,5,5], Δ=6, |Stab|=2)
- G8-14-1428 (n=8, m=14, degs=[3,3,3,3,4,4,4,4], Δ=4, |Stab|=8)
- G8-14-1546 (n=8, m=14, degs=[3,3,3,3,4,4,4,4], Δ=4, |Stab|=32)
- G8-14-1640 (n=8, m=14, degs=[2,2,3,3,4,4,5,5], Δ=6, |Stab|=4)
- G8-14-268 (n=8, m=14, degs=[2,2,2,2,5,5,5,5], Δ=8, |Stab|=8)
- G8-14-390 (n=8, m=14, degs=[3,3,3,3,4,4,4,4], Δ=4, |Stab|=2)
- G8-14-743 (n=8, m=14, degs=[2,2,3,3,4,4,5,5], Δ=6, |Stab|=2)
- G8-14-872 (n=8, m=14, degs=[1,1,3,3,4,4,6,6], Δ=10, |Stab|=4)
- G8-14-970 (n=8, m=14, degs=[2,2,2,2,5,5,5,5], Δ=8, |Stab|=32)

## Q3 — Spektralverteilung / „verbotene" Spektren

- Eigenwert-Wertebereich: **[-4, 7]**.
- Spektralradius: **[0, 7]**.
- Graphen mit ganzzahligem Spektrum: **146**.
- Graphen mit halbzahligem Spektrum: **0**.
- Algebraische Konnektivität = 0 (disconnected): **1486**, > 0: **12112**.
- Distinkte ganzzahlige Eigenwerte im Gesamtkatalog: **[-4, -3, -2, -1, 0, 1, 2, 3, 4, 5, 6, 7]**.

**Häufigste Spektren (Top 10):**

- n=8 · 4×  spec=[-2.536, -1.393, -1.000, -0.736, 0.444, 1.000, 1.116, 3.105]  (Bsp.: G8-11-433, G8-11-573, G8-11-892, G8-11-921)
- n=8 · 4×  spec=[-2.296, -1.618, -1.242, -0.779, 0.420, 0.618, 1.143, 3.755]  (Bsp.: G8-13-234, G8-13-267, G8-13-909, G8-13-1485)
- n=8 · 4×  spec=[-2.210, -2.000, -1.476, -0.611, -0.000, 0.296, 1.508, 4.495]  (Bsp.: G8-17-342, G8-17-357, G8-17-743, G8-17-953)
- n=8 · 4×  spec=[-2.000, -1.618, -1.275, -1.000, 0.300, 0.618, 1.510, 3.465]  (Bsp.: G8-12-141, G8-12-875, G8-12-989, G8-12-1249)
- n=8 · 4×  spec=[-2.000, -1.000, -1.000, 0.000, 0.000, 1.000, 1.000, 2.000]  (Bsp.: G8-6-12, G8-6-38, G8-6-46, G8-6-56)
- n=8 · 4×  spec=[-1.935, -1.618, -1.000, 0.000, 0.000, 0.618, 1.463, 2.473]  (Bsp.: G8-8-17, G8-8-55, G8-8-64, G8-8-86)
- n=7 · 3×  spec=[-2.000, -1.778, -1.000, 0.000, -0.000, 1.289, 3.489]  (Bsp.: G7-11-57, G7-11-107, G7-11-142)
- n=7 · 3×  spec=[-2.000, -1.000, 0.000, 0.000, 0.000, 1.000, 2.000]  (Bsp.: G7-5-5, G7-5-8, G7-5-10)
- n=8 · 3×  spec=[-2.702, -2.000, -1.000, -0.000, -0.000, 1.000, 1.000, 3.702]  (Bsp.: G8-14-235, G8-14-640, G8-14-1131)
- n=8 · 3×  spec=[-2.690, -1.559, -1.000, -0.660, 0.498, 0.805, 1.000, 3.606]  (Bsp.: G8-13-588, G8-13-695, G8-13-1162)

## Q1 — Platonische Körper vs. Stabilisatorordnung

Für jeden der drei im Scaffold eingebetteten Platonischen Körper: Wie viele Katalog-Einträge sind Subgraphen davon, und was ist der mittlere log₂|Stab| (= innere Symmetrie)?

| Körper | enthält | isomorph | ⟨log₂|Stab|⟩ mit | ⟨log₂|Stab|⟩ ohne | Symm.-Ratio |
|--------|---------|----------|------------------|-------------------|-------------|
| tetrahedron (K₄) | 6316 | 1 | 1.501 | 1.322 | 1.132× |
| octahedron (K_{2,2,2}) | 986 | 1 | 2.518 | 1.318 | 2.298× |
| cube (Q₃, n=8) | 890 | 1 | 1.733 | 1.297 | 1.353× |
| dodecahedron [needs n≥20] | 0 | 0 | 0.000 | 0.000 | 0.000× |
| icosahedron [needs n≥12] | 0 | 0 | 0.000 | 0.000 | 0.000× |

_Lesart Symm.-Ratio: geometrisches Mittel der Stabilisatorordnung bei Containing vs Non-Containing. > 1 bedeutet "enthaltende Graphen sind symmetrischer"._

## Deep-dive — Was unterscheidet kospektrale Gruppen (|class| ≥ 3)?

Für jede Kospektralklasse mit ≥ 3 Mitgliedern: welche anderen Invarianten trennen die Mitglieder? Wenn die Liste leer ist, sind selbst mehrere kombinierte Invarianten blind.


**n=7, |class|=3, spec=[-2.000, -1.778, -1.000, 0.000, -0.000, 1.289, 3.489]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G7-11-107 | 11 | 2,2,3,3,3,3,6 | 5 | 16 | 2 | 3 | 3 | Y | N | 1.000 |
| G7-11-142 | 11 | 1,3,3,3,4,4,4 | 5 | 2 | 3 | 3 | 3 | Y | N | 0.697 |
| G7-11-57 | 11 | 2,2,2,4,4,4,4 | 5 | 4 | 3 | 4 | 4 | Y | N | 1.000 |

**n=7, |class|=3, spec=[-2.000, -1.000, 0.000, 0.000, 0.000, 1.000, 2.000]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G7-5-10 | 5 | 0,1,1,1,1,3,3 | 0 | 8 | ∞ | 2 | 2 | N | Y | 0.000 |
| G7-5-5 | 5 | 0,1,1,2,2,2,2 | 0 | 16 | ∞ | 2 | 2 | N | Y | 0.000 |
| G7-5-8 | 5 | 1,1,1,1,1,1,4 | 0 | 48 | ∞ | 2 | 2 | N | Y | 0.000 |

**n=8, |class|=4, spec=[-2.536, -1.393, -1.000, -0.736, 0.444, 1.000, 1.116, 3.105]**

- Unterscheidende Invarianten: `degree_sequence, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-11-433 | 11 | 1,2,2,3,3,3,3,5 | 2 | 2 | 3 | 3 | 3 | Y | N | 0.672 |
| G8-11-573 | 11 | 1,2,2,2,3,4,4,4 | 2 | 2 | 3 | 3 | 3 | Y | N | 0.683 |
| G8-11-892 | 11 | 2,2,2,2,2,3,4,5 | 2 | 2 | 3 | 3 | 3 | Y | N | 1.000 |
| G8-11-921 | 11 | 1,2,2,3,3,3,3,5 | 2 | 2 | 3 | 3 | 3 | Y | N | 0.880 |

**n=8, |class|=4, spec=[-2.000, -1.618, -1.275, -1.000, 0.300, 0.618, 1.510, 3.465]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-1249 | 12 | 2,2,2,2,2,4,4,6 | 5 | 4 | 3 | 3 | 3 | Y | N | 0.878 |
| G8-12-141 | 12 | 1,2,2,3,3,4,4,5 | 5 | 1 | 3 | 4 | 4 | Y | N | 0.735 |
| G8-12-875 | 12 | 2,2,2,2,4,4,4,4 | 5 | 4 | 4 | 4 | 4 | Y | N | 0.725 |
| G8-12-989 | 12 | 1,2,2,3,3,4,4,5 | 5 | 1 | 4 | 3 | 3 | Y | N | 0.622 |

**n=8, |class|=4, spec=[-2.296, -1.618, -1.242, -0.779, 0.420, 0.618, 1.143, 3.755]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-13-1485 | 13 | 1,2,3,3,3,4,4,6 | 6 | 2 | 3 | 4 | 4 | Y | N | 0.936 |
| G8-13-234 | 13 | 2,2,2,2,4,4,4,6 | 6 | 2 | 3 | 4 | 4 | Y | N | 1.062 |
| G8-13-267 | 13 | 1,2,2,3,4,4,5,5 | 6 | 1 | 3 | 3 | 3 | Y | N | 0.805 |
| G8-13-909 | 13 | 1,2,2,3,4,4,5,5 | 6 | 1 | 3 | 4 | 4 | Y | N | 0.885 |

**n=8, |class|=4, spec=[-2.210, -2.000, -1.476, -0.611, -0.000, 0.296, 1.508, 4.495]**

- Unterscheidende Invarianten: `degree_sequence, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-17-342 | 17 | 3,3,3,4,5,5,5,6 | 12 | 2 | 2 | 4 | 4 | Y | N | 1.884 |
| G8-17-357 | 17 | 2,3,4,5,5,5,5,5 | 12 | 2 | 3 | 4 | 4 | Y | N | 1.625 |
| G8-17-743 | 17 | 2,4,4,4,4,5,5,6 | 12 | 2 | 3 | 4 | 4 | Y | N | 1.599 |
| G8-17-953 | 17 | 2,4,4,4,4,5,5,6 | 12 | 2 | 3 | 4 | 4 | Y | N | 1.669 |

**n=8, |class|=4, spec=[-2.000, -1.000, -1.000, 0.000, 0.000, 1.000, 1.000, 2.000]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-6-12 | 6 | 0,0,2,2,2,2,2,2 | 0 | 24 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-6-38 | 6 | 1,1,1,1,1,1,3,3 | 0 | 16 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-6-46 | 6 | 1,1,1,1,2,2,2,2 | 0 | 64 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-6-56 | 6 | 0,1,1,1,2,2,2,3 | 0 | 6 | ∞ | 2 | 2 | N | Y | 0.000 |

**n=8, |class|=4, spec=[-1.935, -1.618, -1.000, 0.000, 0.000, 0.618, 1.463, 2.473]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-8-17 | 8 | 0,2,2,2,2,2,2,4 | 1 | 4 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-8-55 | 8 | 1,1,1,1,3,3,3,3 | 1 | 4 | 4 | 3 | 3 | Y | N | 0.306 |
| G8-8-64 | 8 | 0,1,2,2,2,3,3,3 | 1 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-8-86 | 8 | 1,1,1,2,2,2,3,4 | 1 | 2 | 5 | 3 | 3 | Y | N | 0.238 |

**n=8, |class|=3, spec=[-2.000, -2.000, -1.000, 0.000, -0.000, 1.000, 1.000, 3.000]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-112 | 10 | 1,1,3,3,3,3,3,3 | 2 | 24 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-464 | 10 | 0,2,2,3,3,3,3,4 | 2 | 4 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-575 | 10 | 1,1,2,2,3,3,4,4 | 2 | 4 | 4 | 3 | 3 | Y | N | 0.586 |

**n=8, |class|=3, spec=[-2.372, -1.000, -1.000, 0.000, 0.000, 0.000, 1.000, 3.372]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, max_clique_size, chromatic_number, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-118 | 10 | 1,1,1,1,3,3,3,7 | 4 | 144 | 2 | 4 | 4 | Y | N | 1.000 |
| G8-10-209 | 10 | 1,1,2,2,2,2,5,5 | 4 | 96 | ∞ | 3 | 3 | N | N | -0.000 |
| G8-10-504 | 10 | 0,0,3,3,3,3,4,4 | 4 | 32 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.000, -1.000, -1.000, -1.000, -0.000, -0.000, 2.000, 3.000]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, max_clique_size, chromatic_number`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-137 | 10 | 0,2,2,3,3,3,3,4 | 4 | 8 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-268 | 10 | 2,2,2,2,3,3,3,3 | 4 | 192 | ∞ | 4 | 4 | N | N | 0.000 |
| G8-10-9 | 10 | 2,2,2,2,2,2,4,4 | 4 | 72 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.458, -1.414, -0.870, -0.000, -0.000, 0.310, 1.414, 3.018]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-180 | 10 | 1,2,2,2,2,2,3,6 | 2 | 4 | 3 | 3 | 3 | Y | N | 0.703 |
| G8-10-403 | 10 | 0,2,2,2,3,3,4,4 | 2 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-487 | 10 | 1,1,1,3,3,3,4,4 | 2 | 4 | 4 | 3 | 3 | Y | N | 0.530 |

**n=8, |class|=3, spec=[-2.460, -1.381, -1.000, 0.000, 0.000, 0.766, 1.000, 3.075]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-19 | 10 | 0,2,2,2,3,3,3,5 | 2 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-465 | 10 | 0,2,2,2,2,4,4,4 | 2 | 4 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-473 | 10 | 1,1,1,2,3,4,4,4 | 2 | 2 | 4 | 3 | 3 | Y | N | 0.697 |

**n=8, |class|=3, spec=[-2.179, -1.566, -1.000, 0.000, 0.000, 0.197, 1.433, 3.116]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-279 | 10 | 0,2,2,2,3,3,4,4 | 3 | 1 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-323 | 10 | 0,1,3,3,3,3,3,4 | 3 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-58 | 10 | 1,2,2,2,2,2,4,5 | 3 | 6 | 4 | 3 | 3 | Y | N | 0.277 |

**n=8, |class|=3, spec=[-2.000, -1.842, -1.000, -0.507, 0.000, 1.000, 1.507, 2.842]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-302 | 10 | 1,2,2,2,3,3,3,4 | 2 | 1 | 3 | 3 | 3 | Y | N | 0.594 |
| G8-10-346 | 10 | 1,1,3,3,3,3,3,3 | 2 | 4 | 3 | 3 | 3 | Y | N | 0.657 |
| G8-10-595 | 10 | 2,2,2,2,2,2,4,4 | 2 | 4 | 3 | 3 | 3 | Y | N | 0.657 |

**n=8, |class|=3, spec=[-2.000, -1.681, -1.000, 0.000, -0.000, 0.358, 1.000, 3.323]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, max_clique_size, chromatic_number, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-364 | 10 | 1,1,1,1,3,3,5,5 | 4 | 16 | 3 | 4 | 4 | Y | N | 0.628 |
| G8-10-377 | 10 | 0,1,2,2,3,3,3,6 | 4 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-388 | 10 | 1,1,1,3,3,3,3,5 | 4 | 16 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.294, -1.728, -0.754, 0.000, -0.000, 0.299, 1.505, 2.971]**

- Unterscheidende Invarianten: `degree_sequence, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-412 | 10 | 1,1,2,3,3,3,3,4 | 2 | 4 | 4 | 3 | 3 | Y | N | 0.351 |
| G8-10-476 | 10 | 1,2,2,2,2,2,4,5 | 2 | 4 | 4 | 3 | 3 | Y | N | 0.555 |
| G8-10-484 | 10 | 1,1,2,2,2,4,4,4 | 2 | 4 | 3 | 3 | 3 | Y | N | 0.567 |

**n=8, |class|=3, spec=[-2.296, -1.723, -0.854, 0.000, 0.000, 0.664, 1.176, 3.034]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-10-472 | 10 | 1,1,2,2,3,3,4,4 | 2 | 2 | 4 | 3 | 3 | Y | N | 0.404 |
| G8-10-543 | 10 | 0,2,2,3,3,3,3,4 | 2 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-10-630 | 10 | 1,1,2,2,2,3,4,5 | 2 | 1 | 3 | 3 | 3 | Y | N | 0.722 |

**n=8, |class|=3, spec=[-2.510, -1.369, -1.125, 0.000, 0.000, 0.540, 1.160, 3.305]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-11-201 | 11 | 1,1,2,3,3,3,4,5 | 3 | 2 | 4 | 3 | 3 | Y | N | 0.656 |
| G8-11-697 | 11 | 0,2,3,3,3,3,3,5 | 3 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-11-776 | 11 | 0,2,2,3,3,4,4,4 | 3 | 1 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.250, -1.708, -1.000, 0.000, -0.000, 0.532, 1.000, 3.426]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-11-355 | 11 | 1,1,2,2,3,3,3,7 | 4 | 4 | 2 | 3 | 3 | Y | N | 1.000 |
| G8-11-560 | 11 | 1,1,1,3,3,4,4,5 | 4 | 4 | 4 | 3 | 3 | Y | N | 0.697 |
| G8-11-703 | 11 | 0,2,2,2,3,4,4,5 | 4 | 2 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.000, -1.778, -1.000, 0.000, -0.000, 0.000, 1.289, 3.489]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, max_clique_size, chromatic_number`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-11-449 | 11 | 0,2,2,3,3,3,3,6 | 5 | 16 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-11-66 | 11 | 0,1,3,3,3,4,4,4 | 5 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-11-702 | 11 | 0,2,2,2,4,4,4,4 | 5 | 4 | ∞ | 4 | 4 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.201, -1.547, -1.000, -0.661, -0.000, 1.000, 1.063, 3.346]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-11-541 | 11 | 1,1,2,2,3,3,5,5 | 4 | 4 | 3 | 3 | 3 | Y | N | 0.776 |
| G8-11-878 | 11 | 0,2,3,3,3,3,3,5 | 4 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-11-891 | 11 | 1,1,2,3,3,3,4,5 | 4 | 2 | 4 | 3 | 3 | Y | N | 0.586 |

**n=8, |class|=3, spec=[-1.828, -1.618, -1.618, 0.000, -0.000, 0.618, 0.618, 3.828]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-1004 | 12 | 0,2,2,2,3,5,5,5 | 7 | 6 | ∞ | 4 | 4 | N | N | 0.000 |
| G8-12-1254 | 12 | 0,2,2,2,4,4,4,6 | 7 | 6 | ∞ | 4 | 4 | N | N | 0.000 |
| G8-12-642 | 12 | 1,1,1,3,3,5,5,5 | 7 | 12 | 3 | 4 | 4 | Y | N | 0.807 |

**n=8, |class|=3, spec=[-1.970, -1.667, -1.000, -1.000, 0.125, 0.476, 1.420, 3.617]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-1120 | 12 | 1,1,3,3,3,3,5,5 | 6 | 2 | 4 | 4 | 4 | Y | N | 0.598 |
| G8-12-1160 | 12 | 1,2,2,2,3,3,5,6 | 6 | 4 | 3 | 4 | 4 | Y | N | 0.753 |
| G8-12-712 | 12 | 1,2,2,3,3,4,4,5 | 6 | 1 | 4 | 4 | 4 | Y | N | 0.369 |

**n=8, |class|=3, spec=[-2.532, -1.618, -1.000, -0.663, 0.542, 0.618, 1.319, 3.334]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-1209 | 12 | 1,3,3,3,3,3,3,5 | 3 | 2 | 3 | 3 | 3 | Y | N | 0.672 |
| G8-12-650 | 12 | 2,2,2,2,4,4,4,4 | 3 | 4 | 3 | 3 | 3 | Y | N | 1.000 |
| G8-12-833 | 12 | 1,2,3,3,3,4,4,4 | 3 | 2 | 3 | 3 | 3 | Y | N | 0.683 |

**n=8, |class|=3, spec=[-2.511, -1.618, -1.251, -0.000, -0.000, 0.618, 1.435, 3.327]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-1260 | 12 | 1,3,3,3,3,3,3,5 | 3 | 2 | 3 | 3 | 3 | Y | N | 0.642 |
| G8-12-382 | 12 | 1,2,3,3,3,4,4,4 | 3 | 1 | 3 | 3 | 3 | Y | N | 0.657 |
| G8-12-474 | 12 | 2,2,2,2,4,4,4,4 | 3 | 1 | 3 | 3 | 3 | Y | N | 0.927 |

**n=8, |class|=3, spec=[-2.247, -1.596, -1.167, -0.555, -0.000, 0.802, 1.209, 3.554]**

- Unterscheidende Invarianten: `degree_sequence, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-179 | 12 | 1,2,2,2,3,4,4,6 | 5 | 2 | 3 | 3 | 3 | Y | N | 0.817 |
| G8-12-270 | 12 | 1,1,2,4,4,4,4,4 | 5 | 2 | 3 | 3 | 3 | Y | N | 0.751 |
| G8-12-446 | 12 | 0,2,3,3,4,4,4,4 | 5 | 2 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.593, -1.527, -1.000, 0.000, 0.000, 0.569, 1.000, 3.552]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-211 | 12 | 0,3,3,3,3,3,4,5 | 4 | 2 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-12-371 | 12 | 0,2,3,3,4,4,4,4 | 4 | 4 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-12-761 | 12 | 1,1,2,4,4,4,4,4 | 4 | 4 | 4 | 3 | 3 | Y | N | 0.697 |

**n=8, |class|=3, spec=[-2.376, -1.618, -1.377, -0.517, 0.469, 0.618, 1.550, 3.250]**

- Unterscheidende Invarianten: `degree_sequence, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-12-487 | 12 | 1,3,3,3,3,3,3,5 | 3 | 2 | 3 | 3 | 3 | Y | N | 0.880 |
| G8-12-935 | 12 | 2,2,2,3,3,3,4,5 | 3 | 2 | 3 | 3 | 3 | Y | N | 1.163 |
| G8-12-982 | 12 | 2,2,2,2,4,4,4,4 | 3 | 2 | 3 | 3 | 3 | Y | N | 1.228 |

**n=8, |class|=3, spec=[-2.690, -1.559, -1.000, -0.660, 0.498, 0.805, 1.000, 3.606]**

- Unterscheidende Invarianten: `degree_sequence, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-13-1162 | 13 | 2,2,2,3,3,4,5,5 | 4 | 2 | 3 | 3 | 3 | Y | N | 1.382 |
| G8-13-588 | 13 | 1,2,3,3,4,4,4,5 | 4 | 2 | 3 | 3 | 3 | Y | N | 0.901 |
| G8-13-695 | 13 | 1,3,3,3,3,3,5,5 | 4 | 2 | 3 | 3 | 3 | Y | N | 0.909 |

**n=8, |class|=3, spec=[-2.000, -2.000, -1.000, -1.000, 0.268, 1.000, 1.000, 3.732]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-13-1431 | 13 | 1,3,3,3,3,3,3,7 | 6 | 12 | 2 | 3 | 3 | Y | N | 1.000 |
| G8-13-286 | 13 | 2,2,2,3,3,3,4,7 | 6 | 6 | 2 | 3 | 3 | Y | N | 1.382 |
| G8-13-37 | 13 | 1,2,2,3,4,4,5,5 | 6 | 2 | 3 | 3 | 3 | Y | N | 0.888 |

**n=8, |class|=3, spec=[-2.212, -1.403, -1.000, -1.000, 0.000, 0.650, 1.000, 3.964]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-13-237 | 13 | 1,1,2,4,4,4,5,5 | 8 | 4 | 4 | 4 | 4 | Y | N | 0.697 |
| G8-13-473 | 13 | 1,1,3,3,3,3,5,7 | 8 | 16 | 2 | 4 | 4 | Y | N | 1.000 |
| G8-13-492 | 13 | 0,2,3,3,4,4,5,5 | 8 | 4 | ∞ | 4 | 4 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.201, -2.000, -1.000, -1.000, 0.000, 1.000, 1.455, 3.747]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-14-1005 | 14 | 2,2,4,4,4,4,4,4 | 6 | 16 | 2 | 4 | 4 | Y | N | 1.438 |
| G8-14-1299 | 14 | 2,3,3,3,4,4,4,5 | 6 | 2 | 3 | 3 | 3 | Y | N | 1.273 |
| G8-14-686 | 14 | 2,3,3,3,4,4,4,5 | 6 | 2 | 3 | 4 | 4 | Y | N | 1.438 |

**n=8, |class|=3, spec=[-2.502, -1.840, -1.000, -0.742, 0.346, 0.877, 1.000, 3.862]**

- Unterscheidende Invarianten: `degree_sequence, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-14-1072 | 14 | 2,2,2,3,4,5,5,5 | 6 | 2 | 2 | 3 | 3 | Y | N | 1.697 |
| G8-14-1366 | 14 | 2,2,2,4,4,4,4,6 | 6 | 2 | 2 | 3 | 3 | Y | N | 1.586 |
| G8-14-522 | 14 | 1,3,3,3,4,4,4,6 | 6 | 2 | 3 | 3 | 3 | Y | N | 0.963 |

**n=8, |class|=3, spec=[-2.702, -2.000, -1.000, -0.000, -0.000, 1.000, 1.000, 3.702]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-14-1131 | 14 | 3,3,3,3,3,3,5,5 | 4 | 16 | 2 | 3 | 3 | Y | N | 2.000 |
| G8-14-235 | 14 | 2,3,3,3,4,4,4,5 | 4 | 2 | 3 | 3 | 3 | Y | N | 1.609 |
| G8-14-640 | 14 | 2,2,4,4,4,4,4,4 | 4 | 8 | 3 | 3 | 3 | Y | N | 1.438 |

**n=8, |class|=3, spec=[-2.143, -1.618, -1.367, -1.000, 0.274, 0.618, 1.248, 3.988]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-14-1291 | 14 | 2,2,2,3,3,4,6,6 | 8 | 4 | 2 | 4 | 4 | Y | N | 1.523 |
| G8-14-1448 | 14 | 2,2,2,4,4,4,5,5 | 8 | 4 | 3 | 4 | 4 | Y | N | 1.034 |
| G8-14-452 | 14 | 1,2,3,3,4,5,5,5 | 8 | 1 | 3 | 4 | 4 | Y | N | 0.877 |

**n=8, |class|=3, spec=[-2.000, -1.921, -1.000, -1.000, 0.000, 0.315, 1.685, 3.921]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-14-1437 | 14 | 1,3,3,3,3,5,5,5 | 8 | 4 | 3 | 4 | 4 | Y | N | 0.872 |
| G8-14-309 | 14 | 1,3,3,4,4,4,4,5 | 8 | 2 | 4 | 4 | 4 | Y | N | 0.644 |
| G8-14-932 | 14 | 2,2,3,3,4,4,5,5 | 8 | 8 | 3 | 4 | 4 | Y | N | 0.897 |

**n=8, |class|=3, spec=[-2.000, -1.901, -1.477, -0.483, 0.000, 0.571, 1.292, 3.997]**

- Unterscheidende Invarianten: `degree_sequence, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-14-1445 | 14 | 1,3,3,3,4,4,4,6 | 8 | 2 | 3 | 4 | 4 | Y | N | 0.678 |
| G8-14-25 | 14 | 2,2,2,3,4,5,5,5 | 8 | 2 | 3 | 4 | 4 | Y | N | 1.026 |
| G8-14-403 | 14 | 1,3,3,3,3,5,5,5 | 8 | 2 | 3 | 4 | 4 | Y | N | 0.684 |

**n=8, |class|=3, spec=[-2.000, -2.000, -1.000, -1.000, 0.000, 1.000, 1.000, 4.000]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-14-241 | 14 | 1,2,3,4,4,4,5,5 | 8 | 2 | 3 | 4 | 4 | Y | N | 0.885 |
| G8-14-268 | 14 | 2,2,2,2,5,5,5,5 | 8 | 8 | 3 | 4 | 4 | Y | N | 1.551 |
| G8-14-930 | 14 | 2,2,3,3,3,3,6,6 | 8 | 16 | 2 | 4 | 4 | Y | N | 1.172 |

**n=8, |class|=3, spec=[-2.557, -1.859, -1.000, -0.513, -0.000, 0.793, 1.000, 4.137]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-15-1164 | 15 | 2,2,3,4,4,4,5,6 | 8 | 2 | 2 | 4 | 4 | Y | N | 1.565 |
| G8-15-1336 | 15 | 2,3,3,3,3,4,5,7 | 8 | 2 | 2 | 3 | 3 | Y | N | 1.846 |
| G8-15-824 | 15 | 1,3,3,4,4,5,5,5 | 8 | 4 | 3 | 3 | 3 | Y | N | 0.910 |

**n=8, |class|=3, spec=[-2.000, -1.850, -1.635, -0.588, -0.000, 0.333, 1.651, 4.089]**

- Unterscheidende Invarianten: `degree_sequence, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-15-1443 | 15 | 2,3,3,3,4,4,5,6 | 9 | 2 | 3 | 4 | 4 | Y | N | 1.189 |
| G8-15-422 | 15 | 2,2,4,4,4,4,4,6 | 9 | 2 | 3 | 4 | 4 | Y | N | 1.230 |
| G8-15-898 | 15 | 2,2,3,4,4,5,5,5 | 9 | 2 | 3 | 4 | 4 | Y | N | 1.246 |

**n=8, |class|=3, spec=[-2.484, -1.618, -1.580, -0.644, 0.000, 0.618, 1.507, 4.201]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-16-1000 | 16 | 3,3,3,3,5,5,5,5 | 9 | 4 | 2 | 3 | 4 | Y | N | 1.836 |
| G8-16-18 | 16 | 3,3,3,4,4,4,5,6 | 9 | 2 | 2 | 3 | 4 | Y | N | 1.884 |
| G8-16-450 | 16 | 2,4,4,4,4,4,4,6 | 9 | 2 | 3 | 3 | 4 | Y | N | 1.599 |

**n=8, |class|=3, spec=[-2.000, -1.862, -1.473, -1.000, 0.000, 0.424, 1.592, 4.319]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-16-1119 | 16 | 3,3,3,3,3,5,6,6 | 11 | 4 | 2 | 4 | 4 | Y | N | 1.667 |
| G8-16-1125 | 16 | 2,3,4,4,4,4,4,7 | 11 | 2 | 2 | 4 | 4 | Y | N | 1.586 |
| G8-16-835 | 16 | 3,3,3,3,4,4,5,7 | 11 | 4 | 2 | 4 | 4 | Y | N | 1.609 |

**n=8, |class|=3, spec=[-2.558, -1.618, -1.530, -0.679, 0.288, 0.618, 1.229, 4.250]**

- Unterscheidende Invarianten: `degree_sequence, diameter, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-16-1163 | 16 | 2,4,4,4,4,4,4,6 | 9 | 2 | 3 | 4 | 4 | Y | N | 1.669 |
| G8-16-1194 | 16 | 2,3,4,4,4,5,5,5 | 9 | 2 | 3 | 4 | 4 | Y | N | 1.625 |
| G8-16-413 | 16 | 3,3,3,3,5,5,5,5 | 9 | 2 | 2 | 4 | 4 | Y | N | 2.027 |

**n=8, |class|=3, spec=[-2.518, -1.618, -1.344, -1.000, 0.191, 0.618, 1.468, 4.202]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-16-1209 | 16 | 2,4,4,4,4,4,4,6 | 9 | 2 | 2 | 4 | 4 | Y | N | 1.642 |
| G8-16-606 | 16 | 3,3,3,4,4,4,5,6 | 9 | 1 | 2 | 4 | 4 | Y | N | 1.864 |
| G8-16-628 | 16 | 3,3,3,3,5,5,5,5 | 9 | 1 | 2 | 4 | 4 | Y | N | 1.927 |

**n=8, |class|=3, spec=[-2.000, -1.618, -1.618, -1.000, 0.438, 0.618, 0.618, 4.562]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-16-20 | 16 | 2,2,2,4,5,5,5,7 | 13 | 6 | 2 | 5 | 5 | Y | N | 1.764 |
| G8-16-262 | 16 | 2,2,2,4,4,6,6,6 | 13 | 12 | 2 | 5 | 5 | Y | N | 1.807 |
| G8-16-289 | 16 | 1,3,3,3,5,5,5,7 | 13 | 6 | 2 | 4 | 4 | Y | N | 1.000 |

**n=8, |class|=3, spec=[-2.192, -1.719, -1.487, -1.000, 0.099, 0.268, 1.474, 4.558]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-17-497 | 17 | 2,3,4,4,4,5,6,6 | 13 | 2 | 2 | 4 | 4 | Y | N | 1.758 |
| G8-17-55 | 17 | 3,3,3,4,4,5,5,7 | 13 | 1 | 2 | 4 | 4 | Y | N | 1.864 |
| G8-17-975 | 17 | 2,4,4,4,4,4,5,7 | 13 | 2 | 2 | 4 | 4 | Y | N | 1.667 |

**n=8, |class|=3, spec=[-2.000, -1.805, -1.596, -1.000, 0.000, 0.211, 1.364, 4.826]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-18-292 | 18 | 2,4,4,4,5,5,5,7 | 16 | 2 | 2 | 4 | 4 | Y | N | 1.697 |
| G8-18-38 | 18 | 3,3,3,5,5,5,5,7 | 16 | 4 | 2 | 5 | 5 | Y | N | 2.000 |
| G8-18-509 | 18 | 3,3,3,4,5,6,6,6 | 16 | 2 | 2 | 5 | 5 | Y | N | 2.016 |

**n=8, |class|=3, spec=[-2.000, -2.000, -1.702, -1.000, 0.000, 1.000, 1.000, 4.702]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-18-308 | 18 | 3,3,4,4,5,5,6,6 | 14 | 4 | 2 | 4 | 4 | Y | N | 2.586 |
| G8-18-617 | 18 | 3,3,5,5,5,5,5,5 | 14 | 8 | 2 | 4 | 4 | Y | N | 2.438 |
| G8-18-91 | 18 | 3,4,4,4,4,5,5,7 | 14 | 4 | 2 | 4 | 4 | Y | N | 2.586 |

**n=8, |class|=3, spec=[-2.249, -2.000, -1.380, -1.000, 0.000, 0.192, 1.310, 5.127]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-20-117 | 20 | 4,4,5,5,5,5,5,7 | 19 | 4 | 2 | 5 | 5 | Y | N | 3.139 |
| G8-20-6 | 20 | 4,4,4,5,5,6,6,6 | 19 | 2 | 2 | 5 | 5 | Y | N | 2.934 |
| G8-20-85 | 20 | 3,5,5,5,5,5,6,6 | 19 | 4 | 2 | 4 | 4 | Y | N | 2.639 |

**n=8, |class|=3, spec=[-2.545, -1.618, -1.458, -1.000, 0.000, 0.618, 0.835, 5.168]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, max_clique_size, chromatic_number, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-20-129 | 20 | 4,4,4,5,5,5,6,7 | 19 | 2 | 2 | 5 | 5 | Y | N | 3.586 |
| G8-20-182 | 20 | 4,4,4,4,6,6,6,6 | 19 | 4 | 2 | 5 | 5 | Y | N | 3.306 |
| G8-20-44 | 20 | 3,5,5,5,5,5,5,7 | 19 | 4 | 2 | 4 | 4 | Y | N | 2.836 |

**n=8, |class|=3, spec=[-2.000, -1.000, 0.000, 0.000, 0.000, 0.000, 1.000, 2.000]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-5-10 | 5 | 0,0,1,1,1,1,3,3 | 0 | 16 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-5-11 | 5 | 0,1,1,1,1,1,1,4 | 0 | 48 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-5-13 | 5 | 0,0,1,1,2,2,2,2 | 0 | 32 | ∞ | 2 | 2 | N | Y | 0.000 |

**n=8, |class|=3, spec=[-2.000, -1.414, 0.000, 0.000, 0.000, 0.000, 1.414, 2.000]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-6-26 | 6 | 1,1,1,1,1,1,2,4 | 0 | 48 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-6-29 | 6 | 0,1,1,2,2,2,2,2 | 0 | 16 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-6-52 | 6 | 0,1,1,1,1,2,3,3 | 0 | 8 | ∞ | 2 | 2 | N | Y | 0.000 |

**n=8, |class|=3, spec=[-2.358, -1.199, -1.000, 0.000, -0.000, 1.000, 1.199, 2.358]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-8-106 | 8 | 1,1,2,2,2,2,2,4 | 0 | 4 | 4 | 2 | 2 | Y | Y | 0.382 |
| G8-8-122 | 8 | 0,2,2,2,2,2,3,3 | 0 | 4 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-8-160 | 8 | 1,1,1,2,2,3,3,3 | 0 | 2 | 4 | 2 | 2 | Y | Y | 0.364 |

**n=8, |class|=3, spec=[-2.449, -1.414, 0.000, -0.000, 0.000, -0.000, 1.414, 2.449]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-8-127 | 8 | 0,2,2,2,2,2,2,4 | 0 | 8 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-8-197 | 8 | 1,1,2,2,2,2,3,3 | 0 | 24 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-8-68 | 8 | 1,1,1,1,2,2,4,4 | 0 | 16 | 4 | 2 | 2 | Y | Y | 0.438 |

**n=8, |class|=3, spec=[-2.000, -1.343, -1.000, 0.000, 0.000, 0.529, 1.000, 2.814]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-8-27 | 8 | 0,0,2,2,2,3,3,4 | 2 | 4 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-8-74 | 8 | 1,1,1,1,2,2,3,5 | 2 | 8 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-8-79 | 8 | 0,1,1,1,3,3,3,4 | 2 | 2 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.646, -1.000, -1.000, -0.000, -0.000, 1.000, 1.000, 2.646]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-9-108 | 9 | 1,1,2,2,2,2,3,5 | 0 | 4 | 3 | 2 | 2 | Y | Y | 0.772 |
| G8-9-202 | 9 | 0,2,2,2,3,3,3,3 | 0 | 6 | ∞ | 2 | 2 | N | Y | 0.000 |
| G8-9-401 | 9 | 1,1,1,3,3,3,3,3 | 0 | 12 | 4 | 2 | 2 | Y | Y | 0.586 |

**n=8, |class|=3, spec=[-2.177, -1.414, -1.000, 0.000, -0.000, 0.322, 1.414, 2.856]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-9-292 | 9 | 1,1,1,1,3,3,4,4 | 2 | 16 | 4 | 3 | 3 | Y | N | 0.438 |
| G8-9-32 | 9 | 1,1,1,2,2,3,3,5 | 2 | 4 | 3 | 3 | 3 | Y | N | 0.374 |
| G8-9-65 | 9 | 1,1,2,2,3,3,3,3 | 2 | 8 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.125, -1.000, -1.000, -1.000, 0.000, 1.000, 1.363, 2.762]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-9-298 | 9 | 1,1,2,2,2,3,3,4 | 2 | 4 | 4 | 3 | 3 | Y | N | 0.382 |
| G8-9-37 | 9 | 1,1,2,2,2,2,3,5 | 2 | 16 | 3 | 3 | 3 | Y | N | 0.374 |
| G8-9-73 | 9 | 0,2,2,2,3,3,3,3 | 2 | 4 | ∞ | 3 | 3 | N | N | 0.000 |

**n=8, |class|=3, spec=[-2.000, -1.618, -1.115, 0.000, 0.000, 0.618, 1.254, 2.861]**

- Unterscheidende Invarianten: `degree_sequence, stabilizer_order, diameter, is_connected, algebraic_connectivity`
| id | m | degs | Δ | |Stab| | diam | ω | χ | conn | bip | λ₂ |
|----|---|------|---|--------|------|---|---|------|-----|----|
| G8-9-322 | 9 | 0,2,2,2,2,2,4,4 | 2 | 4 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-9-324 | 9 | 0,1,2,2,3,3,3,4 | 2 | 1 | ∞ | 3 | 3 | N | N | 0.000 |
| G8-9-329 | 9 | 1,1,1,2,2,3,4,4 | 2 | 2 | 4 | 3 | 3 | Y | N | 0.364 |

## Q7 — Metatron-Scaffold-Kantenabdeckung

_Wie stark ‚nutzen' die kanonischen Repräsentanten die beiden Kantenklassen des Scaffolds in der aktiven Zone (Zentrum-Strahlen & Hexagon-Ring)?_

| n | Graphen | distinkte Signaturen | ⟨Strahlen⟩ | ⟨Ring⟩ |
|---|---------|---------------------|-------------|---------|
| 1 | 1 | 1 | 0.000 | 0.000 |
| 2 | 2 | 2 | 0.500 | 0.000 |
| 3 | 4 | 4 | 1.250 | 0.250 |
| 4 | 11 | 8 | 2.000 | 0.727 |
| 5 | 34 | 14 | 2.824 | 1.235 |
| 6 | 156 | 22 | 3.538 | 1.731 |
| 7 | 1044 | 36 | 4.216 | 2.745 |
| 8 | 12346 | 48 | 3.904 | 3.404 |

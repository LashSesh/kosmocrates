//! Integration tests for the Periodic Table catalog generator.
//!
//! These exercise the cross-module pipeline:
//!   bitgraph -> properties -> scan_canonical_bits -> catalog::build_catalog
//! and verify the central correctness claims of `periodensystem_graphen.tex`:
//!   • OEIS A000088 counts per n
//!   • Orbit-Stabilizer theorem on every entry
//!   • tr(A^2) = 2m, tr(A^3) = 6Δ
//!   • Complement involution
//!   • Spec'd self-complementary graphs (single node, P4, C5)
//!
//! `n = 7` (1044 graphs, ~5–10 min depending on hardware) is gated behind
//! `#[ignore]` to keep CI fast; run with `cargo test --release -- --ignored`.

use metatron_scan::catalog::{build_catalog, oeis_a000088, verify};

#[test]
fn catalog_n3_matches_spec() {
    let table = build_catalog(3).unwrap();
    assert_eq!(table.entries.len(), 1 + 2 + 4); // 7
    assert_eq!(table.stats.count_per_n[&3], 4);

    // The four graphs on 3 nodes per the TeX spec, table at line 612.
    let n3: Vec<_> = table.entries.iter().filter(|e| e.n == 3).collect();
    let edges: Vec<usize> = n3.iter().map(|e| e.m).collect();
    assert_eq!(edges, vec![0, 1, 2, 3]);

    // K3 (n=3, m=3) has stabilizer S_3 → |Stab| = 6 over S_3, but in S_7 the
    // stabilizer is 6 * 4! = 144 (S_3 on the K3 vertices times S_4 on the
    // rest). Orbit = 5040 / 144 = 35.
    let k3 = n3.iter().find(|e| e.m == 3).unwrap();
    assert_eq!(k3.report.orbit_size * k3.report.stabilizer_order, 5040);
    assert_eq!(k3.report.triangle_count, 1);
}

#[test]
fn catalog_n4_self_complementary_count() {
    let table = build_catalog(4).unwrap();
    assert_eq!(table.entries.len(), 18);
    // n=1 single node (trivially self-complementary in 1-node sense) + P4.
    assert_eq!(table.stats.self_complementary_count, 2);

    // P4 must appear and be marked self-complementary.
    let p4 = table
        .entries
        .iter()
        .find(|e| e.n == 4 && e.report.properties.is_self_complementary)
        .expect("P4 not found");
    assert_eq!(p4.m, 3);
    assert_eq!(p4.report.properties.degree_sequence, vec![1, 1, 2, 2]);
    assert!(p4.report.properties.is_tree);
}

#[test]
fn catalog_n5_includes_c5_self_complementary() {
    let table = build_catalog(5).unwrap();
    assert_eq!(table.stats.count_per_n[&5], 34);

    // Two self-complementary 5-node graphs exist (C5 and the "bull-like" pair).
    let n5_self_comp = table
        .entries
        .iter()
        .filter(|e| e.n == 5 && e.report.properties.is_self_complementary)
        .count();
    assert_eq!(n5_self_comp, 2);

    // Verify the catalog as a whole.
    verify::verify_table(&table).unwrap();
}

#[test]
fn catalog_n6_full_oeis_match() {
    let table = build_catalog(6).unwrap();
    // Cumulative: 1+2+4+11+34+156 = 208
    assert_eq!(table.entries.len(), 208);
    for n in 1..=6 {
        assert_eq!(
            table.stats.count_per_n[&n],
            oeis_a000088(n).unwrap(),
            "n={}",
            n
        );
    }

    // Exactly 8 asymmetric graphs (|Stab|=1) on 6 vertices (OEIS A003400).
    let n6_asym = table
        .entries
        .iter()
        .filter(|e| e.n == 6 && e.report.stabilizer_order == 1)
        .count();
    assert_eq!(n6_asym, 8);

    verify::verify_table(&table).unwrap();
}

#[test]
fn complement_involution_holds_for_all_n6() {
    let table = build_catalog(6).unwrap();
    for e in &table.entries {
        let comp_id = e.complement_id.as_ref().expect("complement_id missing");
        let comp = table
            .entries
            .iter()
            .find(|x| &x.id == comp_id)
            .expect("complement entry missing");
        assert_eq!(comp.complement_id.as_deref(), Some(e.id.as_str()));
        // Complement of complement is self-isomorphic → same n.
        assert_eq!(e.n, comp.n);
        // Edge counts complement to maximum: m + m_bar = C(n,2)
        assert_eq!(e.m + comp.m, e.n * (e.n - 1) / 2);
    }
}

#[test]
fn catalog_ids_are_systematic_and_unique() {
    let table = build_catalog(5).unwrap();
    let mut by_class = std::collections::HashMap::<(usize, usize), Vec<usize>>::new();
    for e in &table.entries {
        by_class
            .entry((e.n, e.m))
            .or_default()
            .push(e.index_in_class);
    }
    for ((_n, _m), indices) in &by_class {
        let mut sorted = indices.clone();
        sorted.sort();
        // Indices must be 1..=k with no gaps.
        for (i, &idx) in sorted.iter().enumerate() {
            assert_eq!(idx, i + 1);
        }
    }
}

#[test]
fn catalog_a2_a3_traces_match_spec() {
    let table = build_catalog(5).unwrap();
    for e in &table.entries {
        // tr(A^2) = 2m
        assert!(
            (e.report.a2_trace - 2.0 * e.m as f64).abs() < 1e-6,
            "tr(A^2)={} but 2m={} for {}",
            e.report.a2_trace,
            2 * e.m,
            e.id
        );
        // tr(A^3) = 6 * triangles
        assert!(
            (e.report.a3_trace - 6.0 * e.report.triangle_count as f64).abs() < 1e-6,
            "tr(A^3)={} but 6Δ={} for {}",
            e.report.a3_trace,
            6 * e.report.triangle_count,
            e.id
        );
    }
}

/// Full catalog including n=7. ~5–10 minutes in release mode.
/// Run with: `cargo test --release -- --ignored full_periodic_table`.
#[test]
#[ignore]
fn full_periodic_table_n7() {
    let table = build_catalog(7).unwrap();
    assert_eq!(table.entries.len(), 1252);
    assert_eq!(table.stats.count_per_n[&7], 1044);
    // OEIS A003400: 152 asymmetric graphs on 7 vertices.
    let n7_asym = table
        .entries
        .iter()
        .filter(|e| e.n == 7 && e.report.stabilizer_order == 1)
        .count();
    assert_eq!(n7_asym, 152);
    // OEIS A000171: no self-complementary graphs on 6 vertices,
    // so total for n ≤ 7 is the same as for n ≤ 5: 4 (single node + P4 + 2x for n=5).
    assert_eq!(table.stats.self_complementary_count, 4);
    verify::verify_table(&table).unwrap();
}

/// Full catalog up to n=8 via orderly generation. ~8 minutes release mode.
/// Run with: `cargo test --release -- --ignored full_periodic_table_n8`.
#[test]
#[ignore]
fn full_periodic_table_n8() {
    let table = build_catalog(8).unwrap();
    // OEIS A000088: 1 + 2 + 4 + 11 + 34 + 156 + 1044 + 12346 = 13598
    assert_eq!(table.entries.len(), 13598);
    assert_eq!(table.stats.count_per_n[&8], 12346);

    // OEIS A003400 (asymmetric) for n=1..8: 0+0+0+0+0+8+152+3696 = 3856.
    assert_eq!(table.stats.asymmetric_count, 3856);

    // OEIS A000171 (self-complementary) for n=1..8: 1+0+0+1+2+0+0+10 = 14.
    assert_eq!(table.stats.self_complementary_count, 14);

    // Max stabilizer now reaches 8! = 40320 (empty graph + K_8).
    assert_eq!(table.stats.max_stabilizer_order, 40320);

    verify::verify_table(&table).unwrap();
}

/// Orderly canonicity count — fast sanity that build_catalog_orderly
/// matches OEIS for each n.
#[test]
fn orderly_generation_matches_oeis_up_to_n6() {
    use metatron_scan::catalog::{build_catalog_orderly, oeis_a000088};
    for n in 1..=6 {
        let raw = build_catalog_orderly(n).unwrap();
        assert_eq!(raw.len(), oeis_a000088(n).unwrap(), "n={}", n);
    }
}

#[test]
fn threshold_count_matches_oeis_a005840_up_to_n6() {
    use metatron_scan::catalog::oeis_a005840;
    let table = build_catalog(6).unwrap();
    for n in 1..=6 {
        let expected = oeis_a005840(n).unwrap();
        let got = table.stats.threshold_per_n.get(&n).copied().unwrap_or(0);
        assert_eq!(got, expected, "threshold count at n={}", n);
    }
}

#[test]
fn planar_count_matches_oeis_a005470_up_to_n6() {
    use metatron_scan::catalog::oeis_a005470;
    let table = build_catalog(6).unwrap();
    for n in 1..=6 {
        let expected = oeis_a005470(n).unwrap();
        let got = table.stats.planar_per_n.get(&n).copied().unwrap_or(0);
        assert_eq!(got, expected, "planar count at n={}", n);
    }
}

#[test]
fn spanning_tree_sanity() {
    // Matrix-Tree theorem sanity:
    //   trees → τ = 1
    //   cycle C_n → τ = n
    //   K_n → τ = n^(n-2)
    //   disconnected → τ = 0
    let table = build_catalog(5).unwrap();

    // Every tree must have τ = 1.
    for e in &table.entries {
        if e.report.properties.is_tree {
            assert_eq!(e.report.spanning_tree_count, 1, "{}", e.id);
        }
        if !e.report.properties.connected {
            assert_eq!(e.report.spanning_tree_count, 0, "{}", e.id);
        }
    }
    // K_5 has 5^3 = 125 spanning trees (Cayley's formula).
    let k5 = table
        .entries
        .iter()
        .find(|e| e.n == 5 && e.m == 10)
        .expect("K_5 missing");
    assert_eq!(k5.report.spanning_tree_count, 125);
    // C_5 has 5 spanning trees.
    let c5 = table
        .entries
        .iter()
        .find(|e| e.n == 5 && e.m == 5 && e.report.properties.degree_sequence == vec![2, 2, 2, 2, 2])
        .expect("C_5 missing");
    assert_eq!(c5.report.spanning_tree_count, 5);
}

// ---------------------------------------------------------------------------
// Lookup API (find_in_catalog) — these are the application-facing tests
// for the queryable side of the Periodic Table.
// ---------------------------------------------------------------------------

#[test]
fn lookup_finds_triangle() {
    use metatron_scan::{find_in_catalog, InputGraph};
    let table = build_catalog(3).unwrap();
    let g = InputGraph::from_edges(3, &[(1, 2), (2, 3), (1, 3)]).unwrap();
    let entry = find_in_catalog(&g, &table).expect("must find triangle");
    assert_eq!(entry.n, 3);
    assert_eq!(entry.m, 3);
    assert_eq!(entry.id, "G3-3-1");
    assert_eq!(entry.report.triangle_count, 1);
}

#[test]
fn lookup_finds_c5() {
    use metatron_scan::{find_in_catalog, InputGraph};
    let table = build_catalog(5).unwrap();
    let g =
        InputGraph::from_edges(5, &[(1, 2), (2, 3), (3, 4), (4, 5), (5, 1)]).unwrap();
    let entry = find_in_catalog(&g, &table).expect("must find C5");
    assert_eq!(entry.n, 5);
    assert_eq!(entry.m, 5);
    assert!(entry.report.properties.is_self_complementary);
    assert_eq!(entry.report.properties.girth, Some(5));
    assert_eq!(entry.report.properties.wiener_index, Some(15));
}

#[test]
fn lookup_handles_relabelling() {
    // Feed the catalog a differently-labelled K_3 and expect the same
    // catalog entry as the "canonical" triangle.
    use metatron_scan::{find_in_catalog, InputGraph};
    let table = build_catalog(3).unwrap();
    let g1 = InputGraph::from_edges(3, &[(1, 2), (2, 3), (1, 3)]).unwrap();
    let g2 = InputGraph::from_edges(3, &[(2, 3), (3, 1), (1, 2)]).unwrap();
    let e1 = find_in_catalog(&g1, &table).unwrap();
    let e2 = find_in_catalog(&g2, &table).unwrap();
    assert_eq!(e1.id, e2.id);
}

/// Q₃ cube lookup at n = 8 — ~2 minutes.
#[test]
#[ignore]
fn lookup_finds_q3_cube_at_n8() {
    use metatron_scan::{find_in_catalog, InputGraph};
    let table = build_catalog(8).unwrap();
    let q3_edges = [
        (1, 2),
        (1, 3),
        (1, 5),
        (2, 4),
        (2, 6),
        (3, 4),
        (3, 7),
        (4, 8),
        (5, 6),
        (5, 7),
        (6, 8),
        (7, 8),
    ];
    let g = InputGraph::from_edges(8, &q3_edges).unwrap();
    let entry = find_in_catalog(&g, &table).expect("must find Q_3");
    assert_eq!(entry.n, 8);
    assert_eq!(entry.m, 12);
    // Q₃ is 3-regular, bipartite, girth 4, diameter 3.
    assert_eq!(entry.report.properties.degree_sequence, vec![3, 3, 3, 3, 3, 3, 3, 3]);
    assert!(entry.report.properties.is_bipartite);
    assert_eq!(entry.report.properties.girth, Some(4));
    assert_eq!(entry.report.properties.diameter, Some(3));
    // |Aut(Q_3)| = 48.
    assert_eq!(entry.report.stabilizer_order, 48);
    // Wiener index of Q_3 = 48.
    assert_eq!(entry.report.properties.wiener_index, Some(48));
}

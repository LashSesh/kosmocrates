//! Integration test §10.2: synthetic Cargo.toml with known dependencies.

use metatron_scan::adapters::{CargoDepsAdapter, DecompositionStrategy};
use metatron_scan::scan::{scan_with_cache, S7Cache};

const TOML: &str = r#"
[package]
name = "demo"
version = "0.1.0"
edition = "2021"

[dependencies]
serde = "1"
serde_json = "1"
clap = "4"

[dev-dependencies]
tempfile = "3"
"#;

#[test]
fn cargo_deps_produces_expected_graph() {
    let adapter = CargoDepsAdapter::new("demo/Cargo.toml")
        .with_strategy(DecompositionStrategy::Auto, 2);
    let (subs, strategy) = adapter.ingest(TOML).unwrap();
    // demo + 4 deps = 5 nodes, ≤ 7 → scanned whole.
    assert_eq!(strategy, "whole");
    assert_eq!(subs.len(), 1);
    let graph = &subs[0].graph;
    assert_eq!(graph.n, 5);
    assert_eq!(graph.edge_count(), 4); // star: demo ↔ each dep

    let labels = graph.labels.as_ref().unwrap();
    for dep in ["serde", "serde_json", "clap", "tempfile", "demo"] {
        assert!(labels.contains(&dep.to_string()), "missing label {dep}");
    }

    // Pipeline works end-to-end.
    let cache = S7Cache::new();
    let report = scan_with_cache(graph.clone(), &cache).unwrap();
    assert_eq!(report.orbit_size * report.stabilizer_order, 5040);
    // A 5-star embedded in the 13×13 Metatron scaffold: S_4 permutes the
    // four leaves (order 24), and the two unused scaffold vertices
    // (nodes 6, 7) also permute freely (order 2). 24 × 2 = 48.
    assert_eq!(report.stabilizer_order, 48);
}

#[test]
fn single_dependency_is_k2() {
    let toml = r#"
[package]
name = "solo"
version = "0.0.1"
edition = "2021"

[dependencies]
only = "1"
"#;
    let adapter = CargoDepsAdapter::new("solo/Cargo.toml");
    let (subs, _) = adapter.ingest(toml).unwrap();
    assert_eq!(subs.len(), 1);
    assert_eq!(subs[0].graph.n, 2);
    assert_eq!(subs[0].graph.edge_count(), 1);
}

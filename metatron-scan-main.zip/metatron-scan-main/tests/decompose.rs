//! Integration test §10.2: synthetic graphs at n = 8, 10, 15, 20 prove
//! that strategies A, B, C each do what the spec claims.

use metatron_scan::adapters::decompose::{
    decompose, decompose_components, decompose_ego_graphs, decompose_exhaustive,
    DecompositionStrategy, FullGraph,
};

fn path_graph(n: usize) -> FullGraph {
    let labels: Vec<String> = (0..n).map(|i| format!("v{i}")).collect();
    let edges: Vec<(usize, usize)> = (0..n - 1).map(|i| (i, i + 1)).collect();
    FullGraph::from_parts(labels, edges)
}

fn two_components(a: usize, b: usize) -> FullGraph {
    let mut labels: Vec<String> = (0..(a + b)).map(|i| format!("v{i}")).collect();
    let mut edges: Vec<(usize, usize)> = (0..a - 1).map(|i| (i, i + 1)).collect();
    for i in 0..b - 1 {
        edges.push((a + i, a + i + 1));
    }
    labels.reverse();
    labels.reverse(); // no-op but keeps symmetry with real-world usage
    FullGraph::from_parts(labels, edges)
}

#[test]
fn strategy_components_splits_n_equals_8_two_components() {
    // Two chains of length 4 each.
    let g = two_components(4, 4);
    let subs = decompose_components(&g, "t", "edge").unwrap();
    assert_eq!(subs.len(), 2);
    for s in &subs {
        assert_eq!(s.graph.n, 4);
        assert_eq!(s.graph.edge_count(), 3);
    }
}

#[test]
fn strategy_ego_hops_1_on_n_equals_10_path() {
    let g = path_graph(10);
    let subs = decompose_ego_graphs(&g, 1, "t", "edge").unwrap();
    // For a path, every vertex v has 1-hop neighborhood {v-1?, v, v+1?}.
    // Duplicate neighborhoods only exist for the two endpoints'
    // neighborhoods being different, so we expect 10 distinct subsets.
    // Endpoints: {v0, v1} and {v8, v9}; interior: {v_{i-1}, v_i, v_{i+1}}.
    // That's 10 distinct subsets.
    assert_eq!(subs.len(), 10);
    for s in &subs {
        assert!(s.graph.n <= 3);
    }
}

#[test]
fn strategy_ego_hops_2_on_n_equals_15_path() {
    let g = path_graph(15);
    let subs = decompose_ego_graphs(&g, 2, "t", "edge").unwrap();
    // For a 15-node path, every 2-hop neighbourhood has size ≤ 5 ≤ 7 —
    // all 15 are kept (all distinct vertex sets).
    assert_eq!(subs.len(), 15);
}

#[test]
fn strategy_exhaustive_refuses_n_equals_20() {
    let g = path_graph(20);
    let err = decompose_exhaustive(&g, "t", "edge");
    assert!(err.is_err(), "n=20 must be refused");
}

#[test]
fn strategy_exhaustive_enumerates_n_equals_10_7subsets() {
    let g = path_graph(10);
    let subs = decompose_exhaustive(&g, "t", "edge").unwrap();
    // C(10, 7) = 120 induced subgraphs.
    assert_eq!(subs.len(), 120);
}

#[test]
fn strategy_auto_prefers_components_when_possible() {
    let g = two_components(3, 4);
    let (subs, used) =
        decompose(&g, DecompositionStrategy::Auto, 2, "t", "edge").unwrap();
    // 7 nodes total → fits in one subgraph, so whole-path is taken.
    assert_eq!(used, "whole");
    assert_eq!(subs.len(), 1);
}

#[test]
fn strategy_auto_on_n_equals_8_dual_small_components() {
    let g = two_components(3, 5);
    let (subs, used) =
        decompose(&g, DecompositionStrategy::Auto, 2, "t", "edge").unwrap();
    assert_eq!(used, "components");
    assert_eq!(subs.len(), 2);
}

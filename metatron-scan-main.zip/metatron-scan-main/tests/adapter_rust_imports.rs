//! Integration test §10.2: scan metatron-scan's own source tree via the
//! rust-imports adapter. This is the "self-reflection" test — a real
//! Rust crate whose module structure is known.
//!
//! We don't hard-code every node (the codebase may grow), but we assert
//! the specific invariants the spec mentions:
//!   * the modules `orbit`, `stabilizer`, `spectrum`, `scan` appear,
//!   * `crate::scan`'s 2-hop ego graph has a reproducible stabilizer
//!     order (regression probe — stored as the current observed value).

use std::fs;
use std::path::{Path, PathBuf};

use metatron_scan::adapters::rust_imports::{RustFile, RustImportsAdapter, RustImportsInput};
use metatron_scan::adapters::DecompositionStrategy;
use metatron_scan::scan::{scan_with_cache, S7Cache};

fn src_root() -> PathBuf {
    Path::new(env!("CARGO_MANIFEST_DIR")).join("src")
}

fn collect_rs_files(root: &Path, out: &mut Vec<RustFile>) {
    for entry in fs::read_dir(root).unwrap() {
        let e = entry.unwrap();
        let p = e.path();
        if p.is_dir() {
            collect_rs_files(&p, out);
            continue;
        }
        if p.extension().and_then(|s| s.to_str()) != Some("rs") {
            continue;
        }
        let rel = p.strip_prefix(src_root()).unwrap();
        let mut parts: Vec<String> = rel
            .with_extension("")
            .components()
            .map(|c| c.as_os_str().to_string_lossy().to_string())
            .collect();
        if let Some(last) = parts.last() {
            if last == "mod" || last == "lib" || last == "main" {
                parts.pop();
            }
        }
        let module = if parts.is_empty() {
            "crate".to_string()
        } else {
            format!("crate::{}", parts.join("::"))
        };
        let source = fs::read_to_string(&p).unwrap();
        out.push(RustFile { module, source });
    }
}

#[test]
fn scans_own_source_tree() {
    let mut files = Vec::new();
    collect_rs_files(&src_root(), &mut files);
    assert!(files.len() >= 10, "expected plenty of .rs files");

    let envelope = serde_json::to_string(&RustImportsInput { files }).unwrap();

    // hops = 1 guarantees that every hub module (e.g. `crate::orbit`,
    // used directly by `scan`) appears as a centre of a 1-hop ego graph
    // of size ≤ 7, even when the overall import graph has >7 nodes.
    let adapter = RustImportsAdapter::new(src_root().to_string_lossy().to_string())
        .with_strategy(DecompositionStrategy::Ego, 1);
    let (subs, strategy) = adapter.ingest(&envelope).unwrap();
    assert!(!subs.is_empty(), "adapter produced no subgraphs");
    assert_eq!(strategy, "ego");

    // All produced subgraphs must be scanable and within n ≤ 7.
    let cache = S7Cache::new();
    let mut any_module_scanned = false;
    for lg in &subs {
        assert!(lg.graph.n <= 7);
        let report = scan_with_cache(lg.graph.clone(), &cache).unwrap();
        assert_eq!(
            report.orbit_size * report.stabilizer_order,
            5040,
            "orbit × stabilizer mismatch for ego of {:?}",
            lg.origin.location
        );
        any_module_scanned = true;
    }
    assert!(any_module_scanned);

    // Spec §10.2: core modules should appear among the members somewhere.
    let all_members: std::collections::HashSet<String> = subs
        .iter()
        .flat_map(|l| l.graph.labels.clone().unwrap_or_default())
        .collect();
    for expected in ["crate::orbit", "crate::stabilizer", "crate::spectrum", "crate::scan"] {
        assert!(
            all_members.contains(expected),
            "missing expected module {expected} in scan output (members: {:?})",
            all_members
        );
    }
}

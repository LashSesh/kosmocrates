use metatron_scan::{scan, scan_with_cache, InputGraph, S7Cache};

#[test]
fn empty_graph_7() {
    let g = InputGraph::from_edges(7, &[]).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_size, 1);
    assert_eq!(r.stabilizer_order, 5040);
    assert_eq!(r.orbit_stabilizer_product, 5040);
}

#[test]
fn complete_graph_k7() {
    let edges: Vec<(usize, usize)> = (1..=7)
        .flat_map(|i| ((i + 1)..=7).map(move |j| (i, j)))
        .collect();
    let g = InputGraph::from_edges(7, &edges).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_size, 1);
    assert_eq!(r.stabilizer_order, 5040);
    assert_eq!(r.orbit_stabilizer_product, 5040);
}

#[test]
fn triangle_k3() {
    let g = InputGraph::from_edges(3, &[(1, 2), (2, 3), (1, 3)]).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_stabilizer_product, 5040);
    assert_eq!(r.triangle_count, 1);
    // Eigenvalues of K3: [-1, -1, 2]
    assert!((r.eigenvalues[0] - (-1.0)).abs() < 1e-8);
    assert!((r.eigenvalues[2] - 2.0).abs() < 1e-8);
}

#[test]
fn path_p3() {
    let g = InputGraph::from_edges(3, &[(1, 2), (2, 3)]).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_stabilizer_product, 5040);
    assert_eq!(r.triangle_count, 0);
    // Eigenvalues of P3: [-sqrt(2), 0, sqrt(2)]
    let sqrt2 = std::f64::consts::SQRT_2;
    assert!((r.eigenvalues[0] - (-sqrt2)).abs() < 1e-8);
    assert!((r.eigenvalues[1]).abs() < 1e-8);
    assert!((r.eigenvalues[2] - sqrt2).abs() < 1e-8);
}

#[test]
fn star_k1_6() {
    let edges: Vec<_> = (2..=7).map(|i| (1, i)).collect();
    let g = InputGraph::from_edges(7, &edges).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_stabilizer_product, 5040);
}

#[test]
fn cycle_c5() {
    let g = InputGraph::from_edges(5, &[(1, 2), (2, 3), (3, 4), (4, 5), (5, 1)]).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_stabilizer_product, 5040);
}

#[test]
fn single_edge() {
    let g = InputGraph::from_edges(2, &[(1, 2)]).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_stabilizer_product, 5040);
    assert_eq!(r.triangle_count, 0);
}

#[test]
fn single_node() {
    let g = InputGraph::from_edges(1, &[]).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_stabilizer_product, 5040);
    assert_eq!(r.orbit_size, 1);
    assert_eq!(r.stabilizer_order, 5040);
}

#[test]
fn two_disconnected_edges() {
    let g = InputGraph::from_edges(4, &[(1, 2), (3, 4)]).unwrap();
    let r = scan(g).unwrap();
    assert_eq!(r.orbit_stabilizer_product, 5040);
}

/// CRITICAL TEST: Orbit-Stabilizer Theorem for EVERY scan
#[test]
fn orbit_stabilizer_always_5040() {
    let cache = S7Cache::new();

    let test_cases: Vec<(usize, Vec<(usize, usize)>)> = vec![
        (7, vec![]),                                          // E7
        (2, vec![(1, 2)]),                                    // Single edge
        (3, vec![(1, 2), (2, 3), (1, 3)]),                   // K3
        (3, vec![(1, 2), (2, 3)]),                            // P3
        (4, vec![(1, 2), (3, 4)]),                            // 2 disconnected edges
        (5, vec![(1, 2), (2, 3), (3, 4), (4, 5), (5, 1)]),   // C5
        (4, vec![(1, 2), (1, 3), (1, 4)]),                    // Star K1,3
        (4, vec![(1, 2), (2, 3), (3, 4), (4, 1), (1, 3), (2, 4)]), // K4
        (1, vec![]),                                          // Single node
    ];

    for (n, edges) in &test_cases {
        let g = InputGraph::from_edges(*n, edges).unwrap();
        let r = scan_with_cache(g, &cache).unwrap();
        assert_eq!(
            r.orbit_stabilizer_product, 5040,
            "Failed for n={}, edges: {:?} (orbit={}, stab={})",
            n, edges, r.orbit_size, r.stabilizer_order
        );
    }
}

#[test]
fn k7_eigenvalues() {
    let edges: Vec<(usize, usize)> = (1..=7)
        .flat_map(|i| ((i + 1)..=7).map(move |j| (i, j)))
        .collect();
    let g = InputGraph::from_edges(7, &edges).unwrap();
    let r = scan(g).unwrap();
    // K7 eigenvalues: [-1, -1, -1, -1, -1, -1, 6]
    for i in 0..6 {
        assert!(
            (r.eigenvalues[i] - (-1.0)).abs() < 1e-8,
            "eigenvalue[{}] = {}, expected -1",
            i,
            r.eigenvalues[i]
        );
    }
    assert!((r.eigenvalues[6] - 6.0).abs() < 1e-8);
}

#[test]
fn e7_eigenvalues() {
    let g = InputGraph::from_edges(7, &[]).unwrap();
    let r = scan(g).unwrap();
    for &ev in &r.eigenvalues {
        assert!(ev.abs() < 1e-8, "eigenvalue {} should be 0", ev);
    }
}

#[test]
fn complement_of_empty_is_complete() {
    let g = InputGraph::from_edges(7, &[]).unwrap();
    let r = scan(g).unwrap();
    // Complement of E7 is K7, which also has orbit size 1
    assert_eq!(r.complement_orbit_size, 1);
}

#[test]
fn scan_with_cache_works() {
    let cache = S7Cache::new();
    let g1 = InputGraph::from_edges(3, &[(1, 2), (2, 3), (1, 3)]).unwrap();
    let g2 = InputGraph::from_edges(3, &[(1, 2), (2, 3)]).unwrap();
    let r1 = scan_with_cache(g1, &cache).unwrap();
    let r2 = scan_with_cache(g2, &cache).unwrap();
    // Different graphs should have different canonical hashes
    assert_ne!(r1.canonical_hash, r2.canonical_hash);
}

#[test]
fn json_export_works() {
    let g = InputGraph::from_edges(3, &[(1, 2), (2, 3), (1, 3)]).unwrap();
    let r = scan(g).unwrap();
    let json = metatron_scan::report_to_json(&r).unwrap();
    assert!(json.contains("\"orbit_stabilizer_product\": 5040"));
}

#[test]
fn reject_too_many_nodes() {
    let result = InputGraph::from_edges(9, &[(1, 2)]);
    assert!(result.is_err());
}

#[test]
fn reject_self_loop() {
    let mut matrix = vec![vec![0.0; 3]; 3];
    matrix[0][0] = 1.0;
    let result = InputGraph::from_adjacency(matrix);
    assert!(result.is_err());
}

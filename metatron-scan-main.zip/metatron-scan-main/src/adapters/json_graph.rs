//! Adapter 1: Generic JSON-Graph (Spec S1 §3).
//!
//! Accepts a `{nodes: [...], edges: [...]}` document, optionally with
//! arbitrary extra fields per node/edge (ignored). Edge `type` values are
//! collapsed into a comma-separated `entity_type` on every produced
//! subgraph so the domain tag survives decomposition.

use std::collections::BTreeSet;

use serde::{Deserialize, Serialize};

use crate::error::{ScanError, ScanResult};

use super::decompose::{decompose, DecompositionStrategy, FullGraph};
use super::{DomainAdapter, LabeledGraph};

/// Parsed JSON-Graph document.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JsonGraphDoc {
    #[serde(default)]
    pub nodes: Vec<JsonNode>,
    #[serde(default)]
    pub edges: Vec<JsonEdge>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JsonNode {
    pub id: String,
    #[serde(default, rename = "type")]
    pub node_type: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct JsonEdge {
    pub from: String,
    pub to: String,
    #[serde(default, rename = "type")]
    pub edge_type: Option<String>,
}

/// JSON-Graph adapter.
#[derive(Debug, Clone)]
pub struct JsonGraphAdapter {
    pub source: String,
    pub strategy: DecompositionStrategy,
    pub hops: u32,
}

impl JsonGraphAdapter {
    pub fn new(source: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            strategy: DecompositionStrategy::Auto,
            hops: 2,
        }
    }

    pub fn with_strategy(mut self, s: DecompositionStrategy, hops: u32) -> Self {
        self.strategy = s;
        self.hops = hops;
        self
    }

    /// Parse + decompose + return the list of subgraphs alongside the
    /// strategy that was actually used (useful for the ingest report).
    pub fn ingest(&self, raw: &str) -> ScanResult<(Vec<LabeledGraph>, &'static str)> {
        let full = build_full_graph(raw)?;
        let entity_type = collect_edge_types(raw);
        decompose(&full, self.strategy, self.hops, &self.source, &entity_type)
    }
}

impl DomainAdapter for JsonGraphAdapter {
    fn name(&self) -> &'static str {
        "json-graph"
    }

    fn format(&self) -> &'static str {
        "application/json"
    }

    fn to_input_graphs(&self, raw: &str) -> ScanResult<Vec<LabeledGraph>> {
        self.ingest(raw).map(|(g, _)| g)
    }
}

/// Build a `FullGraph` from the raw JSON document.
fn build_full_graph(raw: &str) -> ScanResult<FullGraph> {
    let doc: JsonGraphDoc = serde_json::from_str(raw)
        .map_err(|e| ScanError::AdapterError(format!("json-graph parse error: {e}")))?;
    if doc.nodes.is_empty() {
        return Err(ScanError::AdapterError(
            "json-graph: no nodes declared".into(),
        ));
    }

    let labels: Vec<String> = doc.nodes.iter().map(|n| n.id.clone()).collect();

    // Build id -> index map and detect duplicates.
    let mut idx = std::collections::HashMap::new();
    for (i, l) in labels.iter().enumerate() {
        if idx.insert(l.clone(), i).is_some() {
            return Err(ScanError::AdapterError(format!(
                "json-graph: duplicate node id '{l}'"
            )));
        }
    }

    let mut raw_edges = Vec::with_capacity(doc.edges.len());
    for e in &doc.edges {
        let a = idx.get(&e.from).copied().ok_or_else(|| {
            ScanError::AdapterError(format!("json-graph: edge references unknown node '{}'", e.from))
        })?;
        let b = idx.get(&e.to).copied().ok_or_else(|| {
            ScanError::AdapterError(format!("json-graph: edge references unknown node '{}'", e.to))
        })?;
        raw_edges.push((a, b));
    }

    Ok(FullGraph::from_parts(labels, raw_edges))
}

/// Collect the distinct edge `type` values into a comma-separated string.
/// Spec S1 §3.2 specifies that multiple types are comma-separated.
fn collect_edge_types(raw: &str) -> String {
    let Ok(doc): Result<JsonGraphDoc, _> = serde_json::from_str(raw) else {
        return "graph".into();
    };
    let mut types = BTreeSet::new();
    for e in &doc.edges {
        if let Some(t) = &e.edge_type {
            types.insert(t.clone());
        }
    }
    if types.is_empty() {
        "graph".into()
    } else {
        types.into_iter().collect::<Vec<_>>().join(",")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_success_small_graph() {
        let raw = r#"{
            "nodes": [
                {"id": "a", "type": "person"},
                {"id": "b", "type": "person"},
                {"id": "c", "type": "org"}
            ],
            "edges": [
                {"from": "a", "to": "b", "type": "reports_to"},
                {"from": "a", "to": "c", "type": "member_of"}
            ]
        }"#;
        let adapter = JsonGraphAdapter::new("inline");
        let subs = adapter.to_input_graphs(raw).unwrap();
        assert_eq!(subs.len(), 1);
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 2);
        assert!(subs[0].entity_type.contains("reports_to"));
        assert!(subs[0].entity_type.contains("member_of"));
    }

    #[test]
    fn parse_failure_invalid_json() {
        let adapter = JsonGraphAdapter::new("inline");
        let err = adapter.to_input_graphs("{not json}").unwrap_err();
        match err {
            ScanError::AdapterError(msg) => assert!(msg.contains("json-graph")),
            other => panic!("expected AdapterError, got {other:?}"),
        }
    }

    #[test]
    fn round_trip_triangle_produces_k3_hash() {
        // K3 is a specific canonical form — round-trip via scan.
        let raw = r#"{
            "nodes": [{"id":"a"},{"id":"b"},{"id":"c"}],
            "edges": [
                {"from":"a","to":"b"},
                {"from":"b","to":"c"},
                {"from":"a","to":"c"}
            ]
        }"#;
        let adapter = JsonGraphAdapter::new("inline");
        let subs = adapter.to_input_graphs(raw).unwrap();
        assert_eq!(subs.len(), 1);
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 3);
    }

    #[test]
    fn unknown_node_reference_rejected() {
        let raw = r#"{
            "nodes": [{"id":"a"}],
            "edges": [{"from":"a","to":"ghost"}]
        }"#;
        let adapter = JsonGraphAdapter::new("inline");
        assert!(adapter.to_input_graphs(raw).is_err());
    }

    #[test]
    fn large_graph_triggers_decomposition() {
        let mut nodes = Vec::new();
        let mut edges = Vec::new();
        for i in 0..12 {
            nodes.push(format!(r#"{{"id":"n{i}"}}"#));
        }
        // two 6-node components
        for i in 0..5 {
            edges.push(format!(r#"{{"from":"n{i}","to":"n{}"}}"#, i + 1));
        }
        for i in 6..11 {
            edges.push(format!(r#"{{"from":"n{i}","to":"n{}"}}"#, i + 1));
        }
        let raw = format!(
            r#"{{"nodes":[{}],"edges":[{}]}}"#,
            nodes.join(","),
            edges.join(",")
        );
        let adapter = JsonGraphAdapter::new("inline");
        let (subs, used) = adapter.ingest(&raw).unwrap();
        assert_eq!(used, "components");
        assert_eq!(subs.len(), 2);
    }
}

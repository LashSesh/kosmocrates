//! Decomposition strategies for inputs with n > 7 (Spec S1 §8).
//!
//! The scan engine accepts at most 7 nodes (plus an optional n = 8 fast
//! path via `scan_canonical_bits_n`, but the public adapter pipeline is
//! bounded by the 7-node catalog). Any larger input must be split into
//! subgraphs of size ≤ 7.
//!
//! Three strategies are offered:
//!
//! * **A — Connected components**: if every weakly connected component
//!   already has ≤ 7 nodes, scan each component separately.
//! * **B — k-hop ego graphs**: for every vertex, extract its k-hop
//!   neighbourhood; keep those of size ≤ 7. Yields a motif census.
//! * **C — Exhaustive 7-cliques**: enumerate all induced subgraphs on
//!   exactly 7 nodes. Only feasible up to ~15 nodes; off by default.
//!
//! The `auto` default tries A first, then falls back to B with 2 hops.

use std::collections::{BTreeSet, HashSet, VecDeque};

use serde::{Deserialize, Serialize};

use crate::error::ScanResult;
use crate::ingest::InputGraph;

use super::{GraphOrigin, LabeledGraph};

/// A graph of arbitrary size used as input to the decomposition stage.
#[derive(Debug, Clone)]
pub struct FullGraph {
    pub labels: Vec<String>,
    /// Adjacency as an upper-triangular edge set (unordered pairs).
    pub edges: BTreeSet<(usize, usize)>,
}

impl FullGraph {
    /// Build a `FullGraph` from labels and an unordered pair list.
    ///
    /// Self-loops are removed silently; multi-edges collapse to one.
    pub fn from_parts(labels: Vec<String>, raw_edges: Vec<(usize, usize)>) -> Self {
        let n = labels.len();
        let mut edges = BTreeSet::new();
        for (a, b) in raw_edges {
            if a >= n || b >= n || a == b {
                continue;
            }
            let pair = if a < b { (a, b) } else { (b, a) };
            edges.insert(pair);
        }
        Self { labels, edges }
    }

    pub fn n(&self) -> usize {
        self.labels.len()
    }

    pub fn neighbors(&self, v: usize) -> Vec<usize> {
        let mut out = Vec::new();
        for &(a, b) in &self.edges {
            if a == v {
                out.push(b);
            } else if b == v {
                out.push(a);
            }
        }
        out
    }
}

/// Decomposition strategy selector.
#[derive(Debug, Clone, Copy, Default, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum DecompositionStrategy {
    /// Strategy A if possible, otherwise B with 2 hops.
    #[default]
    Auto,
    /// Strategy A only — keep components of size ≤ 7, drop the rest.
    Components,
    /// Strategy B — k-hop ego graphs (k supplied separately).
    Ego,
    /// Strategy C — exhaustive 7-node induced subgraphs.
    Exhaustive,
}

impl DecompositionStrategy {
    pub fn as_str(self) -> &'static str {
        match self {
            DecompositionStrategy::Auto => "auto",
            DecompositionStrategy::Components => "components",
            DecompositionStrategy::Ego => "ego",
            DecompositionStrategy::Exhaustive => "exhaustive",
        }
    }
}

/// Top-level entry point: apply `strategy` to `g` and return a list of
/// subgraphs (all with n ≤ 7).
///
/// The returned strategy string describes what was actually used — for
/// `Auto` this is either `"components"` or `"ego"`.
pub fn decompose(
    g: &FullGraph,
    strategy: DecompositionStrategy,
    hops: u32,
    source: &str,
    entity_type: &str,
) -> ScanResult<(Vec<LabeledGraph>, &'static str)> {
    // Fast path: n ≤ 7 — no decomposition needed.
    if g.n() <= 7 {
        let location = format!("whole(n={})", g.n());
        let labeled = build_labeled(g, &all_indices(g.n()), source, &location, entity_type)?;
        return Ok((vec![labeled], "whole"));
    }

    match strategy {
        DecompositionStrategy::Components => Ok((
            decompose_components(g, source, entity_type)?,
            "components",
        )),
        DecompositionStrategy::Ego => Ok((
            decompose_ego_graphs(g, hops, source, entity_type)?,
            "ego",
        )),
        DecompositionStrategy::Exhaustive => Ok((
            decompose_exhaustive(g, source, entity_type)?,
            "exhaustive",
        )),
        DecompositionStrategy::Auto => {
            let comps = find_connected_components(g);
            if comps.iter().all(|c| c.len() <= 7) {
                Ok((
                    components_to_labeled(g, &comps, source, entity_type)?,
                    "components",
                ))
            } else {
                Ok((
                    decompose_ego_graphs(g, hops, source, entity_type)?,
                    "ego",
                ))
            }
        }
    }
}

/// Strategy A: return every connected component with ≤ 7 nodes.
pub fn decompose_components(
    g: &FullGraph,
    source: &str,
    entity_type: &str,
) -> ScanResult<Vec<LabeledGraph>> {
    let comps = find_connected_components(g);
    components_to_labeled(g, &comps, source, entity_type)
}

fn components_to_labeled(
    g: &FullGraph,
    comps: &[Vec<usize>],
    source: &str,
    entity_type: &str,
) -> ScanResult<Vec<LabeledGraph>> {
    let mut out = Vec::new();
    for (i, c) in comps.iter().enumerate() {
        if c.len() > 7 || c.is_empty() {
            continue;
        }
        let loc = format!("component({}, size={})", i, c.len());
        out.push(build_labeled(g, c, source, &loc, entity_type)?);
    }
    Ok(out)
}

/// Strategy B: for every vertex whose k-hop neighbourhood has ≤ 7 nodes,
/// extract that neighbourhood as a subgraph.
///
/// Duplicate neighbourhoods (same set of vertex indices) are kept only
/// once — otherwise a clique would emit n identical subgraphs.
pub fn decompose_ego_graphs(
    g: &FullGraph,
    hops: u32,
    source: &str,
    entity_type: &str,
) -> ScanResult<Vec<LabeledGraph>> {
    let mut seen: HashSet<Vec<usize>> = HashSet::new();
    let mut out = Vec::new();
    for v in 0..g.n() {
        let ego = bfs_neighborhood(g, v, hops);
        if ego.len() > 7 || ego.is_empty() {
            continue;
        }
        let mut sorted = ego.clone();
        sorted.sort_unstable();
        if !seen.insert(sorted) {
            continue;
        }
        let loc = format!(
            "ego(pivot={}, hops={}, size={})",
            g.labels[v],
            hops,
            ego.len()
        );
        out.push(build_labeled(g, &ego, source, &loc, entity_type)?);
    }
    Ok(out)
}

/// Strategy C: all induced subgraphs on exactly 7 vertices.
/// Exponential in `n`; refuses to run for n > 15.
pub fn decompose_exhaustive(
    g: &FullGraph,
    source: &str,
    entity_type: &str,
) -> ScanResult<Vec<LabeledGraph>> {
    let n = g.n();
    if n > 15 {
        return Err(crate::error::ScanError::AdapterError(format!(
            "exhaustive decomposition refused for n={n} (limit: 15)"
        )));
    }
    let k = 7.min(n);
    let mut out = Vec::new();
    let mut pick = Vec::with_capacity(k);
    enumerate_k_subsets(0, n, k, &mut pick, &mut |subset| {
        let loc = format!("clique7({:?})", subset);
        if let Ok(l) = build_labeled(g, subset, source, &loc, entity_type) {
            out.push(l);
        }
    });
    Ok(out)
}

fn enumerate_k_subsets<F: FnMut(&[usize])>(
    start: usize,
    n: usize,
    k: usize,
    pick: &mut Vec<usize>,
    f: &mut F,
) {
    if pick.len() == k {
        f(pick);
        return;
    }
    let remaining = k - pick.len();
    if start + remaining > n {
        return;
    }
    for i in start..=n - remaining {
        pick.push(i);
        enumerate_k_subsets(i + 1, n, k, pick, f);
        pick.pop();
    }
}

/// Undirected connected components (1-component per starting vertex).
pub fn find_connected_components(g: &FullGraph) -> Vec<Vec<usize>> {
    let n = g.n();
    let mut visited = vec![false; n];
    let mut adj = vec![Vec::new(); n];
    for &(a, b) in &g.edges {
        adj[a].push(b);
        adj[b].push(a);
    }

    let mut comps = Vec::new();
    for start in 0..n {
        if visited[start] {
            continue;
        }
        let mut comp = Vec::new();
        let mut q = VecDeque::from([start]);
        visited[start] = true;
        while let Some(v) = q.pop_front() {
            comp.push(v);
            for &w in &adj[v] {
                if !visited[w] {
                    visited[w] = true;
                    q.push_back(w);
                }
            }
        }
        comp.sort_unstable();
        comps.push(comp);
    }
    comps
}

/// BFS up to `hops` levels from `start`.
pub fn bfs_neighborhood(g: &FullGraph, start: usize, hops: u32) -> Vec<usize> {
    let n = g.n();
    let mut adj = vec![Vec::new(); n];
    for &(a, b) in &g.edges {
        adj[a].push(b);
        adj[b].push(a);
    }
    let mut dist = vec![u32::MAX; n];
    dist[start] = 0;
    let mut q = VecDeque::from([start]);
    while let Some(v) = q.pop_front() {
        if dist[v] == hops {
            continue;
        }
        for &w in &adj[v] {
            if dist[w] == u32::MAX {
                dist[w] = dist[v] + 1;
                q.push_back(w);
            }
        }
    }
    let mut out: Vec<usize> = (0..n).filter(|&i| dist[i] <= hops).collect();
    out.sort_unstable();
    out
}

fn all_indices(n: usize) -> Vec<usize> {
    (0..n).collect()
}

/// Build a [`LabeledGraph`] from a subset of vertices.
fn build_labeled(
    g: &FullGraph,
    subset: &[usize],
    source: &str,
    location: &str,
    entity_type: &str,
) -> ScanResult<LabeledGraph> {
    let k = subset.len();
    // Map global index -> local index.
    let mut local = vec![usize::MAX; g.n()];
    for (li, &gi) in subset.iter().enumerate() {
        local[gi] = li;
    }
    let mut adj = vec![vec![0.0f64; k]; k];
    for &(a, b) in &g.edges {
        if local[a] != usize::MAX && local[b] != usize::MAX {
            let la = local[a];
            let lb = local[b];
            adj[la][lb] = 1.0;
            adj[lb][la] = 1.0;
        }
    }
    let mut graph = InputGraph::from_adjacency(adj)?;
    graph.labels = Some(subset.iter().map(|&i| g.labels[i].clone()).collect());

    Ok(LabeledGraph {
        graph,
        origin: GraphOrigin::new(source.to_string(), location.to_string()),
        entity_type: entity_type.to_string(),
    })
}

#[cfg(test)]
mod tests {
    use super::*;

    fn g(labels: &[&str], edges: &[(usize, usize)]) -> FullGraph {
        FullGraph::from_parts(
            labels.iter().map(|s| s.to_string()).collect(),
            edges.to_vec(),
        )
    }

    #[test]
    fn self_loops_and_multi_edges_are_collapsed() {
        let fg = g(
            &["a", "b"],
            &[(0, 0), (0, 1), (1, 0), (1, 1)],
        );
        assert_eq!(fg.edges.len(), 1);
        assert!(fg.edges.contains(&(0, 1)));
    }

    #[test]
    fn connected_components_split_cleanly() {
        let fg = g(
            &["a", "b", "c", "d"],
            &[(0, 1), (2, 3)],
        );
        let comps = find_connected_components(&fg);
        assert_eq!(comps.len(), 2);
        assert!(comps.iter().any(|c| c == &vec![0, 1]));
        assert!(comps.iter().any(|c| c == &vec![2, 3]));
    }

    #[test]
    fn ego_graph_respects_hops() {
        let fg = g(
            &["a", "b", "c", "d"],
            &[(0, 1), (1, 2), (2, 3)],
        );
        let nb = bfs_neighborhood(&fg, 0, 1);
        assert_eq!(nb, vec![0, 1]);
        let nb2 = bfs_neighborhood(&fg, 0, 2);
        assert_eq!(nb2, vec![0, 1, 2]);
    }

    #[test]
    fn decompose_auto_prefers_components_when_small() {
        let fg = g(
            &["a", "b", "c", "d", "e", "f", "g", "h"],
            &[(0, 1), (2, 3), (4, 5), (6, 7)],
        );
        let (subs, used) =
            decompose(&fg, DecompositionStrategy::Auto, 2, "t.src", "edge").unwrap();
        assert_eq!(used, "components");
        assert_eq!(subs.len(), 4);
    }

    #[test]
    fn decompose_auto_falls_back_to_ego_for_big_component() {
        // 8-star plus a detached edge → 9 nodes, two components, centre
        // component has 8 nodes so Auto must fall back to ego.
        let fg = g(
            &[
                "c", "a", "b", "d", "e", "f", "g", "h", "x", "y",
            ],
            &[
                (0, 1),
                (0, 2),
                (0, 3),
                (0, 4),
                (0, 5),
                (0, 6),
                (0, 7),
                (8, 9),
            ],
        );
        // hops = 1 gives every leaf a 2-node ego (kept) — enough to prove
        // the ego strategy was chosen.
        let (subs, used) =
            decompose(&fg, DecompositionStrategy::Auto, 1, "t.src", "edge").unwrap();
        assert_eq!(used, "ego");
        assert!(!subs.is_empty());
    }

    #[test]
    fn decompose_ego_yields_nothing_when_every_neighborhood_too_big() {
        // 8-star with hops = 2: every 2-hop neighbourhood contains the whole
        // graph (size 8) — motif census legitimately empty.
        let fg = g(
            &["c", "a", "b", "d", "e", "f", "g", "h"],
            &[(0, 1), (0, 2), (0, 3), (0, 4), (0, 5), (0, 6), (0, 7)],
        );
        let (subs, _used) =
            decompose(&fg, DecompositionStrategy::Ego, 2, "t.src", "edge").unwrap();
        assert!(subs.is_empty());
    }

    #[test]
    fn small_graph_bypasses_decomposition() {
        let fg = g(&["a", "b", "c"], &[(0, 1), (1, 2)]);
        let (subs, used) =
            decompose(&fg, DecompositionStrategy::Auto, 2, "t.src", "edge").unwrap();
        assert_eq!(used, "whole");
        assert_eq!(subs.len(), 1);
        assert_eq!(subs[0].graph.n, 3);
    }

    #[test]
    fn exhaustive_refuses_huge_inputs() {
        let labels: Vec<&str> = (0..20).map(|_| "x").collect();
        let fg = g(&labels, &[]);
        let res = decompose_exhaustive(&fg, "t", "edge");
        assert!(res.is_err());
    }
}

//! Adapter 3: Cargo Dependency Graph (Spec S1 §5).
//!
//! Accepts either a single `Cargo.toml` or a workspace root.
//! Extracts `[dependencies]`, `[dev-dependencies]`, and
//! `[build-dependencies]`. In a workspace, cross-member edges are added
//! automatically: if member A depends on member B, the dependency
//! appears as a real intra-workspace edge.
//!
//! For CLI usage, the adapter's `to_input_graphs` takes a raw string; a
//! typical workflow parses `Cargo.toml` from disk and hands the file
//! contents (or a workspace descriptor — see [`CargoDepsInput`]) to the
//! adapter.

use std::collections::{BTreeMap, BTreeSet};

use serde::{Deserialize, Serialize};
use toml::Value;

use crate::error::{ScanError, ScanResult};

use super::decompose::{decompose, DecompositionStrategy, FullGraph};
use super::{DomainAdapter, LabeledGraph};

/// Input envelope: either a single Cargo.toml or a synthetic workspace.
///
/// The adapter accepts JSON in the following shape:
/// ```json
/// { "package": "Cargo.toml contents as a string" }
/// ```
/// or
/// ```json
/// {
///   "workspace_members": {
///     "pkg_a": "Cargo.toml contents for pkg_a",
///     "pkg_b": "Cargo.toml contents for pkg_b"
///   }
/// }
/// ```
/// The plain single-file case is also accepted: any input that parses as
/// TOML with a `[package]` section is treated as `package`.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum CargoDepsInput {
    Package { package: String },
    Workspace { workspace_members: BTreeMap<String, String> },
}

/// Cargo dependency graph adapter.
#[derive(Debug, Clone)]
pub struct CargoDepsAdapter {
    pub source: String,
    pub strategy: DecompositionStrategy,
    pub hops: u32,
    /// Include `[dev-dependencies]` edges (default: true).
    pub include_dev: bool,
    /// Include `[build-dependencies]` edges (default: true).
    pub include_build: bool,
}

impl CargoDepsAdapter {
    pub fn new(source: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            strategy: DecompositionStrategy::Auto,
            hops: 2,
            include_dev: true,
            include_build: true,
        }
    }

    pub fn with_strategy(mut self, s: DecompositionStrategy, hops: u32) -> Self {
        self.strategy = s;
        self.hops = hops;
        self
    }

    pub fn ingest(&self, raw: &str) -> ScanResult<(Vec<LabeledGraph>, &'static str)> {
        let full = self.parse_full_graph(raw)?;
        decompose(&full, self.strategy, self.hops, &self.source, "cargo-dep")
    }

    fn parse_full_graph(&self, raw: &str) -> ScanResult<FullGraph> {
        // First try workspace-envelope JSON.
        if let Ok(env) = serde_json::from_str::<CargoDepsInput>(raw) {
            match env {
                CargoDepsInput::Package { package } => return self.parse_single_package(&package),
                CargoDepsInput::Workspace { workspace_members } => {
                    return self.parse_workspace(&workspace_members)
                }
            }
        }
        // Fallback: treat input as a raw Cargo.toml.
        self.parse_single_package(raw)
    }

    fn parse_single_package(&self, toml_src: &str) -> ScanResult<FullGraph> {
        let v: Value = toml_src
            .parse()
            .map_err(|e| ScanError::AdapterError(format!("cargo-deps: TOML parse: {e}")))?;

        let name = v
            .get("package")
            .and_then(|p| p.get("name"))
            .and_then(|n| n.as_str())
            .ok_or_else(|| ScanError::AdapterError("cargo-deps: [package].name missing".into()))?
            .to_string();

        let mut edges = BTreeSet::<(String, String)>::new();
        let mut nodes = BTreeSet::<String>::new();
        nodes.insert(name.clone());

        collect_dep_names(&v, "dependencies", &name, &mut nodes, &mut edges);
        if self.include_dev {
            collect_dep_names(&v, "dev-dependencies", &name, &mut nodes, &mut edges);
        }
        if self.include_build {
            collect_dep_names(&v, "build-dependencies", &name, &mut nodes, &mut edges);
        }

        Ok(build_graph(nodes, edges))
    }

    fn parse_workspace(&self, members: &BTreeMap<String, String>) -> ScanResult<FullGraph> {
        let mut nodes = BTreeSet::<String>::new();
        let mut edges = BTreeSet::<(String, String)>::new();
        let mut member_names = BTreeSet::<String>::new();

        for (hint, toml_src) in members {
            let v: Value = toml_src.parse().map_err(|e| {
                ScanError::AdapterError(format!(
                    "cargo-deps: workspace member '{hint}' TOML parse: {e}"
                ))
            })?;
            let name = v
                .get("package")
                .and_then(|p| p.get("name"))
                .and_then(|n| n.as_str())
                .unwrap_or(hint.as_str())
                .to_string();
            member_names.insert(name.clone());
            nodes.insert(name.clone());

            collect_dep_names(&v, "dependencies", &name, &mut nodes, &mut edges);
            if self.include_dev {
                collect_dep_names(&v, "dev-dependencies", &name, &mut nodes, &mut edges);
            }
            if self.include_build {
                collect_dep_names(&v, "build-dependencies", &name, &mut nodes, &mut edges);
            }
        }

        // Intra-workspace edges are already captured by the generic collector
        // because a dependency entry named `pkg_b` shows up as a node; if
        // that node happens to be another workspace member the edge is
        // automatically an intra-workspace edge. Nothing extra required.
        let _ = member_names;

        Ok(build_graph(nodes, edges))
    }
}

fn collect_dep_names(
    v: &Value,
    section: &str,
    pkg: &str,
    nodes: &mut BTreeSet<String>,
    edges: &mut BTreeSet<(String, String)>,
) {
    let Some(table) = v.get(section).and_then(|s| s.as_table()) else {
        return;
    };
    for (dep_name, dep_val) in table {
        // Handle renamed deps: `foo = { package = "real-name", ... }`.
        let real_name = dep_val
            .as_table()
            .and_then(|t| t.get("package"))
            .and_then(|n| n.as_str())
            .unwrap_or(dep_name.as_str())
            .to_string();
        nodes.insert(real_name.clone());
        let pair = order_pair(pkg.to_string(), real_name);
        edges.insert(pair);
    }
}

fn order_pair(a: String, b: String) -> (String, String) {
    if a < b {
        (a, b)
    } else {
        (b, a)
    }
}

fn build_graph(
    nodes: BTreeSet<String>,
    edges: BTreeSet<(String, String)>,
) -> FullGraph {
    let labels: Vec<String> = nodes.into_iter().collect();
    let idx: BTreeMap<String, usize> = labels
        .iter()
        .enumerate()
        .map(|(i, l)| (l.clone(), i))
        .collect();
    let raw_edges: Vec<(usize, usize)> = edges
        .iter()
        .filter_map(|(a, b)| {
            let ia = idx.get(a)?;
            let ib = idx.get(b)?;
            Some((*ia, *ib))
        })
        .collect();
    FullGraph::from_parts(labels, raw_edges)
}

impl DomainAdapter for CargoDepsAdapter {
    fn name(&self) -> &'static str {
        "cargo-deps"
    }

    fn format(&self) -> &'static str {
        "application/toml"
    }

    fn to_input_graphs(&self, raw: &str) -> ScanResult<Vec<LabeledGraph>> {
        self.ingest(raw).map(|(g, _)| g)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const TOML_A: &str = r#"
[package]
name = "foo"
version = "0.1.0"
edition = "2021"

[dependencies]
serde = "1"
serde_json = "1"
"#;

    const TOML_BIG: &str = r#"
[package]
name = "big"
version = "0.1.0"
edition = "2021"

[dependencies]
a = "1"
b = "1"
c = "1"
d = "1"
e = "1"
f = "1"
g = "1"
h = "1"

[dev-dependencies]
tempdir = "1"

[build-dependencies]
cc = "1"
"#;

    #[test]
    fn parse_success_small_package() {
        let adapter = CargoDepsAdapter::new("Cargo.toml");
        let subs = adapter.to_input_graphs(TOML_A).unwrap();
        assert_eq!(subs.len(), 1);
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 2);
        let labels = subs[0].graph.labels.as_ref().unwrap();
        assert!(labels.contains(&"foo".to_string()));
        assert!(labels.contains(&"serde".to_string()));
        assert!(labels.contains(&"serde_json".to_string()));
    }

    #[test]
    fn parse_failure_missing_package_name() {
        let bad = "[dependencies]\nserde = \"1\"\n";
        let adapter = CargoDepsAdapter::new("Cargo.toml");
        assert!(adapter.to_input_graphs(bad).is_err());
    }

    #[test]
    fn large_package_decomposes() {
        let adapter = CargoDepsAdapter::new("Cargo.toml")
            .with_strategy(DecompositionStrategy::Ego, 1);
        let (subs, used) = adapter.ingest(TOML_BIG).unwrap();
        // 11 nodes (big + 8 deps + tempdir + cc): star-shaped. With
        // hops = 1 every leaf's ego graph is {leaf, big} (size 2).
        assert!(!subs.is_empty());
        assert_eq!(used, "ego");
        for s in &subs {
            assert!(s.graph.n <= 7);
        }
    }

    #[test]
    fn workspace_intra_edges_detected() {
        let mut members = BTreeMap::new();
        members.insert(
            "core".to_string(),
            r#"[package]
name = "core"
version = "0.1.0"
edition = "2021"

[dependencies]
util = "1"
"#
            .to_string(),
        );
        members.insert(
            "util".to_string(),
            r#"[package]
name = "util"
version = "0.1.0"
edition = "2021"
"#
            .to_string(),
        );
        let envelope = serde_json::to_string(&serde_json::json!({
            "workspace_members": members
        }))
        .unwrap();
        let adapter = CargoDepsAdapter::new("workspace");
        let subs = adapter.to_input_graphs(&envelope).unwrap();
        assert_eq!(subs.len(), 1);
        // {core, util} = 2 nodes, 1 edge (intra-workspace).
        assert_eq!(subs[0].graph.n, 2);
        assert_eq!(subs[0].graph.edge_count(), 1);
    }
}

//! Standardised output format for the ingestion pipeline (Spec S1 §2.3).
//!
//! These types are write-only by design: an `IngestionReport` is produced
//! by the CLI, emitted as JSON, and read by downstream tooling (jq, etc.).
//! The nested [`crate::scan::ScanReport`] does not derive `Deserialize`
//! (Constraint 11.1 forbids modifications to `scan.rs`), so neither do
//! the output containers defined here.

use std::collections::HashMap;

use serde::Serialize;

use crate::error::ScanResult;
use crate::ingest::InputGraph;
use crate::scan::{scan_with_cache, S7Cache, ScanReport};

use super::{DomainAdapter, GraphOrigin, LabeledGraph};

/// One report per subgraph produced by an adapter.
#[derive(Debug, Clone, Serialize)]
pub struct SubgraphReport {
    pub origin: GraphOrigin,
    pub entity_type: String,
    pub member_labels: Vec<String>,
    pub scan_report: ScanReport,
    /// Catalog match (filled in when `--catalog-match` is requested).
    #[serde(skip_serializing_if = "Option::is_none")]
    pub catalog_id: Option<String>,
}

/// Aggregated statistics across all subgraphs.
#[derive(Debug, Clone, Default, Serialize)]
pub struct AggregatedFingerprints {
    /// How often each canonical hash appeared in the decomposition.
    pub hash_frequency: HashMap<String, usize>,
    /// How often each stabilizer order appeared.
    pub stabilizer_distribution: HashMap<usize, usize>,
    /// Average algebraic connectivity across all subgraphs.
    pub avg_algebraic_connectivity: f64,
    /// Number of subgraphs with a catalog hit.
    pub catalog_matches: usize,
}

/// Top-level JSON output for the `ingest` subcommand.
#[derive(Debug, Clone, Serialize)]
pub struct IngestionReport {
    pub adapter: String,
    pub source: String,
    /// Number of top-level entities the adapter produced before decomposition.
    pub total_entities: usize,
    /// Number of scanned subgraphs (after decomposition).
    pub total_subgraphs: usize,
    pub decomposition_strategy: String,
    pub subgraph_reports: Vec<SubgraphReport>,
    pub aggregated_fingerprints: AggregatedFingerprints,
}

/// Run an adapter end-to-end: parse → decompose → scan → aggregate.
pub fn run_adapter<A, F>(
    adapter: &A,
    raw: &str,
    source: &str,
    decomposition_strategy: &str,
    cache: &S7Cache,
    catalog_lookup: Option<&F>,
) -> ScanResult<IngestionReport>
where
    A: DomainAdapter,
    F: Fn(&InputGraph) -> Option<String>,
{
    let labeled = adapter.to_input_graphs(raw)?;
    run_labeled(
        adapter.name(),
        source,
        labeled,
        decomposition_strategy,
        cache,
        catalog_lookup,
    )
}

/// Scan an already-prepared set of labeled graphs.
///
/// `catalog_lookup`, if supplied, is called once per subgraph with the
/// `InputGraph` (not the hash) and should return the catalog id if any.
pub fn run_labeled<F>(
    adapter_name: &str,
    source: &str,
    labeled: Vec<LabeledGraph>,
    decomposition_strategy: &str,
    cache: &S7Cache,
    catalog_lookup: Option<&F>,
) -> ScanResult<IngestionReport>
where
    F: Fn(&InputGraph) -> Option<String>,
{
    let mut subgraph_reports = Vec::with_capacity(labeled.len());
    let mut hash_frequency: HashMap<String, usize> = HashMap::new();
    let mut stabilizer_distribution: HashMap<usize, usize> = HashMap::new();
    let mut ac_sum = 0.0f64;
    let mut catalog_matches = 0usize;

    for lg in &labeled {
        let scan_report = scan_with_cache(lg.graph.clone(), cache)?;
        *hash_frequency
            .entry(scan_report.canonical_hash.clone())
            .or_insert(0) += 1;
        *stabilizer_distribution
            .entry(scan_report.stabilizer_order)
            .or_insert(0) += 1;
        ac_sum += scan_report.algebraic_connectivity;
        let catalog_id = catalog_lookup.and_then(|f| f(&lg.graph));
        if catalog_id.is_some() {
            catalog_matches += 1;
        }
        subgraph_reports.push(SubgraphReport {
            origin: lg.origin.clone(),
            entity_type: lg.entity_type.clone(),
            member_labels: lg.graph.labels.clone().unwrap_or_default(),
            scan_report,
            catalog_id,
        });
    }

    let avg_algebraic_connectivity = if subgraph_reports.is_empty() {
        0.0
    } else {
        ac_sum / subgraph_reports.len() as f64
    };

    Ok(IngestionReport {
        adapter: adapter_name.to_string(),
        source: source.to_string(),
        total_entities: 1,
        total_subgraphs: subgraph_reports.len(),
        decomposition_strategy: decomposition_strategy.to_string(),
        subgraph_reports,
        aggregated_fingerprints: AggregatedFingerprints {
            hash_frequency,
            stabilizer_distribution,
            avg_algebraic_connectivity,
            catalog_matches,
        },
    })
}

//! Domain Adapter Layer (Spec S1 / Schicht 1 — Passive Sensor).
//!
//! Adapters convert real-world data sources (JSON graph dumps, edge lists,
//! Cargo dependency graphs, Rust module import graphs, state machines)
//! into [`InputGraph`] instances that the existing scan engine can consume.
//!
//! Every adapter implements the [`DomainAdapter`] trait and produces one
//! or more [`LabeledGraph`]s. Larger inputs (n > 7) are split into subgraphs
//! via [`decompose`]; each subgraph goes through the unchanged
//! [`crate::scan::scan_with_cache`] pipeline.

use serde::{Deserialize, Serialize};

use crate::error::ScanResult;
use crate::ingest::InputGraph;

pub mod decompose;
pub mod ingest_report;

pub mod cargo_deps;
pub mod edge_list;
pub mod json_graph;
pub mod rust_imports;
pub mod state_machine;

pub use cargo_deps::CargoDepsAdapter;
pub use decompose::{decompose, DecompositionStrategy, FullGraph};
pub use edge_list::EdgeListAdapter;
pub use ingest_report::{
    run_adapter, AggregatedFingerprints, IngestionReport, SubgraphReport,
};
pub use json_graph::JsonGraphAdapter;
pub use rust_imports::RustImportsAdapter;
pub use state_machine::StateMachineAdapter;

/// Unified interface for every ingestion adapter.
pub trait DomainAdapter {
    /// Adapter name (stable identifier used in CLI and reports).
    fn name(&self) -> &'static str;

    /// Expected input format (MIME type or file suffix, informational).
    fn format(&self) -> &'static str;

    /// Parse `raw` and convert it into one or more labeled graphs with
    /// n ≤ 7 nodes each (larger inputs are decomposed internally).
    fn to_input_graphs(&self, raw: &str) -> ScanResult<Vec<LabeledGraph>>;
}

/// An [`InputGraph`] enriched with provenance and entity-type information.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LabeledGraph {
    pub graph: InputGraph,
    pub origin: GraphOrigin,
    /// Domain-specific entity category ("table", "function", "state", ...).
    /// Multiple categories are comma-separated.
    pub entity_type: String,
}

/// Provenance metadata for a [`LabeledGraph`].
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GraphOrigin {
    /// File path, URL, or free-form identifier of the source.
    pub source: String,
    /// Location inside the source (line range, JSON key, ego pivot, …).
    pub location: String,
    /// ISO-8601 timestamp of extraction (UTC).
    pub extracted_at: String,
}

impl GraphOrigin {
    /// Build a `GraphOrigin` with the current UTC time.
    pub fn new(source: impl Into<String>, location: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            location: location.into(),
            extracted_at: now_iso8601(),
        }
    }
}

/// Simple dependency-free ISO-8601 UTC timestamp.
pub(crate) fn now_iso8601() -> String {
    use std::time::{SystemTime, UNIX_EPOCH};
    let secs = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_secs() as i64)
        .unwrap_or(0);
    // days since 1970-01-01
    let days = secs.div_euclid(86_400);
    let tod = secs.rem_euclid(86_400);
    let hh = tod / 3_600;
    let mm = (tod % 3_600) / 60;
    let ss = tod % 60;
    let (y, mo, d) = civil_from_days(days);
    format!(
        "{:04}-{:02}-{:02}T{:02}:{:02}:{:02}Z",
        y, mo, d, hh, mm, ss
    )
}

/// Howard Hinnant's civil-from-days algorithm (public domain).
fn civil_from_days(z: i64) -> (i32, u32, u32) {
    let z = z + 719_468;
    let era = if z >= 0 { z } else { z - 146_096 } / 146_097;
    let doe = (z - era * 146_097) as u64;
    let yoe = (doe - doe / 1_460 + doe / 36_524 - doe / 146_096) / 365;
    let y = yoe as i64 + era * 400;
    let doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    let mp = (5 * doy + 2) / 153;
    let d = (doy - (153 * mp + 2) / 5 + 1) as u32;
    let m = (if mp < 10 { mp + 3 } else { mp - 9 }) as u32;
    let y = y + if m <= 2 { 1 } else { 0 };
    (y as i32, m, d)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn iso8601_has_expected_shape() {
        let ts = now_iso8601();
        assert_eq!(ts.len(), 20);
        assert!(ts.ends_with('Z'));
        assert_eq!(&ts[4..5], "-");
        assert_eq!(&ts[7..8], "-");
        assert_eq!(&ts[10..11], "T");
    }
}

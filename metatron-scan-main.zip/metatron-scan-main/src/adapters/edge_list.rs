//! Adapter 2: Edge List (CSV/TSV) (Spec S1 §4).
//!
//! Minimum two columns: `from`, `to`. Optional third column with a
//! weight or edge type. Weights are discarded with a warning;
//! multi-edges collapse to one; self-loops are dropped with a warning.
//! Supports both CSV (`,`) and TSV (`\t`) — delimiter detection picks
//! whichever appears in the first line.

use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::error::{ScanError, ScanResult};

use super::decompose::{decompose, DecompositionStrategy, FullGraph};
use super::{DomainAdapter, LabeledGraph};

/// Detected delimiter.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum Delimiter {
    Comma,
    Tab,
}

impl Delimiter {
    fn as_byte(self) -> u8 {
        match self {
            Delimiter::Comma => b',',
            Delimiter::Tab => b'\t',
        }
    }
}

/// Edge-List adapter.
#[derive(Debug, Clone)]
pub struct EdgeListAdapter {
    pub source: String,
    pub strategy: DecompositionStrategy,
    pub hops: u32,
    /// Override auto-detection with a specific delimiter.
    pub force_delimiter: Option<Delimiter>,
    /// If true, the first row is interpreted as a header (default: auto).
    pub has_header: Option<bool>,
    /// Collected warnings from the most recent parse.
    pub warnings: Vec<String>,
}

impl EdgeListAdapter {
    pub fn new(source: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            strategy: DecompositionStrategy::Auto,
            hops: 2,
            force_delimiter: None,
            has_header: None,
            warnings: Vec::new(),
        }
    }

    pub fn with_strategy(mut self, s: DecompositionStrategy, hops: u32) -> Self {
        self.strategy = s;
        self.hops = hops;
        self
    }

    /// Parse + decompose.
    pub fn ingest(&mut self, raw: &str) -> ScanResult<(Vec<LabeledGraph>, &'static str)> {
        self.warnings.clear();
        let (full, entity_type) = self.parse_full_graph(raw)?;
        decompose(&full, self.strategy, self.hops, &self.source, &entity_type)
    }

    fn parse_full_graph(&mut self, raw: &str) -> ScanResult<(FullGraph, String)> {
        let delim = self
            .force_delimiter
            .unwrap_or_else(|| detect_delimiter(raw));
        let mut reader = csv::ReaderBuilder::new()
            .delimiter(delim.as_byte())
            .flexible(true)
            .has_headers(self.has_header.unwrap_or_else(|| header_is_probable(raw, delim)))
            .from_reader(raw.as_bytes());

        let mut label_to_idx: HashMap<String, usize> = HashMap::new();
        let mut labels: Vec<String> = Vec::new();
        let mut raw_edges: Vec<(usize, usize)> = Vec::new();
        let mut edge_type_hits: std::collections::BTreeSet<String> =
            std::collections::BTreeSet::new();
        let mut weight_seen = false;
        let mut self_loops = 0usize;
        let mut multi_edges = 0usize;
        let mut seen_pairs: std::collections::HashSet<(usize, usize)> =
            std::collections::HashSet::new();

        for (i, rec) in reader.records().enumerate() {
            let rec = rec.map_err(|e| {
                ScanError::AdapterError(format!("edge-list: row {i}: {e}"))
            })?;
            if rec.len() < 2 {
                return Err(ScanError::AdapterError(format!(
                    "edge-list: row {i} has {} columns, need ≥ 2",
                    rec.len()
                )));
            }
            let from = rec.get(0).unwrap().trim().to_string();
            let to = rec.get(1).unwrap().trim().to_string();
            if from.is_empty() || to.is_empty() {
                return Err(ScanError::AdapterError(format!(
                    "edge-list: row {i} has empty label"
                )));
            }

            if from == to {
                self_loops += 1;
                continue;
            }

            let a = get_or_insert(&mut label_to_idx, &mut labels, &from);
            let b = get_or_insert(&mut label_to_idx, &mut labels, &to);
            let pair = if a < b { (a, b) } else { (b, a) };
            if !seen_pairs.insert(pair) {
                multi_edges += 1;
                continue;
            }
            raw_edges.push((a, b));

            if let Some(extra) = rec.get(2) {
                let extra = extra.trim();
                if !extra.is_empty() {
                    if extra.parse::<f64>().is_ok() {
                        weight_seen = true;
                    } else {
                        edge_type_hits.insert(extra.to_string());
                    }
                }
            }
        }

        if weight_seen {
            self.warnings
                .push("edge-list: weights detected and discarded (unweighted scan engine)".into());
        }
        if self_loops > 0 {
            self.warnings.push(format!(
                "edge-list: removed {self_loops} self-loop(s)"
            ));
        }
        if multi_edges > 0 {
            self.warnings.push(format!(
                "edge-list: collapsed {multi_edges} multi-edge(s)"
            ));
        }

        if labels.is_empty() {
            return Err(ScanError::AdapterError("edge-list: no edges found".into()));
        }

        let entity_type = if edge_type_hits.is_empty() {
            "edge".into()
        } else {
            edge_type_hits
                .into_iter()
                .collect::<Vec<_>>()
                .join(",")
        };

        Ok((FullGraph::from_parts(labels, raw_edges), entity_type))
    }
}

impl DomainAdapter for EdgeListAdapter {
    fn name(&self) -> &'static str {
        "edge-list"
    }

    fn format(&self) -> &'static str {
        "text/csv"
    }

    fn to_input_graphs(&self, raw: &str) -> ScanResult<Vec<LabeledGraph>> {
        let mut me = self.clone();
        me.ingest(raw).map(|(g, _)| g)
    }
}

fn get_or_insert(
    map: &mut HashMap<String, usize>,
    labels: &mut Vec<String>,
    s: &str,
) -> usize {
    if let Some(&i) = map.get(s) {
        return i;
    }
    let i = labels.len();
    labels.push(s.to_string());
    map.insert(s.to_string(), i);
    i
}

fn detect_delimiter(raw: &str) -> Delimiter {
    let first_line = raw.lines().next().unwrap_or("");
    let tabs = first_line.matches('\t').count();
    let commas = first_line.matches(',').count();
    if tabs > commas {
        Delimiter::Tab
    } else {
        Delimiter::Comma
    }
}

/// Heuristic: the file has a header if the first row's first two fields
/// cannot both be parsed as structurally trivial values (they're string-ish).
/// We consider the header present iff either field equals "from" or "to"
/// (case-insensitive), else we assume no header to play it safe.
fn header_is_probable(raw: &str, delim: Delimiter) -> bool {
    let first = raw.lines().next().unwrap_or("").to_lowercase();
    let parts: Vec<&str> = first.split(delim.as_byte() as char).collect();
    if parts.len() < 2 {
        return false;
    }
    let a = parts[0].trim();
    let b = parts[1].trim();
    a == "from" || a == "source" || a == "src" || b == "to" || b == "target" || b == "dst"
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_success_csv_with_header() {
        let raw = "from,to,weight\nalice,bob,1.0\nbob,charlie,1.0\nalice,charlie,1.0\n";
        let mut a = EdgeListAdapter::new("inline.csv");
        let subs = a.ingest(raw).unwrap().0;
        assert_eq!(subs.len(), 1);
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 3);
        assert!(a.warnings.iter().any(|w| w.contains("weights")));
    }

    #[test]
    fn parse_failure_too_few_columns() {
        let raw = "a\n";
        let mut a = EdgeListAdapter::new("inline.csv");
        assert!(a.ingest(raw).is_err());
    }

    #[test]
    fn self_loops_and_multi_edges_warn_and_drop() {
        let raw = "from,to\na,a\na,b\nb,a\n";
        let mut a = EdgeListAdapter::new("inline.csv");
        let subs = a.ingest(raw).unwrap().0;
        assert_eq!(subs[0].graph.edge_count(), 1);
        assert!(a.warnings.iter().any(|w| w.contains("self-loop")));
        assert!(a.warnings.iter().any(|w| w.contains("multi-edge")));
    }

    #[test]
    fn tsv_auto_detect() {
        let raw = "from\tto\na\tb\nb\tc\n";
        let mut a = EdgeListAdapter::new("inline.tsv");
        let subs = a.ingest(raw).unwrap().0;
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 2);
    }

    #[test]
    fn round_trip_triangle() {
        let raw = "a,b\nb,c\na,c\n";
        let mut a = EdgeListAdapter::new("inline.csv");
        let subs = a.ingest(raw).unwrap().0;
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 3);
    }

    #[test]
    fn edge_type_is_captured() {
        let raw = "from,to,type\nalice,bob,reports_to\nbob,carol,mentors\n";
        let mut a = EdgeListAdapter::new("inline.csv");
        let subs = a.ingest(raw).unwrap().0;
        assert!(subs[0].entity_type.contains("reports_to"));
        assert!(subs[0].entity_type.contains("mentors"));
    }
}

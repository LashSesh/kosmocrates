//! Adapter 5: State Machine (JSON) (Spec S1 §7).
//!
//! States become nodes; transitions become undirected edges. Direction
//! is lost — a warning is emitted (collected on the adapter) since the
//! scan engine is undirected. Event labels are concatenated into the
//! resulting `entity_type` field.

use std::collections::BTreeSet;

use serde::{Deserialize, Serialize};

use crate::error::{ScanError, ScanResult};

use super::decompose::{decompose, DecompositionStrategy, FullGraph};
use super::{DomainAdapter, LabeledGraph};

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StateMachineDoc {
    #[serde(default)]
    pub initial: Option<String>,
    pub states: Vec<String>,
    #[serde(default)]
    pub transitions: Vec<StateTransition>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StateTransition {
    pub from: String,
    pub to: String,
    #[serde(default)]
    pub event: Option<String>,
}

#[derive(Debug, Clone)]
pub struct StateMachineAdapter {
    pub source: String,
    pub strategy: DecompositionStrategy,
    pub hops: u32,
    pub warnings: Vec<String>,
}

impl StateMachineAdapter {
    pub fn new(source: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            strategy: DecompositionStrategy::Auto,
            hops: 2,
            warnings: Vec::new(),
        }
    }

    pub fn with_strategy(mut self, s: DecompositionStrategy, hops: u32) -> Self {
        self.strategy = s;
        self.hops = hops;
        self
    }

    pub fn ingest(&mut self, raw: &str) -> ScanResult<(Vec<LabeledGraph>, &'static str)> {
        self.warnings.clear();
        let doc: StateMachineDoc = serde_json::from_str(raw).map_err(|e| {
            ScanError::AdapterError(format!("state-machine: parse error: {e}"))
        })?;

        if doc.states.is_empty() {
            return Err(ScanError::AdapterError(
                "state-machine: no states declared".into(),
            ));
        }

        let mut seen = BTreeSet::new();
        for s in &doc.states {
            if !seen.insert(s.clone()) {
                return Err(ScanError::AdapterError(format!(
                    "state-machine: duplicate state '{s}'"
                )));
            }
        }

        // Map state -> index.
        let labels: Vec<String> = doc.states.clone();
        let mut idx = std::collections::HashMap::new();
        for (i, l) in labels.iter().enumerate() {
            idx.insert(l.clone(), i);
        }

        let mut raw_edges = Vec::new();
        let mut events: BTreeSet<String> = BTreeSet::new();
        let mut directed_hits = 0;
        for tr in &doc.transitions {
            let a = *idx.get(&tr.from).ok_or_else(|| {
                ScanError::AdapterError(format!("state-machine: unknown state '{}'", tr.from))
            })?;
            let b = *idx.get(&tr.to).ok_or_else(|| {
                ScanError::AdapterError(format!("state-machine: unknown state '{}'", tr.to))
            })?;
            if a == b {
                continue; // self-loops dropped silently (typical for retry transitions)
            }
            raw_edges.push((a, b));
            directed_hits += 1;
            if let Some(e) = &tr.event {
                if !e.is_empty() {
                    events.insert(e.clone());
                }
            }
        }
        if directed_hits > 0 {
            self.warnings.push(
                "state-machine: transition direction discarded (scan engine is undirected)"
                    .into(),
            );
        }

        let full = FullGraph::from_parts(labels, raw_edges);
        let entity_type = if events.is_empty() {
            "state".into()
        } else {
            let mut v: Vec<String> = vec!["state".into()];
            v.extend(events);
            v.join(",")
        };
        decompose(&full, self.strategy, self.hops, &self.source, &entity_type)
    }
}

impl DomainAdapter for StateMachineAdapter {
    fn name(&self) -> &'static str {
        "state-machine"
    }

    fn format(&self) -> &'static str {
        "application/json"
    }

    fn to_input_graphs(&self, raw: &str) -> ScanResult<Vec<LabeledGraph>> {
        let mut me = self.clone();
        me.ingest(raw).map(|(g, _)| g)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    const MACHINE: &str = r#"{
        "initial": "idle",
        "states": ["idle", "loading", "ready", "error"],
        "transitions": [
            {"from": "idle", "to": "loading", "event": "start"},
            {"from": "loading", "to": "ready", "event": "success"},
            {"from": "loading", "to": "error", "event": "fail"},
            {"from": "error", "to": "idle", "event": "reset"},
            {"from": "ready", "to": "idle", "event": "reset"}
        ]
    }"#;

    #[test]
    fn parse_success_four_state_machine() {
        let mut a = StateMachineAdapter::new("inline.json");
        let subs = a.ingest(MACHINE).unwrap().0;
        assert_eq!(subs.len(), 1);
        assert_eq!(subs[0].graph.n, 4);
        assert_eq!(subs[0].graph.edge_count(), 5);
        assert!(subs[0].entity_type.contains("state"));
        assert!(subs[0].entity_type.contains("start"));
        assert!(a.warnings.iter().any(|w| w.contains("direction")));
    }

    #[test]
    fn parse_failure_missing_states() {
        let mut a = StateMachineAdapter::new("inline.json");
        let err = a.ingest(r#"{"states": []}"#).unwrap_err();
        assert!(matches!(err, ScanError::AdapterError(_)));
    }

    #[test]
    fn unknown_transition_target_rejected() {
        let mut a = StateMachineAdapter::new("inline.json");
        let raw = r#"{"states":["a"],"transitions":[{"from":"a","to":"ghost"}]}"#;
        assert!(a.ingest(raw).is_err());
    }

    #[test]
    fn round_trip_two_state_machine() {
        let mut a = StateMachineAdapter::new("inline.json");
        let raw = r#"{"states":["on","off"],"transitions":[{"from":"off","to":"on","event":"flip"},{"from":"on","to":"off","event":"flip"}]}"#;
        let subs = a.ingest(raw).unwrap().0;
        assert_eq!(subs[0].graph.n, 2);
        assert_eq!(subs[0].graph.edge_count(), 1);
    }
}

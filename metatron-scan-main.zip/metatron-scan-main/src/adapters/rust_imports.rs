//! Adapter 4: Rust Module Import Graph (Spec S1 §6).
//!
//! Walks a Rust source tree, treating every `.rs` file as a node labelled
//! by its module path (e.g. `crate::scan::orbit`). A `use crate::foo::bar`
//! in module X produces an edge X → `foo::bar`. External crates and
//! `std/core/alloc` are ignored.
//!
//! Parsing uses a light regex (Spec S1 Constraint 6.1 allows this for
//! v1.0). Macro-use and re-exports are not special-cased — the heuristic
//! is intentionally simple and robust to missing `syn`.
//!
//! The adapter supports two input shapes:
//!
//! * A raw string whose lines are `"module_path :: pseudo/content"`
//!   (used by tests).
//! * A JSON envelope: `{"files": [{"path": "...", "source": "..."}, ...]}`
//!   — this is the natural shape when the CLI walks a directory.

use std::collections::{BTreeMap, BTreeSet, HashSet};

use serde::{Deserialize, Serialize};

use crate::error::{ScanError, ScanResult};

use super::decompose::{decompose, DecompositionStrategy, FullGraph};
use super::{DomainAdapter, LabeledGraph};

/// A Rust source file with its module path.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RustFile {
    /// Module path relative to the crate root, e.g. `crate::scan::orbit`.
    pub module: String,
    /// Raw source.
    pub source: String,
}

/// Envelope for bulk submission.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct RustImportsInput {
    pub files: Vec<RustFile>,
}

/// Rust module import graph adapter.
#[derive(Debug, Clone)]
pub struct RustImportsAdapter {
    pub source: String,
    pub strategy: DecompositionStrategy,
    pub hops: u32,
    /// Additional crate names to treat as "internal" (besides `crate`,
    /// `self`, and `super`). Useful when scanning a workspace.
    pub internal_crates: BTreeSet<String>,
}

impl RustImportsAdapter {
    pub fn new(source: impl Into<String>) -> Self {
        Self {
            source: source.into(),
            strategy: DecompositionStrategy::Auto,
            hops: 2,
            internal_crates: BTreeSet::new(),
        }
    }

    pub fn with_strategy(mut self, s: DecompositionStrategy, hops: u32) -> Self {
        self.strategy = s;
        self.hops = hops;
        self
    }

    pub fn with_internal_crate(mut self, name: impl Into<String>) -> Self {
        self.internal_crates.insert(name.into());
        self
    }

    /// Ingest a list of `RustFile`s directly, skipping the JSON envelope.
    pub fn ingest_files(
        &self,
        files: &[RustFile],
    ) -> ScanResult<(Vec<LabeledGraph>, &'static str)> {
        let full = self.build_graph(files)?;
        decompose(&full, self.strategy, self.hops, &self.source, "rust-module")
    }

    pub fn ingest(&self, raw: &str) -> ScanResult<(Vec<LabeledGraph>, &'static str)> {
        let envelope: RustImportsInput = serde_json::from_str(raw).map_err(|e| {
            ScanError::AdapterError(format!("rust-imports: envelope parse: {e}"))
        })?;
        self.ingest_files(&envelope.files)
    }

    fn build_graph(&self, files: &[RustFile]) -> ScanResult<FullGraph> {
        if files.is_empty() {
            return Err(ScanError::AdapterError("rust-imports: no files".into()));
        }

        let own_modules: HashSet<String> = files.iter().map(|f| f.module.clone()).collect();
        let mut nodes = BTreeSet::<String>::new();
        let mut edges = BTreeSet::<(String, String)>::new();

        for f in files {
            nodes.insert(f.module.clone());
            for target in extract_imports(&f.source, &f.module, &self.internal_crates) {
                let resolved = resolve_target(&target, &f.module, &own_modules);
                if let Some(dst) = resolved {
                    if dst == f.module {
                        continue;
                    }
                    nodes.insert(dst.clone());
                    edges.insert(order_pair(f.module.clone(), dst));
                }
            }
        }

        let labels: Vec<String> = nodes.into_iter().collect();
        let idx: BTreeMap<String, usize> = labels
            .iter()
            .enumerate()
            .map(|(i, l)| (l.clone(), i))
            .collect();
        let raw_edges: Vec<(usize, usize)> = edges
            .iter()
            .filter_map(|(a, b)| {
                let ia = idx.get(a)?;
                let ib = idx.get(b)?;
                Some((*ia, *ib))
            })
            .collect();
        Ok(FullGraph::from_parts(labels, raw_edges))
    }
}

fn order_pair(a: String, b: String) -> (String, String) {
    if a < b {
        (a, b)
    } else {
        (b, a)
    }
}

impl DomainAdapter for RustImportsAdapter {
    fn name(&self) -> &'static str {
        "rust-imports"
    }

    fn format(&self) -> &'static str {
        "text/x-rust"
    }

    fn to_input_graphs(&self, raw: &str) -> ScanResult<Vec<LabeledGraph>> {
        self.ingest(raw).map(|(g, _)| g)
    }
}

/// Extract imports of the form `use <path>(::...|::{..}|::*);` and return
/// the first segment path we care about (internal only).
pub(crate) fn extract_imports(
    source: &str,
    _module: &str,
    internal_crates: &BTreeSet<String>,
) -> Vec<String> {
    // Strip line comments (`// ...`) — cheap and enough to avoid picking
    // up commented-out `use` statements.
    let mut out = Vec::new();
    for raw_line in source.lines() {
        let line = match raw_line.find("//") {
            Some(i) => &raw_line[..i],
            None => raw_line,
        };
        let trimmed = line.trim_start();
        let Some(rest) = trimmed.strip_prefix("use ").or_else(|| trimmed.strip_prefix("pub use ")) else {
            continue;
        };
        // Find the matching `;` on this line (we don't handle multiline use).
        let Some(end) = rest.find(';') else {
            continue;
        };
        let body = rest[..end].trim();
        for target in split_use_body(body) {
            if is_external(&target, internal_crates) {
                continue;
            }
            out.push(target);
        }
    }
    out
}

/// Expand `a::{b, c::{d, e}}` into `["a::b", "a::c::d", "a::c::e"]`.
fn split_use_body(body: &str) -> Vec<String> {
    // Simple greedy brace expander. If no braces, take the path up to the
    // first ` as ` (alias) or whole thing.
    fn strip_alias(p: &str) -> String {
        p.split(" as ").next().unwrap_or(p).trim().to_string()
    }

    let Some(open) = body.find('{') else {
        return vec![strip_alias(body)];
    };
    let prefix = body[..open].trim_end_matches("::").trim().to_string();
    let close = match matching_brace(body, open) {
        Some(c) => c,
        None => return vec![strip_alias(body)],
    };
    let inner = &body[open + 1..close];
    let mut results = Vec::new();
    for part in split_top_level_commas(inner) {
        let sub = part.trim();
        if sub.is_empty() || sub == "self" {
            results.push(prefix.clone());
            continue;
        }
        let joined = if prefix.is_empty() {
            sub.to_string()
        } else {
            format!("{prefix}::{sub}")
        };
        results.extend(split_use_body(&joined));
    }
    results
}

fn matching_brace(s: &str, open: usize) -> Option<usize> {
    let bytes = s.as_bytes();
    let mut depth = 0i32;
    for (i, &c) in bytes.iter().enumerate().skip(open) {
        if c == b'{' {
            depth += 1;
        } else if c == b'}' {
            depth -= 1;
            if depth == 0 {
                return Some(i);
            }
        }
    }
    None
}

fn split_top_level_commas(s: &str) -> Vec<String> {
    let mut out = Vec::new();
    let mut depth = 0i32;
    let mut buf = String::new();
    for c in s.chars() {
        match c {
            '{' => {
                depth += 1;
                buf.push(c);
            }
            '}' => {
                depth -= 1;
                buf.push(c);
            }
            ',' if depth == 0 => {
                out.push(std::mem::take(&mut buf));
            }
            _ => buf.push(c),
        }
    }
    if !buf.trim().is_empty() {
        out.push(buf);
    }
    out
}

fn is_external(path: &str, internal_crates: &BTreeSet<String>) -> bool {
    let head = path.split("::").next().unwrap_or("").trim();
    match head {
        "crate" | "self" | "super" => false,
        "std" | "core" | "alloc" => true,
        other => !internal_crates.contains(other),
    }
}

/// Resolve an imported path to a concrete target module, if any of the
/// files we know about match.
///
/// Resolution rules:
///   * `crate::x::y` → `crate::x::y` if that exact module exists; else
///     truncate by one segment until a match is found.
///   * `self::x` → resolve relative to `module`.
///   * `super::x` → resolve relative to the parent of `module`.
fn resolve_target(
    target: &str,
    from_module: &str,
    own_modules: &HashSet<String>,
) -> Option<String> {
    let t = target.trim();
    if t.is_empty() {
        return None;
    }
    let head = t.split("::").next().unwrap_or("");
    let expanded = match head {
        "crate" => t.to_string(),
        "self" => {
            let tail = t.strip_prefix("self").unwrap_or("");
            let tail = tail.strip_prefix("::").unwrap_or(tail);
            if tail.is_empty() {
                from_module.to_string()
            } else {
                format!("{from_module}::{tail}")
            }
        }
        "super" => {
            let parent = parent_module(from_module);
            let tail = t.strip_prefix("super").unwrap_or("");
            let tail = tail.strip_prefix("::").unwrap_or(tail);
            if tail.is_empty() {
                parent
            } else {
                format!("{parent}::{tail}")
            }
        }
        _ => format!("crate::{t}"),
    };
    // Truncate until we find a real module.
    let mut candidate = expanded;
    loop {
        if own_modules.contains(&candidate) {
            return Some(candidate);
        }
        let pos = candidate.rfind("::")?;
        candidate.truncate(pos);
        if candidate == "crate" {
            return None;
        }
    }
}

fn parent_module(module: &str) -> String {
    match module.rfind("::") {
        Some(i) => module[..i].to_string(),
        None => module.to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn env(files: &[(&str, &str)]) -> String {
        serde_json::to_string(&serde_json::json!({
            "files": files.iter().map(|(m, s)| serde_json::json!({
                "module": m,
                "source": s,
            })).collect::<Vec<_>>()
        }))
        .unwrap()
    }

    #[test]
    fn parse_success_minimal_chain() {
        let raw = env(&[
            ("crate::a", "use crate::b;\nuse crate::c;\n"),
            ("crate::b", "pub fn x(){}"),
            ("crate::c", "use crate::b;"),
        ]);
        let adapter = RustImportsAdapter::new("synthetic");
        let subs = adapter.to_input_graphs(&raw).unwrap();
        assert_eq!(subs.len(), 1);
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 3);
    }

    #[test]
    fn parse_failure_bad_json() {
        let adapter = RustImportsAdapter::new("synthetic");
        assert!(adapter.to_input_graphs("not json").is_err());
    }

    #[test]
    fn external_imports_ignored() {
        let raw = env(&[
            ("crate::a", "use serde::Serialize;\nuse std::collections::HashMap;\nuse crate::b;\n"),
            ("crate::b", ""),
        ]);
        let adapter = RustImportsAdapter::new("synthetic");
        let subs = adapter.to_input_graphs(&raw).unwrap();
        assert_eq!(subs[0].graph.n, 2);
        assert_eq!(subs[0].graph.edge_count(), 1);
    }

    #[test]
    fn grouped_imports_expand() {
        let raw = env(&[
            (
                "crate::root",
                "use crate::{a, b::{c, d}};\n",
            ),
            ("crate::a", ""),
            ("crate::b::c", ""),
            ("crate::b::d", ""),
        ]);
        let adapter = RustImportsAdapter::new("synthetic");
        let subs = adapter.to_input_graphs(&raw).unwrap();
        assert_eq!(subs[0].graph.n, 4);
        assert_eq!(subs[0].graph.edge_count(), 3);
    }

    #[test]
    fn self_and_super_resolved() {
        let raw = env(&[
            ("crate::a::inner", "use super::other;\nuse self::deeper;"),
            ("crate::a::other", ""),
            ("crate::a::inner::deeper", ""),
        ]);
        let adapter = RustImportsAdapter::new("synthetic");
        let subs = adapter.to_input_graphs(&raw).unwrap();
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 2);
    }

    #[test]
    fn round_trip_triangle_modules() {
        let raw = env(&[
            ("crate::a", "use crate::b;\nuse crate::c;\n"),
            ("crate::b", "use crate::c;\n"),
            ("crate::c", ""),
        ]);
        let adapter = RustImportsAdapter::new("synthetic");
        let subs = adapter.to_input_graphs(&raw).unwrap();
        assert_eq!(subs[0].graph.n, 3);
        assert_eq!(subs[0].graph.edge_count(), 3);
    }
}

pub mod error;
pub mod geometry;
pub mod scaffold;
pub mod group;
pub mod ingest;
pub mod embed;
pub mod orbit;
pub mod stabilizer;
pub mod complement;
pub mod spectrum;
pub mod platonic;
pub mod bitgraph;
pub mod bitgraph_n;
pub mod properties;
pub mod scan;
pub mod catalog;
pub mod analysis;
pub mod export;
pub mod adapters;

pub use error::{ScanError, ScanResult};
pub use ingest::InputGraph;
pub use scan::{scan, scan_with_cache, ScanReport, S7Cache};
pub use export::{
    catalog_to_csv, catalog_to_json, report_to_json, report_to_json_compact, write_catalog_json,
};
pub use catalog::{
    build_catalog, build_catalog_for_n, build_catalog_orderly, find_in_catalog, oeis_a000055,
    oeis_a000088, oeis_a000171, oeis_a001349, oeis_a003400, oeis_a005470, oeis_a005840,
    oeis_a033995, CatalogEntry, CatalogStats, PeriodicTable,
};
pub use bitgraph::{S7BitCache, fast_orbit};
pub use properties::{compute_properties, GraphProperties};
pub use analysis::{
    cospectral_analysis, cospectral_distinguishers, full_analysis, matrix_power_analysis,
    platonic_correlation, scaffold_invariants, self_complementary_analysis, spectral_distribution,
    CospectralAnalysis, CospectralDistinguisher, FullAnalysis, MatrixPowerAnalysis,
    PlatonicCorrelationAnalysis, ScaffoldInvariantAnalysis, SelfComplementaryAnalysis,
    SpectralDistribution,
};

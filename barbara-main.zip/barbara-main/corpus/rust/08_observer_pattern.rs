/// Event emitter implementing the observer pattern with typed events.
///
/// Supports registering multiple listeners per event, emitting events
/// with data, and removing listeners by ID.
use std::collections::HashMap;

type ListenerId = usize;

/// An event carrying a string payload.
#[derive(Debug, Clone)]
struct Event { name: String, data: String, timestamp: u64 }

/// Event emitter that manages listeners and dispatches events.
struct EventEmitter {
    listeners: HashMap<String, Vec<(ListenerId, Box<dyn Fn(&Event) -> String>)>>,
    next_id: ListenerId,
    log: Vec<(String, ListenerId, String)>,
    max_listeners: usize,
}

impl EventEmitter {
    fn new(max_listeners: usize) -> Self {
        EventEmitter { listeners: HashMap::new(), next_id: 1, log: Vec::new(), max_listeners }
    }

    /// Registers a listener for the given event name. Returns the listener ID.
    fn on<F: Fn(&Event) -> String + 'static>(&mut self, event: &str, cb: F) -> Result<ListenerId, String> {
        let entry = self.listeners.entry(event.to_string()).or_default();
        if entry.len() >= self.max_listeners {
            return Err(format!("Max listeners ({}) reached for '{}'", self.max_listeners, event));
        }
        let id = self.next_id;
        self.next_id += 1;
        entry.push((id, Box::new(cb)));
        Ok(id)
    }

    /// Removes a listener by ID. Returns true if found and removed.
    fn off(&mut self, listener_id: ListenerId) -> bool {
        for listeners in self.listeners.values_mut() {
            let before = listeners.len();
            listeners.retain(|(id, _)| *id != listener_id);
            if listeners.len() < before { return true; }
        }
        false
    }

    /// Emits an event, calling all registered listeners. Returns count notified.
    fn emit(&mut self, event_name: &str, data: &str, timestamp: u64) -> usize {
        let event = Event { name: event_name.into(), data: data.into(), timestamp };
        let empty = Vec::new();
        let listeners = self.listeners.get(event_name).unwrap_or(&empty);
        let results: Vec<_> = listeners.iter()
            .map(|(id, cb)| (*id, cb(&event))).collect();
        let count = results.len();
        for (id, response) in results {
            self.log.push((event_name.to_string(), id, response));
        }
        count
    }

    fn listener_count(&self, event: &str) -> usize {
        self.listeners.get(event).map_or(0, |v| v.len())
    }

    fn event_names(&self) -> Vec<String> {
        self.listeners.iter().filter(|(_, v)| !v.is_empty()).map(|(k, _)| k.clone()).collect()
    }

    fn get_log(&self) -> &[(String, ListenerId, String)] { &self.log }
}

fn main() {
    let mut emitter = EventEmitter::new(5);

    let id1 = emitter.on("user:login", |e| format!("Logger: {} logged in", e.data)).unwrap();
    let _id2 = emitter.on("user:login", |e| format!("Audit: login at ts={}", e.timestamp)).unwrap();
    let _id3 = emitter.on("user:logout", |e| format!("Logger: {} logged out", e.data)).unwrap();

    println!("Registered listeners:");
    for name in emitter.event_names() {
        println!("  {}: {} listeners", name, emitter.listener_count(&name));
    }

    let n = emitter.emit("user:login", "alice", 1000);
    println!("\nEmitted user:login, notified {}", n);
    emitter.emit("user:login", "bob", 1001);
    emitter.emit("user:logout", "alice", 1002);

    let n = emitter.emit("unknown", "data", 1003);
    assert_eq!(n, 0);

    // Remove listener and verify
    assert!(emitter.off(id1));
    assert!(!emitter.off(id1));
    let n = emitter.emit("user:login", "carol", 1004);
    println!("After removal, notified {}", n);
    assert_eq!(n, 1);

    println!("\nEvent log ({} entries):", emitter.get_log().len());
    for (name, id, resp) in emitter.get_log() {
        println!("  [{}] listener {}: {}", name, id, resp);
    }

    // Test max listeners
    for i in 0..5 {
        emitter.on("flood", move |_| format!("handler {}", i)).unwrap();
    }
    let result = emitter.on("flood", |_| "overflow".into());
    assert!(result.is_err());
    println!("\nMax listener limit enforced: {}", result.unwrap_err());
}

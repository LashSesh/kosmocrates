/// Fibonacci sequence implementations with memoization and iterative approaches.
///
/// Provides both recursive (memoized) and iterative fibonacci computation,
/// along with helper utilities for generating sequences and checking membership.
use std::collections::HashMap;

/// Computes the nth Fibonacci number using recursion with memoization.
///
/// Uses a HashMap cache to avoid redundant computation, reducing
/// time complexity from O(2^n) to O(n).
fn fibonacci_memo(n: u64, cache: &mut HashMap<u64, u64>) -> u64 {
    if n <= 1 {
        return n;
    }
    if let Some(&val) = cache.get(&n) {
        return val;
    }
    let result = fibonacci_memo(n - 1, cache) + fibonacci_memo(n - 2, cache);
    cache.insert(n, result);
    result
}

/// Computes the nth Fibonacci number iteratively.
///
/// Uses constant space and linear time, making it suitable for large values
/// of n (up to the limits of u64 overflow).
fn fibonacci_iterative(n: u64) -> u64 {
    if n <= 1 {
        return n;
    }
    let mut prev = 0u64;
    let mut curr = 1u64;
    for _ in 2..=n {
        let next = prev + curr;
        prev = curr;
        curr = next;
    }
    curr
}

/// Generates a Vec containing the first `count` Fibonacci numbers.
fn fibonacci_sequence(count: usize) -> Vec<u64> {
    let mut cache = HashMap::new();
    (0..count as u64).map(|i| fibonacci_memo(i, &mut cache)).collect()
}

/// Returns true if `value` is a Fibonacci number.
///
/// Uses the mathematical property that n is a Fibonacci number if and only if
/// one of (5*n^2 + 4) or (5*n^2 - 4) is a perfect square.
fn is_fibonacci(value: u64) -> bool {
    let check = |x: u64| {
        let s = (x as f64).sqrt() as u64;
        s * s == x
    };
    let sq = value * value * 5;
    check(sq + 4) || check(sq.saturating_sub(4))
}

/// Returns the index of the first Fibonacci number greater than or equal to `target`.
fn fibonacci_index_at_least(target: u64) -> u64 {
    let mut prev = 0u64;
    let mut curr = 1u64;
    let mut index = 1u64;
    while curr < target {
        let next = prev + curr;
        prev = curr;
        curr = next;
        index += 1;
    }
    if target == 0 {
        0
    } else {
        index
    }
}

fn main() {
    let mut cache = HashMap::new();

    // Demonstrate memoized fibonacci
    println!("Memoized fibonacci(10) = {}", fibonacci_memo(10, &mut cache));
    println!("Memoized fibonacci(20) = {}", fibonacci_memo(20, &mut cache));
    println!("Cache size: {}", cache.len());

    // Demonstrate iterative fibonacci
    println!("Iterative fibonacci(10) = {}", fibonacci_iterative(10));
    println!("Iterative fibonacci(20) = {}", fibonacci_iterative(20));

    // Generate a sequence
    let seq = fibonacci_sequence(15);
    println!("First 15 Fibonacci numbers: {:?}", seq);

    // Check membership
    for &val in &[0, 1, 5, 8, 10, 13, 21] {
        println!("{} is fibonacci: {}", val, is_fibonacci(val));
    }

    // Find index for target
    println!("Index at least 100: {}", fibonacci_index_at_least(100));
    println!("Index at least 1: {}", fibonacci_index_at_least(1));

    // Verify both implementations agree
    for i in 0..20 {
        let memo_val = fibonacci_memo(i, &mut cache);
        let iter_val = fibonacci_iterative(i);
        assert_eq!(memo_val, iter_val, "Mismatch at index {}", i);
    }
    println!("All implementations agree for n=0..19");
}

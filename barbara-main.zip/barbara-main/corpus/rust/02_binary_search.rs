/// Binary search implementations: iterative, recursive, and bound-finding variants.
///
/// All functions operate on sorted slices and return Option-based results
/// to handle the case where the target is not found.

/// Iterative binary search returning the index of `target` in a sorted slice.
fn binary_search_iterative(arr: &[i64], target: i64) -> Option<usize> {
    let mut low = 0usize;
    let mut high = arr.len();
    while low < high {
        let mid = low + (high - low) / 2;
        match arr[mid].cmp(&target) {
            std::cmp::Ordering::Equal => return Some(mid),
            std::cmp::Ordering::Less => low = mid + 1,
            std::cmp::Ordering::Greater => high = mid,
        }
    }
    None
}

/// Recursive binary search returning the index of `target` in a sorted slice.
fn binary_search_recursive(arr: &[i64], target: i64, low: usize, high: usize) -> Option<usize> {
    if low >= high {
        return None;
    }
    let mid = low + (high - low) / 2;
    match arr[mid].cmp(&target) {
        std::cmp::Ordering::Equal => Some(mid),
        std::cmp::Ordering::Less => binary_search_recursive(arr, target, mid + 1, high),
        std::cmp::Ordering::Greater => binary_search_recursive(arr, target, low, mid),
    }
}

/// Finds the index of the first element >= `target` (lower bound).
///
/// Returns `arr.len()` if all elements are less than `target`.
fn lower_bound(arr: &[i64], target: i64) -> usize {
    let mut low = 0usize;
    let mut high = arr.len();
    while low < high {
        let mid = low + (high - low) / 2;
        if arr[mid] < target {
            low = mid + 1;
        } else {
            high = mid;
        }
    }
    low
}

/// Finds the index of the first element > `target` (upper bound).
///
/// Returns `arr.len()` if no element is greater than `target`.
fn upper_bound(arr: &[i64], target: i64) -> usize {
    let mut low = 0usize;
    let mut high = arr.len();
    while low < high {
        let mid = low + (high - low) / 2;
        if arr[mid] <= target {
            low = mid + 1;
        } else {
            high = mid;
        }
    }
    low
}

/// Counts occurrences of `target` in a sorted slice using bound functions.
fn count_occurrences(arr: &[i64], target: i64) -> usize {
    upper_bound(arr, target) - lower_bound(arr, target)
}

/// Finds the insertion point to keep the slice sorted.
fn find_insertion_point(arr: &[i64], target: i64) -> usize {
    lower_bound(arr, target)
}

fn main() {
    let arr: Vec<i64> = (0..20).map(|x| x * 2).collect();
    println!("Array: {:?}", arr);

    // Iterative search
    println!("Search 10 (iterative): {:?}", binary_search_iterative(&arr, 10));
    println!("Search 7 (iterative): {:?}", binary_search_iterative(&arr, 7));

    // Recursive search
    let len = arr.len();
    println!("Search 10 (recursive): {:?}", binary_search_recursive(&arr, 10, 0, len));
    println!("Search 7 (recursive): {:?}", binary_search_recursive(&arr, 7, 0, len));

    // Bounds on array with duplicates
    let dupes = vec![1, 2, 2, 2, 3, 4, 4, 5, 6];
    println!("\nDuplicates array: {:?}", dupes);
    println!("Lower bound of 2: {}", lower_bound(&dupes, 2));
    println!("Upper bound of 2: {}", upper_bound(&dupes, 2));
    println!("Count of 2: {}", count_occurrences(&dupes, 2));
    println!("Count of 4: {}", count_occurrences(&dupes, 4));
    println!("Count of 7: {}", count_occurrences(&dupes, 7));

    // Insertion point
    println!("Insert point for 3 in arr: {}", find_insertion_point(&arr, 3));
    println!("Insert point for 4 in arr: {}", find_insertion_point(&arr, 4));

    // Verify iterative and recursive agree
    for &val in &arr {
        let it = binary_search_iterative(&arr, val);
        let rc = binary_search_recursive(&arr, val, 0, arr.len());
        assert_eq!(it, rc, "Mismatch for value {}", val);
    }
    println!("\nAll search implementations agree.");
}

/// Singly linked list using Box pointers.
///
/// Supports insert (head/tail/at index), delete, search, reverse, and display.
use std::fmt;

type Link = Option<Box<Node>>;

struct Node {
    value: i64,
    next: Link,
}

/// A singly linked list of i64 values.
struct LinkedList {
    head: Link,
    length: usize,
}

impl LinkedList {
    fn new() -> Self { LinkedList { head: None, length: 0 } }

    /// Inserts a value at the head of the list. O(1).
    fn push_front(&mut self, value: i64) {
        let node = Box::new(Node { value, next: self.head.take() });
        self.head = Some(node);
        self.length += 1;
    }

    /// Appends a value at the tail of the list. O(n).
    fn push_back(&mut self, value: i64) {
        let new_node = Box::new(Node { value, next: None });
        if self.head.is_none() {
            self.head = Some(new_node);
        } else {
            let mut cur = self.head.as_mut().unwrap();
            while cur.next.is_some() { cur = cur.next.as_mut().unwrap(); }
            cur.next = Some(new_node);
        }
        self.length += 1;
    }

    /// Inserts a value at the given index. Returns false if out of bounds.
    fn insert_at(&mut self, index: usize, value: i64) -> bool {
        if index > self.length { return false; }
        if index == 0 { self.push_front(value); return true; }
        let mut cur = self.head.as_mut().unwrap();
        for _ in 0..(index - 1) { cur = cur.next.as_mut().unwrap(); }
        let new_node = Box::new(Node { value, next: cur.next.take() });
        cur.next = Some(new_node);
        self.length += 1;
        true
    }

    /// Removes and returns the head value. O(1).
    fn pop_front(&mut self) -> Option<i64> {
        self.head.take().map(|node| {
            self.head = node.next;
            self.length -= 1;
            node.value
        })
    }

    /// Deletes the first occurrence of `value`. Returns true if found.
    fn delete(&mut self, value: i64) -> bool {
        if let Some(ref head) = self.head {
            if head.value == value { self.pop_front(); return true; }
        } else { return false; }
        let mut cur = self.head.as_mut().unwrap();
        while cur.next.is_some() {
            if cur.next.as_ref().unwrap().value == value {
                cur.next = cur.next.as_mut().unwrap().next.take();
                self.length -= 1;
                return true;
            }
            cur = cur.next.as_mut().unwrap();
        }
        false
    }

    /// Returns true if the list contains `value`.
    fn contains(&self, value: i64) -> bool {
        let mut cur = &self.head;
        while let Some(ref node) = cur {
            if node.value == value { return true; }
            cur = &node.next;
        }
        false
    }

    /// Reverses the list in place. O(n).
    fn reverse(&mut self) {
        let mut prev: Link = None;
        let mut current = self.head.take();
        while let Some(mut node) = current {
            let next = node.next.take();
            node.next = prev;
            prev = Some(node);
            current = next;
        }
        self.head = prev;
    }

    fn to_vec(&self) -> Vec<i64> {
        let mut result = Vec::new();
        let mut cur = &self.head;
        while let Some(ref node) = cur { result.push(node.value); cur = &node.next; }
        result
    }

    fn len(&self) -> usize { self.length }
}

impl fmt::Display for LinkedList {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        let strs: Vec<String> = self.to_vec().iter().map(|v| v.to_string()).collect();
        write!(f, "[{}]", strs.join(" -> "))
    }
}

fn main() {
    let mut list = LinkedList::new();
    for &v in &[10, 20, 30] { list.push_back(v); }
    list.push_front(5);
    list.insert_at(2, 15);
    println!("List: {} (len={})", list, list.len());
    println!("Contains 15: {}, Contains 99: {}", list.contains(15), list.contains(99));
    list.delete(15);
    println!("After deleting 15: {}", list);
    list.reverse();
    println!("Reversed: {}", list);
    let popped = list.pop_front();
    println!("Popped: {:?}, remaining: {} (len={})", popped, list, list.len());
}

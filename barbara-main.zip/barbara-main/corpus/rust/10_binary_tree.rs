/// Binary search tree with insert, search, traversals, depth, and balance checking.
///
/// Uses `Box` for heap-allocated child nodes and `Option` for optional children.

type Tree = Option<Box<TreeNode>>;

struct TreeNode { value: i64, left: Tree, right: Tree }

impl TreeNode {
    fn new(value: i64) -> Self { TreeNode { value, left: None, right: None } }
}

/// Inserts a value into the BST. Duplicates are ignored.
fn insert(root: &mut Tree, value: i64) {
    match root {
        None => *root = Some(Box::new(TreeNode::new(value))),
        Some(node) if value < node.value => insert(&mut node.left, value),
        Some(node) if value > node.value => insert(&mut node.right, value),
        _ => {}
    }
}

/// Returns true if the BST contains the given value.
fn search(root: &Tree, value: i64) -> bool {
    match root {
        None => false,
        Some(node) if value == node.value => true,
        Some(node) if value < node.value => search(&node.left, value),
        Some(node) => search(&node.right, value),
    }
}

/// In-order traversal: left, root, right. Produces sorted output.
fn inorder(root: &Tree, result: &mut Vec<i64>) {
    if let Some(node) = root {
        inorder(&node.left, result);
        result.push(node.value);
        inorder(&node.right, result);
    }
}

/// Pre-order traversal: root, left, right.
fn preorder(root: &Tree, result: &mut Vec<i64>) {
    if let Some(node) = root {
        result.push(node.value);
        preorder(&node.left, result);
        preorder(&node.right, result);
    }
}

/// Post-order traversal: left, right, root.
fn postorder(root: &Tree, result: &mut Vec<i64>) {
    if let Some(node) = root {
        postorder(&node.left, result);
        postorder(&node.right, result);
        result.push(node.value);
    }
}

/// Returns the maximum depth (height) of the tree.
fn depth(root: &Tree) -> usize {
    match root {
        None => 0,
        Some(node) => 1 + depth(&node.left).max(depth(&node.right)),
    }
}

/// Checks whether the tree is height-balanced (subtree heights differ by at most 1).
fn is_balanced(root: &Tree) -> bool {
    fn check(root: &Tree) -> (bool, usize) {
        match root {
            None => (true, 0),
            Some(node) => {
                let (lb, lh) = check(&node.left);
                let (rb, rh) = check(&node.right);
                let balanced = lb && rb && (lh as i64 - rh as i64).unsigned_abs() <= 1;
                (balanced, 1 + lh.max(rh))
            }
        }
    }
    check(root).0
}

/// Returns the minimum value in the BST.
fn find_min(root: &Tree) -> Option<i64> {
    match root {
        None => None,
        Some(node) if node.left.is_none() => Some(node.value),
        Some(node) => find_min(&node.left),
    }
}

/// Returns the maximum value in the BST.
fn find_max(root: &Tree) -> Option<i64> {
    match root {
        None => None,
        Some(node) if node.right.is_none() => Some(node.value),
        Some(node) => find_max(&node.right),
    }
}

/// Counts total nodes in the tree.
fn count_nodes(root: &Tree) -> usize {
    match root {
        None => 0,
        Some(node) => 1 + count_nodes(&node.left) + count_nodes(&node.right),
    }
}

fn main() {
    let mut root: Tree = None;
    for &val in &[50, 30, 70, 20, 40, 60, 80, 10, 25, 35, 45] {
        insert(&mut root, val);
    }

    let mut in_res = Vec::new();
    inorder(&root, &mut in_res);
    println!("In-order:   {:?}", in_res);

    let mut pre_res = Vec::new();
    preorder(&root, &mut pre_res);
    println!("Pre-order:  {:?}", pre_res);

    let mut post_res = Vec::new();
    postorder(&root, &mut post_res);
    println!("Post-order: {:?}", post_res);

    println!("\nSearch 40: {}, Search 99: {}", search(&root, 40), search(&root, 99));
    println!("Depth: {}, Balanced: {}, Nodes: {}", depth(&root), is_balanced(&root), count_nodes(&root));
    println!("Min: {:?}, Max: {:?}", find_min(&root), find_max(&root));
    assert!(in_res.windows(2).all(|w| w[0] <= w[1]));

    // Skewed tree
    let mut skewed: Tree = None;
    for val in 1..=10 { insert(&mut skewed, val); }
    println!("\nSkewed depth: {}, balanced: {}", depth(&skewed), is_balanced(&skewed));
    assert!(!is_balanced(&skewed));
}

/// Sorting algorithm implementations: optimized bubble sort and selection sort.
///
/// Both algorithms sort in-place and operate on mutable slices of i64.
/// Includes comparison counting for performance analysis.

/// Sorts a slice using optimized bubble sort with early exit.
///
/// If no swaps occur during a pass, the array is already sorted and
/// the algorithm terminates early. Returns the number of comparisons made.
fn bubble_sort(arr: &mut [i64]) -> usize {
    let n = arr.len();
    let mut comparisons = 0;
    for i in 0..n {
        let mut swapped = false;
        for j in 0..n.saturating_sub(i + 1) {
            comparisons += 1;
            if arr[j] > arr[j + 1] {
                arr.swap(j, j + 1);
                swapped = true;
            }
        }
        if !swapped {
            break;
        }
    }
    comparisons
}

/// Sorts a slice using selection sort.
///
/// Finds the minimum element in the unsorted region and swaps it into place.
/// Returns the number of comparisons made.
fn selection_sort(arr: &mut [i64]) -> usize {
    let n = arr.len();
    let mut comparisons = 0;
    for i in 0..n {
        let mut min_idx = i;
        for j in (i + 1)..n {
            comparisons += 1;
            if arr[j] < arr[min_idx] {
                min_idx = j;
            }
        }
        if min_idx != i {
            arr.swap(i, min_idx);
        }
    }
    comparisons
}

/// Checks whether a slice is sorted in non-decreasing order.
fn is_sorted(arr: &[i64]) -> bool {
    arr.windows(2).all(|w| w[0] <= w[1])
}

/// Generates a reversed array of the given size for worst-case testing.
fn generate_reversed(size: usize) -> Vec<i64> {
    (0..size as i64).rev().collect()
}

/// Generates a nearly sorted array with `swaps` random adjacent swaps.
fn generate_nearly_sorted(size: usize, swaps: usize) -> Vec<i64> {
    let mut arr: Vec<i64> = (0..size as i64).collect();
    for i in 0..swaps {
        let idx = (i * 7 + 3) % (size.saturating_sub(1).max(1));
        if idx + 1 < arr.len() {
            arr.swap(idx, idx + 1);
        }
    }
    arr
}

fn main() {
    // Basic bubble sort test
    let mut data = vec![64, 34, 25, 12, 22, 11, 90];
    println!("Before bubble sort: {:?}", data);
    let comps = bubble_sort(&mut data);
    println!("After bubble sort:  {:?} ({} comparisons)", data, comps);
    assert!(is_sorted(&data));

    // Already sorted (early exit)
    let mut sorted_data = vec![1, 2, 3, 4, 5];
    let comps = bubble_sort(&mut sorted_data);
    println!("Already sorted: {} comparisons (early exit)", comps);
    assert_eq!(comps, 4);

    // Basic selection sort test
    let mut data2 = vec![64, 34, 25, 12, 22, 11, 90];
    println!("\nBefore selection sort: {:?}", data2);
    let comps2 = selection_sort(&mut data2);
    println!("After selection sort:  {:?} ({} comparisons)", data2, comps2);
    assert!(is_sorted(&data2));

    // Worst case comparison
    let size = 20;
    let mut rev_bubble = generate_reversed(size);
    let mut rev_select = rev_bubble.clone();
    let bc = bubble_sort(&mut rev_bubble);
    let sc = selection_sort(&mut rev_select);
    println!("\nReversed array (n={}):", size);
    println!("  Bubble sort comparisons:    {}", bc);
    println!("  Selection sort comparisons: {}", sc);
    assert!(is_sorted(&rev_bubble));
    assert!(is_sorted(&rev_select));

    // Nearly sorted (bubble sort advantage)
    let mut nearly = generate_nearly_sorted(20, 2);
    let mut nearly_clone = nearly.clone();
    println!("\nNearly sorted array: {:?}", nearly);
    let bc2 = bubble_sort(&mut nearly);
    let sc2 = selection_sort(&mut nearly_clone);
    println!("  Bubble sort comparisons:    {}", bc2);
    println!("  Selection sort comparisons: {}", sc2);
    assert!(is_sorted(&nearly));
    assert!(is_sorted(&nearly_clone));

    // Empty and single-element edge cases
    let mut empty: Vec<i64> = vec![];
    bubble_sort(&mut empty);
    assert!(is_sorted(&empty));
    let mut single = vec![42];
    selection_sort(&mut single);
    assert!(is_sorted(&single));

    println!("\nAll sorting tests passed.");
}

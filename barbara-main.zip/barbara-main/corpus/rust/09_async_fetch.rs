/// Simulated HTTP fetch client with retry logic, timeout, and rate limiting.
///
/// No actual networking or async runtime is used; all behavior is simulated
/// using deterministic counters and structs.
use std::collections::HashMap;

#[derive(Debug, Clone)]
struct FetchResponse { url: String, status: u16, body: String, attempt: usize, latency_ms: u64 }

/// Errors that can occur during a fetch operation.
#[derive(Debug)]
enum FetchError {
    Timeout { url: String, timeout_ms: u64 },
    RateLimited { url: String, retry_after_ms: u64 },
    ServerError { url: String, status: u16, attempt: usize },
    MaxRetriesExceeded { url: String, attempts: usize },
}

impl std::fmt::Display for FetchError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            FetchError::Timeout { url, timeout_ms } => write!(f, "Timeout {}ms on {}", timeout_ms, url),
            FetchError::RateLimited { url, retry_after_ms } => write!(f, "Rate limited on {}, retry {}ms", url, retry_after_ms),
            FetchError::ServerError { url, status, attempt } => write!(f, "Server {} on {} (attempt {})", status, url, attempt),
            FetchError::MaxRetriesExceeded { url, attempts } => write!(f, "Max retries ({}) for {}", attempts, url),
        }
    }
}

struct FetchConfig { max_retries: usize, timeout_ms: u64, rate_limit_per_sec: usize, retry_delay_ms: u64 }

/// Simulated HTTP client with retry, timeout, and rate limiting.
struct FetchClient {
    config: FetchConfig,
    request_count: usize,
    timestamps: Vec<u64>,
    mocks: HashMap<String, Vec<(u16, String, u64)>>,
}

impl FetchClient {
    fn new(config: FetchConfig) -> Self {
        FetchClient { config, request_count: 0, timestamps: Vec::new(), mocks: HashMap::new() }
    }

    fn mock(&mut self, url: &str, responses: Vec<(u16, String, u64)>) {
        self.mocks.insert(url.to_string(), responses);
    }

    fn check_rate_limit(&self, now_ms: u64) -> bool {
        let window = now_ms.saturating_sub(1000);
        self.timestamps.iter().filter(|&&ts| ts >= window).count() >= self.config.rate_limit_per_sec
    }

    /// Simulates a single fetch attempt.
    fn fetch_once(&mut self, url: &str, attempt: usize, now_ms: u64) -> Result<FetchResponse, FetchError> {
        self.request_count += 1;
        self.timestamps.push(now_ms);
        let (status, body, latency) = match self.mocks.get_mut(url) {
            Some(list) if !list.is_empty() => list.remove(0),
            _ => (200, format!("OK from {}", url), 50),
        };
        if latency > self.config.timeout_ms {
            return Err(FetchError::Timeout { url: url.into(), timeout_ms: self.config.timeout_ms });
        }
        if status == 429 {
            return Err(FetchError::RateLimited { url: url.into(), retry_after_ms: self.config.retry_delay_ms });
        }
        if status >= 500 {
            return Err(FetchError::ServerError { url: url.into(), status, attempt });
        }
        Ok(FetchResponse { url: url.into(), status, body, attempt, latency_ms: latency })
    }

    /// Fetches a URL with retry logic and rate limiting.
    fn fetch(&mut self, url: &str) -> Result<FetchResponse, FetchError> {
        let mut time: u64 = 0;
        for attempt in 1..=self.config.max_retries {
            if self.check_rate_limit(time) {
                return Err(FetchError::RateLimited { url: url.into(), retry_after_ms: 1000 });
            }
            match self.fetch_once(url, attempt, time) {
                Ok(resp) => return Ok(resp),
                Err(FetchError::ServerError { .. }) | Err(FetchError::RateLimited { .. }) => {
                    time += self.config.retry_delay_ms;
                }
                Err(e) => return Err(e),
            }
        }
        Err(FetchError::MaxRetriesExceeded { url: url.into(), attempts: self.config.max_retries })
    }

    fn total_requests(&self) -> usize { self.request_count }
}

fn main() {
    let config = FetchConfig { max_retries: 3, timeout_ms: 5000, rate_limit_per_sec: 10, retry_delay_ms: 500 };
    let mut client = FetchClient::new(config);

    // Successful fetch
    match client.fetch("https://api.example.com/data") {
        Ok(resp) => println!("Success: {} (status {})", resp.body, resp.status),
        Err(e) => println!("Error: {}", e),
    }

    // Fails twice then succeeds
    client.mock("https://api.example.com/flaky", vec![
        (500, "Error".into(), 100), (503, "Unavailable".into(), 100), (200, "Finally OK".into(), 80),
    ]);
    match client.fetch("https://api.example.com/flaky") {
        Ok(resp) => println!("Flaky success attempt {}: {}", resp.attempt, resp.body),
        Err(e) => println!("Flaky error: {}", e),
    }

    // Timeout
    client.mock("https://api.example.com/slow", vec![(200, "Too slow".into(), 10000)]);
    match client.fetch("https://api.example.com/slow") {
        Ok(_) => println!("Unexpected success"),
        Err(e) => println!("Expected timeout: {}", e),
    }

    // Exhaust retries
    client.mock("https://api.example.com/broken", vec![
        (500, "fail".into(), 50), (500, "fail".into(), 50), (500, "fail".into(), 50),
    ]);
    match client.fetch("https://api.example.com/broken") {
        Ok(_) => println!("Unexpected success"),
        Err(e) => println!("Expected max retries: {}", e),
    }
    println!("\nTotal requests: {}", client.total_requests());
}

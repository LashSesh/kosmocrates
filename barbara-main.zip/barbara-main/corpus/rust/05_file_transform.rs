/// CSV-like data transformation pipeline: parse, filter, aggregate, and format.
///
/// Simulates reading structured data, applying transformations, and producing
/// summary output. Uses Result types for robust error handling throughout.

/// Represents a single record from the input data.
#[derive(Debug, Clone)]
struct Record {
    name: String,
    category: String,
    value: f64,
    active: bool,
}

/// Errors that can occur during data processing.
#[derive(Debug)]
enum TransformError {
    ParseError(String),
    AggregateError(String),
}

impl std::fmt::Display for TransformError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            TransformError::ParseError(msg) => write!(f, "Parse error: {}", msg),
            TransformError::AggregateError(msg) => write!(f, "Aggregate error: {}", msg),
        }
    }
}

/// Parses a CSV-like line into a Record.
fn parse_line(line: &str, line_num: usize) -> Result<Record, TransformError> {
    let fields: Vec<&str> = line.split(',').map(|s| s.trim()).collect();
    if fields.len() != 4 {
        return Err(TransformError::ParseError(
            format!("Line {}: expected 4 fields, got {}", line_num, fields.len()),
        ));
    }
    let value: f64 = fields[2].parse().map_err(|_| {
        TransformError::ParseError(format!("Line {}: invalid number '{}'", line_num, fields[2]))
    })?;
    let active = match fields[3].to_lowercase().as_str() {
        "true" | "yes" | "1" => true,
        "false" | "no" | "0" => false,
        other => return Err(TransformError::ParseError(
            format!("Line {}: invalid boolean '{}'", line_num, other),
        )),
    };
    Ok(Record { name: fields[0].into(), category: fields[1].into(), value, active })
}

/// Parses all lines of CSV data, skipping the header row.
fn parse_csv(data: &str) -> Result<Vec<Record>, TransformError> {
    data.lines().enumerate()
        .filter(|(i, l)| *i > 0 && !l.trim().is_empty())
        .map(|(i, l)| parse_line(l, i + 1))
        .collect()
}

/// Filters records to only active ones with value above the threshold.
fn filter_records(records: &[Record], min_value: f64) -> Vec<&Record> {
    records.iter().filter(|r| r.active && r.value >= min_value).collect()
}

/// Aggregation result for a category.
#[derive(Debug)]
struct CategorySummary {
    category: String,
    count: usize,
    total: f64,
    average: f64,
    min: f64,
    max: f64,
}

/// Aggregates records by category, computing summary statistics.
fn aggregate_by_category(records: &[&Record]) -> Result<Vec<CategorySummary>, TransformError> {
    use std::collections::HashMap;
    let mut groups: HashMap<&str, Vec<f64>> = HashMap::new();
    for r in records {
        groups.entry(&r.category).or_default().push(r.value);
    }
    let mut summaries: Vec<CategorySummary> = groups.iter().map(|(cat, values)| {
        let total: f64 = values.iter().sum();
        CategorySummary {
            category: cat.to_string(),
            count: values.len(),
            total,
            average: total / values.len() as f64,
            min: values.iter().cloned().fold(f64::INFINITY, f64::min),
            max: values.iter().cloned().fold(f64::NEG_INFINITY, f64::max),
        }
    }).collect();
    summaries.sort_by(|a, b| a.category.cmp(&b.category));
    Ok(summaries)
}

/// Formats summaries into a report string.
fn format_report(summaries: &[CategorySummary]) -> String {
    let mut lines = vec!["=== Category Report ===".to_string()];
    for s in summaries {
        lines.push(format!(
            "{}: count={}, total={:.2}, avg={:.2}, min={:.2}, max={:.2}",
            s.category, s.count, s.total, s.average, s.min, s.max
        ));
    }
    lines.push(format!("Total categories: {}", summaries.len()));
    lines.join("\n")
}

fn main() {
    let csv_data = "\
name,category,value,active
Alice,engineering,95000,true
Bob,marketing,72000,true
Carol,engineering,102000,true
Dave,marketing,68000,false
Eve,engineering,88000,true
Frank,sales,77000,true
Grace,sales,81000,true
Heidi,marketing,91000,true
Ivan,engineering,65000,true
Judy,sales,54000,false";

    match parse_csv(csv_data) {
        Ok(records) => {
            println!("Parsed {} records", records.len());
            let filtered = filter_records(&records, 70000.0);
            println!("Filtered to {} active records (value >= 70000)", filtered.len());
            match aggregate_by_category(&filtered) {
                Ok(summaries) => println!("\n{}", format_report(&summaries)),
                Err(e) => eprintln!("Aggregation failed: {}", e),
            }
        }
        Err(e) => eprintln!("Parse failed: {}", e),
    }
}

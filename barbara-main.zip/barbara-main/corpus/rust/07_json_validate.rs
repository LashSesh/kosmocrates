/// JSON-like data validation with enum error types and nested validation.
///
/// Defines a schema system that validates data structures, collecting
/// all errors rather than stopping at the first one.
use std::collections::HashMap;

/// Represents a JSON-like value.
#[derive(Debug, Clone)]
enum Value {
    Null, Bool(bool), Number(f64), Str(String),
    Array(Vec<Value>), Object(HashMap<String, Value>),
}

/// Validation error with path information for nested structures.
#[derive(Debug)]
struct ValidationError { path: String, message: String }

impl std::fmt::Display for ValidationError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}: {}", self.path, self.message)
    }
}

/// Schema rules for validating values.
enum Schema {
    StringType { min_length: Option<usize>, max_length: Option<usize> },
    NumberType { min: Option<f64>, max: Option<f64> },
    BoolType,
    ArrayType { item_schema: Box<Schema>, min_items: Option<usize> },
    ObjectType { fields: Vec<(String, Schema, bool)> },
}

/// Validates a value against a schema, collecting all errors.
fn validate(value: &Value, schema: &Schema, path: &str) -> Vec<ValidationError> {
    let mut errors = Vec::new();
    let err = |p: &str, m: String| ValidationError { path: p.to_string(), message: m };
    match (value, schema) {
        (Value::Str(s), Schema::StringType { min_length, max_length }) => {
            if let Some(min) = min_length { if s.len() < *min {
                errors.push(err(path, format!("String length {} < minimum {}", s.len(), min)));
            }}
            if let Some(max) = max_length { if s.len() > *max {
                errors.push(err(path, format!("String length {} > maximum {}", s.len(), max)));
            }}
        }
        (Value::Number(n), Schema::NumberType { min, max }) => {
            if let Some(lo) = min { if n < lo {
                errors.push(err(path, format!("Number {} < minimum {}", n, lo)));
            }}
            if let Some(hi) = max { if n > hi {
                errors.push(err(path, format!("Number {} > maximum {}", n, hi)));
            }}
        }
        (Value::Bool(_), Schema::BoolType) => {}
        (Value::Array(items), Schema::ArrayType { item_schema, min_items }) => {
            if let Some(min) = min_items { if items.len() < *min {
                errors.push(err(path, format!("Array length {} < minimum {}", items.len(), min)));
            }}
            for (i, item) in items.iter().enumerate() {
                errors.extend(validate(item, item_schema, &format!("{}[{}]", path, i)));
            }
        }
        (Value::Object(map), Schema::ObjectType { fields }) => {
            for (name, field_schema, required) in fields {
                let fp = format!("{}.{}", path, name);
                match map.get(name) {
                    Some(val) => errors.extend(validate(val, field_schema, &fp)),
                    None if *required => errors.push(err(&fp, "Required field missing".into())),
                    _ => {}
                }
            }
        }
        _ => errors.push(err(path, "Type mismatch".to_string())),
    }
    errors
}

fn main() {
    let user_schema = Schema::ObjectType { fields: vec![
        ("name".into(), Schema::StringType { min_length: Some(1), max_length: Some(50) }, true),
        ("age".into(), Schema::NumberType { min: Some(0.0), max: Some(150.0) }, true),
        ("email".into(), Schema::StringType { min_length: Some(5), max_length: Some(100) }, true),
        ("active".into(), Schema::BoolType, false),
        ("tags".into(), Schema::ArrayType {
            item_schema: Box::new(Schema::StringType { min_length: Some(1), max_length: Some(20) }),
            min_items: Some(1),
        }, false),
    ]};

    // Valid user
    let mut valid_map = HashMap::new();
    valid_map.insert("name".into(), Value::Str("Alice".into()));
    valid_map.insert("age".into(), Value::Number(30.0));
    valid_map.insert("email".into(), Value::Str("alice@example.com".into()));
    valid_map.insert("active".into(), Value::Bool(true));
    valid_map.insert("tags".into(), Value::Array(vec![Value::Str("admin".into())]));
    let errs = validate(&Value::Object(valid_map), &user_schema, "$");
    println!("Valid user errors: {}", errs.len());
    assert!(errs.is_empty());

    // Invalid user: missing name, age too high, short email, empty tags
    let mut bad_map = HashMap::new();
    bad_map.insert("age".into(), Value::Number(200.0));
    bad_map.insert("email".into(), Value::Str("x".into()));
    bad_map.insert("tags".into(), Value::Array(Vec::new()));
    let errs = validate(&Value::Object(bad_map), &user_schema, "$");
    println!("\nInvalid user errors ({}):", errs.len());
    for e in &errs { println!("  {}", e); }
    assert!(errs.len() >= 3);
    println!("\nValidation tests passed.");
}

/// Simulated CRUD HTTP handler using an in-memory HashMap store.
///
/// Models a simple REST-like API with Result-based error handling,
/// request/response structs, and method routing.
use std::collections::HashMap;

/// Represents an HTTP method.
#[derive(Debug, Clone, PartialEq)]
enum Method {
    Get,
    Post,
    Put,
    Delete,
}

/// A simplified HTTP request.
#[derive(Debug, Clone)]
struct Request {
    method: Method,
    path: String,
    body: Option<String>,
}

/// A simplified HTTP response.
#[derive(Debug)]
struct Response {
    status: u16,
    body: String,
}

/// Errors that can occur during request handling.
#[derive(Debug)]
enum HandlerError {
    NotFound(String),
    BadRequest(String),
    MethodNotAllowed(String),
    InternalError(String),
}

impl std::fmt::Display for HandlerError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            HandlerError::NotFound(msg) => write!(f, "404 Not Found: {}", msg),
            HandlerError::BadRequest(msg) => write!(f, "400 Bad Request: {}", msg),
            HandlerError::MethodNotAllowed(msg) => write!(f, "405 Method Not Allowed: {}", msg),
            HandlerError::InternalError(msg) => write!(f, "500 Internal Error: {}", msg),
        }
    }
}

/// In-memory CRUD store with request routing.
struct CrudHandler {
    store: HashMap<String, String>,
    request_count: usize,
}

impl CrudHandler {
    fn new() -> Self {
        CrudHandler {
            store: HashMap::new(),
            request_count: 0,
        }
    }

    /// Routes a request to the appropriate handler method.
    fn handle(&mut self, req: &Request) -> Result<Response, HandlerError> {
        self.request_count += 1;
        let id = Self::extract_id(&req.path)?;
        match req.method {
            Method::Get => self.handle_get(&id),
            Method::Post => self.handle_create(&id, req.body.as_deref()),
            Method::Put => self.handle_update(&id, req.body.as_deref()),
            Method::Delete => self.handle_delete(&id),
        }
    }

    fn extract_id(path: &str) -> Result<String, HandlerError> {
        let parts: Vec<&str> = path.trim_matches('/').split('/').collect();
        if parts.len() < 2 {
            return Err(HandlerError::BadRequest("Path must be /resource/<id>".into()));
        }
        Ok(parts[1].to_string())
    }

    fn handle_get(&self, id: &str) -> Result<Response, HandlerError> {
        match self.store.get(id) {
            Some(val) => Ok(Response { status: 200, body: val.clone() }),
            None => Err(HandlerError::NotFound(format!("Item '{}' not found", id))),
        }
    }

    fn handle_create(&mut self, id: &str, body: Option<&str>) -> Result<Response, HandlerError> {
        let data = body.ok_or_else(|| HandlerError::BadRequest("Body required for POST".into()))?;
        if self.store.contains_key(id) {
            return Err(HandlerError::BadRequest(format!("Item '{}' already exists", id)));
        }
        self.store.insert(id.to_string(), data.to_string());
        Ok(Response { status: 201, body: format!("Created '{}'", id) })
    }

    fn handle_update(&mut self, id: &str, body: Option<&str>) -> Result<Response, HandlerError> {
        let data = body.ok_or_else(|| HandlerError::BadRequest("Body required for PUT".into()))?;
        if !self.store.contains_key(id) {
            return Err(HandlerError::NotFound(format!("Item '{}' not found", id)));
        }
        self.store.insert(id.to_string(), data.to_string());
        Ok(Response { status: 200, body: format!("Updated '{}'", id) })
    }

    fn handle_delete(&mut self, id: &str) -> Result<Response, HandlerError> {
        match self.store.remove(id) {
            Some(_) => Ok(Response { status: 200, body: format!("Deleted '{}'", id) }),
            None => Err(HandlerError::NotFound(format!("Item '{}' not found", id))),
        }
    }

    fn item_count(&self) -> usize {
        self.store.len()
    }
}

fn main() {
    let mut handler = CrudHandler::new();

    let requests = vec![
        Request { method: Method::Post, path: "/items/1".into(), body: Some("alpha".into()) },
        Request { method: Method::Post, path: "/items/2".into(), body: Some("beta".into()) },
        Request { method: Method::Get, path: "/items/1".into(), body: None },
        Request { method: Method::Put, path: "/items/1".into(), body: Some("alpha_v2".into()) },
        Request { method: Method::Get, path: "/items/1".into(), body: None },
        Request { method: Method::Delete, path: "/items/2".into(), body: None },
        Request { method: Method::Get, path: "/items/2".into(), body: None },
        Request { method: Method::Get, path: "/items/999".into(), body: None },
        Request { method: Method::Post, path: "/items/1".into(), body: Some("dup".into()) },
    ];

    for req in &requests {
        print!("{:?} {} -> ", req.method, req.path);
        match handler.handle(req) {
            Ok(resp) => println!("{} {}", resp.status, resp.body),
            Err(e) => println!("ERROR: {}", e),
        }
    }

    println!("\nTotal requests: {}", handler.request_count);
    println!("Items in store: {}", handler.item_count());
}

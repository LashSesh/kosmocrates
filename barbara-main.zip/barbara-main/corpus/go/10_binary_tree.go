package main

import "fmt"

// Binary search tree with insert, search, traversals, depth, and balance check.

type TreeNode struct {
	Value int
	Left  *TreeNode
	Right *TreeNode
}

type BST struct{ Root *TreeNode }

func NewBST() *BST { return &BST{} }

// Insert adds a value to the BST. Duplicates go to the right subtree.
func (t *BST) Insert(val int) { t.Root = insertNode(t.Root, val) }

func insertNode(n *TreeNode, val int) *TreeNode {
	if n == nil {
		return &TreeNode{Value: val}
	}
	if val < n.Value {
		n.Left = insertNode(n.Left, val)
	} else {
		n.Right = insertNode(n.Right, val)
	}
	return n
}

// Search returns true if the value exists in the tree.
func (t *BST) Search(val int) bool { return searchNode(t.Root, val) }

func searchNode(n *TreeNode, val int) bool {
	if n == nil {
		return false
	}
	if val == n.Value {
		return true
	}
	if val < n.Value {
		return searchNode(n.Left, val)
	}
	return searchNode(n.Right, val)
}

// InOrder returns values in ascending order (left, root, right).
func (t *BST) InOrder() []int {
	var r []int
	inOrder(t.Root, &r)
	return r
}

func inOrder(n *TreeNode, r *[]int) {
	if n != nil {
		inOrder(n.Left, r)
		*r = append(*r, n.Value)
		inOrder(n.Right, r)
	}
}

// PreOrder returns values in pre-order (root, left, right).
func (t *BST) PreOrder() []int {
	var r []int
	preOrder(t.Root, &r)
	return r
}

func preOrder(n *TreeNode, r *[]int) {
	if n != nil {
		*r = append(*r, n.Value)
		preOrder(n.Left, r)
		preOrder(n.Right, r)
	}
}

// PostOrder returns values in post-order (left, right, root).
func (t *BST) PostOrder() []int {
	var r []int
	postOrder(t.Root, &r)
	return r
}

func postOrder(n *TreeNode, r *[]int) {
	if n != nil {
		postOrder(n.Left, r)
		postOrder(n.Right, r)
		*r = append(*r, n.Value)
	}
}

// Depth returns the maximum depth of the tree.
func (t *BST) Depth() int { return depth(t.Root) }

func depth(n *TreeNode) int {
	if n == nil {
		return 0
	}
	l, r := depth(n.Left), depth(n.Right)
	if l > r {
		return l + 1
	}
	return r + 1
}

// IsBalanced returns true if subtree depths differ by at most 1 at every node.
func (t *BST) IsBalanced() bool {
	ok, _ := checkBalance(t.Root)
	return ok
}

func checkBalance(n *TreeNode) (bool, int) {
	if n == nil {
		return true, 0
	}
	lok, lh := checkBalance(n.Left)
	rok, rh := checkBalance(n.Right)
	if !lok || !rok || lh-rh > 1 || rh-lh > 1 {
		return false, 0
	}
	h := lh
	if rh > h {
		h = rh
	}
	return true, h + 1
}

func main() {
	tree := NewBST()
	for _, v := range []int{50, 30, 70, 20, 40, 60, 80} {
		tree.Insert(v)
	}
	fmt.Println("In-order:", tree.InOrder())
	fmt.Println("Pre-order:", tree.PreOrder())
	fmt.Println("Post-order:", tree.PostOrder())
	fmt.Println("Depth:", tree.Depth(), "Balanced:", tree.IsBalanced())
	fmt.Println("Search 40:", tree.Search(40), "Search 99:", tree.Search(99))
	skewed := NewBST()
	for _, v := range []int{1, 2, 3, 4, 5} {
		skewed.Insert(v)
	}
	fmt.Println("Skewed depth:", skewed.Depth(), "balanced:", skewed.IsBalanced())
}

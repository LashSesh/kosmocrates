package main

import (
	"fmt"
	"strconv"
	"strings"
)

// Row represents a parsed CSV row with typed fields.
type Row struct {
	Name       string
	Department string
	Salary     float64
	Active     bool
}

// parseCSV takes raw CSV text and returns parsed rows, skipping the header.
// Returns an error if any row has an invalid format.
func parseCSV(data string) ([]Row, error) {
	lines := strings.Split(strings.TrimSpace(data), "\n")
	if len(lines) < 2 {
		return nil, fmt.Errorf("CSV must have a header and at least one data row")
	}

	var rows []Row
	for i, line := range lines[1:] {
		fields := strings.Split(line, ",")
		if len(fields) != 4 {
			return nil, fmt.Errorf("row %d: expected 4 fields, got %d", i+1, len(fields))
		}
		salary, err := strconv.ParseFloat(strings.TrimSpace(fields[2]), 64)
		if err != nil {
			return nil, fmt.Errorf("row %d: invalid salary %q: %w", i+1, fields[2], err)
		}
		active := strings.TrimSpace(fields[3]) == "true"
		rows = append(rows, Row{
			Name:       strings.TrimSpace(fields[0]),
			Department: strings.TrimSpace(fields[1]),
			Active:     active,
			Salary:     salary,
		})
	}
	return rows, nil
}

// filterActive returns only rows where Active is true.
func filterActive(rows []Row) []Row {
	var result []Row
	for _, r := range rows {
		if r.Active {
			result = append(result, r)
		}
	}
	return result
}

// filterByDepartment returns rows matching the given department.
func filterByDepartment(rows []Row, dept string) []Row {
	var result []Row
	for _, r := range rows {
		if r.Department == dept {
			result = append(result, r)
		}
	}
	return result
}

// AggregateResult holds summary statistics for a group of rows.
type AggregateResult struct {
	Count      int
	TotalSal   float64
	AvgSal     float64
	MaxSal     float64
	MinSal     float64
}

// aggregateSalaries computes salary statistics across rows.
func aggregateSalaries(rows []Row) AggregateResult {
	if len(rows) == 0 {
		return AggregateResult{}
	}
	res := AggregateResult{
		Count:  len(rows),
		MinSal: rows[0].Salary,
		MaxSal: rows[0].Salary,
	}
	for _, r := range rows {
		res.TotalSal += r.Salary
		if r.Salary > res.MaxSal {
			res.MaxSal = r.Salary
		}
		if r.Salary < res.MinSal {
			res.MinSal = r.Salary
		}
	}
	res.AvgSal = res.TotalSal / float64(res.Count)
	return res
}

// aggregateByDepartment groups rows by department and computes stats for each.
func aggregateByDepartment(rows []Row) map[string]AggregateResult {
	groups := make(map[string][]Row)
	for _, r := range rows {
		groups[r.Department] = append(groups[r.Department], r)
	}
	result := make(map[string]AggregateResult)
	for dept, group := range groups {
		result[dept] = aggregateSalaries(group)
	}
	return result
}

// formatReport generates a text summary from department aggregates.
func formatReport(agg map[string]AggregateResult) string {
	var sb strings.Builder
	sb.WriteString("Department Salary Report\n")
	sb.WriteString(strings.Repeat("=", 40) + "\n")
	for dept, stats := range agg {
		fmt.Fprintf(&sb, "%-15s count=%-3d avg=$%.2f min=$%.2f max=$%.2f\n",
			dept, stats.Count, stats.AvgSal, stats.MinSal, stats.MaxSal)
	}
	return sb.String()
}

func main() {
	csvData := `name,department,salary,active
Alice,Engineering,95000,true
Bob,Marketing,72000,true
Charlie,Engineering,105000,true
Diana,Marketing,68000,false
Eve,Engineering,88000,true
Frank,Sales,77000,true`

	rows, err := parseCSV(csvData)
	if err != nil {
		fmt.Println("Parse error:", err)
		return
	}
	fmt.Printf("Parsed %d rows\n", len(rows))

	active := filterActive(rows)
	fmt.Printf("Active employees: %d\n", len(active))

	byDept := aggregateByDepartment(active)
	fmt.Print(formatReport(byDept))
}

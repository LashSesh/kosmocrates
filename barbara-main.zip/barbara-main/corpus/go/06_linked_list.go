package main

import (
	"fmt"
	"strings"
)

// Node represents a single element in the linked list.
type Node struct {
	Value int
	Next  *Node
}

// LinkedList is a singly linked list with head pointer and size tracking.
type LinkedList struct {
	Head *Node
	Size int
}

// NewLinkedList creates an empty linked list.
func NewLinkedList() *LinkedList {
	return &LinkedList{}
}

// InsertFront adds a value at the beginning of the list. O(1).
func (ll *LinkedList) InsertFront(val int) {
	ll.Head = &Node{Value: val, Next: ll.Head}
	ll.Size++
}

// InsertBack adds a value at the end of the list. O(n).
func (ll *LinkedList) InsertBack(val int) {
	newNode := &Node{Value: val}
	if ll.Head == nil {
		ll.Head = newNode
	} else {
		curr := ll.Head
		for curr.Next != nil {
			curr = curr.Next
		}
		curr.Next = newNode
	}
	ll.Size++
}

// InsertAt inserts a value at the given index (0-based). Returns false if out of range.
func (ll *LinkedList) InsertAt(index, val int) bool {
	if index < 0 || index > ll.Size {
		return false
	}
	if index == 0 {
		ll.InsertFront(val)
		return true
	}
	curr := ll.Head
	for i := 0; i < index-1; i++ {
		curr = curr.Next
	}
	curr.Next = &Node{Value: val, Next: curr.Next}
	ll.Size++
	return true
}

// Delete removes the first occurrence of a value. Returns true if found.
func (ll *LinkedList) Delete(val int) bool {
	if ll.Head == nil {
		return false
	}
	if ll.Head.Value == val {
		ll.Head = ll.Head.Next
		ll.Size--
		return true
	}
	curr := ll.Head
	for curr.Next != nil {
		if curr.Next.Value == val {
			curr.Next = curr.Next.Next
			ll.Size--
			return true
		}
		curr = curr.Next
	}
	return false
}

// Search returns the index of the first occurrence of val, or -1 if not found.
func (ll *LinkedList) Search(val int) int {
	curr := ll.Head
	for i := 0; curr != nil; i++ {
		if curr.Value == val {
			return i
		}
		curr = curr.Next
	}
	return -1
}

// Reverse reverses the linked list in-place.
func (ll *LinkedList) Reverse() {
	var prev *Node
	curr := ll.Head
	for curr != nil {
		next := curr.Next
		curr.Next = prev
		prev = curr
		curr = next
	}
	ll.Head = prev
}

// ToSlice converts the linked list to a slice for easy inspection.
func (ll *LinkedList) ToSlice() []int {
	var result []int
	for curr := ll.Head; curr != nil; curr = curr.Next {
		result = append(result, curr.Value)
	}
	return result
}

// String returns a human-readable representation of the list.
func (ll *LinkedList) String() string {
	parts := make([]string, 0, ll.Size)
	for curr := ll.Head; curr != nil; curr = curr.Next {
		parts = append(parts, fmt.Sprintf("%d", curr.Value))
	}
	return strings.Join(parts, " -> ") + " -> nil"
}

func main() {
	ll := NewLinkedList()
	for _, v := range []int{10, 20, 30, 40, 50} {
		ll.InsertBack(v)
	}
	fmt.Println("List:", ll)
	fmt.Println("Size:", ll.Size)

	ll.InsertFront(5)
	ll.InsertAt(3, 25)
	fmt.Println("After inserts:", ll)

	fmt.Println("Search 30:", ll.Search(30))
	fmt.Println("Search 99:", ll.Search(99))

	ll.Delete(25)
	fmt.Println("After Delete(25):", ll)

	ll.Reverse()
	fmt.Println("After Reverse:", ll)
	fmt.Println("As slice:", ll.ToSlice())
}

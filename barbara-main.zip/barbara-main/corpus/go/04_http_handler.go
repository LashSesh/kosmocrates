package main

import (
	"errors"
	"fmt"
	"strings"
	"sync"
)

// Record represents a stored entity with an ID, name, and metadata.
type Record struct {
	ID       string
	Name     string
	Email    string
	Active   bool
}

// CRUDHandler manages records in an in-memory store with thread-safe access.
type CRUDHandler struct {
	mu    sync.RWMutex
	store map[string]Record
}

// NewCRUDHandler creates a new handler with an initialized store.
func NewCRUDHandler() *CRUDHandler {
	return &CRUDHandler{store: make(map[string]Record)}
}

var (
	ErrNotFound       = errors.New("record not found")
	ErrAlreadyExists  = errors.New("record already exists")
	ErrInvalidInput   = errors.New("invalid input")
)

// validateRecord checks that required fields are present and valid.
func validateRecord(r Record) error {
	if strings.TrimSpace(r.ID) == "" {
		return fmt.Errorf("%w: ID cannot be empty", ErrInvalidInput)
	}
	if strings.TrimSpace(r.Name) == "" {
		return fmt.Errorf("%w: name cannot be empty", ErrInvalidInput)
	}
	if !strings.Contains(r.Email, "@") {
		return fmt.Errorf("%w: email must contain @", ErrInvalidInput)
	}
	return nil
}

// Create adds a new record to the store.
func (h *CRUDHandler) Create(r Record) error {
	if err := validateRecord(r); err != nil {
		return err
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	if _, exists := h.store[r.ID]; exists {
		return fmt.Errorf("%w: id=%s", ErrAlreadyExists, r.ID)
	}
	h.store[r.ID] = r
	return nil
}

// Read retrieves a record by ID.
func (h *CRUDHandler) Read(id string) (Record, error) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	rec, ok := h.store[id]
	if !ok {
		return Record{}, fmt.Errorf("%w: id=%s", ErrNotFound, id)
	}
	return rec, nil
}

// Update modifies an existing record in the store.
func (h *CRUDHandler) Update(r Record) error {
	if err := validateRecord(r); err != nil {
		return err
	}
	h.mu.Lock()
	defer h.mu.Unlock()
	if _, exists := h.store[r.ID]; !exists {
		return fmt.Errorf("%w: id=%s", ErrNotFound, r.ID)
	}
	h.store[r.ID] = r
	return nil
}

// Delete removes a record from the store by ID.
func (h *CRUDHandler) Delete(id string) error {
	h.mu.Lock()
	defer h.mu.Unlock()
	if _, exists := h.store[id]; !exists {
		return fmt.Errorf("%w: id=%s", ErrNotFound, id)
	}
	delete(h.store, id)
	return nil
}

// List returns all records in the store.
func (h *CRUDHandler) List() []Record {
	h.mu.RLock()
	defer h.mu.RUnlock()
	records := make([]Record, 0, len(h.store))
	for _, r := range h.store {
		records = append(records, r)
	}
	return records
}

func main() {
	handler := NewCRUDHandler()

	// Create
	rec := Record{ID: "1", Name: "Alice", Email: "alice@example.com", Active: true}
	if err := handler.Create(rec); err != nil {
		fmt.Println("Create error:", err)
	}

	// Read
	if r, err := handler.Read("1"); err == nil {
		fmt.Printf("Read: %+v\n", r)
	}

	// Update
	rec.Name = "Alice Smith"
	if err := handler.Update(rec); err != nil {
		fmt.Println("Update error:", err)
	}

	// Delete
	if err := handler.Delete("1"); err != nil {
		fmt.Println("Delete error:", err)
	}

	// Read after delete
	if _, err := handler.Read("1"); err != nil {
		fmt.Println("Expected error:", err)
	}

	// Validation error
	bad := Record{ID: "", Name: "Bob", Email: "invalid"}
	if err := handler.Create(bad); err != nil {
		fmt.Println("Validation error:", err)
	}
}

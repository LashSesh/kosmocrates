package main

import "fmt"

// binarySearch performs iterative binary search on a sorted slice.
// Returns the index of target, or -1 if not found.
func binarySearch(arr []int, target int) int {
	low, high := 0, len(arr)-1
	for low <= high {
		mid := low + (high-low)/2
		if arr[mid] == target {
			return mid
		} else if arr[mid] < target {
			low = mid + 1
		} else {
			high = mid - 1
		}
	}
	return -1
}

// binarySearchRecursive performs binary search using recursion.
func binarySearchRecursive(arr []int, target, low, high int) int {
	if low > high {
		return -1
	}
	mid := low + (high-low)/2
	if arr[mid] == target {
		return mid
	}
	if arr[mid] < target {
		return binarySearchRecursive(arr, target, mid+1, high)
	}
	return binarySearchRecursive(arr, target, low, mid-1)
}

// lowerBound finds the first index where arr[i] >= target.
// Returns len(arr) if all elements are less than target.
func lowerBound(arr []int, target int) int {
	low, high := 0, len(arr)
	for low < high {
		mid := low + (high-low)/2
		if arr[mid] < target {
			low = mid + 1
		} else {
			high = mid
		}
	}
	return low
}

// upperBound finds the first index where arr[i] > target.
// Returns len(arr) if no element is greater than target.
func upperBound(arr []int, target int) int {
	low, high := 0, len(arr)
	for low < high {
		mid := low + (high-low)/2
		if arr[mid] <= target {
			low = mid + 1
		} else {
			high = mid
		}
	}
	return low
}

// countOccurrences counts how many times target appears in a sorted slice.
func countOccurrences(arr []int, target int) int {
	return upperBound(arr, target) - lowerBound(arr, target)
}

// searchInsertPosition returns the index at which target should be inserted
// to keep the slice sorted (equivalent to lower_bound).
func searchInsertPosition(arr []int, target int) int {
	return lowerBound(arr, target)
}

// findPeakElement finds a peak element index in an array where
// arr[i] > arr[i-1] and arr[i] > arr[i+1]. Uses binary search for O(log n).
func findPeakElement(arr []int) int {
	if len(arr) == 0 {
		return -1
	}
	low, high := 0, len(arr)-1
	for low < high {
		mid := low + (high-low)/2
		if arr[mid] < arr[mid+1] {
			low = mid + 1
		} else {
			high = mid
		}
	}
	return low
}

func main() {
	sorted := []int{1, 3, 5, 7, 9, 11, 13, 15, 17, 19}

	fmt.Println("Search 7 (iterative):", binarySearch(sorted, 7))
	fmt.Println("Search 7 (recursive):", binarySearchRecursive(sorted, 7, 0, len(sorted)-1))
	fmt.Println("Search 6 (not found):", binarySearch(sorted, 6))

	repeated := []int{1, 2, 2, 2, 3, 4, 5}
	fmt.Println("Lower bound of 2:", lowerBound(repeated, 2))
	fmt.Println("Upper bound of 2:", upperBound(repeated, 2))
	fmt.Println("Count of 2:", countOccurrences(repeated, 2))
	fmt.Println("Insert position for 6:", searchInsertPosition(sorted, 6))

	peaks := []int{1, 3, 5, 4, 2}
	fmt.Println("Peak element index:", findPeakElement(peaks))
}

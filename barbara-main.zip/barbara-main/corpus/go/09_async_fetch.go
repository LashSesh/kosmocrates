package main

import (
	"errors"
	"fmt"
	"math/rand"
	"sync"
	"time"
)

// FetchResult holds the outcome of an HTTP fetch simulation.
type FetchResult struct {
	URL        string
	StatusCode int
	Body       string
	Duration   time.Duration
	Err        error
}

var (
	ErrTimeout    = errors.New("request timed out")
	ErrRateLimit  = errors.New("rate limit exceeded")
	ErrServerDown = errors.New("server error")
)

// simulateFetch simulates an HTTP request with random latency and failure modes.
func simulateFetch(url string) FetchResult {
	start := time.Now()
	// Simulate network latency between 10ms and 200ms
	delay := time.Duration(10+rand.Intn(190)) * time.Millisecond
	time.Sleep(delay)

	// Simulate random failures (30% chance)
	roll := rand.Float64()
	if roll < 0.1 {
		return FetchResult{URL: url, StatusCode: 429, Err: ErrRateLimit, Duration: time.Since(start)}
	}
	if roll < 0.2 {
		return FetchResult{URL: url, StatusCode: 500, Err: ErrServerDown, Duration: time.Since(start)}
	}
	if roll < 0.3 {
		return FetchResult{URL: url, StatusCode: 0, Err: ErrTimeout, Duration: time.Since(start)}
	}

	return FetchResult{
		URL:        url,
		StatusCode: 200,
		Body:       fmt.Sprintf(`{"source": "%s", "data": "ok"}`, url),
		Duration:   time.Since(start),
	}
}

// fetchWithRetry attempts a fetch up to maxRetries times with exponential backoff.
func fetchWithRetry(url string, maxRetries int) FetchResult {
	var result FetchResult
	for attempt := 0; attempt <= maxRetries; attempt++ {
		result = simulateFetch(url)
		if result.Err == nil {
			return result
		}
		if attempt < maxRetries {
			backoff := time.Duration(1<<uint(attempt)) * 50 * time.Millisecond
			time.Sleep(backoff)
		}
	}
	return result
}

// fetchWithTimeout wraps a fetch with a deadline using goroutines and channels.
func fetchWithTimeout(url string, timeout time.Duration) FetchResult {
	ch := make(chan FetchResult, 1)
	go func() {
		ch <- fetchWithRetry(url, 2)
	}()
	select {
	case result := <-ch:
		return result
	case <-time.After(timeout):
		return FetchResult{URL: url, Err: ErrTimeout}
	}
}

// RateLimiter controls the rate of concurrent requests.
type RateLimiter struct {
	sem chan struct{}
}

// NewRateLimiter creates a limiter allowing up to maxConcurrent simultaneous requests.
func NewRateLimiter(maxConcurrent int) *RateLimiter {
	return &RateLimiter{sem: make(chan struct{}, maxConcurrent)}
}

func (rl *RateLimiter) Acquire() { rl.sem <- struct{}{} }
func (rl *RateLimiter) Release() { <-rl.sem }

// fetchAll fetches multiple URLs concurrently with rate limiting and timeout.
func fetchAll(urls []string, maxConcurrent int, timeout time.Duration) []FetchResult {
	limiter := NewRateLimiter(maxConcurrent)
	results := make([]FetchResult, len(urls))
	var wg sync.WaitGroup

	for i, url := range urls {
		wg.Add(1)
		go func(idx int, u string) {
			defer wg.Done()
			limiter.Acquire()
			defer limiter.Release()
			results[idx] = fetchWithTimeout(u, timeout)
		}(i, url)
	}

	wg.Wait()
	return results
}

func main() {
	rand.Seed(time.Now().UnixNano())

	urls := []string{
		"https://api.example.com/users",
		"https://api.example.com/posts",
		"https://api.example.com/comments",
		"https://api.example.com/albums",
		"https://api.example.com/todos",
	}

	fmt.Println("Fetching", len(urls), "URLs with concurrency limit of 3...")
	results := fetchAll(urls, 3, 2*time.Second)

	successes, failures := 0, 0
	for _, r := range results {
		if r.Err != nil {
			failures++
			fmt.Printf("FAIL  %s  err=%v  took=%v\n", r.URL, r.Err, r.Duration)
		} else {
			successes++
			fmt.Printf("OK    %s  status=%d  took=%v\n", r.URL, r.StatusCode, r.Duration)
		}
	}
	fmt.Printf("\nResults: %d succeeded, %d failed\n", successes, failures)
}

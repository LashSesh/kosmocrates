package main

import (
	"fmt"
	"sync"
)

// Event carries data about something that happened in the system.
type Event struct {
	Type string
	Data interface{}
}

// Listener is a callback function that handles events.
type Listener func(Event)

// EventEmitter manages subscriptions and dispatches events to listeners.
// It is safe for concurrent use.
type EventEmitter struct {
	mu        sync.RWMutex
	listeners map[string]map[int]Listener
	nextID    int
}

// NewEventEmitter creates an initialized event emitter.
func NewEventEmitter() *EventEmitter {
	return &EventEmitter{
		listeners: make(map[string]map[int]Listener),
	}
}

// Subscribe registers a listener for a given event type.
// Returns an ID that can be used to unsubscribe.
func (em *EventEmitter) Subscribe(eventType string, fn Listener) int {
	em.mu.Lock()
	defer em.mu.Unlock()
	if em.listeners[eventType] == nil {
		em.listeners[eventType] = make(map[int]Listener)
	}
	id := em.nextID
	em.nextID++
	em.listeners[eventType][id] = fn
	return id
}

// Unsubscribe removes a listener by its subscription ID.
// Returns true if the listener was found and removed.
func (em *EventEmitter) Unsubscribe(eventType string, id int) bool {
	em.mu.Lock()
	defer em.mu.Unlock()
	if subs, ok := em.listeners[eventType]; ok {
		if _, exists := subs[id]; exists {
			delete(subs, id)
			return true
		}
	}
	return false
}

// Emit dispatches an event to all registered listeners for that event type.
func (em *EventEmitter) Emit(eventType string, data interface{}) {
	em.mu.RLock()
	// Copy listeners to avoid holding the lock during callbacks
	subs := make([]Listener, 0)
	for _, fn := range em.listeners[eventType] {
		subs = append(subs, fn)
	}
	em.mu.RUnlock()

	event := Event{Type: eventType, Data: data}
	for _, fn := range subs {
		fn(event)
	}
}

// ListenerCount returns how many listeners are registered for an event type.
func (em *EventEmitter) ListenerCount(eventType string) int {
	em.mu.RLock()
	defer em.mu.RUnlock()
	return len(em.listeners[eventType])
}

// RemoveAllListeners removes all listeners for a given event type.
func (em *EventEmitter) RemoveAllListeners(eventType string) {
	em.mu.Lock()
	defer em.mu.Unlock()
	delete(em.listeners, eventType)
}

// Logger is an example subscriber that logs events.
type Logger struct {
	Prefix string
}

func (l *Logger) HandleEvent(e Event) {
	fmt.Printf("[%s] Event %q: %v\n", l.Prefix, e.Type, e.Data)
}

// Counter is an example subscriber that counts events.
type Counter struct {
	mu    sync.Mutex
	Count int
}

func (c *Counter) HandleEvent(e Event) {
	c.mu.Lock()
	c.Count++
	c.mu.Unlock()
}

func main() {
	em := NewEventEmitter()

	logger := &Logger{Prefix: "APP"}
	counter := &Counter{}

	// Subscribe to user events
	id1 := em.Subscribe("user:login", logger.HandleEvent)
	em.Subscribe("user:login", counter.HandleEvent)
	em.Subscribe("user:logout", logger.HandleEvent)

	fmt.Printf("Login listeners: %d\n", em.ListenerCount("user:login"))

	// Emit some events
	em.Emit("user:login", map[string]string{"user": "alice", "ip": "192.168.1.1"})
	em.Emit("user:login", map[string]string{"user": "bob", "ip": "10.0.0.5"})
	em.Emit("user:logout", map[string]string{"user": "alice"})

	fmt.Printf("Login count: %d\n", counter.Count)

	// Unsubscribe logger from login events
	em.Unsubscribe("user:login", id1)
	fmt.Printf("Login listeners after unsub: %d\n", em.ListenerCount("user:login"))

	// This event only triggers the counter, not the logger
	em.Emit("user:login", map[string]string{"user": "charlie"})
	fmt.Printf("Final login count: %d\n", counter.Count)

	// Remove all logout listeners
	em.RemoveAllListeners("user:logout")
	fmt.Printf("Logout listeners: %d\n", em.ListenerCount("user:logout"))
}

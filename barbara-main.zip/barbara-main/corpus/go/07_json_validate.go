package main

import (
	"fmt"
	"strings"
)

// ValidationError captures a field path and a description of what went wrong.
type ValidationError struct {
	Field   string
	Message string
}

func (e ValidationError) Error() string {
	return fmt.Sprintf("%s: %s", e.Field, e.Message)
}

// ValidationResult collects multiple errors found during validation.
type ValidationResult struct {
	Errors []ValidationError
}

func (vr *ValidationResult) AddError(field, msg string) {
	vr.Errors = append(vr.Errors, ValidationError{Field: field, Message: msg})
}

func (vr *ValidationResult) IsValid() bool {
	return len(vr.Errors) == 0
}

func (vr *ValidationResult) String() string {
	if vr.IsValid() {
		return "Validation passed"
	}
	var sb strings.Builder
	fmt.Fprintf(&sb, "Validation failed with %d error(s):\n", len(vr.Errors))
	for _, e := range vr.Errors {
		fmt.Fprintf(&sb, "  - %s\n", e.Error())
	}
	return sb.String()
}

// UserProfile represents a JSON-like user profile to validate.
type UserProfile struct {
	Name    string
	Email   string
	Age     int
	Address *Address
	Tags    []string
}

// Address represents a nested address object.
type Address struct {
	Street string
	City   string
	Zip    string
}

// ValidateUserProfile checks all fields of a user profile and nested objects.
func ValidateUserProfile(p UserProfile) *ValidationResult {
	result := &ValidationResult{}

	// Top-level field validations
	if strings.TrimSpace(p.Name) == "" {
		result.AddError("name", "must not be empty")
	} else if len(p.Name) < 2 || len(p.Name) > 100 {
		result.AddError("name", "must be between 2 and 100 characters")
	}

	if !strings.Contains(p.Email, "@") || !strings.Contains(p.Email, ".") {
		result.AddError("email", "must be a valid email address")
	}

	if p.Age < 0 || p.Age > 150 {
		result.AddError("age", "must be between 0 and 150")
	}

	// Nested address validation
	if p.Address == nil {
		result.AddError("address", "must not be nil")
	} else {
		validateAddress(p.Address, result)
	}

	// Tags validation
	if len(p.Tags) > 10 {
		result.AddError("tags", "must not exceed 10 items")
	}
	for i, tag := range p.Tags {
		if strings.TrimSpace(tag) == "" {
			result.AddError(fmt.Sprintf("tags[%d]", i), "must not be empty")
		}
	}

	return result
}

// validateAddress validates address fields, prefixing errors with "address.".
func validateAddress(a *Address, result *ValidationResult) {
	if strings.TrimSpace(a.Street) == "" {
		result.AddError("address.street", "must not be empty")
	}
	if strings.TrimSpace(a.City) == "" {
		result.AddError("address.city", "must not be empty")
	}
	if len(a.Zip) != 5 {
		result.AddError("address.zip", "must be exactly 5 characters")
	}
	for _, ch := range a.Zip {
		if ch < '0' || ch > '9' {
			result.AddError("address.zip", "must contain only digits")
			break
		}
	}
}

func main() {
	// Valid profile
	valid := UserProfile{
		Name:    "Alice Johnson",
		Email:   "alice@example.com",
		Age:     30,
		Address: &Address{Street: "123 Main St", City: "Springfield", Zip: "62701"},
		Tags:    []string{"admin", "active"},
	}
	fmt.Println(ValidateUserProfile(valid))

	// Invalid profile with multiple errors
	invalid := UserProfile{
		Name:    "",
		Email:   "not-an-email",
		Age:     -5,
		Address: &Address{Street: "", City: "X", Zip: "abc"},
		Tags:    []string{"ok", ""},
	}
	fmt.Println(ValidateUserProfile(invalid))

	// Missing address
	noAddr := UserProfile{Name: "Bob", Email: "bob@test.com", Age: 25}
	fmt.Println(ValidateUserProfile(noAddr))
}

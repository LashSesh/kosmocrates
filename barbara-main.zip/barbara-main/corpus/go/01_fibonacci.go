package main

import "fmt"

// FibMemo computes fibonacci numbers using memoization with a map.
// This avoids the exponential time complexity of naive recursion.
var memo = map[int]int64{}

func fibMemo(n int) int64 {
	if n <= 0 {
		return 0
	}
	if n == 1 {
		return 1
	}
	if val, ok := memo[n]; ok {
		return val
	}
	result := fibMemo(n-1) + fibMemo(n-2)
	memo[n] = result
	return result
}

// fibIterative computes fibonacci using a simple iterative approach.
// Runs in O(n) time and O(1) space.
func fibIterative(n int) int64 {
	if n <= 0 {
		return 0
	}
	if n == 1 {
		return 1
	}
	var prev, curr int64 = 0, 1
	for i := 2; i <= n; i++ {
		prev, curr = curr, prev+curr
	}
	return curr
}

// fibSequence generates the first n fibonacci numbers as a slice.
func fibSequence(n int) []int64 {
	if n <= 0 {
		return []int64{}
	}
	seq := make([]int64, n)
	seq[0] = 0
	if n > 1 {
		seq[1] = 1
	}
	for i := 2; i < n; i++ {
		seq[i] = seq[i-1] + seq[i-2]
	}
	return seq
}

// isFibonacci checks whether a given number belongs to the fibonacci sequence.
// Uses the property that n is fibonacci iff 5*n^2+4 or 5*n^2-4 is a perfect square.
func isFibonacci(n int64) bool {
	if n < 0 {
		return false
	}
	return isPerfectSquare(5*n*n+4) || isPerfectSquare(5*n*n-4)
}

// isPerfectSquare returns true if n is a perfect square.
func isPerfectSquare(n int64) bool {
	if n < 0 {
		return false
	}
	s := int64(0)
	for s*s <= n {
		if s*s == n {
			return true
		}
		s++
		// Optimization: jump closer for large numbers
		if s > 1000 {
			break
		}
	}
	// Fallback: Newton's method for large numbers
	x := n
	for x*x > n {
		x = (x + n/x) / 2
	}
	return x*x == n
}

// fibSumEven returns the sum of even fibonacci numbers up to limit.
func fibSumEven(limit int64) int64 {
	var sum int64
	var a, b int64 = 0, 1
	for b <= limit {
		if b%2 == 0 {
			sum += b
		}
		a, b = b, a+b
	}
	return sum
}

func main() {
	fmt.Println("Memoized fib(10):", fibMemo(10))
	fmt.Println("Iterative fib(10):", fibIterative(10))
	fmt.Println("Sequence(10):", fibSequence(10))
	fmt.Println("Is 21 fibonacci?", isFibonacci(21))
	fmt.Println("Is 22 fibonacci?", isFibonacci(22))
	fmt.Println("Sum of even fibs up to 100:", fibSumEven(100))
}

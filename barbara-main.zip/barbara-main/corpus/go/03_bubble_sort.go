package main

import "fmt"

// bubbleSort sorts a slice in-place using bubble sort with early exit optimization.
// If no swaps occur during a pass, the slice is already sorted.
func bubbleSort(arr []int) {
	n := len(arr)
	for i := 0; i < n-1; i++ {
		swapped := false
		for j := 0; j < n-i-1; j++ {
			if arr[j] > arr[j+1] {
				arr[j], arr[j+1] = arr[j+1], arr[j]
				swapped = true
			}
		}
		if !swapped {
			break
		}
	}
}

// selectionSort sorts a slice in-place by repeatedly finding the minimum
// element from the unsorted portion and placing it at the beginning.
func selectionSort(arr []int) {
	n := len(arr)
	for i := 0; i < n-1; i++ {
		minIdx := i
		for j := i + 1; j < n; j++ {
			if arr[j] < arr[minIdx] {
				minIdx = j
			}
		}
		if minIdx != i {
			arr[i], arr[minIdx] = arr[minIdx], arr[i]
		}
	}
}

// insertionSort sorts a slice by building the sorted portion one element at a time.
// Efficient for small or nearly sorted datasets.
func insertionSort(arr []int) {
	for i := 1; i < len(arr); i++ {
		key := arr[i]
		j := i - 1
		for j >= 0 && arr[j] > key {
			arr[j+1] = arr[j]
			j--
		}
		arr[j+1] = key
	}
}

// isSorted checks whether a slice is sorted in ascending order.
func isSorted(arr []int) bool {
	for i := 1; i < len(arr); i++ {
		if arr[i] < arr[i-1] {
			return false
		}
	}
	return true
}

// copySlice returns a shallow copy of a slice.
func copySlice(arr []int) []int {
	c := make([]int, len(arr))
	copy(c, arr)
	return c
}

// benchmarkSort runs a sort function and reports whether the result is correct.
func benchmarkSort(name string, sortFn func([]int), data []int) {
	arr := copySlice(data)
	sortFn(arr)
	status := "PASS"
	if !isSorted(arr) {
		status = "FAIL"
	}
	fmt.Printf("%-20s %s  result: %v\n", name, status, arr)
}

func main() {
	testData := []int{64, 34, 25, 12, 22, 11, 90}

	benchmarkSort("Bubble Sort", bubbleSort, testData)
	benchmarkSort("Selection Sort", selectionSort, testData)
	benchmarkSort("Insertion Sort", insertionSort, testData)

	// Test early exit on already-sorted data
	sorted := []int{1, 2, 3, 4, 5}
	benchmarkSort("Bubble (sorted)", bubbleSort, sorted)

	// Edge cases
	benchmarkSort("Empty slice", bubbleSort, []int{})
	benchmarkSort("Single element", bubbleSort, []int{42})
	benchmarkSort("Reverse sorted", bubbleSort, []int{5, 4, 3, 2, 1})
}

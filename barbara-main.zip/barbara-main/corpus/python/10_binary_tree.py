"""Binary search tree with insert, traversal, search, depth, and balance check."""

from typing import Callable, List, Optional


class TreeNode:
    """A node in a binary search tree."""

    def __init__(self, value: int) -> None:
        self.value: int = value
        self.left: Optional["TreeNode"] = None
        self.right: Optional["TreeNode"] = None

    def __repr__(self) -> str:
        return f"TreeNode({self.value})"


class BinarySearchTree:
    """Binary search tree supporting standard operations."""

    def __init__(self) -> None:
        self.root: Optional[TreeNode] = None
        self._size: int = 0

    @property
    def size(self) -> int:
        return self._size

    def insert(self, value: int) -> None:
        """Insert a value into the tree. Duplicates are ignored."""
        if self.root is None:
            self.root = TreeNode(value)
            self._size += 1
        elif self._insert_recursive(self.root, value):
            self._size += 1

    def _insert_recursive(self, node: TreeNode, value: int) -> bool:
        if value < node.value:
            if node.left is None:
                node.left = TreeNode(value)
                return True
            return self._insert_recursive(node.left, value)
        elif value > node.value:
            if node.right is None:
                node.right = TreeNode(value)
                return True
            return self._insert_recursive(node.right, value)
        return False

    def search(self, value: int) -> bool:
        """Check whether a value exists in the tree."""
        return self._search_recursive(self.root, value)

    def _search_recursive(self, node: Optional[TreeNode], value: int) -> bool:
        if node is None:
            return False
        if value == node.value:
            return True
        if value < node.value:
            return self._search_recursive(node.left, value)
        return self._search_recursive(node.right, value)

    def find_min(self) -> Optional[int]:
        """Find the minimum value in the tree."""
        node = self.root
        if node is None:
            return None
        while node.left is not None:
            node = node.left
        return node.value

    def find_max(self) -> Optional[int]:
        """Find the maximum value in the tree."""
        node = self.root
        if node is None:
            return None
        while node.right is not None:
            node = node.right
        return node.value

    def _collect(self, node: Optional[TreeNode], order: str, result: List[int]) -> None:
        if node is None:
            return
        if order == "pre":
            result.append(node.value)
        self._collect(node.left, order, result)
        if order == "in":
            result.append(node.value)
        self._collect(node.right, order, result)
        if order == "post":
            result.append(node.value)

    def inorder(self) -> List[int]:
        """Return values in in-order traversal (sorted order)."""
        result: List[int] = []
        self._collect(self.root, "in", result)
        return result

    def preorder(self) -> List[int]:
        """Return values in pre-order traversal."""
        result: List[int] = []
        self._collect(self.root, "pre", result)
        return result

    def postorder(self) -> List[int]:
        """Return values in post-order traversal."""
        result: List[int] = []
        self._collect(self.root, "post", result)
        return result

    def depth(self) -> int:
        """Compute the maximum depth (height) of the tree."""
        return self._depth_recursive(self.root)

    def _depth_recursive(self, node: Optional[TreeNode]) -> int:
        if node is None:
            return 0
        return 1 + max(self._depth_recursive(node.left), self._depth_recursive(node.right))

    def is_balanced(self) -> bool:
        """Check whether the tree is height-balanced."""
        return self._check_balanced(self.root) >= 0

    def _check_balanced(self, node: Optional[TreeNode]) -> int:
        """Return the height if balanced, or -1 if unbalanced."""
        if node is None:
            return 0
        left = self._check_balanced(node.left)
        if left < 0:
            return -1
        right = self._check_balanced(node.right)
        if right < 0:
            return -1
        if abs(left - right) > 1:
            return -1
        return 1 + max(left, right)

    def traverse(self, callback: Callable[[int], None]) -> None:
        """Apply a callback to each value using in-order traversal."""
        self._traverse_recursive(self.root, callback)

    def _traverse_recursive(self, node: Optional[TreeNode],
                            callback: Callable[[int], None]) -> None:
        if node is None:
            return
        self._traverse_recursive(node.left, callback)
        callback(node.value)
        self._traverse_recursive(node.right, callback)

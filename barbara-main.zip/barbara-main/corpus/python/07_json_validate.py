"""JSON schema validation with multiple error types and nested validation."""

from typing import Any, Dict, List, Optional, Union
from dataclasses import dataclass, field
from enum import Enum


class ErrorKind(Enum):
    """Categories of validation errors."""
    TYPE_MISMATCH = "type_mismatch"
    MISSING_FIELD = "missing_field"
    INVALID_VALUE = "invalid_value"
    OUT_OF_RANGE = "out_of_range"
    PATTERN_MISMATCH = "pattern_mismatch"
    ARRAY_LENGTH = "array_length"


@dataclass
class ValidationError:
    """A single validation error with path context."""
    path: str
    kind: ErrorKind
    message: str
    expected: Optional[str] = None
    actual: Optional[str] = None

    def __str__(self) -> str:
        base = f"[{self.path}] {self.kind.value}: {self.message}"
        if self.expected and self.actual:
            base += f" (expected {self.expected}, got {self.actual})"
        return base


@dataclass
class ValidationResult:
    """Collects validation errors for a single validation run."""
    errors: List[ValidationError] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return len(self.errors) == 0

    def add_error(self, path: str, kind: ErrorKind, message: str,
                  expected: Optional[str] = None, actual: Optional[str] = None) -> None:
        self.errors.append(ValidationError(path, kind, message, expected, actual))

    def merge(self, other: "ValidationResult") -> None:
        self.errors.extend(other.errors)


SchemaType = Dict[str, Any]


def _type_name(value: Any) -> str:
    """Return a human-readable type name for a value."""
    if isinstance(value, bool):
        return "boolean"
    if isinstance(value, int):
        return "integer"
    if isinstance(value, float):
        return "number"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    if value is None:
        return "null"
    return type(value).__name__


def _check_type(value: Any, expected: str) -> bool:
    """Check if a value matches the expected type string."""
    if expected == "boolean":
        return isinstance(value, bool)
    if expected == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    type_map = {"string": str, "number": (int, float), "array": list,
                "object": dict, "null": type(None)}
    expected_type = type_map.get(expected)
    return True if expected_type is None else isinstance(value, expected_type)


def validate(data: Any, schema: SchemaType, path: str = "$") -> ValidationResult:
    """Validate data against a schema definition.

    Supports type checking, required fields, numeric min/max, string and array
    length constraints, enum values, and recursive nested validation.
    """
    result = ValidationResult()
    expected_type = schema.get("type")
    if expected_type is not None and not _check_type(data, expected_type):
        result.add_error(path, ErrorKind.TYPE_MISMATCH,
                         f"Expected type '{expected_type}'",
                         expected=expected_type, actual=_type_name(data))
        return result
    if "enum" in schema and data not in schema["enum"]:
        result.add_error(path, ErrorKind.INVALID_VALUE,
                         f"Value must be one of {schema['enum']}")
    if isinstance(data, (int, float)) and not isinstance(data, bool):
        if "min" in schema and data < schema["min"]:
            result.add_error(path, ErrorKind.OUT_OF_RANGE,
                             f"Value {data} is below minimum {schema['min']}")
        if "max" in schema and data > schema["max"]:
            result.add_error(path, ErrorKind.OUT_OF_RANGE,
                             f"Value {data} exceeds maximum {schema['max']}")
    if isinstance(data, str):
        if "min_length" in schema and len(data) < schema["min_length"]:
            result.add_error(path, ErrorKind.OUT_OF_RANGE,
                             f"String length {len(data)} below minimum {schema['min_length']}")
        if "max_length" in schema and len(data) > schema["max_length"]:
            result.add_error(path, ErrorKind.OUT_OF_RANGE,
                             f"String length {len(data)} exceeds maximum {schema['max_length']}")
    if isinstance(data, list):
        if "min_length" in schema and len(data) < schema["min_length"]:
            result.add_error(path, ErrorKind.ARRAY_LENGTH,
                             f"Array length {len(data)} below minimum {schema['min_length']}")
        if "max_length" in schema and len(data) > schema["max_length"]:
            result.add_error(path, ErrorKind.ARRAY_LENGTH,
                             f"Array length {len(data)} exceeds maximum {schema['max_length']}")
        if "items" in schema:
            for i, item in enumerate(data):
                result.merge(validate(item, schema["items"], f"{path}[{i}]"))
    if isinstance(data, dict):
        for field_name in schema.get("required", []):
            if field_name not in data:
                result.add_error(f"{path}.{field_name}", ErrorKind.MISSING_FIELD,
                                 f"Required field '{field_name}' is missing")
        for field_name, field_schema in schema.get("properties", {}).items():
            if field_name in data:
                result.merge(validate(data[field_name], field_schema, f"{path}.{field_name}"))
    return result

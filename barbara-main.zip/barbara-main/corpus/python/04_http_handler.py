"""CRUD HTTP handler with in-memory store, validation, and error handling."""

from typing import Any, Dict, List, Optional
from dataclasses import dataclass, field
import json
import time


@dataclass
class HttpRequest:
    """Represents an incoming HTTP request."""
    method: str
    path: str
    headers: Dict[str, str] = field(default_factory=dict)
    body: Optional[str] = None

    def json_body(self) -> Optional[Dict[str, Any]]:
        """Parse the request body as JSON."""
        if self.body is None:
            return None
        try:
            return json.loads(self.body)
        except json.JSONDecodeError:
            return None


@dataclass
class HttpResponse:
    """Represents an HTTP response."""
    status_code: int
    headers: Dict[str, str] = field(default_factory=dict)
    body: str = ""

    @staticmethod
    def json_response(status_code: int, data: Any) -> "HttpResponse":
        """Create a JSON response."""
        return HttpResponse(
            status_code=status_code,
            headers={"Content-Type": "application/json"},
            body=json.dumps(data),
        )

    @staticmethod
    def error_response(status_code: int, message: str) -> "HttpResponse":
        """Create an error response."""
        return HttpResponse.json_response(status_code, {"error": message})


class ValidationError(Exception):
    """Raised when request validation fails."""
    def __init__(self, field: str, message: str):
        self.field = field
        self.message = message
        super().__init__(f"Validation error on '{field}': {message}")


@dataclass
class Record:
    """A stored record with metadata."""
    id: str
    data: Dict[str, Any]
    created_at: float
    updated_at: float


class CrudHandler:
    """CRUD handler with in-memory storage and validation."""

    def __init__(self) -> None:
        self._store: Dict[str, Record] = {}
        self._next_id: int = 1
        self._required_fields: List[str] = ["name", "value"]

    def handle(self, request: HttpRequest) -> HttpResponse:
        """Route and handle an HTTP request."""
        parts = request.path.strip("/").split("/")
        resource = parts[0] if parts else ""
        record_id = parts[1] if len(parts) > 1 else None

        if resource != "records":
            return HttpResponse.error_response(404, "Not found")

        try:
            if request.method == "GET" and record_id is None:
                return self._list_records()
            elif request.method == "GET" and record_id:
                return self._get_record(record_id)
            elif request.method == "POST" and record_id is None:
                return self._create_record(request)
            elif request.method == "PUT" and record_id:
                return self._update_record(record_id, request)
            elif request.method == "DELETE" and record_id:
                return self._delete_record(record_id)
            else:
                return HttpResponse.error_response(405, "Method not allowed")
        except ValidationError as e:
            return HttpResponse.error_response(400, str(e))

    def _validate(self, data: Optional[Dict[str, Any]]) -> Dict[str, Any]:
        """Validate request data against required fields."""
        if data is None:
            raise ValidationError("body", "Request body must be valid JSON")
        for f in self._required_fields:
            if f not in data:
                raise ValidationError(f, f"Field '{f}' is required")
            if not isinstance(data[f], (str, int, float)):
                raise ValidationError(f, f"Field '{f}' must be a string or number")
        return data

    def _list_records(self) -> HttpResponse:
        records = [{"id": r.id, **r.data} for r in self._store.values()]
        return HttpResponse.json_response(200, records)

    def _get_record(self, record_id: str) -> HttpResponse:
        record = self._store.get(record_id)
        if record is None:
            return HttpResponse.error_response(404, f"Record '{record_id}' not found")
        return HttpResponse.json_response(200, {"id": record.id, **record.data})

    def _create_record(self, request: HttpRequest) -> HttpResponse:
        data = self._validate(request.json_body())
        record_id = str(self._next_id)
        self._next_id += 1
        now = time.time()
        record = Record(id=record_id, data=data, created_at=now, updated_at=now)
        self._store[record_id] = record
        return HttpResponse.json_response(201, {"id": record.id, **record.data})

    def _update_record(self, record_id: str, request: HttpRequest) -> HttpResponse:
        if record_id not in self._store:
            return HttpResponse.error_response(404, f"Record '{record_id}' not found")
        data = self._validate(request.json_body())
        record = self._store[record_id]
        record.data = data
        record.updated_at = time.time()
        return HttpResponse.json_response(200, {"id": record.id, **record.data})

    def _delete_record(self, record_id: str) -> HttpResponse:
        if record_id not in self._store:
            return HttpResponse.error_response(404, f"Record '{record_id}' not found")
        del self._store[record_id]
        return HttpResponse.json_response(200, {"deleted": record_id})

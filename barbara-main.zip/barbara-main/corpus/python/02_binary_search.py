"""Binary search implementations: iterative, recursive, and bound-finding variants."""

from typing import List, Optional, TypeVar, Callable

T = TypeVar("T")


def binary_search_iterative(arr: List[int], target: int) -> int:
    """Find the index of target in a sorted array using iterative binary search.

    Args:
        arr: A sorted list of integers.
        target: The value to search for.

    Returns:
        The index of the target, or -1 if not found.
    """
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = left + (right - left) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1


def binary_search_recursive(arr: List[int], target: int, left: int, right: int) -> int:
    """Find the index of target in a sorted array using recursive binary search.

    Args:
        arr: A sorted list of integers.
        target: The value to search for.
        left: The left boundary index.
        right: The right boundary index.

    Returns:
        The index of the target, or -1 if not found.
    """
    if left > right:
        return -1
    mid = left + (right - left) // 2
    if arr[mid] == target:
        return mid
    elif arr[mid] < target:
        return binary_search_recursive(arr, target, mid + 1, right)
    else:
        return binary_search_recursive(arr, target, left, mid - 1)


def lower_bound(arr: List[int], target: int) -> int:
    """Find the index of the first element not less than target.

    Args:
        arr: A sorted list of integers.
        target: The threshold value.

    Returns:
        The index of the first element >= target, or len(arr) if all are smaller.
    """
    left, right = 0, len(arr)
    while left < right:
        mid = left + (right - left) // 2
        if arr[mid] < target:
            left = mid + 1
        else:
            right = mid
    return left


def upper_bound(arr: List[int], target: int) -> int:
    """Find the index of the first element greater than target.

    Args:
        arr: A sorted list of integers.
        target: The threshold value.

    Returns:
        The index of the first element > target, or len(arr) if none are greater.
    """
    left, right = 0, len(arr)
    while left < right:
        mid = left + (right - left) // 2
        if arr[mid] <= target:
            left = mid + 1
        else:
            right = mid
    return left


def equal_range(arr: List[int], target: int) -> tuple:
    """Find the range of indices where target appears in a sorted array.

    Args:
        arr: A sorted list of integers.
        target: The value to search for.

    Returns:
        A tuple (start, end) representing the half-open range [start, end).
    """
    return (lower_bound(arr, target), upper_bound(arr, target))


def binary_search_custom(
    arr: List[T], target: T, key: Callable[[T], int], compare_val: int
) -> Optional[int]:
    """Binary search with a custom key function.

    Args:
        arr: A sorted list of elements.
        target: The value to search for.
        key: A function that extracts a comparable integer from each element.
        compare_val: The integer value to compare against using the key function.

    Returns:
        The index of the matching element, or None if not found.
    """
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = left + (right - left) // 2
        mid_val = key(arr[mid])
        if mid_val == compare_val:
            return mid
        elif mid_val < compare_val:
            left = mid + 1
        else:
            right = mid - 1
    return None


def search_insert_position(arr: List[int], target: int) -> int:
    """Find the position where target should be inserted to keep the array sorted.

    Args:
        arr: A sorted list of integers.
        target: The value to insert.

    Returns:
        The insertion index.
    """
    return lower_bound(arr, target)

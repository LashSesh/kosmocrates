"""Simulated async HTTP fetch with retry logic, timeout, and rate limiting."""

from typing import Callable, Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum
import time


class FetchStatus(Enum):
    """Possible outcomes of a fetch operation."""
    SUCCESS = "success"
    TIMEOUT = "timeout"
    RATE_LIMITED = "rate_limited"
    ERROR = "error"
    RETRYING = "retrying"


@dataclass
class FetchResponse:
    """The result of a fetch operation."""
    status: FetchStatus
    status_code: int
    body: Optional[str] = None
    headers: Dict[str, str] = field(default_factory=dict)
    elapsed_ms: float = 0.0
    attempts: int = 1


@dataclass
class FetchRequest:
    """Configuration for a fetch operation."""
    url: str
    method: str = "GET"
    headers: Dict[str, str] = field(default_factory=dict)
    body: Optional[str] = None
    timeout_ms: float = 5000.0
    max_retries: int = 3
    retry_delay_ms: float = 1000.0


class RateLimiter:
    """Token-bucket rate limiter for controlling request throughput."""

    def __init__(self, max_tokens: int, refill_rate: float) -> None:
        self._max_tokens = max_tokens
        self._tokens = float(max_tokens)
        self._refill_rate = refill_rate
        self._last_refill: float = time.time()

    def try_acquire(self) -> bool:
        """Attempt to acquire a token. Returns True if successful."""
        self._refill()
        if self._tokens >= 1.0:
            self._tokens -= 1.0
            return True
        return False

    def _refill(self) -> None:
        now = time.time()
        elapsed = now - self._last_refill
        self._tokens = min(self._max_tokens, self._tokens + elapsed * self._refill_rate)
        self._last_refill = now

    @property
    def available_tokens(self) -> float:
        self._refill()
        return self._tokens


class FetchClient:
    """Simulated HTTP client with retry logic, timeouts, and rate limiting."""

    def __init__(self, rate_limiter: Optional[RateLimiter] = None,
                 mock_handler: Optional[Callable[[FetchRequest], FetchResponse]] = None) -> None:
        self._rate_limiter = rate_limiter
        self._mock_handler = mock_handler
        self._request_log: List[FetchRequest] = []

    def fetch(self, request: FetchRequest) -> FetchResponse:
        """Execute a fetch request with retry and rate limiting logic."""
        self._request_log.append(request)
        if self._rate_limiter is not None and not self._rate_limiter.try_acquire():
            return FetchResponse(status=FetchStatus.RATE_LIMITED,
                                 status_code=429, body="Rate limit exceeded", attempts=0)
        last_response: Optional[FetchResponse] = None
        for attempt in range(1, request.max_retries + 1):
            response = self._execute(request)
            response.attempts = attempt
            if response.status == FetchStatus.SUCCESS:
                return response
            if response.status == FetchStatus.TIMEOUT or response.status_code >= 500:
                last_response = response
                continue
            return response
        if last_response is not None:
            last_response.status = FetchStatus.ERROR
            return last_response
        return FetchResponse(status=FetchStatus.ERROR, status_code=0,
                             body="All retries exhausted", attempts=request.max_retries)

    def _execute(self, request: FetchRequest) -> FetchResponse:
        """Execute a single request attempt using the mock handler."""
        start = time.time()
        if self._mock_handler is not None:
            response = self._mock_handler(request)
        else:
            response = FetchResponse(status=FetchStatus.SUCCESS,
                                     status_code=200, body='{"ok": true}')
        elapsed = (time.time() - start) * 1000.0
        response.elapsed_ms = elapsed
        if elapsed > request.timeout_ms:
            return FetchResponse(status=FetchStatus.TIMEOUT,
                                 status_code=408, elapsed_ms=elapsed)
        return response

    @property
    def request_count(self) -> int:
        return len(self._request_log)

    def clear_log(self) -> None:
        self._request_log.clear()

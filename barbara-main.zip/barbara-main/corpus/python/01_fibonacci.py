"""Fibonacci sequence implementations with memoization and iterative approaches."""

from typing import Dict, List, Optional
from functools import lru_cache


def fibonacci_recursive(n: int, memo: Optional[Dict[int, int]] = None) -> int:
    """Compute the nth Fibonacci number using recursion with memoization.

    Args:
        n: The index in the Fibonacci sequence (0-based).
        memo: Optional memoization dictionary for caching results.

    Returns:
        The nth Fibonacci number.

    Raises:
        ValueError: If n is negative.
    """
    if n < 0:
        raise ValueError(f"Fibonacci is not defined for negative numbers: {n}")
    if memo is None:
        memo = {}
    if n in memo:
        return memo[n]
    if n <= 1:
        return n
    result = fibonacci_recursive(n - 1, memo) + fibonacci_recursive(n - 2, memo)
    memo[n] = result
    return result


def fibonacci_iterative(n: int) -> int:
    """Compute the nth Fibonacci number using iteration.

    Args:
        n: The index in the Fibonacci sequence (0-based).

    Returns:
        The nth Fibonacci number.

    Raises:
        ValueError: If n is negative.
    """
    if n < 0:
        raise ValueError(f"Fibonacci is not defined for negative numbers: {n}")
    if n <= 1:
        return n
    prev, curr = 0, 1
    for _ in range(2, n + 1):
        prev, curr = curr, prev + curr
    return curr


@lru_cache(maxsize=256)
def fibonacci_cached(n: int) -> int:
    """Compute the nth Fibonacci number using lru_cache decorator.

    Args:
        n: The index in the Fibonacci sequence (0-based).

    Returns:
        The nth Fibonacci number.
    """
    if n < 0:
        raise ValueError(f"Fibonacci is not defined for negative numbers: {n}")
    if n <= 1:
        return n
    return fibonacci_cached(n - 1) + fibonacci_cached(n - 2)


def fibonacci_sequence(count: int) -> List[int]:
    """Generate a list of the first `count` Fibonacci numbers.

    Args:
        count: How many Fibonacci numbers to generate.

    Returns:
        A list of Fibonacci numbers.
    """
    if count <= 0:
        return []
    sequence: List[int] = []
    memo: Dict[int, int] = {}
    for i in range(count):
        sequence.append(fibonacci_recursive(i, memo))
    return sequence


def is_fibonacci(num: int) -> bool:
    """Check whether a given number belongs to the Fibonacci sequence.

    Uses the property that n is Fibonacci if and only if
    5*n^2 + 4 or 5*n^2 - 4 is a perfect square.

    Args:
        num: The number to check.

    Returns:
        True if the number is a Fibonacci number, False otherwise.
    """
    if num < 0:
        return False

    def is_perfect_square(x: int) -> bool:
        if x < 0:
            return False
        root = int(x ** 0.5)
        return root * root == x

    return is_perfect_square(5 * num * num + 4) or is_perfect_square(5 * num * num - 4)


def fibonacci_index(num: int) -> int:
    """Find the index of a Fibonacci number in the sequence.

    Args:
        num: A Fibonacci number.

    Returns:
        The 0-based index, or -1 if the number is not a Fibonacci number.
    """
    if not is_fibonacci(num):
        return -1
    if num == 0:
        return 0
    a, b = 0, 1
    index = 1
    while b < num:
        a, b = b, a + b
        index += 1
    return index

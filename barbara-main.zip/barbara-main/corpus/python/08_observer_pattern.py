"""Event emitter with subscribe/unsubscribe, typed events, and handler priority."""

from typing import Any, Callable, Dict, List, Optional
from dataclasses import dataclass, field
from enum import Enum


class EventType(Enum):
    """Standard event types for the observer system."""
    CREATED = "created"
    UPDATED = "updated"
    DELETED = "deleted"
    ERROR = "error"
    CUSTOM = "custom"


@dataclass
class Event:
    """An event carrying a type, topic, and payload."""
    event_type: EventType
    topic: str
    payload: Any = None
    timestamp: float = 0.0

    def __str__(self) -> str:
        return f"Event({self.event_type.value}, topic={self.topic!r})"


@dataclass
class Subscription:
    """A registered event handler with priority and metadata."""
    handler_id: str
    callback: Callable[[Event], None]
    priority: int = 0
    event_type: Optional[EventType] = None
    topic: Optional[str] = None
    active: bool = True


class EventEmitter:
    """Event emitter with typed events, topics, and prioritized handlers."""

    def __init__(self) -> None:
        self._subscriptions: Dict[str, Subscription] = {}
        self._event_log: List[Event] = []
        self._max_log_size: int = 1000
        self._next_id: int = 1

    def subscribe(
        self, callback: Callable[[Event], None],
        event_type: Optional[EventType] = None,
        topic: Optional[str] = None, priority: int = 0,
        handler_id: Optional[str] = None,
    ) -> str:
        """Register an event handler. Returns the handler identifier."""
        if handler_id is None:
            handler_id = f"handler_{self._next_id}"
            self._next_id += 1
        sub = Subscription(handler_id=handler_id, callback=callback,
                           priority=priority, event_type=event_type,
                           topic=topic, active=True)
        self._subscriptions[handler_id] = sub
        return handler_id

    def unsubscribe(self, handler_id: str) -> bool:
        """Remove a handler by its identifier."""
        if handler_id in self._subscriptions:
            del self._subscriptions[handler_id]
            return True
        return False

    def pause(self, handler_id: str) -> bool:
        """Temporarily disable a handler without removing it."""
        sub = self._subscriptions.get(handler_id)
        if sub is not None:
            sub.active = False
            return True
        return False

    def resume(self, handler_id: str) -> bool:
        """Re-enable a paused handler."""
        sub = self._subscriptions.get(handler_id)
        if sub is not None:
            sub.active = True
            return True
        return False

    def emit(self, event: Event) -> int:
        """Emit an event to all matching handlers in priority order.

        Returns the number of handlers that were invoked.
        """
        self._log_event(event)
        matching = self._get_matching_handlers(event)
        matching.sort(key=lambda s: s.priority, reverse=True)
        invoked = 0
        for sub in matching:
            try:
                sub.callback(event)
                invoked += 1
            except Exception:
                pass
        return invoked

    def _get_matching_handlers(self, event: Event) -> List[Subscription]:
        """Return all active subscriptions that match the given event."""
        result: List[Subscription] = []
        for sub in self._subscriptions.values():
            if not sub.active:
                continue
            if sub.event_type is not None and sub.event_type != event.event_type:
                continue
            if sub.topic is not None and sub.topic != event.topic:
                continue
            result.append(sub)
        return result

    def _log_event(self, event: Event) -> None:
        """Append the event to the internal log, evicting old entries if needed."""
        self._event_log.append(event)
        if len(self._event_log) > self._max_log_size:
            self._event_log = self._event_log[-self._max_log_size:]

    def get_event_log(self, event_type: Optional[EventType] = None) -> List[Event]:
        """Retrieve logged events, optionally filtered by type."""
        if event_type is None:
            return list(self._event_log)
        return [e for e in self._event_log if e.event_type == event_type]

    def handler_count(self) -> int:
        """Return the total number of registered handlers."""
        return len(self._subscriptions)

    def clear(self) -> None:
        """Remove all handlers and clear the event log."""
        self._subscriptions.clear()
        self._event_log.clear()

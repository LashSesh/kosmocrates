"""File transformation pipeline: parse CSV, filter, aggregate, and write output."""

from typing import List, Dict, Optional, Callable
from dataclasses import dataclass


@dataclass
class TransformError:
    """Represents an error encountered during transformation."""
    line_number: int
    message: str

    def __str__(self) -> str:
        return f"Line {self.line_number}: {self.message}"


@dataclass
class TransformResult:
    """The result of a file transformation operation."""
    records: List[Dict[str, str]]
    errors: List[TransformError]
    lines_processed: int

    @property
    def success(self) -> bool:
        return len(self.errors) == 0


def parse_csv_line(line: str, headers: List[str]) -> Optional[Dict[str, str]]:
    """Parse a single CSV line into a dictionary keyed by headers."""
    fields = line.strip().split(",")
    if len(fields) != len(headers):
        return None
    return {headers[i]: fields[i].strip() for i in range(len(headers))}


def parse_csv(content: str) -> TransformResult:
    """Parse CSV content into a list of record dictionaries.

    The first line is treated as a header row.
    """
    lines = content.strip().split("\n")
    if not lines:
        return TransformResult(records=[], errors=[TransformError(0, "Empty input")], lines_processed=0)

    headers = [h.strip() for h in lines[0].split(",")]
    records: List[Dict[str, str]] = []
    errors: List[TransformError] = []

    for i, line in enumerate(lines[1:], start=2):
        if not line.strip():
            continue
        record = parse_csv_line(line, headers)
        if record is None:
            errors.append(TransformError(i, f"Expected {len(headers)} fields"))
        else:
            records.append(record)

    return TransformResult(records=records, errors=errors, lines_processed=len(lines) - 1)


def filter_records(
    records: List[Dict[str, str]],
    predicate: Callable[[Dict[str, str]], bool],
) -> List[Dict[str, str]]:
    """Filter records using a predicate function."""
    return [r for r in records if predicate(r)]


def aggregate_records(
    records: List[Dict[str, str]], group_by: str, value_field: str
) -> Dict[str, float]:
    """Aggregate records by summing a numeric field grouped by a key field."""
    result: Dict[str, float] = {}
    for record in records:
        key = record.get(group_by, "unknown")
        try:
            value = float(record.get(value_field, "0"))
        except ValueError:
            value = 0.0
        result[key] = result.get(key, 0.0) + value
    return result


def format_output(aggregated: Dict[str, float], title: str) -> str:
    """Format aggregated results into a readable report."""
    lines = [title, "=" * len(title)]
    total = 0.0
    for key in sorted(aggregated.keys()):
        value = aggregated[key]
        total += value
        lines.append(f"  {key}: {value:.2f}")
    lines.append(f"  Total: {total:.2f}")
    return "\n".join(lines)


def transform_pipeline(
    content: str,
    filter_fn: Optional[Callable[[Dict[str, str]], bool]] = None,
    group_by: str = "category",
    value_field: str = "amount",
    title: str = "Aggregation Report",
) -> str:
    """Run the full transformation pipeline on CSV content.

    Parses the CSV, optionally filters records, aggregates by group,
    and formats the result as a report string.
    """
    result = parse_csv(content)
    if not result.success:
        error_lines = [f"  - {e}" for e in result.errors]
        return "Errors:\n" + "\n".join(error_lines)

    records = result.records
    if filter_fn is not None:
        records = filter_records(records, filter_fn)

    aggregated = aggregate_records(records, group_by, value_field)
    return format_output(aggregated, title)

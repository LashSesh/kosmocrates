"""Sorting algorithms: optimized bubble sort and selection sort."""

from typing import List, Callable, TypeVar, Optional

T = TypeVar("T")


def bubble_sort(arr: List[int]) -> List[int]:
    """Sort a list of integers using optimized bubble sort with early exit.

    The optimization skips the already-sorted tail and exits early
    if no swaps occurred during a full pass.

    Args:
        arr: The list of integers to sort.

    Returns:
        The sorted list (sorted in place and returned).
    """
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr


def bubble_sort_generic(
    arr: List[T], comparator: Optional[Callable[[T, T], int]] = None
) -> List[T]:
    """Sort a list using bubble sort with a custom comparator.

    Args:
        arr: The list of elements to sort.
        comparator: A function that returns negative if a < b, 0 if equal,
                    positive if a > b. Defaults to natural ordering.

    Returns:
        The sorted list.
    """
    def default_compare(a: T, b: T) -> int:
        if a < b:  # type: ignore
            return -1
        elif a > b:  # type: ignore
            return 1
        return 0

    cmp = comparator if comparator is not None else default_compare
    n = len(arr)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            if cmp(arr[j], arr[j + 1]) > 0:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
                swapped = True
        if not swapped:
            break
    return arr


def selection_sort(arr: List[int]) -> List[int]:
    """Sort a list of integers using selection sort.

    Args:
        arr: The list of integers to sort.

    Returns:
        The sorted list (sorted in place and returned).
    """
    n = len(arr)
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_idx]:
                min_idx = j
        if min_idx != i:
            arr[i], arr[min_idx] = arr[min_idx], arr[i]
    return arr


def is_sorted(arr: List[int], descending: bool = False) -> bool:
    """Check whether a list is sorted.

    Args:
        arr: The list to check.
        descending: If True, check for descending order.

    Returns:
        True if the list is sorted in the specified order.
    """
    if len(arr) <= 1:
        return True
    for i in range(len(arr) - 1):
        if descending:
            if arr[i] < arr[i + 1]:
                return False
        else:
            if arr[i] > arr[i + 1]:
                return False
    return True


def sort_stats(arr: List[int]) -> dict:
    """Sort a copy of the array using bubble sort and count comparisons and swaps.

    Args:
        arr: The list of integers to sort.

    Returns:
        A dictionary with keys 'sorted', 'comparisons', and 'swaps'.
    """
    data = arr[:]
    comparisons = 0
    swaps = 0
    n = len(data)
    for i in range(n):
        swapped = False
        for j in range(0, n - i - 1):
            comparisons += 1
            if data[j] > data[j + 1]:
                data[j], data[j + 1] = data[j + 1], data[j]
                swaps += 1
                swapped = True
        if not swapped:
            break
    return {"sorted": data, "comparisons": comparisons, "swaps": swaps}

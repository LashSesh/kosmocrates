"""Singly linked list with insert, delete, search, reverse, and display operations."""

from typing import Optional, List, Any


class Node:
    """A node in a singly linked list."""

    def __init__(self, value: Any, next_node: Optional["Node"] = None) -> None:
        self.value = value
        self.next = next_node

    def __repr__(self) -> str:
        return f"Node({self.value!r})"


class LinkedList:
    """Singly linked list supporting common operations."""

    def __init__(self) -> None:
        self.head: Optional[Node] = None
        self._size: int = 0

    @property
    def size(self) -> int:
        return self._size

    def is_empty(self) -> bool:
        return self.head is None

    def push_front(self, value: Any) -> None:
        """Insert a value at the front of the list."""
        self.head = Node(value, self.head)
        self._size += 1

    def push_back(self, value: Any) -> None:
        """Insert a value at the end of the list."""
        new_node = Node(value)
        if self.head is None:
            self.head = new_node
        else:
            current = self.head
            while current.next is not None:
                current = current.next
            current.next = new_node
        self._size += 1

    def insert_at(self, index: int, value: Any) -> bool:
        """Insert a value at a specific index. Returns True on success."""
        if index < 0 or index > self._size:
            return False
        if index == 0:
            self.push_front(value)
            return True
        current = self.head
        for _ in range(index - 1):
            if current is None:
                return False
            current = current.next
        if current is None:
            return False
        current.next = Node(value, current.next)
        self._size += 1
        return True

    def delete_value(self, value: Any) -> bool:
        """Remove the first occurrence of a value. Returns True if found."""
        if self.head is None:
            return False
        if self.head.value == value:
            self.head = self.head.next
            self._size -= 1
            return True
        current = self.head
        while current.next is not None:
            if current.next.value == value:
                current.next = current.next.next
                self._size -= 1
                return True
            current = current.next
        return False

    def delete_at(self, index: int) -> Optional[Any]:
        """Remove the node at a specific index and return its value."""
        if index < 0 or index >= self._size or self.head is None:
            return None
        if index == 0:
            val = self.head.value
            self.head = self.head.next
            self._size -= 1
            return val
        cur = self.head
        for _ in range(index - 1):
            if cur.next is None:
                return None
            cur = cur.next
        if cur.next is None:
            return None
        val = cur.next.value
        cur.next = cur.next.next
        self._size -= 1
        return val

    def search(self, value: Any) -> int:
        """Find the index of the first occurrence, or -1 if not found."""
        current, index = self.head, 0
        while current is not None:
            if current.value == value:
                return index
            current = current.next
            index += 1
        return -1

    def reverse(self) -> None:
        """Reverse the linked list in place."""
        prev: Optional[Node] = None
        current = self.head
        while current is not None:
            nxt = current.next
            current.next = prev
            prev = current
            current = nxt
        self.head = prev

    def to_list(self) -> List[Any]:
        """Convert the linked list to a Python list."""
        result: List[Any] = []
        current = self.head
        while current is not None:
            result.append(current.value)
            current = current.next
        return result

    def display(self) -> str:
        """Return a string representation of the linked list."""
        if self.head is None:
            return "[]"
        parts: List[str] = []
        cur = self.head
        while cur is not None:
            parts.append(str(cur.value))
            cur = cur.next
        return " -> ".join(parts)

/**
 * Sorting algorithms: optimized bubble sort and selection sort.
 * @module bubble_sort
 */

/**
 * Optimized bubble sort with early exit when no swaps occur.
 * @param {number[]} arr - Array to sort in place.
 * @param {boolean} [ascending=true] - Sort direction.
 * @returns {number[]} The sorted array (same reference).
 */
function bubbleSort(arr, ascending = true) {
  const n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    let swapped = false;
    for (let j = 0; j < n - 1 - i; j++) {
      const shouldSwap = ascending ? arr[j] > arr[j + 1] : arr[j] < arr[j + 1];
      if (shouldSwap) {
        [arr[j], arr[j + 1]] = [arr[j + 1], arr[j]];
        swapped = true;
      }
    }
    if (!swapped) {
      break;
    }
  }
  return arr;
}

/**
 * Selection sort implementation.
 * @param {number[]} arr - Array to sort in place.
 * @param {boolean} [ascending=true] - Sort direction.
 * @returns {number[]} The sorted array (same reference).
 */
function selectionSort(arr, ascending = true) {
  const n = arr.length;
  for (let i = 0; i < n - 1; i++) {
    let bestIdx = i;
    for (let j = i + 1; j < n; j++) {
      const isBetter = ascending
        ? arr[j] < arr[bestIdx]
        : arr[j] > arr[bestIdx];
      if (isBetter) {
        bestIdx = j;
      }
    }
    if (bestIdx !== i) {
      [arr[i], arr[bestIdx]] = [arr[bestIdx], arr[i]];
    }
  }
  return arr;
}

/**
 * Insertion sort implementation, efficient for nearly-sorted data.
 * @param {number[]} arr - Array to sort in place.
 * @param {boolean} [ascending=true] - Sort direction.
 * @returns {number[]} The sorted array (same reference).
 */
function insertionSort(arr, ascending = true) {
  for (let i = 1; i < arr.length; i++) {
    const key = arr[i];
    let j = i - 1;
    const shouldShift = (idx) =>
      ascending ? arr[idx] > key : arr[idx] < key;
    while (j >= 0 && shouldShift(j)) {
      arr[j + 1] = arr[j];
      j--;
    }
    arr[j + 1] = key;
  }
  return arr;
}

/**
 * Verify that an array is sorted.
 * @param {number[]} arr - Array to check.
 * @param {boolean} [ascending=true] - Expected sort direction.
 * @returns {boolean} True if sorted in the given direction.
 */
function isSorted(arr, ascending = true) {
  for (let i = 1; i < arr.length; i++) {
    if (ascending && arr[i] < arr[i - 1]) return false;
    if (!ascending && arr[i] > arr[i - 1]) return false;
  }
  return true;
}

/**
 * Benchmark a sorting function with a random array.
 * @param {function} sortFn - Sorting function to benchmark.
 * @param {number} size - Array size.
 * @returns {{ timeMs: number, sorted: boolean }} Elapsed time and correctness.
 */
function benchmark(sortFn, size) {
  const arr = Array.from({ length: size }, () =>
    Math.floor(Math.random() * size * 10)
  );
  const start = performance.now();
  sortFn(arr);
  const elapsed = performance.now() - start;
  return { timeMs: Math.round(elapsed * 100) / 100, sorted: isSorted(arr) };
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const sizes = [100, 1000, 5000];
  for (const size of sizes) {
    console.log(`\n--- Array size: ${size} ---`);
    console.log("Bubble sort:", benchmark(bubbleSort, size));
    console.log("Selection sort:", benchmark(selectionSort, size));
    console.log("Insertion sort:", benchmark(insertionSort, size));
  }
}

module.exports = {
  bubbleSort,
  selectionSort,
  insertionSort,
  isSorted,
  benchmark,
};

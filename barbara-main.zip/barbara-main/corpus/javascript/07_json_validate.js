/**
 * JSON schema validation with nested object support and multiple error types.
 * @module json_validate
 */

/** Represents a single validation error. */
class ValidationError {
  /**
   * @param {string} path - Dot-separated field path (e.g., "user.address.zip").
   * @param {string} code - Error code (e.g., "required", "type_mismatch").
   * @param {string} message - Human-readable description.
   */
  constructor(path, code, message) {
    this.path = path;
    this.code = code;
    this.message = message;
  }

  toString() {
    return `[${this.code}] ${this.path}: ${this.message}`;
  }
}

/** Result of a validation run. */
class ValidationResult {
  constructor() {
    /** @type {ValidationError[]} */
    this.errors = [];
  }

  get valid() {
    return this.errors.length === 0;
  }

  addError(path, code, message) {
    this.errors.push(new ValidationError(path, code, message));
  }
}

/** Validate a value against a field schema, accumulating errors in result. */
function validateField(value, schema, path, result) {
  if (value === undefined || value === null) {
    if (schema.required) {
      result.addError(path, "required", "Field is required");
    }
    return;
  }

  const actualType = Array.isArray(value) ? "array" : typeof value;
  if (actualType !== schema.type) {
    result.addError(path, "type_mismatch", `Expected ${schema.type}, got ${actualType}`);
    return;
  }

  if (schema.type === "string") {
    if (schema.minLength !== undefined && value.length < schema.minLength) {
      result.addError(path, "min_length", `Length ${value.length} < minimum ${schema.minLength}`);
    }
    if (schema.maxLength !== undefined && value.length > schema.maxLength) {
      result.addError(path, "max_length", `Length ${value.length} > maximum ${schema.maxLength}`);
    }
    if (schema.pattern) {
      const re = new RegExp(schema.pattern);
      if (!re.test(value)) {
        result.addError(path, "pattern", `Value does not match pattern '${schema.pattern}'`);
      }
    }
  }

  if (schema.type === "number") {
    if (schema.min !== undefined && value < schema.min) {
      result.addError(path, "min_value", `Value ${value} < minimum ${schema.min}`);
    }
    if (schema.max !== undefined && value > schema.max) {
      result.addError(path, "max_value", `Value ${value} > maximum ${schema.max}`);
    }
  }

  if (schema.type === "object" && schema.properties) {
    validateObject(value, schema.properties, path, result);
  }

  if (schema.type === "array" && schema.items) {
    for (let i = 0; i < value.length; i++) {
      validateField(value[i], schema.items, `${path}[${i}]`, result);
    }
  }
}

/** Validate an object against a set of property schemas. */
function validateObject(obj, properties, basePath = "", result = new ValidationResult()) {
  for (const [field, schema] of Object.entries(properties)) {
    const path = basePath ? `${basePath}.${field}` : field;
    validateField(obj[field], schema, path, result);
  }
  return result;
}

/** Convenience function: validate data and return { valid, errors }. */
function validate(data, schema) {
  const result = validateObject(data, schema);
  return {
    valid: result.valid,
    errors: result.errors.map((e) => e.toString()),
  };
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const userSchema = {
    name: { type: "string", required: true, minLength: 1, maxLength: 100 },
    email: { type: "string", required: true, pattern: "^[^@]+@[^@]+\\.[^@]+$" },
    age: { type: "number", required: false, min: 0, max: 150 },
    address: {
      type: "object",
      required: true,
      properties: {
        street: { type: "string", required: true },
        city: { type: "string", required: true },
        zip: { type: "string", required: true, pattern: "^\\d{5}$" },
      },
    },
    tags: { type: "array", required: false, items: { type: "string", minLength: 1 } },
  };

  const validUser = {
    name: "Alice",
    email: "alice@example.com",
    age: 30,
    address: { street: "123 Main St", city: "Springfield", zip: "62704" },
    tags: ["admin", "active"],
  };
  console.log("Valid user:", validate(validUser, userSchema));

  const invalidUser = {
    name: "",
    email: "not-an-email",
    age: 200,
    address: { street: "123 Main St", zip: "abc" },
    tags: ["ok", ""],
  };
  console.log("Invalid user:", validate(invalidUser, userSchema));
}

module.exports = { ValidationError, ValidationResult, validateField, validateObject, validate };

/**
 * Data transformation pipeline: parse CSV, filter, aggregate, and format output.
 * Operates on in-memory string data (no filesystem dependency).
 * @module file_transform
 */

/**
 * Parse a CSV string into an array of objects using the header row as keys.
 * @param {string} csvText - Raw CSV content.
 * @param {string} [delimiter=","] - Column delimiter.
 * @returns {Object[]} Array of row objects.
 */
function parseCsv(csvText, delimiter = ",") {
  const lines = csvText.trim().split("\n");
  if (lines.length === 0) {
    return [];
  }
  const headers = lines[0].split(delimiter).map((h) => h.trim());
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const values = lines[i].split(delimiter).map((v) => v.trim());
    if (values.length !== headers.length) {
      continue; // skip malformed rows
    }
    const row = {};
    for (let j = 0; j < headers.length; j++) {
      row[headers[j]] = values[j];
    }
    rows.push(row);
  }
  return rows;
}

/**
 * Convert numeric string fields to numbers in each row.
 * @param {Object[]} rows - Parsed row objects.
 * @param {string[]} numericFields - Field names to convert.
 * @returns {Object[]} Rows with converted fields.
 */
function castNumericFields(rows, numericFields) {
  return rows.map((row) => {
    const copy = { ...row };
    for (const field of numericFields) {
      if (field in copy) {
        const num = Number(copy[field]);
        if (!Number.isNaN(num)) {
          copy[field] = num;
        }
      }
    }
    return copy;
  });
}

/**
 * Filter rows by a predicate function.
 * @param {Object[]} rows - Input rows.
 * @param {function(Object): boolean} predicate - Filter condition.
 * @returns {Object[]} Filtered rows.
 */
function filterRows(rows, predicate) {
  return rows.filter(predicate);
}

/**
 * Group rows by a key field and compute aggregates.
 * @param {Object[]} rows - Input rows.
 * @param {string} groupBy - Field to group by.
 * @param {string} valueField - Numeric field to aggregate.
 * @returns {Object[]} Array of { group, count, sum, avg, min, max }.
 */
function aggregate(rows, groupBy, valueField) {
  const groups = new Map();
  for (const row of rows) {
    const key = row[groupBy];
    if (!groups.has(key)) {
      groups.set(key, []);
    }
    groups.get(key).push(row[valueField]);
  }
  const results = [];
  for (const [group, values] of groups) {
    const sum = values.reduce((a, b) => a + b, 0);
    results.push({
      group,
      count: values.length,
      sum: Math.round(sum * 100) / 100,
      avg: Math.round((sum / values.length) * 100) / 100,
      min: Math.min(...values),
      max: Math.max(...values),
    });
  }
  return results;
}

/**
 * Format aggregated results as a CSV string.
 * @param {Object[]} results - Aggregated rows.
 * @returns {string} CSV-formatted output.
 */
function formatCsv(results) {
  if (results.length === 0) {
    return "";
  }
  const headers = Object.keys(results[0]);
  const lines = [headers.join(",")];
  for (const row of results) {
    lines.push(headers.map((h) => String(row[h])).join(","));
  }
  return lines.join("\n");
}

/**
 * Run the full transformation pipeline on raw CSV input.
 * @param {string} csvInput - Raw CSV text with columns: name, department, salary, active.
 * @returns {{ filtered: number, groups: Object[], csv: string }}
 */
function runPipeline(csvInput) {
  let rows = parseCsv(csvInput);
  rows = castNumericFields(rows, ["salary"]);
  const filtered = filterRows(rows, (r) => r.active === "true" && r.salary > 0);
  const grouped = aggregate(filtered, "department", "salary");
  grouped.sort((a, b) => b.avg - a.avg);
  const csv = formatCsv(grouped);
  return { filtered: filtered.length, groups: grouped, csv };
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const sampleCsv = `name,department,salary,active
Alice,Engineering,95000,true
Bob,Engineering,105000,true
Carol,Marketing,78000,true
Dave,Marketing,82000,true
Eve,Engineering,91000,false
Frank,Sales,70000,true
Grace,Sales,74000,true
Hank,Marketing,0,true`;

  const result = runPipeline(sampleCsv);
  console.log(`Filtered rows: ${result.filtered}`);
  console.log("Aggregated groups:", result.groups);
  console.log("\nOutput CSV:\n" + result.csv);
}

module.exports = { parseCsv, castNumericFields, filterRows, aggregate, formatCsv, runPipeline };

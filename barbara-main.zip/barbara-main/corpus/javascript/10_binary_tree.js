/**
 * Binary search tree with traversals, search, depth, and balance check.
 * @module binary_tree
 */

/** A node in the binary tree. */
class TreeNode {
  /**
   * @param {number} value
   * @param {TreeNode|null} left
   * @param {TreeNode|null} right
   */
  constructor(value, left = null, right = null) {
    this.value = value;
    this.left = left;
    this.right = right;
  }
}

/** Binary search tree implementation. */
class BinaryTree {
  constructor() {
    /** @type {TreeNode|null} */
    this.root = null;
  }

  /** Insert a value into the BST. */
  insert(value) {
    const node = new TreeNode(value);
    if (!this.root) {
      this.root = node;
      return;
    }
    let curr = this.root;
    while (true) {
      if (value < curr.value) {
        if (!curr.left) { curr.left = node; return; }
        curr = curr.left;
      } else if (value > curr.value) {
        if (!curr.right) { curr.right = node; return; }
        curr = curr.right;
      } else {
        return; // duplicate, ignore
      }
    }
  }

  /** Search for a value in the BST. Returns true if found. */
  search(value) {
    let curr = this.root;
    while (curr) {
      if (value === curr.value) return true;
      curr = value < curr.value ? curr.left : curr.right;
    }
    return false;
  }

  /** In-order traversal (left, root, right). */
  inOrder(node = this.root) {
    if (!node) return [];
    return [...this.inOrder(node.left), node.value, ...this.inOrder(node.right)];
  }

  /** Pre-order traversal (root, left, right). */
  preOrder(node = this.root) {
    if (!node) return [];
    return [node.value, ...this.preOrder(node.left), ...this.preOrder(node.right)];
  }

  /** Post-order traversal (left, right, root). */
  postOrder(node = this.root) {
    if (!node) return [];
    return [...this.postOrder(node.left), ...this.postOrder(node.right), node.value];
  }

  /** Compute the maximum depth (height) of the tree. */
  depth(node = this.root) {
    if (!node) return 0;
    return 1 + Math.max(this.depth(node.left), this.depth(node.right));
  }

  /** Find the minimum value in the tree. */
  min() {
    if (!this.root) return null;
    let curr = this.root;
    while (curr.left) curr = curr.left;
    return curr.value;
  }

  /** Find the maximum value in the tree. */
  max() {
    if (!this.root) return null;
    let curr = this.root;
    while (curr.right) curr = curr.right;
    return curr.value;
  }

  /** Check whether the tree is height-balanced (height diff <= 1 at every node). */
  isBalanced(node = this.root) {
    const check = (n) => {
      if (!n) return 0;
      const left = check(n.left);
      if (left === -1) return -1;
      const right = check(n.right);
      if (right === -1) return -1;
      if (Math.abs(left - right) > 1) return -1;
      return 1 + Math.max(left, right);
    };
    return check(node) !== -1;
  }

  /** Count the total number of nodes. */
  size(node = this.root) {
    if (!node) return 0;
    return 1 + this.size(node.left) + this.size(node.right);
  }

  /** Level-order (BFS) traversal returning array of arrays, one per level. */
  levelOrder() {
    if (!this.root) return [];
    const levels = [];
    const queue = [this.root];
    while (queue.length > 0) {
      const levelSize = queue.length;
      const level = [];
      for (let i = 0; i < levelSize; i++) {
        const node = queue.shift();
        level.push(node.value);
        if (node.left) queue.push(node.left);
        if (node.right) queue.push(node.right);
      }
      levels.push(level);
    }
    return levels;
  }
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const tree = new BinaryTree();
  for (const v of [50, 30, 70, 20, 40, 60, 80]) tree.insert(v);
  console.log("In-order:", tree.inOrder());
  console.log("Pre-order:", tree.preOrder());
  console.log("Depth:", tree.depth(), "Size:", tree.size());
  console.log("Min:", tree.min(), "Max:", tree.max());
  console.log("Balanced:", tree.isBalanced());
}

module.exports = { TreeNode, BinaryTree };

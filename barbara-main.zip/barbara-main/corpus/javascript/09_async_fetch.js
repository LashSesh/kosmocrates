/**
 * Async HTTP fetch simulation with retry logic, timeout, and rate limiting.
 * @module async_fetch
 */

/** Simulate a network request with variable latency and failure probability. */
function simulateFetch(url, opts = {}) {
  const { failRate = 0.3, minLatency = 50, maxLatency = 300 } = opts;
  const latency = minLatency + Math.random() * (maxLatency - minLatency);

  return new Promise((resolve, reject) => {
    setTimeout(() => {
      if (Math.random() < failRate) {
        reject(new Error(`Network error fetching ${url}`));
      } else {
        resolve({
          status: 200,
          body: { url, data: `Response from ${url}` },
          latencyMs: Math.round(latency),
        });
      }
    }, latency);
  });
}

/** Wrap a promise with a timeout. */
function withTimeout(promise, ms) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => reject(new Error(`Timeout after ${ms}ms`)), ms);
    promise.then(
      (val) => { clearTimeout(timer); resolve(val); },
      (err) => { clearTimeout(timer); reject(err); }
    );
  });
}

/** Fetch with retry logic and exponential backoff. */
async function fetchWithRetry(url, opts = {}) {
  const { maxRetries = 3, timeoutMs = 2000, backoffMs = 100 } = opts;
  let lastError;

  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const response = await withTimeout(simulateFetch(url), timeoutMs);
      return response;
    } catch (err) {
      lastError = err;
      if (attempt < maxRetries) {
        const delay = backoffMs * Math.pow(2, attempt);
        await new Promise((r) => setTimeout(r, delay));
      }
    }
  }
  throw new Error(`Failed after ${maxRetries + 1} attempts: ${lastError.message}`);
}

/** Simple token-bucket rate limiter. */
class RateLimiter {
  /**
   * @param {number} maxTokens - Maximum tokens (burst capacity).
   * @param {number} refillRate - Tokens added per second.
   */
  constructor(maxTokens, refillRate) {
    this.maxTokens = maxTokens;
    this.tokens = maxTokens;
    this.refillRate = refillRate;
    this.lastRefill = Date.now();
  }

  /** Refill tokens based on elapsed time. */
  _refill() {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000;
    this.tokens = Math.min(this.maxTokens, this.tokens + elapsed * this.refillRate);
    this.lastRefill = now;
  }

  /**
   * Acquire a token, waiting if necessary.
   * @returns {Promise<void>}
   */
  async acquire() {
    this._refill();
    if (this.tokens >= 1) {
      this.tokens -= 1;
      return;
    }
    const waitMs = ((1 - this.tokens) / this.refillRate) * 1000;
    await new Promise((r) => setTimeout(r, Math.ceil(waitMs)));
    this._refill();
    this.tokens -= 1;
  }
}

/** Fetch multiple URLs concurrently with rate limiting. */
async function fetchAll(urls, opts = {}) {
  const { concurrency = 3, ratePerSecond = 5 } = opts;
  const limiter = new RateLimiter(concurrency, ratePerSecond);
  const results = [];

  const tasks = urls.map(async (url) => {
    await limiter.acquire();
    try {
      const res = await fetchWithRetry(url, { maxRetries: 2, timeoutMs: 1000 });
      results.push({ url, result: res });
    } catch (err) {
      results.push({ url, error: err.message });
    }
  });

  await Promise.all(tasks);
  return results;
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  (async () => {
    console.log("--- Single fetch with retry ---");
    try {
      const res = await fetchWithRetry("https://api.example.com/data");
      console.log("Success:", res);
    } catch (err) {
      console.log("Failed:", err.message);
    }

    console.log("\n--- Batch fetch ---");
    const urls = Array.from({ length: 6 }, (_, i) => `https://api.example.com/item/${i}`);
    const results = await fetchAll(urls, { concurrency: 2, ratePerSecond: 3 });
    for (const r of results) {
      if (r.result) {
        console.log(`OK: ${r.url} (${r.result.latencyMs}ms)`);
      } else {
        console.log(`ERR: ${r.url} - ${r.error}`);
      }
    }
  })();
}

module.exports = { simulateFetch, withTimeout, fetchWithRetry, RateLimiter, fetchAll };

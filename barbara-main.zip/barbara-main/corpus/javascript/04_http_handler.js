/**
 * In-memory CRUD handler simulating HTTP request/response patterns.
 * @module http_handler
 */

/** Custom error for HTTP-style responses. */
class HttpError extends Error {
  /**
   * @param {number} status - HTTP status code.
   * @param {string} message - Error description.
   */
  constructor(status, message) {
    super(message);
    this.name = "HttpError";
    this.status = status;
  }
}

/** CRUD handler backed by an in-memory Map store. */
class CrudHandler {
  constructor() {
    /** @type {Map<string, object>} */
    this.store = new Map();
    this.nextId = 1;
  }

  /** Build a standard response object. */
  _response(status, body) {
    return {
      status,
      body,
      headers: { "Content-Type": "application/json" },
    };
  }

  /**
   * Create a new resource.
   * @param {object} data - Resource payload (must have a "name" field).
   * @returns {Response}
   */
  create(data) {
    if (!data || typeof data.name !== "string" || data.name.trim() === "") {
      throw new HttpError(400, "Field 'name' is required and must be non-empty");
    }
    const id = String(this.nextId++);
    const record = {
      id,
      ...data,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };
    this.store.set(id, record);
    return this._response(201, record);
  }

  /** Retrieve a resource by ID. */
  read(id) {
    const record = this.store.get(id);
    if (!record) {
      throw new HttpError(404, `Resource '${id}' not found`);
    }
    return this._response(200, record);
  }

  /** List all resources, with optional name filtering and limit. */
  list(query = {}) {
    let results = Array.from(this.store.values());
    if (query.nameContains) {
      const term = query.nameContains.toLowerCase();
      results = results.filter((r) => r.name.toLowerCase().includes(term));
    }
    if (query.limit && query.limit > 0) {
      results = results.slice(0, query.limit);
    }
    return this._response(200, { items: results, total: results.length });
  }

  /**
   * Update an existing resource.
   * @param {string} id - Resource identifier.
   * @param {object} data - Fields to update.
   * @returns {Response}
   */
  update(id, data) {
    const record = this.store.get(id);
    if (!record) {
      throw new HttpError(404, `Resource '${id}' not found`);
    }
    if (data.name !== undefined && (typeof data.name !== "string" || data.name.trim() === "")) {
      throw new HttpError(400, "Field 'name' must be a non-empty string");
    }
    const updated = { ...record, ...data, id, updatedAt: new Date().toISOString() };
    this.store.set(id, updated);
    return this._response(200, updated);
  }

  /**
   * Delete a resource by ID.
   * @param {string} id - Resource identifier.
   * @returns {Response}
   */
  delete(id) {
    if (!this.store.has(id)) {
      throw new HttpError(404, `Resource '${id}' not found`);
    }
    this.store.delete(id);
    return this._response(204, null);
  }

  /** Route a simulated request to the appropriate handler method. */
  handleRequest(method, id, body, query) {
    try {
      switch (method.toUpperCase()) {
        case "GET":
          return id ? this.read(id) : this.list(query);
        case "POST":
          return this.create(body);
        case "PUT":
          if (!id) throw new HttpError(400, "ID required for update");
          return this.update(id, body);
        case "DELETE":
          if (!id) throw new HttpError(400, "ID required for delete");
          return this.delete(id);
        default:
          throw new HttpError(405, `Method '${method}' not allowed`);
      }
    } catch (err) {
      if (err instanceof HttpError) {
        return this._response(err.status, { error: err.message });
      }
      return this._response(500, { error: "Internal server error" });
    }
  }
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const h = new CrudHandler();
  console.log(h.handleRequest("POST", null, { name: "Alice", role: "admin" }));
  console.log(h.handleRequest("POST", null, { name: "Bob", role: "user" }));
  console.log(h.handleRequest("GET", "1"));
  console.log(h.handleRequest("PUT", "1", { role: "superadmin" }));
  console.log(h.handleRequest("DELETE", "2"));
}

module.exports = { CrudHandler, HttpError };

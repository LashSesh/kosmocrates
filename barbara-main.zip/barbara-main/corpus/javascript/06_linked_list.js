/**
 * Singly linked list with standard operations.
 * @module linked_list
 */

/** A single node in the linked list. */
class ListNode {
  /** @param {*} value  @param {ListNode|null} [next] */
  constructor(value, next = null) {
    this.value = value;
    this.next = next;
  }
}

/** Singly linked list implementation. */
class LinkedList {
  constructor() {
    /** @type {ListNode|null} */
    this.head = null;
    /** @type {number} */
    this.length = 0;
  }

  /** Insert a value at the head of the list. */
  insertFront(value) {
    this.head = new ListNode(value, this.head);
    this.length++;
  }

  /** Append a value at the tail of the list. */
  insertBack(value) {
    const node = new ListNode(value);
    if (!this.head) {
      this.head = node;
    } else {
      let curr = this.head;
      while (curr.next) {
        curr = curr.next;
      }
      curr.next = node;
    }
    this.length++;
  }

  /** Insert a value at a specific index (0-based). Throws RangeError if out of bounds. */
  insertAt(index, value) {
    if (index < 0 || index > this.length) {
      throw new RangeError(`Index ${index} out of bounds [0, ${this.length}]`);
    }
    if (index === 0) {
      this.insertFront(value);
      return;
    }
    let curr = this.head;
    for (let i = 0; i < index - 1; i++) {
      curr = curr.next;
    }
    curr.next = new ListNode(value, curr.next);
    this.length++;
  }

  /** Delete the first occurrence of a value. Returns true if found. */
  delete(value) {
    if (!this.head) return false;
    if (this.head.value === value) {
      this.head = this.head.next;
      this.length--;
      return true;
    }
    let curr = this.head;
    while (curr.next) {
      if (curr.next.value === value) {
        curr.next = curr.next.next;
        this.length--;
        return true;
      }
      curr = curr.next;
    }
    return false;
  }

  /** Search for a value and return its index, or -1 if not found. */
  search(value) {
    let curr = this.head;
    let idx = 0;
    while (curr) {
      if (curr.value === value) return idx;
      curr = curr.next;
      idx++;
    }
    return -1;
  }

  /** Reverse the list in place. */
  reverse() {
    let prev = null;
    let curr = this.head;
    while (curr) {
      const next = curr.next;
      curr.next = prev;
      prev = curr;
      curr = next;
    }
    this.head = prev;
  }

  /** Get the value at an index. Throws RangeError if out of bounds. */
  get(index) {
    if (index < 0 || index >= this.length) {
      throw new RangeError(`Index ${index} out of bounds [0, ${this.length})`);
    }
    let curr = this.head;
    for (let i = 0; i < index; i++) {
      curr = curr.next;
    }
    return curr.value;
  }

  /** Convert the list to an array. */
  toArray() {
    const result = [];
    let curr = this.head;
    while (curr) {
      result.push(curr.value);
      curr = curr.next;
    }
    return result;
  }

  /** Display the list as a formatted string. */
  display() {
    return this.toArray().join(" -> ") + " -> null";
  }
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const list = new LinkedList();
  for (const v of [10, 20, 30, 40, 50]) list.insertBack(v);
  console.log("Original:", list.display());
  list.insertFront(5);
  console.log("After insert:", list.display());
  list.delete(30);
  list.reverse();
  console.log("Reversed:", list.display(), "Length:", list.length);
}

module.exports = { ListNode, LinkedList };

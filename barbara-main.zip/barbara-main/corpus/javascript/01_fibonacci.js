/**
 * Fibonacci sequence implementations with memoization and iterative approaches.
 * @module fibonacci
 */

/**
 * Compute the nth Fibonacci number using recursion with memoization.
 * @param {number} n - The index in the Fibonacci sequence (non-negative).
 * @param {Map<number, bigint>} memo - Cache for previously computed values.
 * @returns {bigint} The nth Fibonacci number.
 */
function fibonacciMemo(n, memo = new Map()) {
  if (n < 0) {
    throw new RangeError("Fibonacci index must be non-negative");
  }
  if (n <= 1) {
    return BigInt(n);
  }
  if (memo.has(n)) {
    return memo.get(n);
  }
  const result = fibonacciMemo(n - 1, memo) + fibonacciMemo(n - 2, memo);
  memo.set(n, result);
  return result;
}

/**
 * Compute the nth Fibonacci number using an iterative approach.
 * @param {number} n - The index in the Fibonacci sequence (non-negative).
 * @returns {bigint} The nth Fibonacci number.
 */
function fibonacciIterative(n) {
  if (n < 0) {
    throw new RangeError("Fibonacci index must be non-negative");
  }
  if (n <= 1) {
    return BigInt(n);
  }
  let prev = 0n;
  let curr = 1n;
  for (let i = 2; i <= n; i++) {
    const next = prev + curr;
    prev = curr;
    curr = next;
  }
  return curr;
}

/**
 * Generate an array of the first n Fibonacci numbers.
 * @param {number} count - How many Fibonacci numbers to generate.
 * @returns {bigint[]} Array of Fibonacci numbers.
 */
function fibonacciSequence(count) {
  if (count <= 0) {
    return [];
  }
  const seq = [0n];
  if (count === 1) {
    return seq;
  }
  seq.push(1n);
  for (let i = 2; i < count; i++) {
    seq.push(seq[i - 1] + seq[i - 2]);
  }
  return seq;
}

/**
 * Check whether a given number is a Fibonacci number.
 * Uses the property that n is Fibonacci iff one of
 * 5*n^2+4 or 5*n^2-4 is a perfect square.
 * @param {number} n - The number to check.
 * @returns {boolean} True if n is a Fibonacci number.
 */
function isFibonacci(n) {
  if (n < 0) {
    return false;
  }
  const isPerfectSquare = (x) => {
    const s = Math.round(Math.sqrt(x));
    return s * s === x;
  };
  return isPerfectSquare(5 * n * n + 4) || isPerfectSquare(5 * n * n - 4);
}

/**
 * Find the index of a Fibonacci number, or -1 if not a Fibonacci number.
 * @param {bigint} target - The value to locate.
 * @returns {number} Index in the sequence, or -1.
 */
function fibonacciIndex(target) {
  if (target < 0n) {
    return -1;
  }
  let prev = 0n;
  let curr = 1n;
  if (target === 0n) return 0;
  let idx = 1;
  while (curr < target) {
    const next = prev + curr;
    prev = curr;
    curr = next;
    idx++;
  }
  return curr === target ? idx : -1;
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  console.log("Memoized fib(50):", fibonacciMemo(50).toString());
  console.log("Iterative fib(50):", fibonacciIterative(50).toString());
  console.log("First 10:", fibonacciSequence(10).map(String));
  console.log("Is 21 fibonacci?", isFibonacci(21));
  console.log("Index of 21:", fibonacciIndex(21n));
}

module.exports = {
  fibonacciMemo,
  fibonacciIterative,
  fibonacciSequence,
  isFibonacci,
  fibonacciIndex,
};

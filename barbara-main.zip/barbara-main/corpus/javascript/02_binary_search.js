/**
 * Binary search variants: iterative, recursive, and bound-finding.
 * @module binary_search
 */

/**
 * Standard iterative binary search.
 * @param {number[]} arr - Sorted array of numbers.
 * @param {number} target - Value to find.
 * @returns {number} Index of target, or -1 if not found.
 */
function binarySearch(arr, target) {
  let lo = 0;
  let hi = arr.length - 1;
  while (lo <= hi) {
    const mid = lo + Math.floor((hi - lo) / 2);
    if (arr[mid] === target) {
      return mid;
    } else if (arr[mid] < target) {
      lo = mid + 1;
    } else {
      hi = mid - 1;
    }
  }
  return -1;
}

/**
 * Recursive binary search implementation.
 * @param {number[]} arr - Sorted array of numbers.
 * @param {number} target - Value to find.
 * @param {number} [lo=0] - Lower bound index.
 * @param {number} [hi] - Upper bound index.
 * @returns {number} Index of target, or -1 if not found.
 */
function binarySearchRecursive(arr, target, lo = 0, hi = arr.length - 1) {
  if (lo > hi) {
    return -1;
  }
  const mid = lo + Math.floor((hi - lo) / 2);
  if (arr[mid] === target) {
    return mid;
  } else if (arr[mid] < target) {
    return binarySearchRecursive(arr, target, mid + 1, hi);
  } else {
    return binarySearchRecursive(arr, target, lo, mid - 1);
  }
}

/**
 * Find the leftmost (lower bound) index where target could be inserted.
 * @param {number[]} arr - Sorted array.
 * @param {number} target - Value to locate.
 * @returns {number} Insertion index (lower bound).
 */
function lowerBound(arr, target) {
  let lo = 0;
  let hi = arr.length;
  while (lo < hi) {
    const mid = lo + Math.floor((hi - lo) / 2);
    if (arr[mid] < target) {
      lo = mid + 1;
    } else {
      hi = mid;
    }
  }
  return lo;
}

/**
 * Find the rightmost (upper bound) index where target could be inserted.
 * @param {number[]} arr - Sorted array.
 * @param {number} target - Value to locate.
 * @returns {number} Insertion index (upper bound).
 */
function upperBound(arr, target) {
  let lo = 0;
  let hi = arr.length;
  while (lo < hi) {
    const mid = lo + Math.floor((hi - lo) / 2);
    if (arr[mid] <= target) {
      lo = mid + 1;
    } else {
      hi = mid;
    }
  }
  return lo;
}

/**
 * Find the range [first, last] of indices matching target.
 * @param {number[]} arr - Sorted array.
 * @param {number} target - Value to locate.
 * @returns {[number, number]} Tuple of [first, last] indices, or [-1, -1].
 */
function searchRange(arr, target) {
  const lo = lowerBound(arr, target);
  if (lo >= arr.length || arr[lo] !== target) {
    return [-1, -1];
  }
  const hi = upperBound(arr, target) - 1;
  return [lo, hi];
}

/**
 * Binary search on a rotated sorted array.
 * @param {number[]} arr - Rotated sorted array with unique elements.
 * @param {number} target - Value to find.
 * @returns {number} Index of target, or -1 if not found.
 */
function searchRotated(arr, target) {
  let lo = 0;
  let hi = arr.length - 1;
  while (lo <= hi) {
    const mid = lo + Math.floor((hi - lo) / 2);
    if (arr[mid] === target) {
      return mid;
    }
    if (arr[lo] <= arr[mid]) {
      if (arr[lo] <= target && target < arr[mid]) {
        hi = mid - 1;
      } else {
        lo = mid + 1;
      }
    } else {
      if (arr[mid] < target && target <= arr[hi]) {
        lo = mid + 1;
      } else {
        hi = mid - 1;
      }
    }
  }
  return -1;
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const sorted = [1, 2, 3, 4, 4, 4, 5, 6, 7, 8];
  console.log("Search 4:", binarySearch(sorted, 4));
  console.log("Lower bound 4:", lowerBound(sorted, 4));
  console.log("Range of 4:", searchRange(sorted, 4));
  console.log("Rotated search 0:", searchRotated([4, 5, 6, 7, 0, 1, 2], 0));
}

module.exports = { binarySearch, binarySearchRecursive, lowerBound, upperBound, searchRange, searchRotated };

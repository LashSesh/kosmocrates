/**
 * Event emitter with typed events, priority ordering, and unsubscribe support.
 * @module observer_pattern
 */

/** Priority-based event emitter with typed event support. */
class EventEmitter {
  constructor() {
    /** @type {Map<string, Array<{ id: number, handler: function, priority: number, once: boolean }>>} */
    this._listeners = new Map();
    this._nextId = 1;
  }

  /** Subscribe a handler to an event. Higher priority executes first. */
  on(event, handler, options = {}) {
    const { priority = 0, once = false } = options;
    if (typeof handler !== "function") {
      throw new TypeError("Handler must be a function");
    }
    if (!this._listeners.has(event)) {
      this._listeners.set(event, []);
    }
    const id = this._nextId++;
    const entry = { id, handler, priority, once };
    const list = this._listeners.get(event);
    list.push(entry);
    list.sort((a, b) => b.priority - a.priority);

    return {
      event,
      id,
      unsubscribe: () => this.off(event, id),
    };
  }

  /** Subscribe a handler that fires only once. */
  once(event, handler, options = {}) {
    return this.on(event, handler, { ...options, once: true });
  }

  /** Remove a specific listener by event and subscription ID. */
  off(event, id) {
    const list = this._listeners.get(event);
    if (!list) return false;
    const idx = list.findIndex((e) => e.id === id);
    if (idx === -1) return false;
    list.splice(idx, 1);
    if (list.length === 0) {
      this._listeners.delete(event);
    }
    return true;
  }

  /** Remove all listeners for an event, or all listeners entirely. */
  removeAll(event) {
    if (event) {
      this._listeners.delete(event);
    } else {
      this._listeners.clear();
    }
  }

  /** Emit an event, calling all registered handlers in priority order. */
  emit(event, ...args) {
    const list = this._listeners.get(event);
    if (!list || list.length === 0) return 0;

    const toRemove = [];
    let count = 0;

    for (const entry of list) {
      entry.handler(...args);
      count++;
      if (entry.once) {
        toRemove.push(entry.id);
      }
    }

    for (const id of toRemove) {
      this.off(event, id);
    }

    return count;
  }

  /** Get the count of listeners for a given event. */
  listenerCount(event) {
    const list = this._listeners.get(event);
    return list ? list.length : 0;
  }

  /** Get all event names that have at least one listener. */
  eventNames() {
    return Array.from(this._listeners.keys());
  }
}

/** Typed wrapper that restricts events to a known set. */
class TypedEmitter extends EventEmitter {
  /**
   * @param {string[]} allowedEvents - List of valid event names.
   */
  constructor(allowedEvents) {
    super();
    this._allowed = new Set(allowedEvents);
  }

  /** @override */
  on(event, handler, options) {
    if (!this._allowed.has(event)) {
      throw new Error(`Unknown event '${event}'. Allowed: ${[...this._allowed].join(", ")}`);
    }
    return super.on(event, handler, options);
  }

  /** @override */
  emit(event, ...args) {
    if (!this._allowed.has(event)) {
      throw new Error(`Unknown event '${event}'.`);
    }
    return super.emit(event, ...args);
  }
}

// --- Main execution ---
if (typeof require !== "undefined" && require.main === module) {
  const emitter = new EventEmitter();
  const sub1 = emitter.on("data", (msg) => console.log("Low:", msg), { priority: 1 });
  emitter.on("data", (msg) => console.log("High:", msg), { priority: 10 });
  emitter.once("data", (msg) => console.log("Once:", msg), { priority: 5 });

  console.log("--- First emit ---");
  emitter.emit("data", "hello");
  console.log("--- Second emit ---");
  emitter.emit("data", "world");

  sub1.unsubscribe();
  console.log("After unsubscribe, listeners:", emitter.listenerCount("data"));

  const typed = new TypedEmitter(["connect", "disconnect"]);
  typed.on("connect", (user) => console.log(`${user} connected`));
  typed.emit("connect", "Alice");
}

module.exports = { EventEmitter, TypedEmitter };

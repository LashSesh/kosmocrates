# PSE-Codex + Die Schmiede

**Language-Independent Code Intelligence Through Topological Computation**
**+ Constraint-Based Programming Language Generation Through Topological Inversion**

This workspace contains two complementary systems:

- **PSE-Codex (Barbara)** — the *forward function*: analyzes source code in any language, extracts language-independent topological signatures using the [Post-Symbolic Engine (PSE)](https://github.com/LashSesh/pse), and accumulates cross-language patterns.
- **Die Schmiede** — the *inverse function*: takes declarative constraints (TOML) and generates complete, compilable programming languages with formal specifications and SHA-256 evidence chains.

## Architecture

### PSE-Codex (Forward: Code → Topology)

```
Source Code → tree-sitter → AST → CodeObservation → PSE Graph
    → Laplacian Spectral Decomposition → Kuramoto Synchronization
    → Betti Numbers → CodeTopology → Pattern Matching → CodeCrystal
```

### Die Schmiede (Inverse: Constraints → Language)

```
Constraint TOML → Validated Constraints → Language Topology
    → EBNF Grammar → Lexer + Parser + Type Checker + Code Generator
    → Standalone Compiler Crate (Rust) → C99 Output
```

## Prerequisites

- **Rust** (stable toolchain): Install via [rustup](https://rustup.rs/)
- **PSE Repository** (required for PSE-Codex crates only): The `codex-*` crates depend on the
  [Post-Symbolic Engine](https://github.com/LashSesh/pse) via relative path references.
  Clone both repositories so they share a common parent directory:

  ```
  parent/
  ├── pse/          ← git clone https://github.com/LashSesh/pse
  └── babylon/      ← this repository
  ```

  > **Note:** The Die Schmiede crates (`schmiede-*`) have **no PSE dependency** and can be
  > built without cloning the PSE repo. See [Quick Start](#quick-start) for the command.

## Crates

### PSE-Codex

| Crate | Purpose |
|-------|---------|
| `codex-parse` | Tree-sitter parsing → PSE observations |
| `codex-topo` | Topological signature computation |
| `codex-learn` | Cross-language pattern accumulation |
| `codex-generate` | Code generation from crystals |
| `codex-cli` | Command-line interface |

### Die Schmiede

| Crate | Purpose |
|-------|---------|
| `schmiede-constraints` | Parse and validate constraint TOML, detect conflicts, compute DoF |
| `schmiede-topology` | Map constraints to topological crystal (SHA-256 evidence chain) |
| `schmiede-grammar` | Generate EBNF grammar from topology |
| `schmiede-lexgen` | Generate Rust lexer code |
| `schmiede-parsegen` | Generate Rust parser + AST code |
| `schmiede-typegen` | Generate type checker from constraints |
| `schmiede-codegen` | Generate C99 code generator |
| `schmiede-emit` | Assemble standalone compiler crate, write to disk |
| `schmiede-verify` | Verify generated compiler satisfies constraints |
| `schmiede-cli` | CLI: `schmiede forge`, `check`, `analyze`, `presets` |

## Quick Start

```bash
# Build everything (requires PSE repo cloned as sibling — see Prerequisites)
cargo build --workspace

# Build only Die Schmiede (no PSE dependency required)
cargo build -p schmiede-constraints -p schmiede-topology -p schmiede-grammar \
  -p schmiede-lexgen -p schmiede-parsegen -p schmiede-typegen \
  -p schmiede-codegen -p schmiede-emit -p schmiede-verify -p schmiede-cli

# Run all tests
cargo test --workspace

# --- PSE-Codex ---

# Observe Python corpus
cargo run -p codex-cli --example observe_python

# Cross-language proof
cargo run -p codex-cli --example cross_language_proof

# CLI
cargo run -p codex-cli -- observe corpus/python/ --recursive
cargo run -p codex-cli -- topology corpus/python/01_fibonacci.py
cargo run -p codex-cli -- compare corpus/python/01_fibonacci.py corpus/rust/01_fibonacci.rs

# --- Die Schmiede ---

# Generate a language from a preset
cargo run -p schmiede-cli -- forge --preset embedded_safety --output ./output/

# Validate constraints only
cargo run -p schmiede-cli -- check --constraints presets/embedded_safety.toml

# Show degrees-of-freedom analysis
cargo run -p schmiede-cli -- analyze --constraints presets/embedded_safety.toml

# List available presets
cargo run -p schmiede-cli -- presets
```

## Presets

| Preset | Description |
|--------|-------------|
| `embedded_safety` | Safety-critical embedded language for medical devices (ARM Cortex-M4, no heap, C output) |
| `systems_programming` | Low-level systems language similar to Rust (borrow semantics, generics, traits) |
| `web_scripting` | Dynamic scripting language for web applications (GC, async, WASM output) |
| `data_science` | Data processing language with array operations (hardware floats, interpreted) |
| `education_swahili` | Educational language with Swahili keywords |
| `education_german` | Educational language with German keywords |

## Embedded Corpus

40 programs (10 algorithms x 4 languages: Python, Rust, JavaScript, Go):

1. Fibonacci (recursive + memoization)
2. Binary search (iterative + recursive)
3. Bubble sort (with optimization)
4. HTTP CRUD handler
5. File read/transform/write pipeline
6. Linked list operations
7. JSON schema validation
8. Observer pattern (event emitter)
9. Async HTTP fetch (with retry)
10. Binary tree traversal

## License

MIT - Copyright (c) 2026 Sebastian Klemm

//! codex-parse — Source Code to PSE Observations
//!
//! Parses source code in any tree-sitter-supported language and converts
//! the concrete syntax tree into PSE observations. This is the universal
//! entry point — the only place where language-specific knowledge exists.

pub mod normalize;
pub mod workspace;

pub use workspace::{walk_workspace, WorkspaceFiles, ParsedFile};

use std::path::Path;
use std::time::Instant;

use pse_graph::{derive_vertex_id, PersistentGraph};
use pse_types::{Observation, MeasurementContext, ProvenanceEnvelope};
use serde::{Deserialize, Serialize};
use thiserror::Error;

pub use normalize::NodeKind;

// ── Errors ───────────────────────────────────────────────────────────

/// Errors from the parsing subsystem.
#[derive(Debug, Error)]
pub enum ParseError {
    /// Unsupported or unrecognized language.
    #[error("unsupported language: {0}")]
    UnsupportedLanguage(String),
    /// Tree-sitter failed to parse the source.
    #[error("tree-sitter parse error")]
    TreeSitterError,
    /// I/O error reading a file.
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
}

// ── Core Types ───────────────────────────────────────────────────────

/// A single observation derived from an AST node.
/// This is what PSE sees — language-independent structural data.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeObservation {
    /// Unique identifier for this AST node.
    pub node_id: String,
    /// Generalized node kind (see NodeKind enum).
    pub kind: NodeKind,
    /// Nesting depth in the AST (root = 0).
    pub depth: u32,
    /// Number of direct children.
    pub child_count: u32,
    /// Number of named children (excludes punctuation/keywords).
    pub named_child_count: u32,
    /// Byte range in source [start, end).
    pub byte_range: (usize, usize),
    /// Parent node kind (None for root).
    pub parent_kind: Option<NodeKind>,
    /// Source language identifier.
    pub source_language: String,
    /// Subtree complexity (total descendant count).
    pub subtree_size: u32,
}

/// Edge types between code observations.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum CodeEdge {
    /// Parent contains child (AST nesting).
    Contains,
    /// Sequential siblings (control flow order).
    SequentialSibling,
    /// Function call reference (caller -> callee).
    Calls,
    /// Type reference (usage -> definition).
    TypeReference,
    /// Import dependency.
    Imports,
}

/// Metadata about a parse operation.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ParseMetadata {
    /// Source language.
    pub language: String,
    /// Total AST nodes.
    pub total_nodes: usize,
    /// Named AST nodes.
    pub named_nodes: usize,
    /// Maximum nesting depth.
    pub max_depth: u32,
    /// Number of function definitions.
    pub function_count: usize,
    /// Number of class/struct definitions.
    pub class_count: usize,
    /// Lines of source code.
    pub line_count: usize,
    /// Bytes of source code.
    pub byte_count: usize,
    /// Parse time in microseconds.
    pub parse_time_us: u64,
    /// Whether tree-sitter detected parse errors.
    pub has_errors: bool,
}

// ── Language Detection ───────────────────────────────────────────────

/// Auto-detect language from file extension.
pub fn detect_language(path: &Path) -> Option<String> {
    let ext = path.extension()?.to_str()?;
    match ext {
        "py" => Some("python".into()),
        "rs" => Some("rust".into()),
        "js" | "mjs" | "cjs" => Some("javascript".into()),
        "ts" => Some("typescript".into()),
        "go" => Some("go".into()),
        "c" | "h" => Some("c".into()),
        "java" => Some("java".into()),
        "cpp" | "cc" | "cxx" | "hpp" => Some("cpp".into()),
        "tsx" => Some("tsx".into()),
        _ => None,
    }
}

// ── Tree-sitter Language Binding ─────────────────────────────────────

fn get_ts_language(language: &str) -> Result<tree_sitter::Language, ParseError> {
    match language {
        "python" => Ok(tree_sitter_python::LANGUAGE.into()),
        "rust" => Ok(tree_sitter_rust::LANGUAGE.into()),
        "javascript" => Ok(tree_sitter_javascript::LANGUAGE.into()),
        "go" => Ok(tree_sitter_go::LANGUAGE.into()),
        "typescript" => Ok(tree_sitter_typescript::LANGUAGE_TYPESCRIPT.into()),
        "tsx" => Ok(tree_sitter_typescript::LANGUAGE_TSX.into()),
        "c" => Ok(tree_sitter_c::LANGUAGE.into()),
        "java" => Ok(tree_sitter_java::LANGUAGE.into()),
        "cpp" => Ok(tree_sitter_cpp::LANGUAGE.into()),
        other => Err(ParseError::UnsupportedLanguage(other.into())),
    }
}

// ── AST Walking ──────────────────────────────────────────────────────

/// Count total descendants of a node (subtree size).
fn subtree_size(node: &tree_sitter::Node) -> u32 {
    let mut count = 0u32;
    let mut cursor = node.walk();
    // Walk all descendants
    if cursor.goto_first_child() {
        loop {
            count += 1 + subtree_size(&cursor.node());
            if !cursor.goto_next_sibling() {
                break;
            }
        }
    }
    count
}

/// Walk the AST and produce CodeObservations.
fn walk_tree(
    node: tree_sitter::Node,
    language: &str,
    depth: u32,
    parent_kind: Option<NodeKind>,
    counter: &mut usize,
    observations: &mut Vec<CodeObservation>,
) {
    let kind = normalize::normalize_node_kind(language, node.kind());
    let id = *counter;
    *counter += 1;

    let obs = CodeObservation {
        node_id: format!("n{}", id),
        kind: kind.clone(),
        depth,
        child_count: node.child_count() as u32,
        named_child_count: node.named_child_count() as u32,
        byte_range: (node.start_byte(), node.end_byte()),
        parent_kind: parent_kind.clone(),
        source_language: language.to_string(),
        subtree_size: subtree_size(&node),
    };
    observations.push(obs);

    let mut cursor = node.walk();
    if cursor.goto_first_child() {
        loop {
            walk_tree(
                cursor.node(),
                language,
                depth + 1,
                Some(kind.clone()),
                counter,
                observations,
            );
            if !cursor.goto_next_sibling() {
                break;
            }
        }
    }
}

// ── Public API ───────────────────────────────────────────────────────

/// Parse source code and produce observations.
///
/// Uses tree-sitter to parse, then walks the CST converting
/// each node into a CodeObservation.
pub fn parse_source(
    source: &str,
    language: &str,
) -> Result<(Vec<CodeObservation>, ParseMetadata), ParseError> {
    let start = Instant::now();
    let ts_lang = get_ts_language(language)?;

    let mut parser = tree_sitter::Parser::new();
    parser
        .set_language(&ts_lang)
        .map_err(|_| ParseError::TreeSitterError)?;

    let tree = parser
        .parse(source, None)
        .ok_or(ParseError::TreeSitterError)?;

    let root = tree.root_node();
    let has_errors = root.has_error();

    let mut observations = Vec::new();
    let mut counter = 0usize;
    walk_tree(root, language, 0, None, &mut counter, &mut observations);

    let function_count = observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::Function))
        .count();
    let class_count = observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::Class))
        .count();
    let max_depth = observations.iter().map(|o| o.depth).max().unwrap_or(0);

    let metadata = ParseMetadata {
        language: language.to_string(),
        total_nodes: observations.len(),
        named_nodes: observations
            .iter()
            .filter(|o| !matches!(o.kind, NodeKind::Unknown(_)))
            .count(),
        max_depth,
        function_count,
        class_count,
        line_count: source.lines().count(),
        byte_count: source.len(),
        parse_time_us: start.elapsed().as_micros() as u64,
        has_errors,
    };

    Ok((observations, metadata))
}

/// Parse a file from disk.
pub fn parse_file(path: &Path) -> Result<(Vec<CodeObservation>, ParseMetadata), ParseError> {
    let language = detect_language(path)
        .ok_or_else(|| ParseError::UnsupportedLanguage(format!("{}", path.display())))?;
    let source = std::fs::read_to_string(path)?;
    parse_source(&source, &language)
}

/// Convert observations into a PSE PersistentGraph.
///
/// Each observation becomes a vertex in the PSE graph.
/// Parent-child relationships become edges (Contains).
/// Adjacent siblings become SequentialSibling edges.
pub fn observations_to_graph(observations: &[CodeObservation]) -> PersistentGraph {
    let mut graph = PersistentGraph::new();
    let timestamp = 0.0;

    // Create vertices for all observations
    for obs in observations {
        let vid = derive_vertex_id(&obs.node_id);
        graph.upsert_vertex(vid, timestamp);
    }

    // Create edges based on parent-child relationships
    // We track the parent stack by depth
    let mut parent_stack: Vec<(u32, &str)> = Vec::new(); // (depth, node_id)
    let mut sibling_at_depth: std::collections::HashMap<u32, String> = std::collections::HashMap::new();

    for obs in observations {
        // Pop parent stack to find actual parent
        while let Some(&(d, _)) = parent_stack.last() {
            if d >= obs.depth {
                parent_stack.pop();
            } else {
                break;
            }
        }

        // Contains edge: parent -> child
        if let Some(&(_, parent_id)) = parent_stack.last() {
            let from_vid = derive_vertex_id(parent_id);
            let to_vid = derive_vertex_id(&obs.node_id);
            graph.upsert_edge(from_vid, to_vid, timestamp);
        }

        // SequentialSibling edge: previous sibling at same depth -> this node
        if let Some(prev_id) = sibling_at_depth.get(&obs.depth) {
            // Only if they share the same parent
            if parent_stack.last().is_some() || obs.depth == 0 {
                let from_vid = derive_vertex_id(prev_id);
                let to_vid = derive_vertex_id(&obs.node_id);
                graph.upsert_edge(from_vid, to_vid, timestamp);
            }
        }
        sibling_at_depth.insert(obs.depth, obs.node_id.clone());

        parent_stack.push((obs.depth, &obs.node_id));
    }

    graph
}

/// Convert observations to PSE Observation format for ingestion.
pub fn observations_to_pse(observations: &[CodeObservation]) -> Vec<Observation> {
    observations
        .iter()
        .map(|obs| {
            let payload = serde_json::to_vec(obs).unwrap_or_default();
            let digest = pse_types::content_address_raw(&payload);
            Observation {
                timestamp: obs.depth as f64,
                source_id: obs.node_id.clone(),
                provenance: ProvenanceEnvelope {
                    origin: format!("codex-parse:{}", obs.source_language),
                    chain: vec![],
                    sig: None,
                },
                payload,
                context: MeasurementContext {
                    tags: {
                        let mut tags = std::collections::BTreeMap::new();
                        tags.insert("language".into(), obs.source_language.clone());
                        tags.insert("kind".into(), format!("{:?}", obs.kind));
                        tags.insert("depth".into(), obs.depth.to_string());
                        tags
                    },
                },
                digest,
                schema_version: "codex-parse-1.0".into(),
            }
        })
        .collect()
}

// ── Tests ────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_python() {
        let source = r#"
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)

def main():
    for i in range(10):
        print(fibonacci(i))
"#;
        let (obs, meta) = parse_source(source, "python").unwrap();
        assert!(!obs.is_empty());
        assert_eq!(meta.language, "python");
        assert!(meta.function_count >= 2);
        assert!(!meta.has_errors);
    }

    #[test]
    fn test_parse_rust() {
        let source = r#"
fn fibonacci(n: u64) -> u64 {
    if n <= 1 {
        return n;
    }
    fibonacci(n - 1) + fibonacci(n - 2)
}

fn main() {
    for i in 0..10 {
        println!("{}", fibonacci(i));
    }
}
"#;
        let (obs, meta) = parse_source(source, "rust").unwrap();
        assert!(!obs.is_empty());
        assert_eq!(meta.language, "rust");
        assert!(meta.function_count >= 2);
        assert!(!meta.has_errors);
    }

    #[test]
    fn test_parse_javascript() {
        let source = r#"
function fibonacci(n) {
    if (n <= 1) return n;
    return fibonacci(n - 1) + fibonacci(n - 2);
}

for (let i = 0; i < 10; i++) {
    console.log(fibonacci(i));
}
"#;
        let (obs, meta) = parse_source(source, "javascript").unwrap();
        assert!(!obs.is_empty());
        assert_eq!(meta.language, "javascript");
        assert!(meta.function_count >= 1);
    }

    #[test]
    fn test_parse_go() {
        let source = r#"
package main

import "fmt"

func fibonacci(n int) int {
    if n <= 1 {
        return n
    }
    return fibonacci(n-1) + fibonacci(n-2)
}

func main() {
    for i := 0; i < 10; i++ {
        fmt.Println(fibonacci(i))
    }
}
"#;
        let (obs, meta) = parse_source(source, "go").unwrap();
        assert!(!obs.is_empty());
        assert_eq!(meta.language, "go");
        assert!(meta.function_count >= 2);
    }

    #[test]
    fn test_detect_language() {
        assert_eq!(detect_language(Path::new("foo.py")), Some("python".into()));
        assert_eq!(detect_language(Path::new("foo.rs")), Some("rust".into()));
        assert_eq!(detect_language(Path::new("foo.js")), Some("javascript".into()));
        assert_eq!(detect_language(Path::new("foo.go")), Some("go".into()));
        assert_eq!(detect_language(Path::new("foo.xyz")), None);
    }

    #[test]
    fn test_empty_source() {
        let (obs, meta) = parse_source("", "python").unwrap();
        // Empty source should parse without panic
        assert_eq!(meta.byte_count, 0);
        assert!(!meta.has_errors);
    }

    #[test]
    fn test_observations_to_graph() {
        let source = "def foo():\n    pass\n";
        let (obs, _) = parse_source(source, "python").unwrap();
        let graph = observations_to_graph(&obs);
        assert!(graph.active_vertices().len() > 0);
    }

    #[test]
    fn test_node_kind_normalization() {
        let source = "def foo():\n    if True:\n        for x in []:\n            pass\n";
        let (obs, _) = parse_source(source, "python").unwrap();
        let kinds: Vec<_> = obs.iter().map(|o| &o.kind).collect();
        assert!(kinds.iter().any(|k| matches!(k, NodeKind::Function)));
        assert!(kinds.iter().any(|k| matches!(k, NodeKind::IfStatement)));
        assert!(kinds.iter().any(|k| matches!(k, NodeKind::ForLoop)));
    }

    #[test]
    fn test_parse_metadata_accuracy() {
        let source = "def a():\n    pass\ndef b():\n    pass\nclass C:\n    pass\n";
        let (_, meta) = parse_source(source, "python").unwrap();
        assert!(meta.function_count >= 2, "expected >= 2 functions, got {}", meta.function_count);
        assert!(meta.class_count >= 1, "expected >= 1 class, got {}", meta.class_count);
        assert!(meta.total_nodes > 0);
        assert!(meta.max_depth > 0);
    }

    #[test]
    fn test_edge_construction() {
        let source = "def foo():\n    x = 1\n    y = 2\n";
        let (obs, _) = parse_source(source, "python").unwrap();
        let graph = observations_to_graph(&obs);
        // Should have vertices and edges
        assert!(graph.active_vertices().len() > 1);
    }

    #[test]
    fn test_parse_typescript() {
        let source = "function greet(name: string): string {\n    return `Hello, ${name}`;\n}\n";
        let (obs, meta) = parse_source(source, "typescript").unwrap();
        assert!(!obs.is_empty());
        assert_eq!(meta.language, "typescript");
    }

    #[test]
    fn test_parse_c() {
        let source = "#include <stdio.h>\nint main() {\n    printf(\"hello\");\n    return 0;\n}\n";
        let (obs, meta) = parse_source(source, "c").unwrap();
        assert!(!obs.is_empty());
        assert!(meta.function_count >= 1);
    }

    #[test]
    fn test_observations_to_pse() {
        let source = "def foo():\n    return 42\n";
        let (obs, _) = parse_source(source, "python").unwrap();
        let pse_obs = observations_to_pse(&obs);
        assert_eq!(pse_obs.len(), obs.len());
        for po in &pse_obs {
            assert!(!po.payload.is_empty());
            assert_ne!(po.digest, [0u8; 32]);
        }
    }

    #[test]
    fn test_subtree_sizes() {
        let source = "def foo():\n    if True:\n        x = 1\n        y = 2\n    return 0\n";
        let (obs, _) = parse_source(source, "python").unwrap();
        // Module should have the largest subtree
        let module_obs = obs.iter().find(|o| matches!(o.kind, NodeKind::Module));
        assert!(module_obs.is_some());
        let module = module_obs.unwrap();
        assert!(module.subtree_size > 0, "Module should have children");
    }

    #[test]
    fn test_depth_ordering() {
        let source = "def outer():\n    def inner():\n        pass\n";
        let (obs, _) = parse_source(source, "python").unwrap();
        // First observation should be at depth 0 (module)
        assert_eq!(obs[0].depth, 0);
        // Should have observations at multiple depths
        let max_depth = obs.iter().map(|o| o.depth).max().unwrap();
        assert!(max_depth >= 2);
    }

    #[test]
    fn test_unsupported_language() {
        let result = parse_source("hello world", "brainfuck");
        assert!(result.is_err());
    }

    #[test]
    fn test_byte_range_valid() {
        let source = "x = 42\ny = 'hello'\n";
        let (obs, _) = parse_source(source, "python").unwrap();
        for o in &obs {
            assert!(o.byte_range.0 <= o.byte_range.1);
            assert!(o.byte_range.1 <= source.len());
        }
    }
}

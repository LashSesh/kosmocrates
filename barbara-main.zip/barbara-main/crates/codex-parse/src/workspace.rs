//! Workspace-level file discovery and raw parsing.
//!
//! Walks a Rust workspace directory tree, finds all source files, and parses
//! them into `CodeObservation` sets. This module does **not** compute topology
//! — that lives in `codex-topo` which depends on this crate.
//!
//! Files that fail to parse are skipped with a warning (no panic).

use std::path::{Path, PathBuf};

use crate::{parse_source, detect_language, CodeObservation, ParseMetadata};

// ── Public Types ─────────────────────────────────────────────────────────────

/// The result of walking and parsing an entire Rust workspace.
#[derive(Debug)]
pub struct WorkspaceFiles {
    /// Workspace root directory.
    pub root: PathBuf,
    /// All successfully parsed files.
    pub files: Vec<ParsedFile>,
    /// Unique crate names detected, sorted.
    pub crate_names: Vec<String>,
    /// Files that failed to parse (path + error message).
    pub parse_errors: Vec<(PathBuf, String)>,
}

/// A single successfully parsed source file.
#[derive(Debug)]
pub struct ParsedFile {
    /// Absolute path to the file.
    pub path: PathBuf,
    /// Path relative to the workspace root.
    pub relative_path: String,
    /// Name of the crate this file belongs to.
    pub crate_name: String,
    /// Parsed AST observations.
    pub observations: Vec<CodeObservation>,
    /// Parse metadata (node counts, depth, etc.).
    pub metadata: ParseMetadata,
    /// Lines of code (non-empty lines).
    pub loc: usize,
}

// ── Main Entry Point ──────────────────────────────────────────────────────────

/// Walk a workspace directory, parse all source files, and return results.
///
/// Skips directories: `target/`, `.git/`, `node_modules/`, `.cargo/`.
/// Skips files that fail to parse (logs a warning to stderr).
///
/// # Example
/// ```no_run
/// use std::path::Path;
/// use codex_parse::workspace::walk_workspace;
/// let ws = walk_workspace(Path::new("/path/to/workspace"));
/// println!("{} files from {} crates", ws.files.len(), ws.crate_names.len());
/// ```
pub fn walk_workspace(root: &Path) -> WorkspaceFiles {
    let mut files = Vec::new();
    let mut parse_errors = Vec::new();

    collect_files(root, root, &mut files, &mut parse_errors);

    // Deduplicate and sort crate names.
    let mut crate_names: Vec<String> = files
        .iter()
        .map(|f| f.crate_name.clone())
        .collect();
    crate_names.sort();
    crate_names.dedup();

    WorkspaceFiles {
        root: root.to_path_buf(),
        files,
        crate_names,
        parse_errors,
    }
}

// ── Internal helpers ──────────────────────────────────────────────────────────

/// Directories to skip when walking.
const SKIP_DIRS: &[&str] = &["target", ".git", "node_modules", ".cargo", ".idea", ".vscode"];

fn collect_files(
    dir: &Path,
    root: &Path,
    files: &mut Vec<ParsedFile>,
    errors: &mut Vec<(PathBuf, String)>,
) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(e) => {
            eprintln!("warn: cannot read {}: {}", dir.display(), e);
            return;
        }
    };

    let mut entries: Vec<_> = entries.flatten().collect();
    entries.sort_by_key(|e| e.path());

    for entry in entries {
        let path = entry.path();
        if path.is_dir() {
            let name = path.file_name().unwrap_or_default().to_string_lossy();
            if SKIP_DIRS.contains(&name.as_ref()) {
                continue;
            }
            collect_files(&path, root, files, errors);
        } else if path.is_file() {
            if detect_language(&path).is_none() {
                continue; // Not a supported source file.
            }
            match parse_file_at(&path, root) {
                Ok(pf) => files.push(pf),
                Err(e) => {
                    eprintln!("warn: skipping {} — {}", path.display(), e);
                    errors.push((path, e));
                }
            }
        }
    }
}

fn parse_file_at(path: &Path, root: &Path) -> Result<ParsedFile, String> {
    let language = detect_language(path)
        .ok_or_else(|| "unsupported language".to_string())?;

    let source = std::fs::read_to_string(path)
        .map_err(|e| e.to_string())?;

    let loc = source.lines().filter(|l| !l.trim().is_empty()).count();

    let (observations, metadata) = parse_source(&source, &language)
        .map_err(|e| e.to_string())?;

    let relative_path = path
        .strip_prefix(root)
        .unwrap_or(path)
        .to_string_lossy()
        .into_owned();

    let crate_name = detect_crate_name(path, root);

    Ok(ParsedFile {
        path: path.to_path_buf(),
        relative_path,
        crate_name,
        observations,
        metadata,
        loc,
    })
}

/// Walk up from `file` toward `root` to find the nearest `Cargo.toml` and
/// extract the `name = "..."` line.  Falls back to the directory name if no
/// Cargo.toml is found.
pub fn detect_crate_name(file: &Path, root: &Path) -> String {
    let mut dir = file.parent().unwrap_or(file);
    loop {
        let cargo_toml = dir.join("Cargo.toml");
        if cargo_toml.exists() {
            if let Some(name) = extract_cargo_name(&cargo_toml) {
                return name;
            }
        }
        if dir == root || dir.parent().is_none() {
            break;
        }
        dir = dir.parent().unwrap();
    }
    // Fallback: use the directory name.
    dir.file_name()
        .unwrap_or_default()
        .to_string_lossy()
        .into_owned()
}

/// Extract the `name = "..."` value from a `Cargo.toml` file.
fn extract_cargo_name(cargo_toml: &Path) -> Option<String> {
    let content = std::fs::read_to_string(cargo_toml).ok()?;
    // Simple line-by-line search — no toml dependency needed.
    for line in content.lines() {
        let trimmed = line.trim();
        if trimmed.starts_with("name") {
            if let Some(eq) = trimmed.find('=') {
                let value = trimmed[eq + 1..].trim().trim_matches('"').trim_matches('\'');
                if !value.is_empty() && !value.contains('{') {
                    return Some(value.to_string());
                }
            }
        }
    }
    None
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::PathBuf;

    #[test]
    fn detect_crate_name_from_cargo_toml() {
        // Use the codex-parse crate itself as a test fixture.
        let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
        let src_lib = manifest.join("src/lib.rs");
        if src_lib.exists() {
            let root = manifest.parent().unwrap().parent().unwrap();
            let name = detect_crate_name(&src_lib, root);
            // Should detect "codex-parse" from the nearest Cargo.toml
            assert!(
                name.contains("codex"),
                "Expected crate name containing 'codex', got: {}",
                name
            );
        }
    }

    #[test]
    fn extract_cargo_name_simple() {
        use std::io::Write;
        let dir = std::env::temp_dir().join("barbara_test_cargo");
        std::fs::create_dir_all(&dir).ok();
        let cargo_toml = dir.join("Cargo.toml");
        {
            let mut f = std::fs::File::create(&cargo_toml).unwrap();
            writeln!(f, "[package]").unwrap();
            writeln!(f, r#"name = "my-test-crate""#).unwrap();
            writeln!(f, r#"version = "0.1.0""#).unwrap();
        }
        let name = extract_cargo_name(&cargo_toml);
        assert_eq!(name, Some("my-test-crate".to_string()));
        std::fs::remove_dir_all(&dir).ok();
    }
}

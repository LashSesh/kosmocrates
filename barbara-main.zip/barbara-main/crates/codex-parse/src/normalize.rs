//! Language normalization — maps tree-sitter node types to universal NodeKind.
//!
//! This is the *only* place where per-language knowledge is hardcoded.

use serde::{Deserialize, Serialize};

/// Language-independent generalization of AST node types.
///
/// tree-sitter returns language-specific kinds like
/// "function_definition" (Python), "function_item" (Rust),
/// "function_declaration" (JS). This enum normalizes them
/// into universal categories.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Hash)]
pub enum NodeKind {
    // Structure
    /// Top-level file/module.
    Module,
    /// Function/method definition.
    Function,
    /// Class/struct/interface definition.
    Class,
    /// Code block / compound statement.
    Block,

    // Control flow
    /// If statement / conditional.
    IfStatement,
    /// Else clause.
    ElseClause,
    /// For loop.
    ForLoop,
    /// While loop.
    WhileLoop,
    /// Match/switch/case.
    MatchSwitch,
    /// Return statement.
    ReturnStatement,
    /// Break or continue.
    BreakContinue,
    /// Try/catch/except.
    TryCatch,

    // Data
    /// Variable binding / assignment.
    Assignment,
    /// General expression.
    Expression,
    /// Function/method call.
    CallExpression,
    /// Field access (a.b, a->b, a::b).
    FieldAccess,
    /// Index access (a[b]).
    IndexAccess,
    /// String, number, bool literals.
    Literal,
    /// Function parameter.
    Parameter,
    /// Type annotation / type hint.
    TypeAnnotation,

    // Declarations
    /// Import/use/require/include.
    Import,
    /// let/var/const/mut.
    VariableDecl,

    // Other
    /// Comment.
    Comment,
    /// Unmapped node types.
    Unknown(String),
}

/// Map a language-specific tree-sitter node kind to a universal NodeKind.
pub fn normalize_node_kind(language: &str, ts_kind: &str) -> NodeKind {
    // Try language-specific mappings first
    let result = match language {
        "python" => normalize_python(ts_kind),
        "rust" => normalize_rust(ts_kind),
        "javascript" | "typescript" | "tsx" => normalize_javascript(ts_kind),
        "go" => normalize_go(ts_kind),
        "c" => normalize_c(ts_kind),
        "java" => normalize_java(ts_kind),
        "cpp" => normalize_cpp(ts_kind),
        _ => None,
    };

    // Fall back to generic mapping
    result
        .or_else(|| normalize_generic(ts_kind))
        .unwrap_or_else(|| NodeKind::Unknown(ts_kind.to_string()))
}

fn normalize_python(ts_kind: &str) -> Option<NodeKind> {
    match ts_kind {
        "module" => Some(NodeKind::Module),
        "function_definition" | "decorated_definition" | "lambda" => Some(NodeKind::Function),
        "class_definition" => Some(NodeKind::Class),
        "block" => Some(NodeKind::Block),
        "if_statement" | "conditional_expression" => Some(NodeKind::IfStatement),
        "elif_clause" | "else_clause" => Some(NodeKind::ElseClause),
        "for_statement"
        | "list_comprehension"
        | "set_comprehension"
        | "dict_comprehension"
        | "generator_expression"
        | "comprehension" => Some(NodeKind::ForLoop),
        "while_statement" => Some(NodeKind::WhileLoop),
        "match_statement" => Some(NodeKind::MatchSwitch),
        "return_statement" | "yield" | "yield_from" => Some(NodeKind::ReturnStatement),
        "break_statement" | "continue_statement" => Some(NodeKind::BreakContinue),
        "try_statement" | "with_statement" | "except_clause" | "finally_clause" => {
            Some(NodeKind::TryCatch)
        }
        "assignment" | "augmented_assignment" | "named_expression" => Some(NodeKind::Assignment),
        "expression_statement" => Some(NodeKind::Expression),
        "call" => Some(NodeKind::CallExpression),
        "attribute" => Some(NodeKind::FieldAccess),
        "subscript" => Some(NodeKind::IndexAccess),
        "string" | "integer" | "float" | "true" | "false" | "none" => Some(NodeKind::Literal),
        "parameters" | "default_parameter" | "typed_parameter" | "typed_default_parameter" => {
            Some(NodeKind::Parameter)
        }
        "type" => Some(NodeKind::TypeAnnotation),
        "import_statement" | "import_from_statement" => Some(NodeKind::Import),
        "global_statement" | "nonlocal_statement" => Some(NodeKind::VariableDecl),
        "raise_statement" | "assert_statement" | "delete_statement" | "pass_statement" => {
            Some(NodeKind::Expression)
        }
        "comment" => Some(NodeKind::Comment),
        _ => None,
    }
}

fn normalize_rust(ts_kind: &str) -> Option<NodeKind> {
    match ts_kind {
        "source_file" => Some(NodeKind::Module),
        "function_item" | "method_definition" | "closure_expression" | "async_block" => {
            Some(NodeKind::Function)
        }
        "struct_item" | "impl_item" | "enum_item" | "trait_item" | "type_item" => {
            Some(NodeKind::Class)
        }
        "block" => Some(NodeKind::Block),
        "if_expression" | "if_let_expression" => Some(NodeKind::IfStatement),
        "else_clause" => Some(NodeKind::ElseClause),
        "for_expression" | "iterator" => Some(NodeKind::ForLoop),
        "while_expression" | "loop_expression" | "while_let_expression" => {
            Some(NodeKind::WhileLoop)
        }
        "match_expression" | "match_arm" => Some(NodeKind::MatchSwitch),
        "return_expression" | "await_expression" => Some(NodeKind::ReturnStatement),
        "break_expression" | "continue_expression" => Some(NodeKind::BreakContinue),
        "try_expression" | "try_block" => Some(NodeKind::TryCatch),
        "let_declaration" | "const_item" | "static_item" => Some(NodeKind::Assignment),
        "expression_statement" => Some(NodeKind::Expression),
        "call_expression" | "macro_invocation" | "method_call_expression" => {
            Some(NodeKind::CallExpression)
        }
        "field_expression" | "scoped_identifier" | "scoped_use_list" => Some(NodeKind::FieldAccess),
        "index_expression" => Some(NodeKind::IndexAccess),
        "string_literal" | "char_literal" | "integer_literal" | "float_literal"
        | "boolean_literal" | "raw_string_literal" => Some(NodeKind::Literal),
        "parameters" | "parameter" | "self_parameter" => Some(NodeKind::Parameter),
        "type_identifier" | "generic_type" | "reference_type" | "lifetime"
        | "primitive_type" | "tuple_type" | "slice_type" | "pointer_type" => {
            Some(NodeKind::TypeAnnotation)
        }
        "use_declaration" | "extern_crate_declaration" => Some(NodeKind::Import),
        "line_comment" | "block_comment" => Some(NodeKind::Comment),
        _ => None,
    }
}

fn normalize_javascript(ts_kind: &str) -> Option<NodeKind> {
    match ts_kind {
        "program" => Some(NodeKind::Module),
        "function_declaration" | "function" | "arrow_function" | "method_definition"
        | "function_expression" | "generator_function" | "generator_function_declaration" => {
            Some(NodeKind::Function)
        }
        "class_declaration" | "class" | "class_body" => Some(NodeKind::Class),
        "statement_block" => Some(NodeKind::Block),
        "if_statement" | "ternary_expression" => Some(NodeKind::IfStatement),
        "else_clause" => Some(NodeKind::ElseClause),
        "for_statement" | "for_in_statement" | "for_of_statement" => Some(NodeKind::ForLoop),
        "while_statement" | "do_statement" => Some(NodeKind::WhileLoop),
        "switch_statement" | "switch_case" => Some(NodeKind::MatchSwitch),
        "return_statement" | "yield_expression" => Some(NodeKind::ReturnStatement),
        "break_statement" | "continue_statement" => Some(NodeKind::BreakContinue),
        "try_statement" | "catch_clause" | "finally_clause" => Some(NodeKind::TryCatch),
        "variable_declaration" | "lexical_declaration" => Some(NodeKind::VariableDecl),
        "assignment_expression" | "augmented_assignment_expression" => Some(NodeKind::Assignment),
        "expression_statement" | "await_expression" | "throw_statement" | "delete_expression"
        | "spread_element" => Some(NodeKind::Expression),
        "call_expression" | "new_expression" => Some(NodeKind::CallExpression),
        "member_expression" | "computed_property_name" => Some(NodeKind::FieldAccess),
        "subscript_expression" => Some(NodeKind::IndexAccess),
        "string" | "template_string" | "number" | "true" | "false" | "null" | "undefined"
        | "regex" => Some(NodeKind::Literal),
        "formal_parameters" | "required_parameter" | "optional_parameter" => {
            Some(NodeKind::Parameter)
        }
        "type_annotation" | "type_identifier" | "predefined_type" | "union_type"
        | "intersection_type" | "generic_type" => Some(NodeKind::TypeAnnotation),
        "import_statement" | "import_declaration" | "export_statement" | "export_clause" => {
            Some(NodeKind::Import)
        }
        "comment" => Some(NodeKind::Comment),
        _ => None,
    }
}

fn normalize_go(ts_kind: &str) -> Option<NodeKind> {
    match ts_kind {
        "source_file" => Some(NodeKind::Module),
        "function_declaration" | "method_declaration" | "func_literal" => Some(NodeKind::Function),
        "type_declaration" | "struct_type" | "interface_type" | "type_spec" => {
            Some(NodeKind::Class)
        }
        "block" => Some(NodeKind::Block),
        "if_statement" => Some(NodeKind::IfStatement),
        "else_clause" => Some(NodeKind::ElseClause),
        "for_statement" | "range_clause" | "for_clause" => Some(NodeKind::ForLoop),
        "expression_switch_statement" | "type_switch_statement" | "select_statement"
        | "expression_case" | "default_case" | "communication_case" => Some(NodeKind::MatchSwitch),
        "return_statement" => Some(NodeKind::ReturnStatement),
        "break_statement" | "continue_statement" | "goto_statement" | "fallthrough_statement" => {
            Some(NodeKind::BreakContinue)
        }
        // Go defers are resource guards (like Python's with / try-finally)
        "defer_statement" => Some(NodeKind::TryCatch),
        // Goroutines are async expressions
        "go_statement" | "send_statement" | "receive_statement" => Some(NodeKind::Expression),
        "short_var_declaration" | "var_declaration" | "const_declaration" | "var_spec"
        | "const_spec" => Some(NodeKind::VariableDecl),
        "assignment_statement" | "inc_statement" | "dec_statement" => Some(NodeKind::Assignment),
        "expression_statement" => Some(NodeKind::Expression),
        "call_expression" => Some(NodeKind::CallExpression),
        "selector_expression" | "qualified_identifier" => Some(NodeKind::FieldAccess),
        "index_expression" | "slice_expression" => Some(NodeKind::IndexAccess),
        "interpreted_string_literal" | "raw_string_literal" | "int_literal" | "float_literal"
        | "imaginary_literal" | "rune_literal" | "true" | "false" | "nil" => Some(NodeKind::Literal),
        "parameter_list" | "parameter_declaration" | "variadic_parameter_declaration" => {
            Some(NodeKind::Parameter)
        }
        "type_identifier" | "qualified_type" | "pointer_type" | "array_type" | "map_type"
        | "channel_type" | "function_type" | "slice_type" => {
            Some(NodeKind::TypeAnnotation)
        }
        "import_declaration" | "import_spec" | "import_spec_list" | "blank_identifier" => {
            Some(NodeKind::Import)
        }
        "labeled_statement" | "empty_statement" => Some(NodeKind::Expression),
        "comment" => Some(NodeKind::Comment),
        _ => None,
    }
}

fn normalize_c(ts_kind: &str) -> Option<NodeKind> {
    match ts_kind {
        "translation_unit" => Some(NodeKind::Module),
        "function_definition" => Some(NodeKind::Function),
        "struct_specifier" | "union_specifier" | "enum_specifier" => Some(NodeKind::Class),
        "compound_statement" => Some(NodeKind::Block),
        "if_statement" => Some(NodeKind::IfStatement),
        "else_clause" => Some(NodeKind::ElseClause),
        "for_statement" => Some(NodeKind::ForLoop),
        "while_statement" | "do_statement" => Some(NodeKind::WhileLoop),
        "switch_statement" | "case_statement" => Some(NodeKind::MatchSwitch),
        "return_statement" => Some(NodeKind::ReturnStatement),
        "break_statement" | "continue_statement" => Some(NodeKind::BreakContinue),
        "declaration" | "init_declarator" => Some(NodeKind::VariableDecl),
        "assignment_expression" => Some(NodeKind::Assignment),
        "expression_statement" => Some(NodeKind::Expression),
        "call_expression" => Some(NodeKind::CallExpression),
        "field_expression" => Some(NodeKind::FieldAccess),
        "subscript_expression" => Some(NodeKind::IndexAccess),
        "string_literal" | "char_literal" | "number_literal" => Some(NodeKind::Literal),
        "parameter_list" | "parameter_declaration" => Some(NodeKind::Parameter),
        "type_identifier" | "primitive_type" => Some(NodeKind::TypeAnnotation),
        "preproc_include" => Some(NodeKind::Import),
        "comment" => Some(NodeKind::Comment),
        _ => None,
    }
}

fn normalize_java(ts_kind: &str) -> Option<NodeKind> {
    match ts_kind {
        "program" => Some(NodeKind::Module),
        "method_declaration" | "constructor_declaration" => Some(NodeKind::Function),
        "class_declaration" | "interface_declaration" | "enum_declaration" => {
            Some(NodeKind::Class)
        }
        "block" => Some(NodeKind::Block),
        "if_statement" => Some(NodeKind::IfStatement),
        "for_statement" | "enhanced_for_statement" => Some(NodeKind::ForLoop),
        "while_statement" | "do_statement" => Some(NodeKind::WhileLoop),
        "switch_expression" | "switch_statement" => Some(NodeKind::MatchSwitch),
        "return_statement" => Some(NodeKind::ReturnStatement),
        "break_statement" | "continue_statement" => Some(NodeKind::BreakContinue),
        "try_statement" | "catch_clause" => Some(NodeKind::TryCatch),
        "local_variable_declaration" => Some(NodeKind::VariableDecl),
        "assignment_expression" => Some(NodeKind::Assignment),
        "expression_statement" => Some(NodeKind::Expression),
        "method_invocation" | "object_creation_expression" => Some(NodeKind::CallExpression),
        "field_access" => Some(NodeKind::FieldAccess),
        "array_access" => Some(NodeKind::IndexAccess),
        "string_literal" | "character_literal" | "decimal_integer_literal"
        | "decimal_floating_point_literal" | "true" | "false" | "null_literal" => {
            Some(NodeKind::Literal)
        }
        "formal_parameters" | "formal_parameter" => Some(NodeKind::Parameter),
        "type_identifier" | "generic_type" => Some(NodeKind::TypeAnnotation),
        "import_declaration" => Some(NodeKind::Import),
        "line_comment" | "block_comment" => Some(NodeKind::Comment),
        _ => None,
    }
}

fn normalize_cpp(ts_kind: &str) -> Option<NodeKind> {
    match ts_kind {
        "translation_unit" => Some(NodeKind::Module),
        "function_definition" => Some(NodeKind::Function),
        "class_specifier" | "struct_specifier" => Some(NodeKind::Class),
        "compound_statement" => Some(NodeKind::Block),
        "if_statement" => Some(NodeKind::IfStatement),
        "else_clause" => Some(NodeKind::ElseClause),
        "for_statement" | "for_range_loop" => Some(NodeKind::ForLoop),
        "while_statement" | "do_statement" => Some(NodeKind::WhileLoop),
        "switch_statement" | "case_statement" => Some(NodeKind::MatchSwitch),
        "return_statement" => Some(NodeKind::ReturnStatement),
        "break_statement" | "continue_statement" => Some(NodeKind::BreakContinue),
        "try_statement" | "catch_clause" => Some(NodeKind::TryCatch),
        "declaration" | "init_declarator" => Some(NodeKind::VariableDecl),
        "assignment_expression" => Some(NodeKind::Assignment),
        "expression_statement" => Some(NodeKind::Expression),
        "call_expression" => Some(NodeKind::CallExpression),
        "field_expression" => Some(NodeKind::FieldAccess),
        "subscript_expression" => Some(NodeKind::IndexAccess),
        "string_literal" | "char_literal" | "number_literal" => Some(NodeKind::Literal),
        "parameter_list" | "parameter_declaration" => Some(NodeKind::Parameter),
        "type_identifier" | "primitive_type" | "template_type" => Some(NodeKind::TypeAnnotation),
        "preproc_include" | "using_declaration" => Some(NodeKind::Import),
        "comment" => Some(NodeKind::Comment),
        _ => None,
    }
}

/// Generic fallback normalization for common tree-sitter patterns.
fn normalize_generic(ts_kind: &str) -> Option<NodeKind> {
    if ts_kind.contains("function") || ts_kind.contains("method") {
        Some(NodeKind::Function)
    } else if ts_kind.contains("class") || ts_kind.contains("struct") {
        Some(NodeKind::Class)
    } else if ts_kind.contains("if") {
        Some(NodeKind::IfStatement)
    } else if ts_kind.contains("for") && !ts_kind.contains("format") {
        Some(NodeKind::ForLoop)
    } else if ts_kind.contains("while") {
        Some(NodeKind::WhileLoop)
    } else if ts_kind.contains("return") {
        Some(NodeKind::ReturnStatement)
    } else if ts_kind.contains("import") || ts_kind.contains("include") || ts_kind.contains("use")
    {
        Some(NodeKind::Import)
    } else if ts_kind.contains("comment") {
        Some(NodeKind::Comment)
    } else {
        None
    }
}

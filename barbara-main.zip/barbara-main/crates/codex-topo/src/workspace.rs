//! Workspace-level topology analysis for multi-crate Rust projects.
//!
//! Builds on `codex_parse::walk_workspace` to add topology computation,
//! crate-level aggregation, and architectural clustering.

use std::path::Path;

use codex_parse::workspace::walk_workspace;
use codex_parse::{NodeKind, observations_to_graph};
use serde::{Deserialize, Serialize};

use crate::{compute_code_topology, topology_similarity, CodeTopology, TopoConfig};

// ── Public Types ─────────────────────────────────────────────────────────────

/// Full analysis of a Rust workspace.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct WorkspaceAnalysis {
    /// Per-file topology (memory-efficient: observations not retained).
    pub files: Vec<FileAnalysis>,
    /// Module/crate dependency graph.
    pub module_graph: ModuleGraph,
    /// Workspace-wide aggregate topology (averaged over all files).
    pub workspace_topology: CodeTopology,
    /// Per-crate aggregate topologies.
    pub crate_topologies: Vec<CrateTopology>,
    /// Summary statistics.
    pub stats: WorkspaceStats,
}

/// Topology analysis of a single source file.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileAnalysis {
    /// Absolute path.
    pub path: String,
    /// Path relative to workspace root.
    pub relative_path: String,
    /// Crate this file belongs to.
    pub crate_name: String,
    /// Computed topology.
    pub topology: CodeTopology,
    /// Lines of code (non-empty lines).
    pub loc: usize,
    /// Total AST nodes.
    pub total_nodes: usize,
}

/// Aggregate topology for one crate.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrateTopology {
    pub name: String,
    pub file_count: usize,
    pub total_loc: usize,
    pub topology: CodeTopology,
    pub function_count: usize,
    pub struct_count: usize,
    pub trait_count: usize,
    pub test_count: usize,
}

/// Cross-crate dependency graph.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ModuleGraph {
    /// Directed edges between crates.
    pub edges: Vec<(String, String, DepType)>,
}

/// Type of dependency relationship.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum DepType {
    /// Listed in Cargo.toml [dependencies].
    DirectDependency,
    /// `use` import in source code (heuristic).
    UseImport,
    /// Implements a trait from another crate (heuristic).
    TraitImpl,
}

/// Workspace-level summary counts.
#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct WorkspaceStats {
    pub total_files: usize,
    pub total_loc: usize,
    pub total_functions: usize,
    pub total_structs: usize,
    pub total_traits: usize,
    pub total_tests: usize,
    pub total_crates: usize,
    pub parse_errors: usize,
}

// ── Crate Relationship Analysis ───────────────────────────────────────────────

/// Report on pairwise crate similarities.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrateRelationshipReport {
    /// All (crate_a, crate_b, similarity) triples, sorted descending.
    pub similarity_matrix: Vec<(String, String, f64)>,
    /// Groups of topologically similar crates.
    pub clusters: Vec<CrateCluster>,
    /// Crates with no similar partner (avg similarity < 0.60).
    pub isolated_crates: Vec<String>,
    /// Pairs with similarity > 0.90 — potential duplication.
    pub potential_duplicates: Vec<(String, String, f64)>,
    /// Architectural layers detected via Fiedler value ordering.
    pub architectural_layers: Vec<Vec<String>>,
}

/// A group of topologically similar crates.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CrateCluster {
    pub crates: Vec<String>,
    pub avg_internal_similarity: f64,
    /// Auto-generated description from dominant node kinds.
    pub description: String,
}

// ── Entry Points ─────────────────────────────────────────────────────────────

/// Parse and analyze an entire Rust workspace.
///
/// Files that fail to parse are skipped (error count in `stats.parse_errors`).
/// Observations are discarded after topology computation to save memory.
pub fn parse_workspace(root: &Path) -> WorkspaceAnalysis {
    let config = TopoConfig::default();
    parse_workspace_with_config(root, &config)
}

/// Same as `parse_workspace` but with a custom `TopoConfig`.
pub fn parse_workspace_with_config(root: &Path, config: &TopoConfig) -> WorkspaceAnalysis {
    let raw = walk_workspace(root);

    let mut file_analyses: Vec<FileAnalysis> = Vec::new();
    let mut stats = WorkspaceStats {
        parse_errors: raw.parse_errors.len(),
        ..Default::default()
    };

    for pf in &raw.files {
        let graph = observations_to_graph(&pf.observations);
        let topology = compute_code_topology(&graph, &pf.observations, config);

        // Count by NodeKind.
        let func_count = count_kind(&pf.observations, &NodeKind::Function);
        let struct_count = count_kind(&pf.observations, &NodeKind::Class); // Class ≅ struct/class
        let trait_count = count_kind(&pf.observations, &NodeKind::TypeAnnotation);
        let test_count = count_test_functions(&pf.observations);

        stats.total_loc += pf.loc;
        stats.total_functions += func_count;
        stats.total_structs += struct_count;
        stats.total_traits += trait_count;
        stats.total_tests += test_count;

        file_analyses.push(FileAnalysis {
            path: pf.path.to_string_lossy().into_owned(),
            relative_path: pf.relative_path.clone(),
            crate_name: pf.crate_name.clone(),
            topology,
            loc: pf.loc,
            total_nodes: pf.metadata.total_nodes,
        });
    }

    stats.total_files = file_analyses.len();
    stats.total_crates = raw.crate_names.len();

    // Aggregate per-crate topologies.
    let crate_topologies = aggregate_crate_topologies(&file_analyses, &raw.files, config);

    // Build aggregate workspace topology (average of crate topologies).
    let workspace_topology = if !crate_topologies.is_empty() {
        average_topologies(crate_topologies.iter().map(|c| &c.topology).collect())
    } else if !file_analyses.is_empty() {
        average_topologies(file_analyses.iter().map(|f| &f.topology).collect())
    } else {
        empty_topology()
    };

    // Build a lightweight module graph from `use` import heuristics.
    let module_graph = build_module_graph(&raw.files, &raw.crate_names);

    WorkspaceAnalysis {
        files: file_analyses,
        module_graph,
        workspace_topology,
        crate_topologies,
        stats,
    }
}

/// Compare every pair of crates in a workspace and produce a relationship report.
pub fn analyze_crate_relationships(analysis: &WorkspaceAnalysis) -> CrateRelationshipReport {
    let crates = &analysis.crate_topologies;
    let n = crates.len();

    // Build pairwise similarity matrix.
    let mut matrix: Vec<(String, String, f64)> = Vec::new();
    for i in 0..n {
        for j in (i + 1)..n {
            let sim = topology_similarity(&crates[i].topology, &crates[j].topology);
            matrix.push((crates[i].name.clone(), crates[j].name.clone(), sim));
        }
    }
    matrix.sort_by(|a, b| b.2.partial_cmp(&a.2).unwrap_or(std::cmp::Ordering::Equal));

    // Potential duplicates: sim > 0.90.
    let potential_duplicates: Vec<_> = matrix
        .iter()
        .filter(|(_, _, s)| *s > 0.90)
        .cloned()
        .collect();

    // Greedy clustering at threshold 0.70.
    let clusters = greedy_cluster(crates, &matrix, 0.70);

    // Isolated crates: not in any cluster of size ≥ 2.
    let clustered: std::collections::HashSet<String> = clusters
        .iter()
        .flat_map(|c| c.crates.iter().cloned())
        .collect();
    let isolated_crates: Vec<String> = crates
        .iter()
        .map(|c| c.name.clone())
        .filter(|name| !clustered.contains(name))
        .collect();

    // Architectural layers: sort crates by Fiedler value (proxy for hierarchy).
    let architectural_layers = fiedler_layers(crates);

    CrateRelationshipReport {
        similarity_matrix: matrix,
        clusters,
        isolated_crates,
        potential_duplicates,
        architectural_layers,
    }
}

// ── Internal Helpers ──────────────────────────────────────────────────────────

fn count_kind(observations: &[codex_parse::CodeObservation], kind: &NodeKind) -> usize {
    observations.iter().filter(|o| &o.kind == kind).count()
}

fn count_test_functions(observations: &[codex_parse::CodeObservation]) -> usize {
    // Heuristic: count nodes that are probably test functions.
    // In Rust, test functions are marked by #[test] attribute — we detect
    // them by looking for Function nodes preceded by an Attribute containing "test".
    // Simple proxy: count Function nodes where node_id contains "test".
    observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::Function) && o.node_id.contains("test"))
        .count()
}

fn aggregate_crate_topologies(
    file_analyses: &[FileAnalysis],
    raw_files: &[codex_parse::workspace::ParsedFile],
    _config: &TopoConfig,
) -> Vec<CrateTopology> {
    use std::collections::HashMap;

    // Group files by crate.
    let mut crate_files: HashMap<&str, Vec<usize>> = HashMap::new();
    for (i, fa) in file_analyses.iter().enumerate() {
        crate_files.entry(fa.crate_name.as_str()).or_default().push(i);
    }

    let mut result: Vec<CrateTopology> = crate_files
        .iter()
        .map(|(crate_name, indices)| {
            let topos: Vec<&CodeTopology> = indices.iter().map(|&i| &file_analyses[i].topology).collect();
            let topology = average_topologies(topos);

            let total_loc: usize = indices.iter().map(|&i| file_analyses[i].loc).sum();
            let file_count = indices.len();

            // Count node kinds across all files in this crate.
            let function_count: usize = indices
                .iter()
                .map(|&i| count_kind(&raw_files[i].observations, &NodeKind::Function))
                .sum();
            let struct_count: usize = indices
                .iter()
                .map(|&i| count_kind(&raw_files[i].observations, &NodeKind::Class))
                .sum();
            let trait_count: usize = indices
                .iter()
                .map(|&i| count_kind(&raw_files[i].observations, &NodeKind::TypeAnnotation))
                .sum();
            let test_count: usize = indices
                .iter()
                .map(|&i| count_test_functions(&raw_files[i].observations))
                .sum();

            CrateTopology {
                name: crate_name.to_string(),
                file_count,
                total_loc,
                topology,
                function_count,
                struct_count,
                trait_count,
                test_count,
            }
        })
        .collect();

    result.sort_by(|a, b| a.name.cmp(&b.name));
    result
}

/// Average a collection of topologies into one representative topology.
/// Uses element-wise averaging for numeric fields; takes the first for
/// discrete fields (kind_distribution, control_flow_sequence).
fn average_topologies(topos: Vec<&CodeTopology>) -> CodeTopology {
    if topos.is_empty() {
        return empty_topology();
    }
    if topos.len() == 1 {
        return (*topos[0]).clone();
    }

    let n = topos.len() as f64;

    // Average spectral signature (pad/truncate to min length).
    let min_spec = topos.iter().map(|t| t.spectral_signature.len()).min().unwrap_or(0);
    let spectral_signature: Vec<f64> = (0..min_spec)
        .map(|i| topos.iter().map(|t| t.spectral_signature[i]).sum::<f64>() / n)
        .collect();

    let spectral_gap = topos.iter().map(|t| t.spectral_gap).sum::<f64>() / n;
    let fiedler_value = topos.iter().map(|t| t.fiedler_value).sum::<f64>() / n;
    let kuramoto_order = topos.iter().map(|t| t.kuramoto_order).sum::<f64>() / n;
    let sync_clusters = (topos.iter().map(|t| t.sync_clusters as f64).sum::<f64>() / n) as usize;
    let call_density = topos.iter().map(|t| t.call_density).sum::<f64>() / n;
    let structural_volume = topos.iter().map(|t| t.structural_volume).sum::<f64>() / n;
    let cyclomatic_complexity =
        (topos.iter().map(|t| t.cyclomatic_complexity as f64).sum::<f64>() / n) as u32;

    // Betti: element-wise average (truncate to min length).
    let min_betti = topos.iter().map(|t| t.betti.len()).min().unwrap_or(0);
    let betti: Vec<usize> = (0..min_betti)
        .map(|i| (topos.iter().map(|t| t.betti[i] as f64).sum::<f64>() / n) as usize)
        .collect();

    // Depth histogram: average (pad shorter with 0s).
    let max_depth = topos.iter().map(|t| t.depth_histogram.len()).max().unwrap_or(0);
    let depth_histogram: Vec<f64> = (0..max_depth)
        .map(|i| {
            topos
                .iter()
                .map(|t| t.depth_histogram.get(i).copied().unwrap_or(0.0))
                .sum::<f64>()
                / n
        })
        .collect();

    // Kind distribution: sum counts, then normalize.
    let kind_distribution = aggregate_kind_distribution(topos.iter().copied());

    // Structural ratios: average.
    let sr = crate::StructuralRatios {
        control_density: topos.iter().map(|t| t.structural_ratios.control_density).sum::<f64>() / n,
        function_density: topos.iter().map(|t| t.structural_ratios.function_density).sum::<f64>() / n,
        call_density: topos.iter().map(|t| t.structural_ratios.call_density).sum::<f64>() / n,
        nesting_ratio: topos.iter().map(|t| t.structural_ratios.nesting_ratio).sum::<f64>() / n,
        leaf_ratio: topos.iter().map(|t| t.structural_ratios.leaf_ratio).sum::<f64>() / n,
    };

    // Control flow sequence: take the longest (most representative).
    let control_flow_sequence = topos
        .iter()
        .max_by_key(|t| t.control_flow_sequence.len())
        .map(|t| t.control_flow_sequence.clone())
        .unwrap_or_default();

    CodeTopology {
        spectral_signature,
        spectral_gap,
        fiedler_value,
        betti,
        kuramoto_order,
        sync_clusters,
        depth_histogram,
        kind_distribution,
        call_density,
        cyclomatic_complexity,
        structural_volume,
        control_flow_sequence,
        structural_ratios: sr,
    }
}

fn aggregate_kind_distribution<'a, I>(topos: I) -> Vec<(NodeKind, u32)>
where
    I: Iterator<Item = &'a CodeTopology>,
{
    use std::collections::HashMap;
    let mut counts: HashMap<String, u32> = HashMap::new();
    let mut kind_map: HashMap<String, NodeKind> = HashMap::new();
    for topo in topos {
        for (kind, count) in &topo.kind_distribution {
            let key = format!("{:?}", kind);
            *counts.entry(key.clone()).or_insert(0) += count;
            kind_map.entry(key).or_insert_with(|| kind.clone());
        }
    }
    let mut result: Vec<(NodeKind, u32)> = counts
        .into_iter()
        .map(|(key, count)| (kind_map[&key].clone(), count))
        .collect();
    result.sort_by(|a, b| b.1.cmp(&a.1));
    result
}

fn empty_topology() -> CodeTopology {
    CodeTopology {
        spectral_signature: vec![0.0],
        spectral_gap: 0.0,
        fiedler_value: 0.0,
        betti: vec![0, 0, 0],
        kuramoto_order: 0.0,
        sync_clusters: 0,
        depth_histogram: vec![],
        kind_distribution: vec![],
        call_density: 0.0,
        cyclomatic_complexity: 0,
        structural_volume: 0.0,
        control_flow_sequence: vec![],
        structural_ratios: crate::StructuralRatios {
            control_density: 0.0,
            function_density: 0.0,
            call_density: 0.0,
            nesting_ratio: 0.0,
            leaf_ratio: 0.0,
        },
    }
}

fn build_module_graph(
    files: &[codex_parse::workspace::ParsedFile],
    crate_names: &[String],
) -> ModuleGraph {
    use std::collections::HashSet;

    let crate_set: HashSet<&str> = crate_names.iter().map(|s| s.as_str()).collect();
    let mut edges: Vec<(String, String, DepType)> = Vec::new();
    let mut seen: HashSet<(String, String)> = HashSet::new();

    for file in files {
        // Heuristic: look for `use <crate_name>::` patterns in source.
        if let Ok(source) = std::fs::read_to_string(&file.path) {
            for line in source.lines() {
                let trimmed = line.trim();
                if trimmed.starts_with("use ") || trimmed.starts_with("extern crate ") {
                    for crate_name in crate_set.iter() {
                        let normalized = crate_name.replace('-', "_");
                        if (trimmed.contains(&format!("use {}::", normalized))
                            || trimmed.contains(&format!("extern crate {}", normalized))
                            || trimmed.contains(&format!("use {}::", crate_name)))
                            && file.crate_name != *crate_name
                        {
                            let key = (file.crate_name.clone(), crate_name.to_string());
                            if !seen.contains(&key) {
                                seen.insert(key.clone());
                                edges.push((key.0, key.1, DepType::UseImport));
                            }
                        }
                    }
                }
            }
        }
    }

    ModuleGraph { edges }
}

fn greedy_cluster(
    crates: &[CrateTopology],
    matrix: &[(String, String, f64)],
    threshold: f64,
) -> Vec<CrateCluster> {
    use std::collections::HashMap;

    // Build adjacency for threshold.
    let mut adjacency: HashMap<&str, Vec<(&str, f64)>> = HashMap::new();
    for (a, b, sim) in matrix {
        if *sim >= threshold {
            adjacency.entry(a.as_str()).or_default().push((b.as_str(), *sim));
            adjacency.entry(b.as_str()).or_default().push((a.as_str(), *sim));
        }
    }

    let mut assigned: std::collections::HashSet<&str> = std::collections::HashSet::new();
    let mut clusters: Vec<CrateCluster> = Vec::new();

    for ct in crates {
        let name = ct.name.as_str();
        if assigned.contains(name) {
            continue;
        }
        let mut cluster_members: Vec<String> = vec![name.to_string()];
        assigned.insert(name);

        if let Some(neighbors) = adjacency.get(name) {
            for (neighbor, _) in neighbors {
                if !assigned.contains(neighbor) {
                    cluster_members.push(neighbor.to_string());
                    assigned.insert(neighbor);
                }
            }
        }

        if cluster_members.len() < 2 {
            continue; // Only form clusters of 2+.
        }

        // Compute avg internal similarity.
        let mut sim_sum = 0.0;
        let mut sim_count = 0;
        for i in 0..cluster_members.len() {
            for j in (i + 1)..cluster_members.len() {
                if let Some((_, _, s)) = matrix.iter().find(|(a, b, _)| {
                    (a == &cluster_members[i] && b == &cluster_members[j])
                        || (a == &cluster_members[j] && b == &cluster_members[i])
                }) {
                    sim_sum += s;
                    sim_count += 1;
                }
            }
        }
        let avg_sim = if sim_count > 0 { sim_sum / sim_count as f64 } else { threshold };

        // Description from cluster name patterns.
        let description = describe_cluster(&cluster_members);

        clusters.push(CrateCluster {
            crates: cluster_members,
            avg_internal_similarity: avg_sim,
            description,
        });
    }

    clusters
}

fn describe_cluster(names: &[String]) -> String {
    let prefix = common_prefix(names);
    if !prefix.is_empty() {
        format!("{}-* cluster ({} crates)", prefix.trim_end_matches('-'), names.len())
    } else {
        format!("cluster of {} crates", names.len())
    }
}

fn common_prefix(names: &[String]) -> String {
    if names.is_empty() {
        return String::new();
    }
    let first = &names[0];
    let mut len = first.len();
    for name in &names[1..] {
        len = first
            .chars()
            .zip(name.chars())
            .take_while(|(a, b)| a == b)
            .count()
            .min(len);
    }
    first[..len].to_string()
}

fn fiedler_layers(crates: &[CrateTopology]) -> Vec<Vec<String>> {
    // Sort crates by Fiedler value (ascending = more "foundational").
    let mut sorted: Vec<(&CrateTopology, f64)> = crates
        .iter()
        .map(|c| (c, c.topology.fiedler_value))
        .collect();
    sorted.sort_by(|a, b| a.1.partial_cmp(&b.1).unwrap_or(std::cmp::Ordering::Equal));

    if sorted.is_empty() {
        return vec![];
    }

    // Partition into 3-5 layers by quantile.
    let layer_count = (sorted.len() / 3).max(2).min(5);
    let layer_size = (sorted.len() + layer_count - 1) / layer_count;

    sorted
        .chunks(layer_size)
        .map(|chunk| chunk.iter().map(|(c, _)| c.name.clone()).collect())
        .collect()
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn average_empty_returns_empty_topology() {
        let result = average_topologies(vec![]);
        assert_eq!(result.spectral_signature, vec![0.0]);
    }

    #[test]
    fn describe_cluster_uses_common_prefix() {
        let names = vec!["codex-parse".to_string(), "codex-topo".to_string(), "codex-learn".to_string()];
        let desc = describe_cluster(&names);
        assert!(desc.contains("codex"), "expected 'codex' in description, got: {}", desc);
    }

    #[test]
    fn common_prefix_extracted_correctly() {
        let names = vec!["schmiede-lexgen".to_string(), "schmiede-parsegen".to_string()];
        let prefix = common_prefix(&names);
        assert_eq!(prefix, "schmiede-");
    }
}

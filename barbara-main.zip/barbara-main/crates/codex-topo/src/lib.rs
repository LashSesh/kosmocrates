//! codex-topo — Code Topology
//!
//! Computes code-specific topological features from the PSE observation
//! graph. This is where language-independent structural signatures emerge.

pub mod workspace;

pub use workspace::{
    parse_workspace, parse_workspace_with_config,
    analyze_crate_relationships,
    WorkspaceAnalysis, FileAnalysis, CrateTopology, CrateRelationshipReport,
    CrateCluster, ModuleGraph, DepType, WorkspaceStats,
};

use codex_parse::NodeKind;
use pse_graph::PersistentGraph;
use pse_topology::{
    compute_laplacian, init_kuramoto_state, kuramoto_order_parameter, kuramoto_step,
    spectral_decompose, TopologyConfig,
};
use serde::{Deserialize, Serialize};

// ── Configuration ────────────────────────────────────────────────────

/// Configuration for topology computation.
#[derive(Debug, Clone)]
pub struct TopoConfig {
    /// Number of spectral components to compute.
    pub spectral_k: usize,
    /// Kuramoto coupling strength.
    pub kuramoto_kappa: f64,
    /// Kuramoto max ticks.
    pub kuramoto_max_ticks: u32,
    /// Connection radius for Betti computation.
    pub betti_radius: f64,
}

impl Default for TopoConfig {
    fn default() -> Self {
        Self {
            spectral_k: 16,
            kuramoto_kappa: 2.0,
            kuramoto_max_ticks: 500,
            betti_radius: 0.0, // auto
        }
    }
}

// ── Core Type ────────────────────────────────────────────────────────

/// The language-independent topological signature of a program
/// or program fragment.
///
/// Two programs that do the same thing — regardless of language —
/// should produce similar CodeTopology values.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeTopology {
    /// First k eigenvalues of the program graph Laplacian.
    /// Captures the "shape" of the program.
    pub spectral_signature: Vec<f64>,
    /// Spectral gap (lambda_2 - lambda_1).
    pub spectral_gap: f64,
    /// Fiedler value (second-smallest eigenvalue).
    pub fiedler_value: f64,
    /// Betti numbers: [b0, b1, b2].
    pub betti: Vec<usize>,
    /// Kuramoto order parameter r (0..1).
    pub kuramoto_order: f64,
    /// Number of synchronized clusters detected.
    pub sync_clusters: usize,
    /// Depth distribution normalized to a probability distribution.
    /// Each value = count_at_depth_n / total_nodes.
    /// This makes it scale-independent: a deep Rust program and a shallow
    /// Python program with the same SHAPE of nesting produce similar histograms.
    pub depth_histogram: Vec<f64>,
    /// Node kind distribution: how many of each NodeKind.
    pub kind_distribution: Vec<(NodeKind, u32)>,
    /// Call graph density: edges / possible_edges.
    pub call_density: f64,
    /// Cyclomatic complexity (approximated from control flow topology).
    pub cyclomatic_complexity: u32,
    /// Halstead-like volume derived from AST node counts.
    pub structural_volume: f64,
    /// Ordered sequence of control flow node kinds.
    /// Used for LCS-based control flow similarity (language-independent ordering).
    pub control_flow_sequence: Vec<NodeKind>,
    /// Language-independent structural ratios (all in [0, 1]).
    pub structural_ratios: StructuralRatios,
}

/// Language-independent structural ratios (all relative to total node count).
/// Robust against language verbosity: Rust is more verbose than Python, but
/// the RATIO of control flow nodes to total nodes is similar for equivalent programs.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct StructuralRatios {
    /// control_flow_nodes / total_nodes
    pub control_density: f64,
    /// function_nodes / total_nodes
    pub function_density: f64,
    /// call_nodes / total_nodes
    pub call_density: f64,
    /// max_depth / sqrt(total_nodes) — normalizes nesting for size
    pub nesting_ratio: f64,
    /// leaf_nodes (named_child_count == 0) / total_nodes
    pub leaf_ratio: f64,
}

// ── Computation ──────────────────────────────────────────────────────

/// Compute the full topological signature of a program.
///
/// Input: PSE observation graph built by codex-parse
/// Output: CodeTopology
pub fn compute_code_topology(
    graph: &PersistentGraph,
    observations: &[codex_parse::CodeObservation],
    config: &TopoConfig,
) -> CodeTopology {
    let topo_config = TopologyConfig {
        spectral_k_max: config.spectral_k,
        kuramoto_coupling: config.kuramoto_kappa,
        kuramoto_steps: config.kuramoto_max_ticks as usize,
        kuramoto_dt: 0.05,
        ctqw_time_max: 10.0,
        ctqw_threshold: 0.01,
        ctqw_time_steps: 100,
        fixpoint_epsilon: 1e-6,
        fixpoint_consecutive: 3,
        budget_ms: 5000,
    };

    // Spectral decomposition
    let laplacian = compute_laplacian(graph);
    let spectral = spectral_decompose(&laplacian, topo_config.spectral_k_max);

    let spectral_signature = spectral.eigenvalues.clone();
    let spectral_gap = spectral.spectral_gap;
    let fiedler_value = if spectral.eigenvalues.len() > 1 {
        spectral.eigenvalues[1]
    } else {
        0.0
    };

    // Betti numbers from the PSE topology signature
    let topo_sig = graph.topology_signature();
    let betti = vec![
        topo_sig.betti_0 as usize,
        topo_sig.betti_1 as usize,
        topo_sig.betti_2 as usize,
    ];

    // Kuramoto synchronization
    let mut kuramoto = init_kuramoto_state(graph);
    for _ in 0..config.kuramoto_max_ticks {
        kuramoto_step(&mut kuramoto, graph, &topo_config);
    }
    let (kuramoto_order, _mean_phase) = kuramoto_order_parameter(&kuramoto.phases);

    // Count synchronized clusters (groups of phases within pi/4)
    let sync_clusters = count_sync_clusters(&kuramoto.phases);

    // Depth histogram from observations
    let depth_histogram = compute_depth_histogram(observations);

    // Kind distribution from observations
    let kind_distribution = compute_kind_distribution(observations);

    // Structural metrics
    let call_density = compute_call_density(observations);
    let cyclomatic_complexity = compute_cyclomatic_complexity(observations);
    let structural_volume = compute_structural_volume(observations);

    let control_flow_sequence = extract_control_flow_sequence(observations);
    let structural_ratios = compute_structural_ratios(observations);

    CodeTopology {
        spectral_signature,
        spectral_gap,
        fiedler_value,
        betti,
        kuramoto_order,
        sync_clusters,
        depth_histogram,
        kind_distribution,
        call_density,
        cyclomatic_complexity,
        structural_volume,
        control_flow_sequence,
        structural_ratios,
    }
}

/// Compute topology directly from source code (convenience).
pub fn topology_from_source(
    source: &str,
    language: &str,
    config: &TopoConfig,
) -> Result<CodeTopology, codex_parse::ParseError> {
    let (observations, _meta) = codex_parse::parse_source(source, language)?;
    let graph = codex_parse::observations_to_graph(&observations);
    Ok(compute_code_topology(&graph, &observations, config))
}

// ── Similarity ───────────────────────────────────────────────────────

/// Compute similarity between two CodeTopology instances.
///
/// Returns value in [0.0, 1.0] where 1.0 = topologically identical.
///
/// Weight distribution (Round 4 — structural features added at calibrated weights):
///   25%  spectral cosine similarity    (always ~1.0; anchors the score)
///   10%  Betti number match            (topological invariants)
///   10%  Kuramoto order proximity      (always ~1.0; anchors the score)
///   19%  depth histogram correlation   (nesting shape — most stable cross-language)
///   19%  kind distribution similarity  (AST node proportions — most discriminating)
///    5%  control flow LCS similarity   (structural sequence, avg 0.80 — calibrated low
///                                       because Go's explicit error-handling inflates
///                                       IfStatement count vs Python/Rust)
///    5%  structural ratios similarity  (density ratios, avg ~0.90 — language-robust)
///    7%  cyclomatic complexity ratio   (control flow count, language-noisy — reduced)
///    0%  structural volume             (dropped: high language noise, avg 0.848)
///    0%  call density                  (dropped: too noisy across languages, avg 0.628)
pub fn topology_similarity(a: &CodeTopology, b: &CodeTopology) -> f64 {
    let spectral_sim = cosine_similarity(&a.spectral_signature, &b.spectral_signature);
    let betti_sim = betti_similarity(&a.betti, &b.betti);
    let kuramoto_sim = 1.0 - (a.kuramoto_order - b.kuramoto_order).abs();
    let depth_sim = histogram_correlation(&a.depth_histogram, &b.depth_histogram);
    let kind_sim = kind_distribution_similarity(&a.kind_distribution, &b.kind_distribution);

    // Control flow LCS similarity (language-independent structural sequence)
    // Weight calibrated low: Go's explicit error handling inflates IfStatement count
    // vs Python/Rust, dragging LCS ratio down for equivalent cross-language programs.
    let cf_sim = control_flow_similarity(&a.control_flow_sequence, &b.control_flow_sequence);

    // Structural ratios (language-independent density proportions)
    let ratios_sim = structural_ratios_similarity(&a.structural_ratios, &b.structural_ratios);

    // Cyclomatic complexity (language-noisy — kept low weight)
    let cc_sim = {
        let max_cc = (a.cyclomatic_complexity.max(b.cyclomatic_complexity)).max(1) as f64;
        1.0 - (a.cyclomatic_complexity as f64 - b.cyclomatic_complexity as f64).abs() / max_cc
    };

    let similarity = 0.25 * spectral_sim
        + 0.10 * betti_sim
        + 0.10 * kuramoto_sim
        + 0.19 * depth_sim
        + 0.19 * kind_sim
        + 0.05 * cf_sim
        + 0.05 * ratios_sim
        + 0.07 * cc_sim;

    similarity.clamp(0.0, 1.0)
}

// ── Structural Feature Computation ───────────────────────────────────

/// Extract the ordered control flow sequence from observations.
/// A flat list of control flow NodeKinds in traversal order — language-independent
/// because it captures WHAT decisions are made, not HOW they're expressed syntactically.
fn extract_control_flow_sequence(observations: &[codex_parse::CodeObservation]) -> Vec<NodeKind> {
    observations
        .iter()
        .filter(|o| {
            matches!(
                o.kind,
                NodeKind::Function
                    | NodeKind::IfStatement
                    | NodeKind::ElseClause
                    | NodeKind::ForLoop
                    | NodeKind::WhileLoop
                    | NodeKind::MatchSwitch
                    | NodeKind::ReturnStatement
                    | NodeKind::TryCatch
                    | NodeKind::BreakContinue
            )
        })
        .map(|o| o.kind.clone())
        .collect()
}

/// Compute longest common subsequence length (dynamic programming).
fn lcs_length(a: &[NodeKind], b: &[NodeKind]) -> usize {
    if a.is_empty() || b.is_empty() {
        return 0;
    }
    let m = a.len();
    let n = b.len();
    // Use two rows to save memory
    let mut prev = vec![0usize; n + 1];
    let mut curr = vec![0usize; n + 1];
    for i in 1..=m {
        for j in 1..=n {
            curr[j] = if a[i - 1] == b[j - 1] {
                prev[j - 1] + 1
            } else {
                curr[j - 1].max(prev[j])
            };
        }
        std::mem::swap(&mut prev, &mut curr);
        curr.iter_mut().for_each(|x| *x = 0);
    }
    prev[n]
}

/// LCS ratio: lcs_len / max(|a|, |b|).
pub fn control_flow_similarity(a: &[NodeKind], b: &[NodeKind]) -> f64 {
    let max_len = a.len().max(b.len());
    if max_len == 0 {
        return 1.0;
    }
    lcs_length(a, b) as f64 / max_len as f64
}

/// Compute structural ratios from observations.
fn compute_structural_ratios(observations: &[codex_parse::CodeObservation]) -> StructuralRatios {
    let total = observations.len();
    if total == 0 {
        return StructuralRatios {
            control_density: 0.0,
            function_density: 0.0,
            call_density: 0.0,
            nesting_ratio: 0.0,
            leaf_ratio: 0.0,
        };
    }

    let n = total as f64;
    let control = observations
        .iter()
        .filter(|o| {
            matches!(
                o.kind,
                NodeKind::IfStatement
                    | NodeKind::ElseClause
                    | NodeKind::ForLoop
                    | NodeKind::WhileLoop
                    | NodeKind::MatchSwitch
                    | NodeKind::TryCatch
            )
        })
        .count() as f64;

    let functions = observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::Function))
        .count() as f64;

    let calls = observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::CallExpression))
        .count() as f64;

    let max_depth = observations.iter().map(|o| o.depth).max().unwrap_or(0) as f64;

    let leaves = observations
        .iter()
        .filter(|o| o.named_child_count == 0)
        .count() as f64;

    StructuralRatios {
        control_density: control / n,
        function_density: functions / n,
        call_density: calls / n,
        nesting_ratio: if n > 0.0 { max_depth / n.sqrt() } else { 0.0 },
        leaf_ratio: leaves / n,
    }
}

/// Similarity between two StructuralRatios (mean absolute difference → similarity).
fn structural_ratios_similarity(a: &StructuralRatios, b: &StructuralRatios) -> f64 {
    let diffs = [
        (a.control_density - b.control_density).abs(),
        (a.function_density - b.function_density).abs(),
        (a.call_density - b.call_density).abs(),
        (a.nesting_ratio - b.nesting_ratio).abs().min(1.0),
        (a.leaf_ratio - b.leaf_ratio).abs(),
    ];
    let mean_diff = diffs.iter().sum::<f64>() / diffs.len() as f64;
    (1.0 - mean_diff).clamp(0.0, 1.0)
}

// ── Helper Functions ─────────────────────────────────────────────────

fn cosine_similarity(a: &[f64], b: &[f64]) -> f64 {
    let len = a.len().max(b.len());
    if len == 0 {
        return 1.0;
    }

    let mut dot = 0.0;
    let mut norm_a = 0.0;
    let mut norm_b = 0.0;

    for i in 0..len {
        let va = a.get(i).copied().unwrap_or(0.0);
        let vb = b.get(i).copied().unwrap_or(0.0);
        dot += va * vb;
        norm_a += va * va;
        norm_b += vb * vb;
    }

    if norm_a < 1e-12 || norm_b < 1e-12 {
        if norm_a < 1e-12 && norm_b < 1e-12 {
            return 1.0; // both zero vectors
        }
        return 0.0;
    }

    (dot / (norm_a.sqrt() * norm_b.sqrt())).clamp(0.0, 1.0)
}

fn betti_similarity(a: &[usize], b: &[usize]) -> f64 {
    let len = a.len().max(b.len());
    if len == 0 {
        return 1.0;
    }

    let mut total = 0.0;
    for i in 0..len {
        let va = *a.get(i).unwrap_or(&0) as f64;
        let vb = *b.get(i).unwrap_or(&0) as f64;
        let max_val = va.max(vb).max(1.0);
        total += 1.0 - (va - vb).abs() / max_val;
    }

    total / len as f64
}

fn histogram_correlation(a: &[f64], b: &[f64]) -> f64 {
    // depth_histogram is already normalized; use cosine similarity directly
    cosine_similarity(a, b)
}

fn kind_distribution_similarity(
    a: &[(NodeKind, u32)],
    b: &[(NodeKind, u32)],
) -> f64 {
    // Collect all unique kinds
    let mut all_kinds: Vec<NodeKind> = Vec::new();
    for (k, _) in a.iter().chain(b.iter()) {
        if !all_kinds.contains(k) {
            all_kinds.push(k.clone());
        }
    }

    if all_kinds.is_empty() {
        return 1.0;
    }

    let a_vec: Vec<f64> = all_kinds
        .iter()
        .map(|k| {
            a.iter()
                .find(|(kind, _)| kind == k)
                .map(|(_, c)| *c as f64)
                .unwrap_or(0.0)
        })
        .collect();
    let b_vec: Vec<f64> = all_kinds
        .iter()
        .map(|k| {
            b.iter()
                .find(|(kind, _)| kind == k)
                .map(|(_, c)| *c as f64)
                .unwrap_or(0.0)
        })
        .collect();

    // Normalize by total to get proportions, then cosine similarity
    let a_total: f64 = a_vec.iter().sum::<f64>().max(1.0);
    let b_total: f64 = b_vec.iter().sum::<f64>().max(1.0);
    let a_norm: Vec<f64> = a_vec.iter().map(|v| v / a_total).collect();
    let b_norm: Vec<f64> = b_vec.iter().map(|v| v / b_total).collect();

    cosine_similarity(&a_norm, &b_norm)
}

fn count_sync_clusters(phases: &[f64]) -> usize {
    if phases.is_empty() {
        return 0;
    }

    let threshold = std::f64::consts::FRAC_PI_4;
    let mut assigned = vec![false; phases.len()];
    let mut clusters = 0;

    for i in 0..phases.len() {
        if assigned[i] {
            continue;
        }
        clusters += 1;
        assigned[i] = true;
        for j in (i + 1)..phases.len() {
            if !assigned[j] {
                let diff = (phases[i] - phases[j]).abs();
                let diff = diff.min(2.0 * std::f64::consts::PI - diff);
                if diff < threshold {
                    assigned[j] = true;
                }
            }
        }
    }

    clusters
}

fn compute_depth_histogram(observations: &[codex_parse::CodeObservation]) -> Vec<f64> {
    if observations.is_empty() {
        return vec![];
    }
    let max_depth = observations.iter().map(|o| o.depth).max().unwrap_or(0);
    let mut counts = vec![0u32; max_depth as usize + 1];
    for obs in observations {
        counts[obs.depth as usize] += 1;
    }
    // Normalize to probability distribution (scale-independent across languages)
    let total = observations.len() as f64;
    counts.iter().map(|&c| c as f64 / total).collect()
}

fn compute_kind_distribution(
    observations: &[codex_parse::CodeObservation],
) -> Vec<(NodeKind, u32)> {
    let mut counts: std::collections::HashMap<String, (NodeKind, u32)> =
        std::collections::HashMap::new();
    for obs in observations {
        let key = format!("{:?}", obs.kind);
        let entry = counts.entry(key).or_insert((obs.kind.clone(), 0));
        entry.1 += 1;
    }
    let mut result: Vec<(NodeKind, u32)> = counts.into_values().collect();
    result.sort_by(|a, b| b.1.cmp(&a.1));
    result
}

fn compute_call_density(observations: &[codex_parse::CodeObservation]) -> f64 {
    let functions = observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::Function))
        .count();
    let calls = observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::CallExpression))
        .count();

    if functions <= 1 {
        return 0.0;
    }

    let possible = functions * (functions - 1);
    if possible == 0 {
        0.0
    } else {
        (calls as f64 / possible as f64).min(1.0)
    }
}

fn compute_cyclomatic_complexity(observations: &[codex_parse::CodeObservation]) -> u32 {
    let decisions = observations
        .iter()
        .filter(|o| {
            matches!(
                o.kind,
                NodeKind::IfStatement
                    | NodeKind::ForLoop
                    | NodeKind::WhileLoop
                    | NodeKind::MatchSwitch
                    | NodeKind::TryCatch
            )
        })
        .count();

    (1 + decisions) as u32
}

fn compute_structural_volume(observations: &[codex_parse::CodeObservation]) -> f64 {
    let n = observations.len() as f64;
    if n <= 1.0 {
        return 0.0;
    }

    let operators = observations
        .iter()
        .filter(|o| {
            matches!(
                o.kind,
                NodeKind::IfStatement
                    | NodeKind::ForLoop
                    | NodeKind::WhileLoop
                    | NodeKind::Assignment
                    | NodeKind::CallExpression
                    | NodeKind::ReturnStatement
                    | NodeKind::MatchSwitch
            )
        })
        .count() as f64;

    let operands = observations
        .iter()
        .filter(|o| {
            matches!(
                o.kind,
                NodeKind::Literal | NodeKind::Parameter | NodeKind::FieldAccess
            )
        })
        .count() as f64;

    let vocabulary = operators.max(1.0) + operands.max(1.0);
    let length = operators + operands;

    length * vocabulary.log2()
}

// ── Tests ────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_topology_from_source() {
        let source = r#"
def fibonacci(n):
    if n <= 1:
        return n
    return fibonacci(n - 1) + fibonacci(n - 2)
"#;
        let topo = topology_from_source(source, "python", &TopoConfig::default()).unwrap();
        assert!(!topo.spectral_signature.is_empty());
        assert!(topo.cyclomatic_complexity >= 1);
    }

    #[test]
    fn test_similarity_identical() {
        let source = "def foo():\n    x = 1\n    return x\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "python", &config).unwrap();
        let sim = topology_similarity(&topo, &topo);
        assert!(
            sim > 0.99,
            "identical topology similarity should be ~1.0, got {}",
            sim
        );
    }

    #[test]
    fn test_similarity_symmetric() {
        let py = "def foo():\n    if True:\n        return 1\n    return 0\n";
        let rs = "fn foo() -> i32 {\n    if true {\n        return 1;\n    }\n    0\n}\n";
        let config = TopoConfig::default();
        let topo_py = topology_from_source(py, "python", &config).unwrap();
        let topo_rs = topology_from_source(rs, "rust", &config).unwrap();
        let sim_ab = topology_similarity(&topo_py, &topo_rs);
        let sim_ba = topology_similarity(&topo_rs, &topo_py);
        assert!(
            (sim_ab - sim_ba).abs() < 1e-10,
            "similarity should be symmetric: {} vs {}",
            sim_ab,
            sim_ba
        );
    }

    #[test]
    fn test_betti_numbers() {
        let source = "def foo():\n    pass\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "python", &config).unwrap();
        assert_eq!(topo.betti.len(), 3);
    }

    #[test]
    fn test_depth_histogram() {
        let source = "def foo():\n    if True:\n        pass\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "python", &config).unwrap();
        assert!(!topo.depth_histogram.is_empty());
        // Normalized: first bucket should be > 0 and entire histogram should sum to ~1.0
        assert!(topo.depth_histogram[0] > 0.0, "depth 0 bucket should be non-zero");
        let sum: f64 = topo.depth_histogram.iter().sum();
        assert!((sum - 1.0).abs() < 1e-9, "depth histogram should sum to 1.0, got {}", sum);
    }

    #[test]
    fn test_cosine_similarity() {
        assert!((cosine_similarity(&[1.0, 0.0], &[1.0, 0.0]) - 1.0).abs() < 1e-10);
        assert!((cosine_similarity(&[1.0, 0.0], &[0.0, 1.0])).abs() < 1e-10);
        assert!((cosine_similarity(&[], &[]) - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_cyclomatic_complexity() {
        let source = "def foo():\n    if True:\n        for x in []:\n            while True:\n                pass\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "python", &config).unwrap();
        // 1 + 3 decisions (if, for, while)
        assert!(topo.cyclomatic_complexity >= 4, "cc should be >= 4, got {}", topo.cyclomatic_complexity);
    }

    #[test]
    fn test_structural_volume() {
        let source = "def foo(x):\n    y = x + 1\n    if y > 0:\n        return y\n    return 0\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "python", &config).unwrap();
        assert!(topo.structural_volume > 0.0, "volume should be positive");
    }

    #[test]
    fn test_kind_distribution() {
        let source = "def foo():\n    pass\ndef bar():\n    pass\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "python", &config).unwrap();
        assert!(!topo.kind_distribution.is_empty());
    }

    #[test]
    fn test_topology_rust() {
        let source = "fn main() {\n    let x = 42;\n    println!(\"{}\", x);\n}\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "rust", &config).unwrap();
        assert!(!topo.spectral_signature.is_empty());
        assert!(topo.betti.len() == 3);
    }

    #[test]
    fn test_topology_javascript() {
        let source = "function hello() {\n    console.log('hi');\n}\n";
        let config = TopoConfig::default();
        let topo = topology_from_source(source, "javascript", &config).unwrap();
        assert!(!topo.spectral_signature.is_empty());
    }

    #[test]
    fn test_betti_similarity() {
        assert!((betti_similarity(&[1, 0, 0], &[1, 0, 0]) - 1.0).abs() < 1e-10);
        assert!(betti_similarity(&[1, 0, 0], &[5, 3, 2]) < 1.0);
    }

    #[test]
    fn test_cross_language_similarity_positive() {
        let py = "def fib(n):\n    if n <= 1:\n        return n\n    return fib(n-1) + fib(n-2)\n";
        let js = "function fib(n) {\n    if (n <= 1) return n;\n    return fib(n-1) + fib(n-2);\n}\n";
        let config = TopoConfig::default();
        let py_topo = topology_from_source(py, "python", &config).unwrap();
        let js_topo = topology_from_source(js, "javascript", &config).unwrap();
        let sim = topology_similarity(&py_topo, &js_topo);
        assert!(sim > 0.60, "cross-language similarity should be > 0.60, got {}", sim);
    }
}

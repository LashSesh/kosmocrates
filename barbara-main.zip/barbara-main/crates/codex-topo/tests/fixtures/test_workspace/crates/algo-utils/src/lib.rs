//! Shared utilities for algorithm crates.

/// Return the minimum of two values.
pub fn min_val(a: i64, b: i64) -> i64 {
    if a < b { a } else { b }
}

/// Return the maximum of two values.
pub fn max_val(a: i64, b: i64) -> i64 {
    if a > b { a } else { b }
}

/// Clamp a value to [lo, hi].
pub fn clamp(val: i64, lo: i64, hi: i64) -> i64 {
    if val < lo {
        lo
    } else if val > hi {
        hi
    } else {
        val
    }
}

/// Check if a number is prime.
pub fn is_prime(n: u64) -> bool {
    if n < 2 {
        return false;
    }
    if n == 2 {
        return true;
    }
    if n % 2 == 0 {
        return false;
    }
    let mut i = 3u64;
    while i * i <= n {
        if n % i == 0 {
            return false;
        }
        i += 2;
    }
    true
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_min_max() {
        assert_eq!(min_val(3, 7), 3);
        assert_eq!(max_val(3, 7), 7);
    }

    #[test]
    fn test_clamp() {
        assert_eq!(clamp(5, 0, 10), 5);
        assert_eq!(clamp(-5, 0, 10), 0);
        assert_eq!(clamp(15, 0, 10), 10);
    }

    #[test]
    fn test_is_prime() {
        assert!(is_prime(2));
        assert!(is_prime(17));
        assert!(!is_prime(1));
        assert!(!is_prime(4));
    }
}

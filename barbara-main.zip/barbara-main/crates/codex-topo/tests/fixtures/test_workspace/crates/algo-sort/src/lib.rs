//! Sorting algorithms: comparison-based.

/// Sort a slice in-place using bubble sort.
pub fn bubble_sort(arr: &mut Vec<i64>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j] > arr[j + 1] {
                arr.swap(j, j + 1);
            }
        }
    }
}

/// Sort a slice using merge sort (returns new sorted vec).
pub fn merge_sort(arr: &[i64]) -> Vec<i64> {
    if arr.len() <= 1 {
        return arr.to_vec();
    }
    let mid = arr.len() / 2;
    let left = merge_sort(&arr[..mid]);
    let right = merge_sort(&arr[mid..]);
    merge(left, right)
}

fn merge(left: Vec<i64>, right: Vec<i64>) -> Vec<i64> {
    let mut result = Vec::with_capacity(left.len() + right.len());
    let mut i = 0;
    let mut j = 0;
    while i < left.len() && j < right.len() {
        if left[i] <= right[j] {
            result.push(left[i]);
            i += 1;
        } else {
            result.push(right[j]);
            j += 1;
        }
    }
    result.extend_from_slice(&left[i..]);
    result.extend_from_slice(&right[j..]);
    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_bubble_sort() {
        let mut arr = vec![5, 3, 1, 4, 2];
        bubble_sort(&mut arr);
        assert_eq!(arr, vec![1, 2, 3, 4, 5]);
    }

    #[test]
    fn test_merge_sort() {
        let arr = vec![5, 3, 1, 4, 2];
        assert_eq!(merge_sort(&arr), vec![1, 2, 3, 4, 5]);
    }

    #[test]
    fn test_merge_sort_empty() {
        assert_eq!(merge_sort(&[]), vec![]);
    }
}

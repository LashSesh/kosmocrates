//! Workspace parsing integration tests.
//!
//! Uses the 3-crate test fixture at tests/fixtures/test_workspace/.

use std::path::PathBuf;

use codex_topo::{analyze_crate_relationships, parse_workspace};

fn fixture_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("tests/fixtures/test_workspace")
}

// ── Workspace file discovery ──────────────────────────────────────────────────

#[test]
fn parse_workspace_finds_rs_files() {
    let ws = parse_workspace(&fixture_root());
    // 3 crates × 1 lib.rs each = 3 files minimum.
    assert!(
        ws.stats.total_files >= 3,
        "Expected ≥3 .rs files, found {}",
        ws.stats.total_files
    );
}

#[test]
fn parse_workspace_detects_three_crates() {
    let ws = parse_workspace(&fixture_root());
    assert_eq!(
        ws.stats.total_crates, 3,
        "Expected 3 crates (algo-core, algo-sort, algo-utils), found {}",
        ws.stats.total_crates
    );
}

#[test]
fn parse_workspace_detects_correct_crate_names() {
    let ws = parse_workspace(&fixture_root());
    let names: Vec<&str> = ws
        .crate_topologies
        .iter()
        .map(|c| c.name.as_str())
        .collect();
    assert!(names.contains(&"algo-core"), "Expected 'algo-core', got: {:?}", names);
    assert!(names.contains(&"algo-sort"), "Expected 'algo-sort', got: {:?}", names);
    assert!(names.contains(&"algo-utils"), "Expected 'algo-utils', got: {:?}", names);
}

#[test]
fn parse_workspace_skips_target_directory() {
    // Even if a target/ dir exists (it won't in CI), it should be excluded.
    // We test this by checking no file path contains "/target/".
    let ws = parse_workspace(&fixture_root());
    for file in &ws.files {
        assert!(
            !file.relative_path.contains("/target/"),
            "Should skip target/ but found: {}",
            file.relative_path
        );
    }
}

#[test]
fn parse_workspace_computes_file_topologies() {
    let ws = parse_workspace(&fixture_root());
    assert!(ws.files.len() >= 3, "Expected ≥3 FileAnalysis entries");
    for file in &ws.files {
        // Every file should have a non-trivial topology.
        assert!(
            file.total_nodes > 0,
            "FileAnalysis for {} has 0 nodes",
            file.relative_path
        );
        assert!(
            !file.topology.spectral_signature.is_empty(),
            "FileAnalysis for {} has empty spectral signature",
            file.relative_path
        );
    }
}

#[test]
fn parse_workspace_crate_topologies_count() {
    let ws = parse_workspace(&fixture_root());
    assert_eq!(
        ws.crate_topologies.len(), 3,
        "Expected 3 CrateTopology entries, got {}",
        ws.crate_topologies.len()
    );
}

#[test]
fn workspace_stats_correct() {
    let ws = parse_workspace(&fixture_root());
    assert_eq!(ws.stats.total_crates, 3);
    assert!(ws.stats.total_files >= 3);
    assert!(ws.stats.total_loc > 0, "total_loc should be > 0");
    assert!(ws.stats.total_functions > 0, "total_functions should be > 0");
}

// ── Crate relationship analysis ───────────────────────────────────────────────

#[test]
fn analyze_crate_relationships_produces_similarity_matrix() {
    let ws = parse_workspace(&fixture_root());
    let report = analyze_crate_relationships(&ws);
    // 3 crates → 3 pairs (C(3,2) = 3).
    assert_eq!(
        report.similarity_matrix.len(), 3,
        "Expected 3 crate pairs, got {}",
        report.similarity_matrix.len()
    );
}

#[test]
fn similarity_matrix_values_in_range() {
    let ws = parse_workspace(&fixture_root());
    let report = analyze_crate_relationships(&ws);
    for (a, b, sim) in &report.similarity_matrix {
        assert!(
            *sim >= 0.0 && *sim <= 1.0,
            "Similarity {} ↔ {} = {} is out of range [0,1]",
            a, b, sim
        );
    }
}

#[test]
fn similar_crates_form_clusters() {
    let ws = parse_workspace(&fixture_root());
    let report = analyze_crate_relationships(&ws);
    // algo-core (recursive + iterative) and algo-sort (iterative) should
    // have similarity > 0.50 (both have functions + control flow).
    let algo_core_sort = report
        .similarity_matrix
        .iter()
        .find(|(a, b, _)| {
            (a == "algo-core" && b == "algo-sort") || (a == "algo-sort" && b == "algo-core")
        });
    if let Some((_, _, sim)) = algo_core_sort {
        println!("algo-core ↔ algo-sort similarity: {:.4}", sim);
        // Both have iteration + conditionals — should be reasonably similar.
        assert!(*sim > 0.40, "Expected algo-core ↔ algo-sort > 0.40, got {:.4}", sim);
    }
}

#[test]
fn architectural_layers_non_empty() {
    let ws = parse_workspace(&fixture_root());
    let report = analyze_crate_relationships(&ws);
    // 3 crates → at least 1 layer.
    assert!(
        !report.architectural_layers.is_empty(),
        "Expected at least 1 architectural layer"
    );
    // All crates should appear in some layer.
    let total_in_layers: usize = report.architectural_layers.iter().map(|l| l.len()).sum();
    assert_eq!(
        total_in_layers,
        ws.crate_topologies.len(),
        "All {} crates should appear in layers, but only {} do",
        ws.crate_topologies.len(),
        total_in_layers
    );
}

//! Die Schmiede CLI — Constraint-Based Programming Language Generation

use clap::{Parser, Subcommand};
use std::path::PathBuf;

#[derive(Parser)]
#[command(name = "schmiede", about = "Die Schmiede — generate programming languages from constraints")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Generate a language from constraints.
    Forge {
        /// Path to constraint TOML file.
        #[arg(short, long)]
        constraints: Option<PathBuf>,
        /// Use a built-in preset.
        #[arg(short, long)]
        preset: Option<String>,
        /// Output directory for the generated compiler.
        #[arg(short, long)]
        output: PathBuf,
        /// Verify after generation.
        #[arg(long)]
        verify: bool,
    },
    /// Validate constraints only (no generation).
    Check {
        /// Path to constraint TOML file.
        #[arg(short, long)]
        constraints: PathBuf,
    },
    /// Show degrees-of-freedom analysis.
    Analyze {
        /// Path to constraint TOML file.
        #[arg(short, long)]
        constraints: PathBuf,
    },
    /// List available presets.
    Presets,
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Forge { constraints, preset, output, verify } => {
            let c = if let Some(preset_name) = preset {
                load_preset(&preset_name)
            } else if let Some(path) = constraints {
                match schmiede_constraints::load_constraints(&path) {
                    Ok(c) => c,
                    Err(e) => {
                        eprintln!("Error loading constraints: {}", e);
                        std::process::exit(1);
                    }
                }
            } else {
                eprintln!("Either --constraints or --preset is required");
                std::process::exit(1);
            };

            // Check for conflicts
            let conflicts = schmiede_constraints::detect_conflicts(&c);
            let errors: Vec<_> = conflicts.iter()
                .filter(|c| c.severity == schmiede_constraints::ConflictSeverity::Error)
                .collect();
            if !errors.is_empty() {
                eprintln!("Constraint conflicts detected:");
                for err in &errors {
                    eprintln!("  ERROR: {} vs {} — {}", err.constraint_a, err.constraint_b, err.reason);
                }
                std::process::exit(1);
            }
            for warning in conflicts.iter().filter(|c| c.severity == schmiede_constraints::ConflictSeverity::Warning) {
                eprintln!("  WARNING: {} vs {} — {}", warning.constraint_a, warning.constraint_b, warning.reason);
            }

            // Pipeline
            let dof = schmiede_constraints::compute_dof(&c);
            let topology = match schmiede_topology::constraints_to_topology(&c, &dof) {
                Ok(t) => t,
                Err(e) => {
                    eprintln!("Topology error: {}", e);
                    std::process::exit(1);
                }
            };
            let grammar = match schmiede_grammar::generate_grammar(&topology, &c) {
                Ok(g) => g,
                Err(e) => {
                    eprintln!("Grammar error: {}", e);
                    std::process::exit(1);
                }
            };

            let config = schmiede_emit::EmitConfig { output_dir: output };
            match schmiede_emit::emit_from_pipeline(&config, &c, &topology, &grammar) {
                Ok(result) => {
                    println!("Generated compiler at: {}", result.output_dir.display());
                    println!("Files written: {}", result.files_written.len());
                    println!("Spec: {}", result.spec_path.display());
                    println!("Proof: {}", result.proof_path.display());

                    if verify {
                        println!("\nVerifying...");
                        match schmiede_verify::verify(&result.output_dir, &c) {
                            Ok(report) => {
                                println!("Compiler builds: {}", report.compiler_builds);
                                for check in &report.constraint_checks {
                                    let status = if check.satisfied { "PASS" } else { "FAIL" };
                                    println!("  [{}] {} — {}", status, check.constraint, check.evidence);
                                }
                                if report.all_satisfied {
                                    println!("\nAll constraints satisfied!");
                                } else {
                                    println!("\nSome constraints not satisfied.");
                                    std::process::exit(1);
                                }
                            }
                            Err(e) => {
                                eprintln!("Verification error: {}", e);
                                std::process::exit(1);
                            }
                        }
                    }
                }
                Err(e) => {
                    eprintln!("Emit error: {}", e);
                    std::process::exit(1);
                }
            }
        }
        Commands::Check { constraints: path } => {
            let c = match schmiede_constraints::load_constraints(&path) {
                Ok(c) => c,
                Err(e) => {
                    eprintln!("Error: {}", e);
                    std::process::exit(1);
                }
            };
            let conflicts = schmiede_constraints::detect_conflicts(&c);
            if conflicts.is_empty() {
                println!("No conflicts detected. Constraints are consistent.");
            } else {
                for conflict in &conflicts {
                    let severity = match conflict.severity {
                        schmiede_constraints::ConflictSeverity::Error => "ERROR",
                        schmiede_constraints::ConflictSeverity::Warning => "WARNING",
                    };
                    println!("[{}] {} vs {} — {}", severity, conflict.constraint_a, conflict.constraint_b, conflict.reason);
                }
            }
        }
        Commands::Analyze { constraints: path } => {
            let c = match schmiede_constraints::load_constraints(&path) {
                Ok(c) => c,
                Err(e) => {
                    eprintln!("Error: {}", e);
                    std::process::exit(1);
                }
            };
            let dof = schmiede_constraints::compute_dof(&c);
            println!("Degrees of Freedom Analysis for '{}':", c.meta.name);
            println!("  Total constraints: {}", dof.total_constraints);
            println!("  Determined (DoF=0): {}", dof.determined);
            println!("  Underdetermined (DoF>0): {}", dof.underdetermined);
            println!("  Conflicts: {}", dof.conflicts);
            for entry in &dof.details {
                if entry.dof > 0 {
                    println!("  {} — DoF={}, choices: {:?}", entry.constraint, entry.dof, entry.choices);
                }
            }
        }
        Commands::Presets => {
            println!("Available presets:");
            println!("  embedded_safety   — Safety-critical embedded language for medical devices");
            println!("  web_scripting     — Dynamic scripting language for web applications");
            println!("  data_science      — Data processing language with array operations");
            println!("  systems_programming — Low-level systems language similar to Rust");
            println!("  education_swahili — Educational language with Swahili keywords");
            println!("  education_german  — Educational language with German keywords");
        }
    }
}

fn load_preset(name: &str) -> schmiede_constraints::LanguageConstraints {
    let toml = match name {
        "embedded_safety" => include_str!("../../../presets/embedded_safety.toml"),
        "education_swahili" => include_str!("../../../presets/education_swahili.toml"),
        "education_german" => include_str!("../../../presets/education_german.toml"),
        "web_scripting" => include_str!("../../../presets/web_scripting.toml"),
        "data_science" => include_str!("../../../presets/data_science.toml"),
        "systems_programming" => include_str!("../../../presets/systems_programming.toml"),
        _ => {
            eprintln!("Unknown preset: {}", name);
            eprintln!("Run 'schmiede presets' for a list.");
            std::process::exit(1);
        }
    };
    schmiede_constraints::parse_constraints(toml).unwrap_or_else(|e| {
        eprintln!("Error parsing preset {}: {}", name, e);
        std::process::exit(1);
    })
}

//! codex-learn — Cross-Language Pattern Accumulation
//!
//! Manages the learning lifecycle: observing programs, crystallizing
//! patterns, accumulating knowledge across sessions and languages,
//! and recognizing previously seen patterns.

pub mod export;
pub mod patterns;

pub use export::{
    crystal_to_exported, export_crystals, export_to_json, import_crystals,
    CallPattern, ExportedCrystal, PatternBlueprint, PatternInstance,
};
pub use patterns::{
    extract_function_subtrees, mine_function_patterns,
    FunctionInfo, FunctionInstance, FunctionPattern, FunctionPatternReport,
};

use std::path::Path;
use std::time::Instant;

use codex_parse::{CodeObservation, ParseError, ParseMetadata};
use codex_topo::{topology_similarity, CodeTopology, TopoConfig};
use pse_evidence::build_evidence_chain;
use pse_graph::PersistentGraph;
use pse_types::EvidenceChain;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};

// ── Core Types ───────────────────────────────────────────────────────

/// Content-addressed crystal identifier.
pub type CrystalId = String;

/// A language-independent code pattern, crystallized.
///
/// This is the fundamental unit of accumulated knowledge.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct CodeCrystal {
    /// Unique content-addressed identifier.
    pub id: CrystalId,
    /// Topological signature (language-independent).
    pub topology: CodeTopology,
    /// Human-readable pattern description.
    pub description: String,
    /// Pattern category.
    pub pattern_type: CodePatternType,
    /// Languages this pattern has been observed in.
    pub observed_languages: Vec<LanguageObservation>,
    /// Confidence score (from PSE cascade).
    pub confidence: f64,
    /// Resonance (from PSE Kuramoto).
    pub resonance: f64,
    /// Evidence chain.
    pub evidence: EvidenceChain,
    /// Creation timestamp.
    pub created_at: String,
}

/// Record of observing a pattern in a specific language.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LanguageObservation {
    /// Language identifier.
    pub language: String,
    /// Source file path.
    pub file_path: Option<String>,
    /// Number of AST observations.
    pub observation_count: usize,
    /// PSE tick when first seen.
    pub first_seen_tick: u64,
    /// Similarity to the crystal's canonical topology.
    pub topology_similarity: f64,
}

/// Pattern categories.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub enum CodePatternType {
    /// CRUD endpoint pattern.
    CRUDEndpoint,
    /// Data transformation pipeline.
    DataTransformPipeline,
    /// Error handling chain.
    ErrorHandlingChain,
    /// Recursive traversal.
    RecursiveTraversal,
    /// Iterative processing (loops).
    IterativeProcessing,
    /// Event loop pattern.
    EventLoop,
    /// Builder pattern.
    BuilderPattern,
    /// Observer pattern.
    ObserverPattern,
    /// Factory pattern.
    FactoryPattern,
    /// Strategy pattern.
    StrategyPattern,
    /// Singleton pattern.
    SingletonPattern,
    /// Map/filter/reduce chain.
    MapFilterReduce,
    /// Closure.
    Closure,
    /// Higher-order function.
    HigherOrderFunction,
    /// Async/await chain.
    AsyncAwaitChain,
    /// Channel communication.
    ChannelCommunication,
    /// Mutex guard.
    MutexGuard,
    /// File read/write.
    FileReadWrite,
    /// HTTP request.
    HttpRequest,
    /// Database query.
    DatabaseQuery,
    /// Serialization roundtrip.
    SerializationRoundtrip,
    /// Unknown pattern.
    Unknown { description: String },
}

// ── Pattern Engine ───────────────────────────────────────────────────

/// The main learning engine that accumulates patterns across languages.
pub struct CodexEngine {
    /// Known crystals (pattern memory).
    crystals: Vec<CodeCrystal>,
    /// Topology configuration.
    topo_config: TopoConfig,
    /// Similarity threshold for pattern matching.
    similarity_threshold: f64,
    /// Memory hit counter.
    memory_hits: u64,
    /// Memory miss counter.
    memory_misses: u64,
    /// Current PSE tick.
    current_tick: u64,
    /// PSE graph (accumulated observations).
    _graph: PersistentGraph,
}

impl CodexEngine {
    /// Create a new engine with default configuration.
    pub fn new() -> Self {
        Self {
            crystals: Vec::new(),
            topo_config: TopoConfig::default(),
            similarity_threshold: 0.88,
            memory_hits: 0,
            memory_misses: 0,
            current_tick: 0,
            _graph: PersistentGraph::new(),
        }
    }

    /// Create an engine with custom configuration.
    pub fn with_config(topo_config: TopoConfig, similarity_threshold: f64) -> Self {
        Self {
            crystals: Vec::new(),
            topo_config,
            similarity_threshold,
            memory_hits: 0,
            memory_misses: 0,
            current_tick: 0,
            _graph: PersistentGraph::new(),
        }
    }

    /// Observe a source code string and learn patterns from it.
    ///
    /// Returns the topology and whether a pattern was recognized (hit) or new (miss).
    pub fn observe_source(
        &mut self,
        source: &str,
        language: &str,
        file_path: Option<&str>,
    ) -> Result<ObserveResult, ParseError> {
        let start = Instant::now();

        // Parse
        let (observations, metadata) = codex_parse::parse_source(source, language)?;
        let graph = codex_parse::observations_to_graph(&observations);

        // Compute topology
        let topology =
            codex_topo::compute_code_topology(&graph, &observations, &self.topo_config);

        // Check pattern memory
        let match_result = self.find_matching_crystal(&topology);

        let result = match match_result {
            Some((idx, similarity)) => {
                // HIT: pattern already known
                self.memory_hits += 1;
                let crystal = &mut self.crystals[idx];
                crystal.observed_languages.push(LanguageObservation {
                    language: language.to_string(),
                    file_path: file_path.map(|s| s.to_string()),
                    observation_count: observations.len(),
                    first_seen_tick: self.current_tick,
                    topology_similarity: similarity,
                });
                ObserveResult {
                    topology,
                    metadata,
                    hit: true,
                    crystal_id: Some(crystal.id.clone()),
                    similarity: Some(similarity),
                    elapsed_us: start.elapsed().as_micros() as u64,
                }
            }
            None => {
                // MISS: novel pattern — crystallize
                self.memory_misses += 1;
                let crystal = self.crystallize(
                    &topology,
                    &observations,
                    language,
                    file_path,
                );
                let crystal_id = crystal.id.clone();
                self.crystals.push(crystal);
                ObserveResult {
                    topology,
                    metadata,
                    hit: false,
                    crystal_id: Some(crystal_id),
                    similarity: None,
                    elapsed_us: start.elapsed().as_micros() as u64,
                }
            }
        };

        self.current_tick += 1;
        Ok(result)
    }

    /// Observe a file from disk.
    pub fn observe_file(&mut self, path: &Path) -> Result<ObserveResult, ParseError> {
        let language = codex_parse::detect_language(path)
            .ok_or_else(|| ParseError::UnsupportedLanguage(path.display().to_string()))?;
        let source = std::fs::read_to_string(path)
            .map_err(ParseError::Io)?;
        self.observe_source(&source, &language, Some(&path.display().to_string()))
    }

    /// Get the number of crystallized patterns.
    pub fn crystal_count(&self) -> usize {
        self.crystals.len()
    }

    /// Get memory hit count.
    pub fn memory_hits(&self) -> u64 {
        self.memory_hits
    }

    /// Get memory miss count.
    pub fn memory_misses(&self) -> u64 {
        self.memory_misses
    }

    /// Get all crystals.
    pub fn crystals(&self) -> &[CodeCrystal] {
        &self.crystals
    }

    /// Get the similarity threshold.
    pub fn similarity_threshold(&self) -> f64 {
        self.similarity_threshold
    }

    /// Get the topo config.
    pub fn topo_config(&self) -> &TopoConfig {
        &self.topo_config
    }

    /// Get hit rate as fraction.
    pub fn hit_rate(&self) -> f64 {
        let total = self.memory_hits + self.memory_misses;
        if total == 0 {
            0.0
        } else {
            self.memory_hits as f64 / total as f64
        }
    }

    /// Find a crystal matching the given topology.
    fn find_matching_crystal(&self, topology: &CodeTopology) -> Option<(usize, f64)> {
        let mut best: Option<(usize, f64)> = None;
        for (idx, crystal) in self.crystals.iter().enumerate() {
            let sim = topology_similarity(&crystal.topology, topology);
            if sim >= self.similarity_threshold {
                match &best {
                    Some((_, best_sim)) if sim <= *best_sim => {}
                    _ => best = Some((idx, sim)),
                }
            }
        }
        best
    }

    /// Create a new crystal from a topology.
    fn crystallize(
        &self,
        topology: &CodeTopology,
        observations: &[CodeObservation],
        language: &str,
        file_path: Option<&str>,
    ) -> CodeCrystal {
        let pattern_type = classify_pattern(topology, observations);
        let description = describe_pattern(&pattern_type, topology);
        let confidence = compute_confidence(topology);
        let resonance = topology.kuramoto_order;

        // Build evidence chain
        let topo_bytes = serde_json::to_vec(topology).unwrap_or_default();
        let evidence = build_evidence_chain(&[topo_bytes]);

        // Content-addressed ID
        let id = compute_crystal_id(topology);

        CodeCrystal {
            id,
            topology: topology.clone(),
            description,
            pattern_type,
            observed_languages: vec![LanguageObservation {
                language: language.to_string(),
                file_path: file_path.map(|s| s.to_string()),
                observation_count: observations.len(),
                first_seen_tick: self.current_tick,
                topology_similarity: 1.0,
            }],
            confidence,
            resonance,
            evidence,
            created_at: chrono_now(),
        }
    }
}

impl Default for CodexEngine {
    fn default() -> Self {
        Self::new()
    }
}

// ── Observe Result ───────────────────────────────────────────────────

/// Result of observing a source file.
#[derive(Debug)]
pub struct ObserveResult {
    /// Computed topology.
    pub topology: CodeTopology,
    /// Parse metadata.
    pub metadata: ParseMetadata,
    /// Whether this was a memory hit (pattern already known).
    pub hit: bool,
    /// Crystal ID (existing or newly created).
    pub crystal_id: Option<CrystalId>,
    /// Similarity to matched crystal (if hit).
    pub similarity: Option<f64>,
    /// Time spent in microseconds.
    pub elapsed_us: u64,
}

// ── Pattern Classification ───────────────────────────────────────────

/// Classify a pattern from its topology and observations.
fn classify_pattern(
    topology: &CodeTopology,
    observations: &[CodeObservation],
) -> CodePatternType {
    use codex_parse::NodeKind;

    let has_recursion = {
        let func_names: Vec<_> = observations
            .iter()
            .filter(|o| matches!(o.kind, NodeKind::Function))
            .map(|o| &o.node_id)
            .collect();
        let call_count = observations
            .iter()
            .filter(|o| matches!(o.kind, NodeKind::CallExpression))
            .count();
        !func_names.is_empty() && call_count > func_names.len()
    };

    let has_loop = observations
        .iter()
        .any(|o| matches!(o.kind, NodeKind::ForLoop | NodeKind::WhileLoop));
    let has_try_catch = observations
        .iter()
        .any(|o| matches!(o.kind, NodeKind::TryCatch));
    let has_class = observations
        .iter()
        .any(|o| matches!(o.kind, NodeKind::Class));
    let func_count = observations
        .iter()
        .filter(|o| matches!(o.kind, NodeKind::Function))
        .count();
    let has_import = observations
        .iter()
        .any(|o| matches!(o.kind, NodeKind::Import));

    // Heuristic classification based on structural patterns
    if has_recursion && topology.cyclomatic_complexity <= 3 {
        CodePatternType::RecursiveTraversal
    } else if func_count >= 4 && has_try_catch {
        CodePatternType::CRUDEndpoint
    } else if has_try_catch && !has_class {
        CodePatternType::ErrorHandlingChain
    } else if has_loop
        && observations
            .iter()
            .filter(|o| matches!(o.kind, NodeKind::CallExpression))
            .count()
            > 3
    {
        CodePatternType::DataTransformPipeline
    } else if has_class && func_count >= 3 {
        CodePatternType::ObserverPattern
    } else if has_loop && !has_recursion {
        CodePatternType::IterativeProcessing
    } else if has_import && func_count >= 2 {
        CodePatternType::MapFilterReduce
    } else {
        CodePatternType::Unknown {
            description: format!(
                "funcs={}, cc={}, loops={}",
                func_count, topology.cyclomatic_complexity, has_loop
            ),
        }
    }
}

/// Generate a human-readable description for a pattern.
fn describe_pattern(pattern_type: &CodePatternType, topology: &CodeTopology) -> String {
    let base = match pattern_type {
        CodePatternType::RecursiveTraversal => "Recursive traversal pattern",
        CodePatternType::IterativeProcessing => "Iterative processing pattern",
        CodePatternType::CRUDEndpoint => "CRUD endpoint pattern",
        CodePatternType::ErrorHandlingChain => "Error handling chain",
        CodePatternType::DataTransformPipeline => "Data transformation pipeline",
        CodePatternType::ObserverPattern => "Observer pattern",
        CodePatternType::MapFilterReduce => "Map/filter/reduce chain",
        CodePatternType::FileReadWrite => "File I/O pattern",
        CodePatternType::HttpRequest => "HTTP request pattern",
        _ => "Code pattern",
    };
    format!(
        "{} (cc={}, depth={}, betti={:?})",
        base,
        topology.cyclomatic_complexity,
        topology.depth_histogram.len().saturating_sub(1),
        topology.betti
    )
}

/// Compute confidence score from topology.
fn compute_confidence(topology: &CodeTopology) -> f64 {
    // Higher confidence for more complex, well-structured code
    let cc_factor = (topology.cyclomatic_complexity as f64).min(10.0) / 10.0;
    let spectral_factor = if topology.spectral_gap > 0.01 {
        1.0
    } else {
        0.5
    };
    let kuramoto_factor = topology.kuramoto_order;

    (0.4 * cc_factor + 0.3 * spectral_factor + 0.3 * kuramoto_factor).clamp(0.0, 1.0)
}

/// Compute content-addressed crystal ID from topology.
fn compute_crystal_id(topology: &CodeTopology) -> CrystalId {
    let bytes = serde_json::to_vec(topology).unwrap_or_default();
    let mut hasher = Sha256::new();
    hasher.update(&bytes);
    let hash = hasher.finalize();
    format!("crystal-{}", hex::encode(&hash[..8]))
}

fn chrono_now() -> String {
    // Simple timestamp without chrono dependency
    "2026-03-23T00:00:00Z".to_string()
}

// Need hex encoding for crystal IDs
mod hex {
    pub fn encode(bytes: &[u8]) -> String {
        bytes.iter().map(|b| format!("{:02x}", b)).collect()
    }
}

// ── Tests ────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_engine_creation() {
        let engine = CodexEngine::new();
        assert_eq!(engine.crystal_count(), 0);
        assert_eq!(engine.memory_hits(), 0);
    }

    #[test]
    fn test_observe_source() {
        let mut engine = CodexEngine::new();
        let source = "def fibonacci(n):\n    if n <= 1:\n        return n\n    return fibonacci(n - 1) + fibonacci(n - 2)\n";
        let result = engine.observe_source(source, "python", None).unwrap();
        assert!(!result.hit);
        assert!(result.crystal_id.is_some());
        assert_eq!(engine.crystal_count(), 1);
    }

    #[test]
    fn test_memory_hit_same_program() {
        let mut engine = CodexEngine::new();
        let source = "def fibonacci(n):\n    if n <= 1:\n        return n\n    return fibonacci(n - 1) + fibonacci(n - 2)\n";

        let r1 = engine.observe_source(source, "python", None).unwrap();
        assert!(!r1.hit);

        let r2 = engine.observe_source(source, "python", None).unwrap();
        assert!(r2.hit, "second observation of same source should be a hit");
        assert_eq!(engine.memory_hits(), 1);
    }

    #[test]
    fn test_crystal_has_evidence() {
        let mut engine = CodexEngine::new();
        let source = "def foo():\n    return 42\n";
        engine.observe_source(source, "python", None).unwrap();
        let crystal = &engine.crystals()[0];
        assert!(!crystal.evidence.is_empty(), "crystal should have evidence chain");
        // Verify SHA-256 evidence chain
        for entry in &crystal.evidence {
            assert_ne!(entry.digest, [0u8; 32], "evidence digest should not be zero");
        }
    }

    #[test]
    fn test_pattern_classification() {
        let mut engine = CodexEngine::new();

        // Simple pattern — should classify to something
        let source = "def fib(n):\n    if n <= 1:\n        return n\n    return fib(n-1) + fib(n-2)\n";
        engine.observe_source(source, "python", None).unwrap();
        let crystal = &engine.crystals()[0];
        // Should have a pattern type assigned
        assert!(
            !crystal.description.is_empty(),
            "crystal should have a description"
        );
    }

    #[test]
    fn test_cross_language_recognition() {
        let mut engine = CodexEngine::new();

        // Observe Python fibonacci
        let py = "def fibonacci(n):\n    if n <= 1:\n        return n\n    return fibonacci(n - 1) + fibonacci(n - 2)\n";
        let r1 = engine.observe_source(py, "python", None).unwrap();
        assert!(!r1.hit);

        // Observe Rust fibonacci - should be recognized
        let rs = "fn fibonacci(n: u64) -> u64 {\n    if n <= 1 {\n        return n;\n    }\n    fibonacci(n - 1) + fibonacci(n - 2)\n}\n";
        let r2 = engine.observe_source(rs, "rust", None).unwrap();

        // It should either be a hit or at least produce a crystal
        assert!(r2.crystal_id.is_some());
    }

    #[test]
    fn test_language_observation_tracking() {
        let mut engine = CodexEngine::new();
        let source = "def foo():\n    return 42\n";

        engine.observe_source(source, "python", Some("test.py")).unwrap();
        engine.observe_source(source, "python", Some("test2.py")).unwrap();

        let crystal = &engine.crystals()[0];
        assert!(
            crystal.observed_languages.len() >= 1,
            "should track language observations"
        );
    }

    #[test]
    fn test_hit_rate() {
        let mut engine = CodexEngine::new();
        assert_eq!(engine.hit_rate(), 0.0);

        let source = "def foo():\n    return 42\n";
        engine.observe_source(source, "python", None).unwrap();
        engine.observe_source(source, "python", None).unwrap();

        assert!(engine.hit_rate() > 0.0);
    }
}

//! Crystal export format for ISLS consumption.
//!
//! `ExportedCrystal` is a self-contained, JSON-serializable representation of a
//! `CodeCrystal`. A consumer of the JSON file does not need Barbara installed.
//!
//! ## ISLS Consumption Spec
//!
//! 1. Parse `isls_crystals.json` → `Vec<ExportedCrystal>`
//! 2. For each crystal, extract `PatternBlueprint`
//! 3. Register blueprint in isls-registry
//! 4. Before LLM oracle call: check if requested component matches a known blueprint
//!    (compare structural requirements → `control_flow`, `cyclomatic_range`, `call_pattern`)
//! 5. If match: constrain LLM prompt with blueprint
//! 6. After generation: parse output, compute topology, verify against blueprint
//! 7. If topology mismatch > threshold: reject and retry
//!
//! This creates the feedback loop:
//! ```text
//! ISLS generates code
//!   → Barbara reads code, crystallizes patterns
//!   → crystals exported (this module)
//!   → ISLS imports crystals as blueprints
//!   → ISLS generates better code (guided by blueprints)
//!   → Barbara reads better code, finds refined patterns
//!   → ...
//! ```

use serde::{Deserialize, Serialize};

use crate::{CodeCrystal, CodePatternType};

// ── Public Types ─────────────────────────────────────────────────────────────

/// A crystal exported for consumption by another system (e.g., ISLS).
/// JSON-serializable, self-contained, verifiable.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ExportedCrystal {
    /// Crystal identity.
    pub id: String,
    pub created_at: String,
    /// Source system that produced this crystal.
    pub source: String,

    /// Topological signature (the universal, language-independent part).
    pub spectral_signature: Vec<f64>,
    pub betti_numbers: Vec<usize>,
    pub kuramoto_order: f64,
    pub fiedler_value: f64,
    pub spectral_gap: f64,

    /// Pattern classification.
    pub pattern_type: String,
    pub description: String,
    pub confidence: f64,

    /// Instances where this pattern was observed.
    pub instances: Vec<PatternInstance>,

    /// Evidence chain — SHA-256 hex strings.
    pub evidence_chain: Vec<String>,
    /// Content hash of this exported crystal for integrity checking.
    pub content_hash: String,

    /// Structural blueprint for guided code generation.
    pub blueprint: PatternBlueprint,
}

/// A structural blueprint that ISLS can use to guide code generation.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PatternBlueprint {
    /// Ordered control flow node kinds (language-independent).
    pub control_flow: Vec<String>,
    /// Node kind distribution (normalized ratios).
    pub kind_ratios: Vec<(String, f64)>,
    /// Expected nesting depth range: (min, max).
    pub depth_range: (u32, u32),
    /// Expected function count range: (min, max).
    pub function_count_range: (usize, usize),
    /// Call graph shape.
    pub call_pattern: CallPattern,
    /// Cyclomatic complexity range: (min, max).
    pub cyclomatic_range: (u32, u32),
}

/// Where a pattern was observed.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct PatternInstance {
    pub file: String,
    pub crate_name: String,
    pub language: String,
    pub observation_count: usize,
}

/// Shape of the call graph for a pattern.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
#[serde(rename_all = "snake_case")]
pub enum CallPattern {
    /// A → B → C (linear chain, no branching).
    Linear,
    /// A → {B, C, D} (one caller, many callees).
    Tree,
    /// A → A (function calls itself).
    Recursive,
    /// Many → A → many (hub function).
    Hub,
    /// A → B → C → D (deep pipeline).
    Pipeline,
}

// ── Conversion ────────────────────────────────────────────────────────────────

/// Convert a `CodeCrystal` to an `ExportedCrystal`.
pub fn crystal_to_exported(crystal: &CodeCrystal) -> ExportedCrystal {
    let topo = &crystal.topology;

    let spectral_signature = topo.spectral_signature.clone();
    let betti_numbers = topo.betti.clone();
    let kuramoto_order = topo.kuramoto_order;
    let fiedler_value = topo.fiedler_value;
    let spectral_gap = topo.spectral_gap;

    let pattern_type = pattern_type_to_string(&crystal.pattern_type);
    let description = crystal.description.clone();
    let confidence = crystal.confidence;

    // Build instances from language observations.
    let instances: Vec<PatternInstance> = crystal
        .observed_languages
        .iter()
        .map(|lo| PatternInstance {
            file: lo.file_path.clone().unwrap_or_default(),
            crate_name: extract_crate_from_path(
                lo.file_path.as_deref().unwrap_or(""),
            ),
            language: lo.language.clone(),
            observation_count: lo.observation_count,
        })
        .collect();

    // Evidence chain: convert [u8; 32] hashes to hex strings.
    let evidence_chain: Vec<String> = crystal
        .evidence
        .iter()
        .map(|entry| hex_encode(&entry.digest))
        .collect();

    // Build blueprint.
    let blueprint = build_blueprint(crystal);

    // Content hash: SHA-256 of the spectral signature + pattern type.
    let content_hash = compute_content_hash(&spectral_signature, &pattern_type);

    ExportedCrystal {
        id: crystal.id.clone(),
        created_at: crystal.created_at.clone(),
        source: "barbara-v0.2.0".to_string(),
        spectral_signature,
        betti_numbers,
        kuramoto_order,
        fiedler_value,
        spectral_gap,
        pattern_type,
        description,
        confidence,
        instances,
        evidence_chain,
        content_hash,
        blueprint,
    }
}

/// Export a slice of crystals to a `Vec<ExportedCrystal>`.
pub fn export_crystals(crystals: &[CodeCrystal]) -> Vec<ExportedCrystal> {
    crystals.iter().map(crystal_to_exported).collect()
}

/// Export crystals to a pretty-printed JSON string.
pub fn export_to_json(crystals: &[CodeCrystal]) -> Result<String, serde_json::Error> {
    let exported = export_crystals(crystals);
    serde_json::to_string_pretty(&exported)
}

/// Import crystals from a JSON string.
pub fn import_crystals(json: &str) -> Result<Vec<ExportedCrystal>, serde_json::Error> {
    serde_json::from_str(json)
}

// ── Internal Helpers ──────────────────────────────────────────────────────────

fn build_blueprint(crystal: &CodeCrystal) -> PatternBlueprint {
    let topo = &crystal.topology;

    // Control flow sequence → Vec<String>.
    let control_flow: Vec<String> = topo
        .control_flow_sequence
        .iter()
        .map(|k| format!("{:?}", k))
        .collect();

    // Kind ratios: normalize counts to fractions.
    let total: u32 = topo.kind_distribution.iter().map(|(_, c)| c).sum();
    let kind_ratios: Vec<(String, f64)> = topo
        .kind_distribution
        .iter()
        .take(10)
        .map(|(kind, count)| {
            let ratio = if total > 0 { *count as f64 / total as f64 } else { 0.0 };
            (format!("{:?}", kind), ratio)
        })
        .collect();

    // Depth range: first non-zero bucket to last non-zero bucket.
    let first_nonzero = topo
        .depth_histogram
        .iter()
        .position(|&v| v > 0.0)
        .unwrap_or(0) as u32;
    let last_nonzero = topo
        .depth_histogram
        .iter()
        .rposition(|&v| v > 0.0)
        .unwrap_or(0) as u32;
    let depth_range = (first_nonzero, last_nonzero);

    // Function count range: derived from kind_distribution.
    let func_count = topo
        .kind_distribution
        .iter()
        .find(|(k, _)| format!("{:?}", k) == "Function")
        .map(|(_, c)| *c as usize)
        .unwrap_or(0);
    let function_count_range = (func_count.saturating_sub(2), func_count + 2);

    // Cyclomatic complexity range.
    let cc = topo.cyclomatic_complexity;
    let cyclomatic_range = (cc.saturating_sub(3), cc + 3);

    // Call pattern heuristic.
    let call_pattern = classify_call_pattern(topo, crystal);

    PatternBlueprint {
        control_flow,
        kind_ratios,
        depth_range,
        function_count_range,
        call_pattern,
        cyclomatic_range,
    }
}

fn classify_call_pattern(
    topo: &codex_topo::CodeTopology,
    _crystal: &CodeCrystal,
) -> CallPattern {
    // Check for recursive pattern in control flow sequence.
    use codex_parse::NodeKind;

    let cf = &topo.control_flow_sequence;
    let has_recursive = cf.windows(2).any(|w| {
        matches!(&w[0], NodeKind::Function) && matches!(&w[1], NodeKind::CallExpression)
    });

    let call_count = topo
        .kind_distribution
        .iter()
        .find(|(k, _)| matches!(k, NodeKind::CallExpression))
        .map(|(_, c)| *c)
        .unwrap_or(0);

    let func_count = topo
        .kind_distribution
        .iter()
        .find(|(k, _)| matches!(k, NodeKind::Function))
        .map(|(_, c)| *c)
        .unwrap_or(1);

    if has_recursive {
        CallPattern::Recursive
    } else if topo.structural_volume > 500.0 && call_count > 20 {
        CallPattern::Hub
    } else if call_count > func_count * 4 {
        CallPattern::Pipeline
    } else if call_count > func_count * 2 {
        CallPattern::Tree
    } else {
        CallPattern::Linear
    }
}

fn pattern_type_to_string(pt: &CodePatternType) -> String {
    match pt {
        CodePatternType::CRUDEndpoint => "crud_endpoint",
        CodePatternType::DataTransformPipeline => "data_transform_pipeline",
        CodePatternType::ErrorHandlingChain => "error_handling_chain",
        CodePatternType::RecursiveTraversal => "recursive_traversal",
        CodePatternType::IterativeProcessing => "iterative_processing",
        CodePatternType::EventLoop => "event_loop",
        CodePatternType::BuilderPattern => "builder_pattern",
        CodePatternType::ObserverPattern => "observer_pattern",
        CodePatternType::FactoryPattern => "factory_pattern",
        CodePatternType::StrategyPattern => "strategy_pattern",
        CodePatternType::SingletonPattern => "singleton_pattern",
        CodePatternType::MapFilterReduce => "map_filter_reduce",
        CodePatternType::Closure => "closure",
        CodePatternType::HigherOrderFunction => "higher_order_function",
        CodePatternType::AsyncAwaitChain => "async_await_chain",
        CodePatternType::ChannelCommunication => "channel_communication",
        CodePatternType::MutexGuard => "mutex_guard",
        CodePatternType::FileReadWrite => "file_read_write",
        CodePatternType::HttpRequest => "http_request",
        CodePatternType::DatabaseQuery => "database_query",
        CodePatternType::SerializationRoundtrip => "serialization_roundtrip",
        CodePatternType::Unknown { description } => {
            return format!("unknown:{}", description);
        }
    }
    .to_string()
}

fn extract_crate_from_path(path: &str) -> String {
    if let Some(pos) = path.find("crates/") {
        let after = &path[pos + 7..];
        if let Some(slash) = after.find('/') {
            return after[..slash].to_string();
        }
    }
    let parts: Vec<&str> = path.split('/').collect();
    if parts.len() >= 2 {
        parts[parts.len() - 2].to_string()
    } else {
        "unknown".to_string()
    }
}

fn hex_encode(bytes: &[u8]) -> String {
    bytes.iter().map(|b| format!("{:02x}", b)).collect()
}

fn compute_content_hash(spectral: &[f64], pattern_type: &str) -> String {
    use sha2::{Digest, Sha256};
    let mut hasher = Sha256::new();
    for v in spectral {
        hasher.update(v.to_le_bytes());
    }
    hasher.update(pattern_type.as_bytes());
    let result = hasher.finalize();
    hex_encode(&result[..8])
}

// ── Tests ─────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn import_invalid_json_returns_error() {
        let result = import_crystals("not valid json");
        assert!(result.is_err(), "Expected error for invalid JSON");
    }

    #[test]
    fn import_valid_empty_array() {
        let result = import_crystals("[]");
        assert!(result.is_ok());
        assert_eq!(result.unwrap().len(), 0);
    }

    #[test]
    fn call_pattern_debug_values() {
        // Smoke test: all CallPattern variants serialize without panic.
        let patterns = [
            CallPattern::Linear,
            CallPattern::Tree,
            CallPattern::Recursive,
            CallPattern::Hub,
            CallPattern::Pipeline,
        ];
        for p in &patterns {
            let json = serde_json::to_string(p).unwrap();
            assert!(!json.is_empty());
        }
    }

    #[test]
    fn hex_encode_produces_lowercase_hex() {
        let bytes = [0u8, 1, 255, 16];
        let encoded = hex_encode(&bytes);
        assert_eq!(encoded, "0001ff10");
    }
}

//! Function-level pattern mining across a workspace.
//!
//! Re-parses workspace files to extract per-function observation sub-trees,
//! then clusters them by topology similarity to find recurring patterns
//! across crates.

use std::path::Path;

use codex_parse::workspace::walk_workspace;
use codex_parse::{CodeObservation, NodeKind};
use codex_topo::{compute_code_topology, topology_similarity, CodeTopology, TopoConfig};

use crate::CodeCrystal;

// ── Public Types ─────────────────────────────────────────────────────────────

/// Report on recurring function-level patterns across a workspace.
#[derive(Debug)]
pub struct FunctionPatternReport {
    /// Total number of functions analyzed (functions with ≥5 nodes).
    pub total_functions: usize,
    /// Recurring patterns (appear in 2+ instances).
    pub patterns: Vec<FunctionPattern>,
    /// Functions with no similar partner (max similarity below threshold).
    pub unique_functions: Vec<FunctionInfo>,
    /// The most common pattern (by instance count).
    pub dominant_pattern: Option<FunctionPattern>,
}

/// A recurring structural pattern found across multiple functions.
#[derive(Debug, Clone)]
pub struct FunctionPattern {
    /// Unique identifier (SHA-256 prefix of the representative topology).
    pub pattern_id: String,
    /// Representative topology for this pattern.
    pub topology: CodeTopology,
    /// All function instances matching this pattern.
    pub instances: Vec<FunctionInstance>,
    /// Crystallized pattern if this matches a known crystal.
    pub crystal: Option<CodeCrystal>,
    /// Human-readable description (dominant node kinds).
    pub description: String,
}

/// A concrete function instance that matches a pattern.
#[derive(Debug, Clone)]
pub struct FunctionInstance {
    pub file: String,
    pub crate_name: String,
    pub function_name: String,
    pub line_range: (usize, usize),
    pub similarity_to_pattern: f64,
}

/// A function with no similar partner — potentially novel.
#[derive(Debug, Clone)]
pub struct FunctionInfo {
    pub file: String,
    pub crate_name: String,
    pub function_name: String,
    pub topology: CodeTopology,
    pub max_similarity_to_any_pattern: f64,
}

// ── Internal helper ───────────────────────────────────────────────────────────

struct ExtractedFunction {
    file: String,
    crate_name: String,
    name: String,
    topology: CodeTopology,
}

// ── Entry Point ───────────────────────────────────────────────────────────────

/// Mine recurring function patterns across an entire workspace.
///
/// For each source file, extracts per-function observation sub-trees,
/// computes their topology, then clusters by similarity.
///
/// # Arguments
/// * `root` — workspace root directory
/// * `config` — topology configuration
/// * `threshold` — similarity threshold for grouping (e.g. 0.88)
pub fn mine_function_patterns(
    root: &Path,
    config: &TopoConfig,
    threshold: f64,
) -> FunctionPatternReport {
    let raw = walk_workspace(root);
    let mut all_funcs: Vec<ExtractedFunction> = Vec::new();

    for pf in &raw.files {
        let subtrees = extract_function_subtrees(&pf.observations);
        for (func_name, sub_obs) in subtrees {
            if sub_obs.len() < 5 {
                continue;
            }
            let graph = codex_parse::observations_to_graph(&sub_obs);
            let topo = compute_code_topology(&graph, &sub_obs, config);
            all_funcs.push(ExtractedFunction {
                file: pf.relative_path.clone(),
                crate_name: pf.crate_name.clone(),
                name: func_name,
                topology: topo,
            });
        }
    }

    let total_functions = all_funcs.len();

    // Greedy clustering: assign each function to the first existing cluster
    // whose representative topology is within `threshold`.
    // Each cluster[0] is the representative.
    let mut clusters: Vec<Vec<usize>> = Vec::new();
    let mut reps: Vec<usize> = Vec::new(); // indices of representatives

    for i in 0..all_funcs.len() {
        let mut best_cluster: Option<(usize, f64)> = None;
        for (ci, &rep) in reps.iter().enumerate() {
            let sim = topology_similarity(&all_funcs[rep].topology, &all_funcs[i].topology);
            if sim >= threshold {
                match best_cluster {
                    Some((_, best_sim)) if sim <= best_sim => {}
                    _ => best_cluster = Some((ci, sim)),
                }
            }
        }
        if let Some((ci, _)) = best_cluster {
            clusters[ci].push(i);
        } else {
            reps.push(i);
            clusters.push(vec![i]);
        }
    }

    // Build patterns for clusters with 2+ members.
    let mut patterns: Vec<FunctionPattern> = Vec::new();
    let mut unique_functions: Vec<FunctionInfo> = Vec::new();

    for (ci, members) in clusters.iter().enumerate() {
        let rep_idx = reps[ci];
        let rep = &all_funcs[rep_idx];

        if members.len() < 2 {
            // Unique function.
            unique_functions.push(FunctionInfo {
                file: rep.file.clone(),
                crate_name: rep.crate_name.clone(),
                function_name: rep.name.clone(),
                topology: rep.topology.clone(),
                max_similarity_to_any_pattern: 0.0,
            });
            continue;
        }

        let instances: Vec<FunctionInstance> = members
            .iter()
            .map(|&idx| {
                let f = &all_funcs[idx];
                let sim = topology_similarity(&rep.topology, &f.topology);
                FunctionInstance {
                    file: f.file.clone(),
                    crate_name: f.crate_name.clone(),
                    function_name: f.name.clone(),
                    line_range: (0, 0),
                    similarity_to_pattern: sim,
                }
            })
            .collect();

        let description = describe_topology(&rep.topology);
        let pattern_id = short_hash(&rep.topology);

        patterns.push(FunctionPattern {
            pattern_id,
            topology: rep.topology.clone(),
            instances,
            crystal: None,
            description,
        });
    }

    // Update unique_functions: compute their max similarity to any pattern representative.
    let rep_topos: Vec<&CodeTopology> = reps.iter().map(|&i| &all_funcs[i].topology).collect();
    for uf in &mut unique_functions {
        let max_sim = rep_topos
            .iter()
            .map(|rt| topology_similarity(rt, &uf.topology))
            .fold(0.0_f64, f64::max);
        uf.max_similarity_to_any_pattern = max_sim;
    }

    // Sort patterns by instance count descending.
    patterns.sort_by(|a, b| b.instances.len().cmp(&a.instances.len()));

    let dominant_pattern = patterns.first().cloned();

    FunctionPatternReport {
        total_functions,
        patterns,
        unique_functions,
        dominant_pattern,
    }
}

// ── Internal Helpers ──────────────────────────────────────────────────────────

/// Extract per-function observation sub-trees from a file's observations.
///
/// Returns `(function_name, observations_in_subtree)` pairs.
/// Only returns top-level functions (depth ≤ 4 to avoid nested lambdas).
///
/// Uses depth-based traversal: a function at depth D "owns" all consecutive
/// observations with depth > D that follow it in document order, up to the
/// next observation at depth ≤ D.
pub fn extract_function_subtrees(
    observations: &[CodeObservation],
) -> Vec<(String, Vec<CodeObservation>)> {
    let mut result = Vec::new();

    for (start_idx, obs) in observations.iter().enumerate() {
        if !matches!(obs.kind, NodeKind::Function) {
            continue;
        }
        if obs.depth > 4 {
            continue; // Skip deeply nested closures/lambdas.
        }

        let func_depth = obs.depth;
        // Collect this node + all consecutive deeper nodes (the subtree).
        let subtree: Vec<CodeObservation> = std::iter::once(obs)
            .chain(observations[start_idx + 1..].iter().take_while(|o| o.depth > func_depth))
            .cloned()
            .collect();

        if subtree.len() < 5 {
            continue;
        }

        let func_name = extract_name_from_node_id(&obs.node_id);
        result.push((func_name, subtree));
    }

    result
}

fn extract_name_from_node_id(node_id: &str) -> String {
    // node_id formats vary: "Function:name:depth:pos" or hash-based.
    // Try extracting second colon-segment.
    let parts: Vec<&str> = node_id.splitn(3, ':').collect();
    if parts.len() >= 2 && !parts[1].is_empty() && parts[1].len() > 2 {
        return parts[1].to_string();
    }
    // Fallback: use the first 8 chars of the node_id.
    node_id[..node_id.len().min(8)].to_string()
}

fn describe_topology(topo: &CodeTopology) -> String {
    let top_kinds: Vec<String> = topo
        .kind_distribution
        .iter()
        .take(3)
        .map(|(k, _)| format!("{:?}", k))
        .collect();
    format!(
        "cc={} kinds=[{}]",
        topo.cyclomatic_complexity,
        top_kinds.join(", ")
    )
}

fn short_hash(topo: &CodeTopology) -> String {
    use std::collections::hash_map::DefaultHasher;
    use std::hash::{Hash, Hasher};

    let mut hasher = DefaultHasher::new();
    // Hash a few stable fields.
    topo.cyclomatic_complexity.hash(&mut hasher);
    topo.betti.len().hash(&mut hasher);
    ((topo.spectral_gap * 1000.0) as u64).hash(&mut hasher);
    format!("pat-{:016x}", hasher.finish())
}

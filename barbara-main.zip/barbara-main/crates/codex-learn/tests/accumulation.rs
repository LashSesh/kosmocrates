//! Accumulation test: verify that pattern memory grows and transfers
//! across languages, with hit rate increasing and time decreasing.

use codex_learn::CodexEngine;
use std::path::PathBuf;
use std::time::Instant;

fn workspace_root() -> PathBuf {
    let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest_dir.parent().unwrap().parent().unwrap().to_path_buf()
}

#[test]
fn accumulation_across_four_languages() {
    let mut engine = CodexEngine::new();
    let languages = ["python", "rust", "javascript", "go"];
    let extensions = ["py", "rs", "js", "go"];

    let mut hit_rates = Vec::new();
    let mut times = Vec::new();

    for (language, ext) in languages.iter().zip(extensions.iter()) {
        let corpus_dir = workspace_root().join(format!("corpus/{}", language));
        if !corpus_dir.exists() {
            eprintln!("Skipping {} (no corpus)", language);
            continue;
        }

        let mut files: Vec<PathBuf> = std::fs::read_dir(&corpus_dir)
            .unwrap()
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().map(|e| e == *ext).unwrap_or(false))
            .collect();
        files.sort();

        let hits_before = engine.memory_hits();
        let misses_before = engine.memory_misses();
        let start = Instant::now();

        for file in &files {
            let _ = engine.observe_file(file);
        }

        let elapsed = start.elapsed();
        let new_hits = engine.memory_hits() - hits_before;
        let new_misses = engine.memory_misses() - misses_before;
        let phase_total = new_hits + new_misses;
        let phase_hit_rate = if phase_total > 0 {
            new_hits as f64 / phase_total as f64
        } else {
            0.0
        };

        hit_rates.push(phase_hit_rate);
        times.push(elapsed.as_millis());

        println!(
            "{}: hits={}, misses={}, rate={:.1}%, time={}ms",
            language, new_hits, new_misses, phase_hit_rate * 100.0, elapsed.as_millis()
        );
    }

    println!("\nHit rates by phase: {:?}", hit_rates);
    println!("Times by phase: {:?}", times);

    // Verify accumulation: overall hit rate demonstrates cross-language transfer
    let total_hits: u64 = engine.memory_hits();
    let total_observations = engine.memory_hits() + engine.memory_misses();
    let overall_rate = total_hits as f64 / total_observations as f64;
    println!(
        "\nOverall: {}/{} hits ({:.1}% recognition)",
        total_hits, total_observations, overall_rate * 100.0
    );

    // Phases 2-4 should have hits (cross-language learning)
    if hit_rates.len() >= 2 {
        let later_hits: f64 = hit_rates[1..].iter().sum::<f64>();
        assert!(
            later_hits > 0.0,
            "Phases after first should have some memory hits (cross-language transfer)"
        );
    }

    // Overall hit rate should be > 0
    assert!(total_hits > 0, "Should have at least some memory hits");
}

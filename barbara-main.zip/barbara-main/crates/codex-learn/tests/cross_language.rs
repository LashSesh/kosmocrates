//! Cross-language invariance tests.
//!
//! For each of the 10 algorithms, verify that all 4 language
//! implementations produce topologically similar crystals.

use codex_topo::{topology_from_source, topology_similarity, TopoConfig};
use std::path::PathBuf;

fn workspace_root() -> PathBuf {
    // Integration tests run from the crate directory; navigate to workspace root
    let manifest_dir = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    manifest_dir.parent().unwrap().parent().unwrap().to_path_buf()
}

fn read_corpus(language: &str, filename: &str) -> Option<String> {
    let path = workspace_root().join(format!("corpus/{}/{}", language, filename));
    std::fs::read_to_string(path).ok()
}

fn parse_and_topology(source: &str, language: &str) -> codex_topo::CodeTopology {
    let config = TopoConfig::default();
    topology_from_source(source, language, &config).expect("parse and topology")
}

struct AlgoSpec {
    name: &'static str,
    py_file: &'static str,
    rs_file: &'static str,
    js_file: &'static str,
    go_file: &'static str,
}

const ALGORITHMS: &[AlgoSpec] = &[
    AlgoSpec {
        name: "fibonacci",
        py_file: "01_fibonacci.py",
        rs_file: "01_fibonacci.rs",
        js_file: "01_fibonacci.js",
        go_file: "01_fibonacci.go",
    },
    AlgoSpec {
        name: "binary_search",
        py_file: "02_binary_search.py",
        rs_file: "02_binary_search.rs",
        js_file: "02_binary_search.js",
        go_file: "02_binary_search.go",
    },
    AlgoSpec {
        name: "bubble_sort",
        py_file: "03_bubble_sort.py",
        rs_file: "03_bubble_sort.rs",
        js_file: "03_bubble_sort.js",
        go_file: "03_bubble_sort.go",
    },
    AlgoSpec {
        name: "http_handler",
        py_file: "04_http_handler.py",
        rs_file: "04_http_handler.rs",
        js_file: "04_http_handler.js",
        go_file: "04_http_handler.go",
    },
    AlgoSpec {
        name: "file_transform",
        py_file: "05_file_transform.py",
        rs_file: "05_file_transform.rs",
        js_file: "05_file_transform.js",
        go_file: "05_file_transform.go",
    },
    AlgoSpec {
        name: "linked_list",
        py_file: "06_linked_list.py",
        rs_file: "06_linked_list.rs",
        js_file: "06_linked_list.js",
        go_file: "06_linked_list.go",
    },
    AlgoSpec {
        name: "json_validate",
        py_file: "07_json_validate.py",
        rs_file: "07_json_validate.rs",
        js_file: "07_json_validate.js",
        go_file: "07_json_validate.go",
    },
    AlgoSpec {
        name: "observer_pattern",
        py_file: "08_observer_pattern.py",
        rs_file: "08_observer_pattern.rs",
        js_file: "08_observer_pattern.js",
        go_file: "08_observer_pattern.go",
    },
    AlgoSpec {
        name: "async_fetch",
        py_file: "09_async_fetch.py",
        rs_file: "09_async_fetch.rs",
        js_file: "09_async_fetch.js",
        go_file: "09_async_fetch.go",
    },
    AlgoSpec {
        name: "binary_tree",
        py_file: "10_binary_tree.py",
        rs_file: "10_binary_tree.rs",
        js_file: "10_binary_tree.js",
        go_file: "10_binary_tree.go",
    },
];

#[test]
fn cross_language_invariance() {
    let threshold = 0.70;

    let mut total_pairs = 0;
    let mut passing_pairs = 0;

    for algo in ALGORITHMS {
        let py_src = match read_corpus("python", algo.py_file) {
            Some(s) => s,
            None => {
                eprintln!("Skipping {} (Python corpus file missing)", algo.name);
                continue;
            }
        };
        let rs_src = match read_corpus("rust", algo.rs_file) {
            Some(s) => s,
            None => {
                eprintln!("Skipping {} (Rust corpus file missing)", algo.name);
                continue;
            }
        };
        let js_src = match read_corpus("javascript", algo.js_file) {
            Some(s) => s,
            None => {
                eprintln!("Skipping {} (JavaScript corpus file missing)", algo.name);
                continue;
            }
        };
        let go_src = match read_corpus("go", algo.go_file) {
            Some(s) => s,
            None => {
                eprintln!("Skipping {} (Go corpus file missing)", algo.name);
                continue;
            }
        };

        let py_topo = parse_and_topology(&py_src, "python");
        let rs_topo = parse_and_topology(&rs_src, "rust");
        let js_topo = parse_and_topology(&js_src, "javascript");
        let go_topo = parse_and_topology(&go_src, "go");

        let pairs = [
            ("Python-Rust", &py_topo, &rs_topo),
            ("Python-JS", &py_topo, &js_topo),
            ("Python-Go", &py_topo, &go_topo),
            ("Rust-JS", &rs_topo, &js_topo),
            ("Rust-Go", &rs_topo, &go_topo),
            ("JS-Go", &js_topo, &go_topo),
        ];

        for (pair_name, a, b) in &pairs {
            let sim = topology_similarity(a, b);
            total_pairs += 1;
            if sim >= threshold {
                passing_pairs += 1;
            }
            println!(
                "{}: {} similarity = {:.4} {}",
                algo.name,
                pair_name,
                sim,
                if sim >= threshold { "PASS" } else { "BELOW" }
            );
        }
    }

    let pass_rate = passing_pairs as f64 / total_pairs.max(1) as f64;
    println!(
        "\nCross-language invariance: {}/{} pairs above {:.2} ({:.1}%)",
        passing_pairs, total_pairs, threshold, pass_rate * 100.0
    );

    // At least 67% of pairs should pass at threshold 0.70
    assert!(
        pass_rate > 0.67,
        "Cross-language pass rate {:.1}% is below 67%",
        pass_rate * 100.0
    );
}

#[test]
fn cross_language_accumulation() {
    use codex_learn::CodexEngine;

    let mut engine = CodexEngine::new();

    // Phase 1: observe all Python files
    let py_dir = workspace_root().join("corpus/python");
    if !py_dir.exists() {
        eprintln!("Skipping accumulation test (no corpus)");
        return;
    }

    let mut py_files: Vec<PathBuf> = std::fs::read_dir(&py_dir)
        .unwrap()
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|e| e == "py").unwrap_or(false))
        .collect();
    py_files.sort();

    for file in &py_files {
        let _ = engine.observe_file(file);
    }
    let py_crystals = engine.crystal_count();
    println!("After Python: {} crystals", py_crystals);
    assert!(py_crystals >= 1, "Expected >= 1 crystal from Python, got {}", py_crystals);

    // Phase 2: observe all Rust files
    let rs_dir = workspace_root().join("corpus/rust");
    if !rs_dir.exists() {
        return;
    }

    let hits_before = engine.memory_hits();
    let mut rs_files: Vec<PathBuf> = std::fs::read_dir(&rs_dir)
        .unwrap()
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|e| e == "rs").unwrap_or(false))
        .collect();
    rs_files.sort();

    for file in &rs_files {
        let _ = engine.observe_file(file);
    }
    let rust_hits = engine.memory_hits() - hits_before;
    println!(
        "After Rust: {} new hits, {} total crystals",
        rust_hits,
        engine.crystal_count()
    );

    let recognition_rate = rust_hits as f64 / rs_files.len() as f64;
    println!("Cross-language recognition rate: {:.1}%", recognition_rate * 100.0);

    // At least 70% of Rust files should be recognized as cross-language matches
    assert!(
        recognition_rate > 0.70,
        "Cross-language recognition rate {:.1}% is below 70%",
        recognition_rate * 100.0
    );
}

#[test]
fn dissimilar_programs_create_separate_crystals() {
    use codex_learn::CodexEngine;
    use codex_topo::TopoConfig;

    // At a high threshold, structurally distinct algorithms should not merge.
    // From threshold sweep: threshold 0.95 produces >= 4 distinct Python crystals.
    let mut engine = CodexEngine::with_config(TopoConfig::default(), 0.95);

    let py_dir = workspace_root().join("corpus/python");
    if !py_dir.exists() {
        eprintln!("Skipping dissimilar test (no corpus)");
        return;
    }

    let mut py_files: Vec<PathBuf> = std::fs::read_dir(&py_dir)
        .unwrap()
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|e| e == "py").unwrap_or(false))
        .collect();
    py_files.sort();

    for file in &py_files {
        let _ = engine.observe_file(file);
    }
    let crystal_count = engine.crystal_count();
    println!(
        "At threshold 0.95: {} distinct crystals from {} Python files",
        crystal_count,
        py_files.len()
    );

    // At threshold 0.95, dissimilar programs should resolve to separate crystals.
    // We expect at least 2 distinct clusters (verified by threshold sweep).
    assert!(
        crystal_count >= 2,
        "Expected >= 2 distinct crystals at threshold 0.95 (got {}), \
        meaning all programs collapse to one — no algorithm discrimination",
        crystal_count
    );
}

#[test]
fn same_algo_cross_lang_scores_high() {
    // Verify that same-algorithm different-language topology similarity is ≥ 0.80.
    // This is the core invariant: our topology is language-independent.
    let algos = [
        ("fibonacci", "01_fibonacci.py", "01_fibonacci.rs"),
        ("binary_search", "02_binary_search.py", "02_binary_search.rs"),
        ("bubble_sort", "03_bubble_sort.py", "03_bubble_sort.rs"),
    ];

    let config = TopoConfig::default();

    for (name, py_file, rs_file) in &algos {
        let py_src = match read_corpus("python", py_file) {
            Some(s) => s,
            None => {
                eprintln!("Skipping {} (missing corpus)", name);
                continue;
            }
        };
        let rs_src = match read_corpus("rust", rs_file) {
            Some(s) => s,
            None => {
                eprintln!("Skipping {} (missing corpus)", name);
                continue;
            }
        };

        let py_topo = topology_from_source(&py_src, "python", &config).unwrap();
        let rs_topo = topology_from_source(&rs_src, "rust", &config).unwrap();
        let sim = topology_similarity(&py_topo, &rs_topo);

        println!("{} Python-Rust similarity = {:.4}", name, sim);
        assert!(
            sim >= 0.80,
            "{} Python-Rust similarity {:.4} is below 0.80",
            name,
            sim
        );
    }
}

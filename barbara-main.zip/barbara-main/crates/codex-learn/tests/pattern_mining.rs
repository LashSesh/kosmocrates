//! Pattern mining and export integration tests.

use std::path::PathBuf;

use codex_learn::{
    export_crystals, export_to_json, import_crystals, mine_function_patterns, CodexEngine,
    ExportedCrystal,
};
use codex_topo::TopoConfig;

fn fixture_root() -> PathBuf {
    // Navigate from codex-learn crate root to the test fixture.
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .join("codex-topo/tests/fixtures/test_workspace")
}

fn barbara_root() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf()
}

// ── Function pattern mining ───────────────────────────────────────────────────

#[test]
fn mine_function_patterns_finds_functions() {
    let config = TopoConfig::default();
    let report = mine_function_patterns(&fixture_root(), &config, 0.88);
    assert!(
        report.total_functions > 0,
        "Expected > 0 functions in the 3-crate fixture, found 0"
    );
}

#[test]
fn mine_function_patterns_finds_recurring_patterns() {
    let config = TopoConfig::default();
    let report = mine_function_patterns(&fixture_root(), &config, 0.85);

    println!(
        "total_functions={}, patterns={}, unique={}",
        report.total_functions,
        report.patterns.len(),
        report.unique_functions.len()
    );

    // The fixture has similar patterns across crates (conditional + loop structures).
    // At threshold 0.85, we should find at least some recurring patterns.
    // (If everything is unique that's also valid — just assert no panic.)
    let total = report.patterns.len() + report.unique_functions.len();
    assert!(total > 0, "Expected some functions to be classified");
}

#[test]
fn function_instances_have_crate_names() {
    let config = TopoConfig::default();
    let report = mine_function_patterns(&fixture_root(), &config, 0.80);
    for pattern in &report.patterns {
        for instance in &pattern.instances {
            assert!(
                !instance.crate_name.is_empty(),
                "Instance in pattern {} has empty crate_name",
                pattern.pattern_id
            );
        }
    }
}

#[test]
fn function_instances_have_function_names() {
    let config = TopoConfig::default();
    let report = mine_function_patterns(&fixture_root(), &config, 0.85);
    let all_instances = report.patterns.iter().flat_map(|p| p.instances.iter());
    for inst in all_instances {
        assert!(
            !inst.function_name.is_empty(),
            "Instance has empty function_name"
        );
    }
}

// ── Export format ─────────────────────────────────────────────────────────────

fn make_test_engine() -> CodexEngine {
    let mut engine = CodexEngine::new();
    let source = "fn fibonacci(n: u64) -> u64 {\n    if n <= 1 { return n; }\n    fibonacci(n - 1) + fibonacci(n - 2)\n}\n";
    engine.observe_source(source, "rust", Some("test.rs")).unwrap();
    engine
}

#[test]
fn export_crystal_roundtrip() {
    let engine = make_test_engine();
    let crystals = engine.crystals();
    assert!(!crystals.is_empty(), "Engine should have at least one crystal");

    // Export to JSON.
    let json = export_to_json(crystals).expect("export_to_json failed");
    assert!(!json.is_empty(), "JSON should not be empty");

    // Import back.
    let imported: Vec<ExportedCrystal> = import_crystals(&json).expect("import_crystals failed");
    assert_eq!(
        imported.len(),
        crystals.len(),
        "Roundtrip should preserve crystal count"
    );

    // IDs should match.
    for (original, imported) in crystals.iter().zip(imported.iter()) {
        assert_eq!(
            original.id, imported.id,
            "Crystal ID should be preserved through roundtrip"
        );
    }
}

#[test]
fn exported_crystal_has_required_fields() {
    let engine = make_test_engine();
    let crystals = engine.crystals();
    let exported = export_crystals(crystals);
    assert!(!exported.is_empty());

    let crystal = &exported[0];
    assert!(!crystal.id.is_empty(), "id must not be empty");
    assert!(!crystal.source.is_empty(), "source must not be empty");
    assert_eq!(crystal.source, "barbara-v0.2.0");
    assert!(!crystal.pattern_type.is_empty(), "pattern_type must not be empty");
    assert!(!crystal.description.is_empty(), "description must not be empty");
    assert!(crystal.confidence >= 0.0 && crystal.confidence <= 1.0, "confidence must be in [0,1]");
    assert!(!crystal.content_hash.is_empty(), "content_hash must not be empty");
}

#[test]
fn exported_crystal_has_blueprint() {
    let engine = make_test_engine();
    let crystals = engine.crystals();
    let exported = export_crystals(crystals);
    assert!(!exported.is_empty());

    let blueprint = &exported[0].blueprint;
    // Blueprint should have kind_ratios (from topology).
    assert!(
        !blueprint.kind_ratios.is_empty(),
        "blueprint.kind_ratios should not be empty"
    );
    // Cyclomatic range should be non-degenerate.
    assert!(
        blueprint.cyclomatic_range.1 >= blueprint.cyclomatic_range.0,
        "cyclomatic_range max should be >= min"
    );
}

#[test]
fn blueprint_control_flow_for_recursive_function() {
    // fibonacci is recursive — control_flow should contain function-related kinds.
    let engine = make_test_engine();
    let crystals = engine.crystals();
    let exported = export_crystals(crystals);
    assert!(!exported.is_empty());

    let blueprint = &exported[0].blueprint;
    println!("Control flow: {:?}", blueprint.control_flow);
    // Should contain at least one node kind.
    assert!(!blueprint.control_flow.is_empty() || !blueprint.kind_ratios.is_empty(),
        "Blueprint should have either control_flow or kind_ratios populated");
}

#[test]
fn import_invalid_json_returns_error() {
    let result = import_crystals("this is not json");
    assert!(result.is_err(), "Invalid JSON should return error");
}

#[test]
fn import_empty_array_succeeds() {
    let result = import_crystals("[]");
    assert!(result.is_ok());
    assert_eq!(result.unwrap().len(), 0);
}

// ── Self-analysis ─────────────────────────────────────────────────────────────

#[test]
fn barbara_parses_its_own_workspace() {
    let ws = codex_topo::parse_workspace(&barbara_root());
    assert!(
        ws.stats.total_crates >= 5,
        "Expected ≥5 crates in barbara workspace, found {}",
        ws.stats.total_crates
    );
    assert!(
        ws.stats.total_files >= 10,
        "Expected ≥10 files in barbara workspace, found {}",
        ws.stats.total_files
    );
    assert!(
        ws.stats.total_loc > 0,
        "Expected non-zero LOC in barbara workspace"
    );
}

#[test]
fn barbara_produces_crate_clusters() {
    let ws = codex_topo::parse_workspace(&barbara_root());
    let report = codex_topo::analyze_crate_relationships(&ws);

    println!(
        "Barbara: {} crates, {} clusters, {} isolated",
        ws.stats.total_crates,
        report.clusters.len(),
        report.isolated_crates.len()
    );

    // Barbara has 15+ crates — at threshold 0.70, some should cluster.
    // At minimum, the similarity matrix should be non-empty.
    assert!(
        !report.similarity_matrix.is_empty(),
        "similarity_matrix should not be empty for barbara workspace"
    );

    // All similarities should be valid.
    for (a, b, sim) in &report.similarity_matrix {
        assert!(
            *sim >= 0.0 && *sim <= 1.0,
            "{} ↔ {} similarity {} out of range",
            a, b, sim
        );
    }
}

//! schmiede-constraints — Constraint Parsing and Analysis
//!
//! Parses constraint TOML files, validates consistency, computes
//! degrees of freedom, and detects conflicts between constraints.

use serde::{Deserialize, Serialize};
use std::path::Path;
use thiserror::Error;

// ── Errors ──────────────────────────────────────────────────────────

/// Errors that can occur during constraint parsing and validation.
#[derive(Debug, Error)]
pub enum ConstraintError {
    /// TOML parsing failed.
    #[error("failed to parse constraint TOML: {0}")]
    ParseError(#[from] toml::de::Error),
    /// File I/O error.
    #[error("failed to read constraint file: {0}")]
    IoError(#[from] std::io::Error),
    /// Validation error.
    #[error("constraint validation failed: {0}")]
    ValidationError(String),
}

pub type Result<T> = std::result::Result<T, ConstraintError>;

// ── Core Constraint Types ───────────────────────────────────────────

/// Fully parsed and validated constraint set.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LanguageConstraints {
    pub meta: MetaConstraints,
    #[serde(default)]
    pub platform: PlatformConstraints,
    #[serde(default)]
    pub safety: SafetyConstraints,
    #[serde(default)]
    pub types: TypeConstraints,
    #[serde(default)]
    pub syntax: SyntaxConstraints,
    #[serde(default)]
    pub control_flow: ControlFlowConstraints,
    #[serde(default)]
    pub modules: ModuleConstraints,
    #[serde(default)]
    pub output: OutputConstraints,
}

/// Metadata about the language being generated.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MetaConstraints {
    pub name: String,
    #[serde(default = "default_description")]
    pub description: String,
    #[serde(default = "default_version")]
    pub version: String,
}

fn default_description() -> String {
    "A generated programming language".to_string()
}
fn default_version() -> String {
    "1.0".to_string()
}

/// Platform and resource constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlatformConstraints {
    #[serde(default)]
    pub target: TargetPlatform,
    pub max_ram_kb: Option<u32>,
    pub max_flash_kb: Option<u32>,
    #[serde(default = "default_true")]
    pub heap_allowed: bool,
    #[serde(default)]
    pub os: OsRequirement,
    #[serde(default)]
    pub float: FloatSupport,
}

impl Default for PlatformConstraints {
    fn default() -> Self {
        Self {
            target: TargetPlatform::Any,
            max_ram_kb: None,
            max_flash_kb: None,
            heap_allowed: true,
            os: OsRequirement::Any,
            float: FloatSupport::Hardware,
        }
    }
}

/// Target platform architecture.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum TargetPlatform {
    ArmCortexM0,
    ArmCortexM4,
    X86_64,
    Wasm32,
    Riscv32,
    Any,
}

impl Default for TargetPlatform {
    fn default() -> Self {
        Self::Any
    }
}

/// OS requirement.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "kebab-case")]
pub enum OsRequirement {
    BareMetal,
    Posix,
    Any,
}

impl Default for OsRequirement {
    fn default() -> Self {
        Self::Any
    }
}

/// Float support level.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum FloatSupport {
    Hardware,
    Soft,
    None,
}

impl Default for FloatSupport {
    fn default() -> Self {
        Self::Hardware
    }
}

/// Safety-related constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SafetyConstraints {
    #[serde(default)]
    pub memory_safety: SafetyLevel,
    #[serde(default = "default_true")]
    pub null_allowed: bool,
    #[serde(default)]
    pub overflow: OverflowBehavior,
    #[serde(default)]
    pub array_bounds: BoundsCheck,
    #[serde(default)]
    pub concurrency: ConcurrencyModel,
    #[serde(default)]
    pub recursion: RecursionPolicy,
    #[serde(default)]
    pub stack_usage: StackPolicy,
}

impl Default for SafetyConstraints {
    fn default() -> Self {
        Self {
            memory_safety: SafetyLevel::None,
            null_allowed: true,
            overflow: OverflowBehavior::Wrapping,
            array_bounds: BoundsCheck::None,
            concurrency: ConcurrencyModel::None,
            recursion: RecursionPolicy::Unlimited,
            stack_usage: StackPolicy::Unanalyzed,
        }
    }
}

/// Memory safety level.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum SafetyLevel {
    None,
    Partial,
    Full,
}

impl Default for SafetyLevel {
    fn default() -> Self {
        Self::None
    }
}

/// Arithmetic overflow behavior.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum OverflowBehavior {
    Wrapping,
    Checked,
    Saturating,
}

impl Default for OverflowBehavior {
    fn default() -> Self {
        Self::Wrapping
    }
}

/// Array bounds checking strategy.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum BoundsCheck {
    None,
    Runtime,
    Static,
}

impl Default for BoundsCheck {
    fn default() -> Self {
        Self::None
    }
}

/// Concurrency model.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum ConcurrencyModel {
    None,
    SharedMemory,
    MessagePassing,
    Async,
}

impl Default for ConcurrencyModel {
    fn default() -> Self {
        Self::None
    }
}

/// Recursion policy.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum RecursionPolicy {
    Unlimited,
    Bounded,
    Forbidden,
}

impl Default for RecursionPolicy {
    fn default() -> Self {
        Self::Unlimited
    }
}

/// Stack usage analysis policy.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum StackPolicy {
    Unanalyzed,
    Analyzed,
    BoundedStatic,
}

impl Default for StackPolicy {
    fn default() -> Self {
        Self::Unanalyzed
    }
}

/// Type system constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TypeConstraints {
    #[serde(default = "default_integers")]
    pub integers: Vec<String>,
    #[serde(default)]
    pub floats: Vec<String>,
    #[serde(default)]
    pub strings: StringModel,
    #[serde(default)]
    pub generics: bool,
    #[serde(default)]
    pub traits: bool,
    #[serde(default = "default_true")]
    pub enums: bool,
    #[serde(default = "default_true")]
    pub structs: bool,
    #[serde(default)]
    pub tuples: bool,
    #[serde(default)]
    pub references: ReferenceModel,
}

impl Default for TypeConstraints {
    fn default() -> Self {
        Self {
            integers: default_integers(),
            floats: vec![],
            strings: StringModel::Dynamic,
            generics: false,
            traits: false,
            enums: true,
            structs: true,
            tuples: false,
            references: ReferenceModel::None,
        }
    }
}

fn default_integers() -> Vec<String> {
    vec![
        "i32".to_string(),
        "u32".to_string(),
    ]
}

/// String representation model.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum StringModel {
    None,
    Fixed,
    Dynamic,
}

impl Default for StringModel {
    fn default() -> Self {
        Self::Dynamic
    }
}

/// Reference/pointer model.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ReferenceModel {
    None,
    Raw,
    Borrow,
    GarbageCollected,
}

impl Default for ReferenceModel {
    fn default() -> Self {
        Self::None
    }
}

/// Syntax constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SyntaxConstraints {
    #[serde(default)]
    pub keyword_language: KeywordLanguage,
    pub max_keywords: Option<u32>,
    #[serde(default)]
    pub block_style: BlockStyle,
    #[serde(default)]
    pub comment_style: CommentStyle,
    #[serde(default = "default_true")]
    pub semicolons: bool,
    #[serde(default)]
    pub indent_significant: bool,
    #[serde(default)]
    pub operator_overloading: bool,
}

impl Default for SyntaxConstraints {
    fn default() -> Self {
        Self {
            keyword_language: KeywordLanguage::English,
            max_keywords: None,
            block_style: BlockStyle::Braces,
            comment_style: CommentStyle::SlashSlash,
            semicolons: true,
            indent_significant: false,
            operator_overloading: false,
        }
    }
}

/// Keyword language for the generated language.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum KeywordLanguage {
    #[serde(alias = "en")]
    English,
    #[serde(alias = "de")]
    German,
    #[serde(alias = "sw")]
    Swahili,
    #[serde(alias = "zh")]
    Chinese,
    #[serde(alias = "hi")]
    Hindi,
    #[serde(alias = "ar")]
    Arabic,
    #[serde(alias = "es")]
    Spanish,
    #[serde(alias = "fr")]
    French,
    Custom(Vec<KeywordMapping>),
}

impl Default for KeywordLanguage {
    fn default() -> Self {
        Self::English
    }
}

/// Mapping from canonical keyword to surface form.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct KeywordMapping {
    /// Canonical English keyword (e.g., "function").
    pub canonical: String,
    /// Surface form in the target language (e.g., "kazi" for Swahili).
    pub surface: String,
}

/// Block delimiter style.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum BlockStyle {
    Braces,
    Indentation,
    #[serde(alias = "begin_end")]
    BeginEnd,
    #[serde(alias = "do_end")]
    DoEnd,
}

impl Default for BlockStyle {
    fn default() -> Self {
        Self::Braces
    }
}

/// Comment style.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum CommentStyle {
    SlashSlash,
    Hash,
    Dash,
    Percent,
}

impl Default for CommentStyle {
    fn default() -> Self {
        Self::SlashSlash
    }
}

/// Control flow constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ControlFlowConstraints {
    #[serde(default = "default_true")]
    pub if_else: bool,
    #[serde(default)]
    pub match_exhaustive: bool,
    #[serde(default = "default_true")]
    pub for_loop: bool,
    #[serde(default = "default_true")]
    pub while_loop: bool,
    #[serde(default)]
    pub goto_allowed: bool,
    #[serde(default)]
    pub exceptions: bool,
    #[serde(default = "default_true")]
    pub early_return: bool,
}

impl Default for ControlFlowConstraints {
    fn default() -> Self {
        Self {
            if_else: true,
            match_exhaustive: false,
            for_loop: true,
            while_loop: true,
            goto_allowed: false,
            exceptions: false,
            early_return: true,
        }
    }
}

/// Module system constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ModuleConstraints {
    #[serde(default = "default_true")]
    pub imports: bool,
    #[serde(default)]
    pub visibility: VisibilityModel,
    #[serde(default)]
    pub namespaces: NamespaceModel,
}

impl Default for ModuleConstraints {
    fn default() -> Self {
        Self {
            imports: true,
            visibility: VisibilityModel::AllPublic,
            namespaces: NamespaceModel::Flat,
        }
    }
}

/// Visibility model.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum VisibilityModel {
    #[serde(alias = "all_public")]
    AllPublic,
    Explicit,
    #[serde(alias = "module_private")]
    ModulePrivate,
}

impl Default for VisibilityModel {
    fn default() -> Self {
        Self::AllPublic
    }
}

/// Namespace model.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum NamespaceModel {
    Flat,
    Nested,
    None,
}

impl Default for NamespaceModel {
    fn default() -> Self {
        Self::Flat
    }
}

/// Output constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutputConstraints {
    #[serde(default)]
    pub emit: EmitTarget,
    #[serde(default)]
    pub optimization: OptimizationGoal,
    #[serde(default = "default_true")]
    pub debug_info: bool,
}

impl Default for OutputConstraints {
    fn default() -> Self {
        Self {
            emit: EmitTarget::C,
            optimization: OptimizationGoal::Speed,
            debug_info: true,
        }
    }
}

/// Code generation target.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum EmitTarget {
    C,
    Llvm,
    Wasm,
    Interpreted,
}

impl Default for EmitTarget {
    fn default() -> Self {
        Self::C
    }
}

/// Optimization goal.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum OptimizationGoal {
    Speed,
    Size,
    Debug,
}

impl Default for OptimizationGoal {
    fn default() -> Self {
        Self::Speed
    }
}

fn default_true() -> bool {
    true
}

// ── Conflict Detection ──────────────────────────────────────────────

/// A detected conflict between constraints.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConstraintConflict {
    /// First conflicting constraint.
    pub constraint_a: String,
    /// Second conflicting constraint.
    pub constraint_b: String,
    /// Explanation of why they conflict.
    pub reason: String,
    /// Severity of the conflict.
    pub severity: ConflictSeverity,
}

/// Severity of a constraint conflict.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum ConflictSeverity {
    /// Impossible to satisfy both constraints.
    Error,
    /// Possible but risky combination.
    Warning,
}

/// Detect conflicts between constraints.
///
/// Returns a list of conflicts (empty means no conflicts detected).
pub fn detect_conflicts(constraints: &LanguageConstraints) -> Vec<ConstraintConflict> {
    let mut conflicts = Vec::new();

    // generics=true + max_flash_kb < 128 → monomorphization bloat
    if constraints.types.generics {
        if let Some(flash) = constraints.platform.max_flash_kb {
            if flash < 128 {
                conflicts.push(ConstraintConflict {
                    constraint_a: "types.generics = true".to_string(),
                    constraint_b: format!("platform.max_flash_kb = {flash}"),
                    reason: "monomorphization may exceed flash limit".to_string(),
                    severity: ConflictSeverity::Warning,
                });
            }
        }
    }

    // heap_allowed=false + strings=dynamic → contradiction
    if !constraints.platform.heap_allowed && constraints.types.strings == StringModel::Dynamic {
        conflicts.push(ConstraintConflict {
            constraint_a: "platform.heap_allowed = false".to_string(),
            constraint_b: "types.strings = \"dynamic\"".to_string(),
            reason: "dynamic strings require heap allocation".to_string(),
            severity: ConflictSeverity::Error,
        });
    }

    // concurrency=async + os=bare-metal → async runtime needs OS
    if constraints.safety.concurrency == ConcurrencyModel::Async
        && constraints.platform.os == OsRequirement::BareMetal
    {
        conflicts.push(ConstraintConflict {
            constraint_a: "safety.concurrency = \"async\"".to_string(),
            constraint_b: "platform.os = \"bare-metal\"".to_string(),
            reason: "async runtime requires OS support".to_string(),
            severity: ConflictSeverity::Error,
        });
    }

    // while_loop=false + recursion=forbidden → no unbounded iteration
    if !constraints.control_flow.while_loop
        && constraints.safety.recursion == RecursionPolicy::Forbidden
    {
        conflicts.push(ConstraintConflict {
            constraint_a: "control_flow.while_loop = false".to_string(),
            constraint_b: "safety.recursion = \"forbidden\"".to_string(),
            reason: "no unbounded iteration possible without while loops or recursion".to_string(),
            severity: ConflictSeverity::Warning,
        });
    }

    // float=none + floats=[f32] → contradiction
    if constraints.platform.float == FloatSupport::None && !constraints.types.floats.is_empty() {
        conflicts.push(ConstraintConflict {
            constraint_a: "platform.float = \"none\"".to_string(),
            constraint_b: format!("types.floats = {:?}", constraints.types.floats),
            reason: "float types requested but float support is disabled".to_string(),
            severity: ConflictSeverity::Error,
        });
    }

    // garbage_collected + memory_safety=full → GC pauses break RT guarantees
    if constraints.types.references == ReferenceModel::GarbageCollected
        && constraints.safety.memory_safety == SafetyLevel::Full
    {
        conflicts.push(ConstraintConflict {
            constraint_a: "types.references = \"garbage_collected\"".to_string(),
            constraint_b: "safety.memory_safety = \"full\"".to_string(),
            reason: "GC pauses may break real-time safety guarantees".to_string(),
            severity: ConflictSeverity::Warning,
        });
    }

    // indent_significant + block_style=braces → contradiction
    if constraints.syntax.indent_significant
        && constraints.syntax.block_style == BlockStyle::Braces
    {
        conflicts.push(ConstraintConflict {
            constraint_a: "syntax.indent_significant = true".to_string(),
            constraint_b: "syntax.block_style = \"braces\"".to_string(),
            reason: "indentation-significant syntax conflicts with brace-delimited blocks"
                .to_string(),
            severity: ConflictSeverity::Error,
        });
    }

    conflicts
}

// ── Degrees of Freedom Analysis ─────────────────────────────────────

/// Analysis of how constrained the language design is.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DoFAnalysis {
    /// Total number of constraint dimensions analyzed.
    pub total_constraints: usize,
    /// Number of fully determined constraints (DoF = 0).
    pub determined: usize,
    /// Number of underdetermined constraints (DoF > 0).
    pub underdetermined: usize,
    /// Number of conflicts detected.
    pub conflicts: usize,
    /// Detailed analysis per constraint dimension.
    pub details: Vec<DoFEntry>,
}

/// A single degree-of-freedom entry.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DoFEntry {
    /// Constraint name.
    pub constraint: String,
    /// Degrees of freedom (0 = fully determined).
    pub dof: u32,
    /// Possible implementation choices if DoF > 0.
    pub choices: Vec<String>,
}

/// Compute degrees of freedom for a constraint set.
pub fn compute_dof(constraints: &LanguageConstraints) -> DoFAnalysis {
    let mut details = Vec::new();

    // Platform target
    let target_dof = if constraints.platform.target == TargetPlatform::Any {
        DoFEntry {
            constraint: "platform.target".to_string(),
            dof: 5,
            choices: vec![
                "arm-cortex-m0".into(),
                "arm-cortex-m4".into(),
                "x86_64".into(),
                "wasm32".into(),
                "riscv32".into(),
            ],
        }
    } else {
        DoFEntry {
            constraint: "platform.target".to_string(),
            dof: 0,
            choices: vec![],
        }
    };
    details.push(target_dof);

    // Memory safety
    details.push(DoFEntry {
        constraint: "safety.memory_safety".to_string(),
        dof: 0,
        choices: vec![],
    });

    // String model
    details.push(DoFEntry {
        constraint: "types.strings".to_string(),
        dof: 0,
        choices: vec![],
    });

    // Keyword language
    let kw_dof = if constraints.syntax.keyword_language == KeywordLanguage::English {
        0
    } else {
        0 // all keyword languages are fully determined
    };
    details.push(DoFEntry {
        constraint: "syntax.keyword_language".to_string(),
        dof: kw_dof,
        choices: vec![],
    });

    // Block style
    details.push(DoFEntry {
        constraint: "syntax.block_style".to_string(),
        dof: 0,
        choices: vec![],
    });

    // Emit target
    details.push(DoFEntry {
        constraint: "output.emit".to_string(),
        dof: 0,
        choices: vec![],
    });

    // Generics implementation (if enabled, there are choices)
    if constraints.types.generics {
        details.push(DoFEntry {
            constraint: "types.generics (implementation)".to_string(),
            dof: 2,
            choices: vec!["monomorphization".into(), "type_erasure".into()],
        });
    }

    // Reference model implementation
    if constraints.types.references == ReferenceModel::Borrow {
        details.push(DoFEntry {
            constraint: "types.references (borrow complexity)".to_string(),
            dof: 1,
            choices: vec!["simple_lifetimes".into(), "full_borrow_checker".into()],
        });
    }

    // Optimization strategy details
    details.push(DoFEntry {
        constraint: "output.optimization".to_string(),
        dof: 0,
        choices: vec![],
    });

    let conflicts = detect_conflicts(constraints).len();
    let determined = details.iter().filter(|d| d.dof == 0).count();
    let underdetermined = details.iter().filter(|d| d.dof > 0).count();

    DoFAnalysis {
        total_constraints: details.len(),
        determined,
        underdetermined,
        conflicts,
        details,
    }
}

// ── Parsing Functions ───────────────────────────────────────────────

/// Parse a constraint TOML string into a validated `LanguageConstraints`.
pub fn parse_constraints(toml_str: &str) -> Result<LanguageConstraints> {
    let constraints: LanguageConstraints = toml::from_str(toml_str)?;
    Ok(constraints)
}

/// Load constraints from a TOML file path.
pub fn load_constraints(path: &Path) -> Result<LanguageConstraints> {
    let content = std::fs::read_to_string(path)?;
    parse_constraints(&content)
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parse_embedded_safety() {
        let toml = r#"
[meta]
name = "SafeEmbed"
description = "Safety-critical embedded language for medical devices"
version = "1.0"

[platform]
target = "arm-cortex-m4"
max_ram_kb = 256
max_flash_kb = 512
heap_allowed = false
os = "bare-metal"
float = "soft"

[safety]
memory_safety = "full"
null_allowed = false
overflow = "checked"
array_bounds = "static"
concurrency = "none"
recursion = "bounded"
stack_usage = "analyzed"

[types]
integers = ["u8", "u16", "u32", "i8", "i16", "i32"]
floats = []
strings = "fixed"
generics = false
traits = false
enums = true
structs = true
tuples = true
references = "borrow"

[syntax]
keyword_language = "en"
max_keywords = 25
block_style = "braces"
comment_style = "slashslash"
semicolons = true
indent_significant = false
operator_overloading = false

[control_flow]
if_else = true
match_exhaustive = true
for_loop = true
while_loop = false
goto_allowed = false
exceptions = false
early_return = true

[modules]
imports = true
visibility = "explicit"
namespaces = "flat"

[output]
emit = "c"
optimization = "size"
debug_info = true
"#;
        let c = parse_constraints(toml).unwrap();
        assert_eq!(c.meta.name, "SafeEmbed");
        assert_eq!(c.platform.target, TargetPlatform::ArmCortexM4);
        assert!(!c.platform.heap_allowed);
        assert_eq!(c.safety.memory_safety, SafetyLevel::Full);
        assert!(!c.control_flow.while_loop);
        assert_eq!(c.output.emit, EmitTarget::C);
    }

    #[test]
    fn conflict_heap_false_strings_dynamic() {
        let toml = r#"
[meta]
name = "Conflict"

[platform]
heap_allowed = false

[types]
strings = "dynamic"
"#;
        let c = parse_constraints(toml).unwrap();
        let conflicts = detect_conflicts(&c);
        assert!(!conflicts.is_empty());
        let heap_conflict = conflicts
            .iter()
            .find(|c| c.reason.contains("heap"))
            .expect("should find heap conflict");
        assert_eq!(heap_conflict.severity, ConflictSeverity::Error);
    }

    #[test]
    fn conflict_float_none_with_floats() {
        let toml = r#"
[meta]
name = "FloatConflict"

[platform]
float = "none"

[types]
floats = ["f32"]
"#;
        let c = parse_constraints(toml).unwrap();
        let conflicts = detect_conflicts(&c);
        assert!(conflicts.iter().any(|c| c.reason.contains("float")));
    }

    #[test]
    fn conflict_indent_significant_braces() {
        let toml = r#"
[meta]
name = "IndentConflict"

[syntax]
indent_significant = true
block_style = "braces"
"#;
        let c = parse_constraints(toml).unwrap();
        let conflicts = detect_conflicts(&c);
        assert!(conflicts
            .iter()
            .any(|c| c.reason.contains("indentation")));
    }

    #[test]
    fn conflict_while_false_recursion_forbidden() {
        let toml = r#"
[meta]
name = "IterConflict"

[control_flow]
while_loop = false

[safety]
recursion = "forbidden"
"#;
        let c = parse_constraints(toml).unwrap();
        let conflicts = detect_conflicts(&c);
        assert!(conflicts
            .iter()
            .any(|c| c.reason.contains("unbounded iteration")));
    }

    #[test]
    fn no_conflicts_for_valid_constraints() {
        let toml = r#"
[meta]
name = "Valid"

[platform]
heap_allowed = true

[types]
strings = "dynamic"

[syntax]
block_style = "braces"
indent_significant = false
"#;
        let c = parse_constraints(toml).unwrap();
        let conflicts = detect_conflicts(&c);
        assert!(conflicts.is_empty());
    }

    #[test]
    fn dof_analysis() {
        let toml = r#"
[meta]
name = "DoFTest"

[platform]
target = "arm-cortex-m4"
"#;
        let c = parse_constraints(toml).unwrap();
        let dof = compute_dof(&c);
        assert!(dof.total_constraints > 0);
        assert!(dof.determined > 0);
    }

    #[test]
    fn reject_invalid_toml() {
        let result = parse_constraints("not valid toml {{{}");
        assert!(result.is_err());
    }

    #[test]
    fn parse_minimal_constraints() {
        let toml = r#"
[meta]
name = "Minimal"
"#;
        let c = parse_constraints(toml).unwrap();
        assert_eq!(c.meta.name, "Minimal");
        // Defaults should be applied
        assert!(c.platform.heap_allowed);
        assert_eq!(c.syntax.block_style, BlockStyle::Braces);
    }
}

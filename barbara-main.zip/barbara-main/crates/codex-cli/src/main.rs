//! codex — PSE-Codex Command-Line Interface
//!
//! Provides commands for observing source code, computing topology,
//! managing pattern memory, and generating code from crystals.

use clap::{Parser, Subcommand};
use codex_learn::CodexEngine;
use codex_topo::TopoConfig;
use std::path::{Path, PathBuf};

#[derive(Parser)]
#[command(name = "codex", about = "PSE-Codex: Language-Independent Code Intelligence")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand)]
enum Commands {
    /// Observe a source file and produce topology + crystals.
    Observe {
        /// Path to source file or directory.
        path: PathBuf,
        /// Recurse into directories.
        #[arg(short, long)]
        recursive: bool,
        /// Filter by language.
        #[arg(short, long)]
        language: Option<String>,
    },
    /// Show topology of a file.
    Topology {
        /// Path to source file.
        path: PathBuf,
    },
    /// Show crystals in pattern memory.
    Crystals {
        /// Filter by language.
        #[arg(short, long)]
        language: Option<String>,
    },
    /// Cross-language similarity check.
    Compare {
        /// First file.
        file1: PathBuf,
        /// Second file.
        file2: PathBuf,
    },
    /// Generate code from a crystal.
    Generate {
        /// Crystal ID.
        #[arg(long)]
        crystal: String,
        /// Target language.
        #[arg(short, long)]
        language: String,
    },
    /// Pattern memory status.
    Memory,
    /// Full pipeline demo with embedded corpus.
    Demo,
    /// Analyze an entire Rust workspace topologically.
    Analyze {
        /// Path to the workspace root.
        path: PathBuf,
        /// Save full analysis to JSON file.
        #[arg(short, long)]
        output: Option<PathBuf>,
        /// Show per-file breakdown.
        #[arg(short, long)]
        verbose: bool,
    },
    /// Export crystals from a workspace analysis to JSON.
    Export {
        /// Workspace root to analyze.
        #[arg(long)]
        workspace: PathBuf,
        /// Output JSON file path.
        #[arg(short, long)]
        output: PathBuf,
        /// Minimum number of instances to include a crystal (default: 1).
        #[arg(long, default_value = "1")]
        min_instances: usize,
        /// Output format: "json" (default).
        #[arg(long, default_value = "json")]
        format: String,
    },
    /// Find recurring function patterns in a workspace.
    Patterns {
        /// Path to the workspace root.
        path: PathBuf,
        /// Minimum number of instances to show (default: 2).
        #[arg(long, default_value = "2")]
        min_instances: usize,
    },
    /// Compare two workspaces topologically.
    CompareWorkspaces {
        /// First workspace root.
        path1: PathBuf,
        /// Second workspace root.
        path2: PathBuf,
    },
}

fn main() {
    let cli = Cli::parse();

    match cli.command {
        Commands::Observe {
            path,
            recursive,
            language,
        } => cmd_observe(&path, recursive, language.as_deref()),
        Commands::Topology { path } => cmd_topology(&path),
        Commands::Crystals { language } => cmd_crystals(language.as_deref()),
        Commands::Compare { file1, file2 } => cmd_compare(&file1, &file2),
        Commands::Generate { crystal, language } => cmd_generate(&crystal, &language),
        Commands::Memory => cmd_memory(),
        Commands::Demo => cmd_demo(),
        Commands::Analyze { path, output, verbose } => cmd_analyze(&path, output.as_deref(), verbose),
        Commands::Export { workspace, output, min_instances, format } => {
            cmd_export(&workspace, &output, min_instances, &format)
        }
        Commands::Patterns { path, min_instances } => cmd_patterns(&path, min_instances),
        Commands::CompareWorkspaces { path1, path2 } => cmd_compare_workspaces(&path1, &path2),
    }
}

fn cmd_observe(path: &PathBuf, recursive: bool, _language: Option<&str>) {
    let mut engine = CodexEngine::new();

    if path.is_file() {
        match engine.observe_file(path) {
            Ok(result) => {
                println!(
                    "  {}: {} nodes, depth {}, {:.1}ms{}",
                    path.display(),
                    result.metadata.total_nodes,
                    result.metadata.max_depth,
                    result.elapsed_us as f64 / 1000.0,
                    if result.hit { " [HIT]" } else { " [NEW]" }
                );
            }
            Err(e) => eprintln!("Error: {}", e),
        }
    } else if path.is_dir() {
        let files = collect_source_files(path, recursive);
        println!("Observing {} files...", files.len());
        for file in &files {
            match engine.observe_file(file) {
                Ok(result) => {
                    println!(
                        "  {}: {} nodes, depth {}, {:.1}ms{}",
                        file.display(),
                        result.metadata.total_nodes,
                        result.metadata.max_depth,
                        result.elapsed_us as f64 / 1000.0,
                        if result.hit { " [HIT]" } else { " [NEW]" }
                    );
                }
                Err(e) => eprintln!("  {} Error: {}", file.display(), e),
            }
        }
        println!(
            "\nCrystals: {}, Hits: {}, Misses: {}",
            engine.crystal_count(),
            engine.memory_hits(),
            engine.memory_misses()
        );
    }
}

fn cmd_topology(path: &PathBuf) {
    let config = TopoConfig::default();
    let source = match std::fs::read_to_string(path) {
        Ok(s) => s,
        Err(e) => {
            eprintln!("Error reading {}: {}", path.display(), e);
            return;
        }
    };
    let language = match codex_parse::detect_language(path) {
        Some(l) => l,
        None => {
            eprintln!("Cannot detect language for {}", path.display());
            return;
        }
    };

    match codex_topo::topology_from_source(&source, &language, &config) {
        Ok(topo) => {
            println!("Topology for {}:", path.display());
            println!("  Spectral signature: {:?}", &topo.spectral_signature[..topo.spectral_signature.len().min(8)]);
            println!("  Spectral gap: {:.4}", topo.spectral_gap);
            println!("  Fiedler value: {:.4}", topo.fiedler_value);
            println!("  Betti numbers: {:?}", topo.betti);
            println!("  Kuramoto order: {:.4}", topo.kuramoto_order);
            println!("  Sync clusters: {}", topo.sync_clusters);
            println!("  Cyclomatic complexity: {}", topo.cyclomatic_complexity);
            println!("  Structural volume: {:.2}", topo.structural_volume);
        }
        Err(e) => eprintln!("Error: {}", e),
    }
}

fn cmd_crystals(_language: Option<&str>) {
    println!("No crystals in memory. Use 'codex observe' first.");
}

fn cmd_compare(file1: &PathBuf, file2: &PathBuf) {
    let config = TopoConfig::default();

    let read_and_topo = |path: &PathBuf| -> Option<codex_topo::CodeTopology> {
        let source = std::fs::read_to_string(path).ok()?;
        let language = codex_parse::detect_language(path)?;
        codex_topo::topology_from_source(&source, &language, &config).ok()
    };

    let topo1 = match read_and_topo(file1) {
        Some(t) => t,
        None => {
            eprintln!("Could not analyze {}", file1.display());
            return;
        }
    };
    let topo2 = match read_and_topo(file2) {
        Some(t) => t,
        None => {
            eprintln!("Could not analyze {}", file2.display());
            return;
        }
    };

    let sim = codex_topo::topology_similarity(&topo1, &topo2);
    println!(
        "Similarity: {:.4} ({} vs {})",
        sim,
        file1.display(),
        file2.display()
    );
}

fn cmd_generate(_crystal_id: &str, _language: &str) {
    println!("Code generation requires an active pattern memory. Use 'codex demo' for demonstration.");
}

fn cmd_memory() {
    println!("Pattern memory: empty. Use 'codex observe' to populate.");
}

fn cmd_demo() {
    println!("=== PSE-Codex Demo ===\n");

    let mut engine = CodexEngine::new();
    let corpus_dir = PathBuf::from("corpus");

    if !corpus_dir.exists() {
        eprintln!("Corpus directory not found. Run from the project root.");
        return;
    }

    let languages = ["python", "rust", "javascript", "go"];
    let mut _total_crystals_before = 0;

    for language in &languages {
        let lang_dir = corpus_dir.join(language);
        if !lang_dir.exists() {
            println!("Skipping {} (no corpus)", language);
            continue;
        }

        let files = collect_source_files(&lang_dir, false);
        let hits_before = engine.memory_hits();
        let crystals_before = engine.crystal_count();

        println!("Phase: {} ({} files)", language, files.len());

        for file in &files {
            match engine.observe_file(file) {
                Ok(result) => {
                    println!(
                        "  {}: {} nodes, {:.1}ms {}",
                        file.file_name().unwrap_or_default().to_string_lossy(),
                        result.metadata.total_nodes,
                        result.elapsed_us as f64 / 1000.0,
                        if result.hit { "[HIT]" } else { "[NEW]" }
                    );
                }
                Err(e) => eprintln!("  Error: {}", e),
            }
        }

        let new_crystals = engine.crystal_count() - crystals_before;
        let new_hits = engine.memory_hits() - hits_before;
        println!(
            "  New crystals: {}, Memory hits: {} ({:.0}% recognition)\n",
            new_crystals,
            new_hits,
            if new_crystals + new_hits as usize > 0 {
                new_hits as f64 / (new_crystals as f64 + new_hits as f64) * 100.0
            } else {
                0.0
            }
        );
        _total_crystals_before = engine.crystal_count();
    }

    println!("=== Summary ===");
    println!("Total unique crystals: {}", engine.crystal_count());
    println!("Total memory hits: {}", engine.memory_hits());
    println!("Total memory misses: {}", engine.memory_misses());
    println!(
        "Overall hit rate: {:.1}%",
        engine.hit_rate() * 100.0
    );
}

// ── New workspace commands ────────────────────────────────────────────────────

fn cmd_analyze(path: &PathBuf, output: Option<&Path>, verbose: bool) {
    println!("=== Barbara Analysis: {} ===\n", path.display());

    let analysis = codex_topo::parse_workspace(path);
    let stats = &analysis.stats;

    println!(
        "Workspace: {} crates, {} files, {} LOC ({} parse errors)",
        stats.total_crates,
        stats.total_files,
        stats.total_loc,
        stats.parse_errors,
    );
    println!();

    // Print crate topology map.
    let report = codex_topo::analyze_crate_relationships(&analysis);

    if !report.architectural_layers.is_empty() {
        println!("=== Crate Topology Map ===");
        for (i, layer) in report.architectural_layers.iter().enumerate() {
            println!("  Layer {}: {}", i + 1, layer.join(", "));
        }
        println!();
    }

    // Print architectural insights.
    println!("=== Architectural Insights ===");
    if report.potential_duplicates.is_empty() {
        println!("  No potential duplicate crates detected.");
    } else {
        for (a, b, sim) in &report.potential_duplicates {
            println!("  - {} and {} have {:.0}% similarity → potential merge candidate", a, b, sim * 100.0);
        }
    }
    if !report.isolated_crates.is_empty() {
        println!("  - Isolated crates (no similar partner): {}", report.isolated_crates.join(", "));
    }
    println!();

    // Print clusters.
    if !report.clusters.is_empty() {
        println!("=== Crate Clusters ===");
        for cluster in &report.clusters {
            println!(
                "  {} (avg similarity {:.2}): {}",
                cluster.description,
                cluster.avg_internal_similarity,
                cluster.crates.join(", ")
            );
        }
        println!();
    }

    // Workspace stats.
    println!("=== Workspace Stats ===");
    println!("  Functions: {}", stats.total_functions);
    println!("  Structs/Classes: {}", stats.total_structs);
    println!("  Tests: {}", stats.total_tests);

    // Per-crate breakdown in verbose mode.
    if verbose {
        println!("\n=== Per-Crate Breakdown ===");
        for ct in &analysis.crate_topologies {
            println!(
                "  {:30} files={:3}  loc={:6}  fn={:4}  cc={:3}",
                ct.name, ct.file_count, ct.total_loc, ct.function_count,
                ct.topology.cyclomatic_complexity
            );
        }
    }

    // Save JSON output.
    if let Some(out_path) = output {
        match serde_json::to_string_pretty(&analysis) {
            Ok(json) => {
                if let Err(e) = std::fs::write(out_path, json) {
                    eprintln!("Error saving analysis: {}", e);
                } else {
                    println!("\nAnalysis saved to {}", out_path.display());
                }
            }
            Err(e) => eprintln!("Serialization error: {}", e),
        }
    }
}

fn cmd_export(workspace: &PathBuf, output: &PathBuf, min_instances: usize, _format: &str) {
    println!("Analyzing workspace {}...", workspace.display());
    let analysis = codex_topo::parse_workspace(workspace);

    // Use CodexEngine to crystallize all files and then export.
    let mut engine = CodexEngine::new();
    for file_analysis in &analysis.files {
        if let Ok(result) = engine.observe_file(std::path::Path::new(&file_analysis.path)) {
            let _ = result;
        }
    }

    let crystals = engine.crystals();
    let filtered: Vec<_> = crystals
        .iter()
        .filter(|c| c.observed_languages.len() >= min_instances)
        .cloned()
        .collect();

    println!("Crystals: {} total, {} with ≥{} instances", crystals.len(), filtered.len(), min_instances);

    match codex_learn::export_to_json(&filtered) {
        Ok(json) => {
            if let Err(e) = std::fs::write(output, &json) {
                eprintln!("Error saving: {}", e);
            } else {
                println!("Exported {} crystals to {}", filtered.len(), output.display());
            }
        }
        Err(e) => eprintln!("Serialization error: {}", e),
    }
}

fn cmd_patterns(path: &PathBuf, min_instances: usize) {
    println!("Mining function patterns in {}...\n", path.display());

    let config = TopoConfig::default();
    let report = codex_learn::mine_function_patterns(path, &config, 0.88);

    println!("Total functions analyzed: {}", report.total_functions);
    println!("Recurring patterns: {}", report.patterns.len());
    println!("Unique functions: {}", report.unique_functions.len());
    println!();

    let patterns: Vec<_> = report
        .patterns
        .iter()
        .filter(|p| p.instances.len() >= min_instances)
        .take(10)
        .collect();

    if patterns.is_empty() {
        println!("No patterns with ≥{} instances found.", min_instances);
        return;
    }

    println!("=== Top Patterns ===");
    for (i, pattern) in patterns.iter().enumerate() {
        println!(
            "  {}. {} ({} instances) — {}",
            i + 1,
            pattern.pattern_id,
            pattern.instances.len(),
            pattern.description
        );
        for inst in pattern.instances.iter().take(3) {
            println!("     · {}::{} ({})", inst.crate_name, inst.function_name, inst.file);
        }
        if pattern.instances.len() > 3 {
            println!("     · ... and {} more", pattern.instances.len() - 3);
        }
    }

    if let Some(dom) = &report.dominant_pattern {
        println!("\nDominant pattern: {} ({} instances)", dom.pattern_id, dom.instances.len());
    }
}

fn cmd_compare_workspaces(path1: &PathBuf, path2: &PathBuf) {
    println!("Comparing workspaces:");
    println!("  A: {}", path1.display());
    println!("  B: {}", path2.display());
    println!();

    let ws1 = codex_topo::parse_workspace(path1);
    let ws2 = codex_topo::parse_workspace(path2);

    let overall_sim = codex_topo::topology_similarity(
        &ws1.workspace_topology,
        &ws2.workspace_topology,
    );

    println!("Overall workspace similarity: {:.4}", overall_sim);
    println!();
    println!("  A: {} crates, {} files, {} LOC", ws1.stats.total_crates, ws1.stats.total_files, ws1.stats.total_loc);
    println!("  B: {} crates, {} files, {} LOC", ws2.stats.total_crates, ws2.stats.total_files, ws2.stats.total_loc);

    // Find crates with similar names (same-name comparison).
    println!("\nSame-name crate comparison:");
    for ct1 in &ws1.crate_topologies {
        if let Some(ct2) = ws2.crate_topologies.iter().find(|c| c.name == ct1.name) {
            let sim = codex_topo::topology_similarity(&ct1.topology, &ct2.topology);
            println!("  {:30} similarity: {:.4}", ct1.name, sim);
        }
    }
}

// ── Utilities ─────────────────────────────────────────────────────────────────

fn collect_source_files(dir: &PathBuf, recursive: bool) -> Vec<PathBuf> {
    let mut files = Vec::new();
    if let Ok(entries) = std::fs::read_dir(dir) {
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_file() {
                if codex_parse::detect_language(&path).is_some() {
                    files.push(path);
                }
            } else if recursive && path.is_dir() {
                files.extend(collect_source_files(&path, true));
            }
        }
    }
    files.sort();
    files
}

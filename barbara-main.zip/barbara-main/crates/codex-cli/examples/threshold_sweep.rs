//! Round 5: Threshold sweep to find optimal recognition/precision trade-off.
//!
//! Tests the CodexEngine at thresholds 0.70, 0.75, 0.80, 0.85, 0.88, 0.90, 0.92, 0.95.
//! Measures cross-language recognition (Python→Rust/JS/Go) and intra-language
//! discrimination (how many unique crystals Python creates — lower = more merges = worse precision).
//!
//! ```
//! cargo run --example threshold_sweep --manifest-path crates/codex-cli/Cargo.toml
//! ```

use codex_learn::CodexEngine;
use codex_topo::TopoConfig;
use std::path::PathBuf;

fn workspace_root() -> PathBuf {
    let manifest = env!("CARGO_MANIFEST_DIR");
    PathBuf::from(manifest)
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf()
}

fn corpus_files(language: &str, ext: &str) -> Vec<PathBuf> {
    let dir = workspace_root().join(format!("corpus/{}", language));
    if !dir.exists() {
        return vec![];
    }
    let mut files: Vec<PathBuf> = std::fs::read_dir(&dir)
        .unwrap()
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|e| e == ext).unwrap_or(false))
        .collect();
    files.sort();
    files
}

fn run_at_threshold(threshold: f64) -> (usize, usize, usize, usize, usize, f64) {
    // Returns: (py_crystals, rs_hits, js_hits, go_hits, total_crystals, hit_rate)
    let mut engine = CodexEngine::with_config(TopoConfig::default(), threshold);

    let py_files = corpus_files("python", "py");
    let rs_files = corpus_files("rust", "rs");
    let js_files = corpus_files("javascript", "js");
    let go_files = corpus_files("go", "go");

    // Phase 1: Python
    for f in &py_files {
        let _ = engine.observe_file(f);
    }
    let py_crystals = engine.crystal_count();

    // Phase 2: Rust
    let hits_before = engine.memory_hits();
    for f in &rs_files {
        let _ = engine.observe_file(f);
    }
    let rs_hits = (engine.memory_hits() - hits_before) as usize;

    // Phase 3: JavaScript
    let hits_before = engine.memory_hits();
    for f in &js_files {
        let _ = engine.observe_file(f);
    }
    let js_hits = (engine.memory_hits() - hits_before) as usize;

    // Phase 4: Go
    let hits_before = engine.memory_hits();
    for f in &go_files {
        let _ = engine.observe_file(f);
    }
    let go_hits = (engine.memory_hits() - hits_before) as usize;

    let total_crystals = engine.crystal_count();
    let hit_rate = engine.hit_rate();

    (py_crystals, rs_hits, js_hits, go_hits, total_crystals, hit_rate)
}

fn main() {
    println!("=== Barbara Threshold Sweep ===\n");
    println!(
        "{:<10}  {:>10}  {:>7}  {:>7}  {:>7}  {:>13}  {:>9}  {:>8}",
        "Threshold", "Py-crystals", "Rs-hits", "JS-hits", "Go-hits", "Total-crystals", "Hit-rate", "RecPy→Rx"
    );
    println!("{}", "-".repeat(90));

    let thresholds = [0.70, 0.75, 0.80, 0.82, 0.84, 0.86, 0.88, 0.90, 0.92, 0.95, 0.96];

    for &t in &thresholds {
        let (py, rs, js, go, total, rate) = run_at_threshold(t);
        // Cross-language recognition: how many of the 30 non-Python files were recognized
        let non_py_hits = rs + js + go;
        let non_py_total = 30usize;  // 10 Rust + 10 JS + 10 Go
        let cross_lang_rec = non_py_hits as f64 / non_py_total as f64 * 100.0;
        println!(
            "{:<10.2}  {:>10}  {:>7}  {:>7}  {:>7}  {:>13}  {:>8.1}%  {:>7.1}%",
            t, py, rs, js, go, total, rate * 100.0, cross_lang_rec
        );
    }

    println!("\nNotes:");
    println!("  Py-crystals: # unique patterns from Python (higher = better discrimination)");
    println!("  Rs/JS/Go-hits: # of 10 files recognized as cross-language hits");
    println!("  Total-crystals: ideal = 10 (one per algorithm)");
    println!("  Hit-rate: overall (incl. intra-language hits)");
    println!("  RecPy→Rx: cross-language recognition = (Rs+JS+Go hits) / 30");
}

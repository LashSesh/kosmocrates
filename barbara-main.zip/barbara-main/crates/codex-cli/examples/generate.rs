//! Example: Generate code from crystals in multiple languages.

use codex_generate::{generate, GenerateConfig};
use codex_learn::{CodePatternType, CodexEngine};

fn main() {
    println!("=== PSE-Codex: Code Generation ===\n");

    let mut engine = CodexEngine::new();

    // Observe a CRUD handler to create a crystal
    let python_crud = r#"
class ItemStore:
    def __init__(self):
        self.items = {}

    def create(self, item_id, data):
        if item_id in self.items:
            raise ValueError("exists")
        self.items[item_id] = data
        return data

    def read(self, item_id):
        if item_id not in self.items:
            raise KeyError("not found")
        return self.items[item_id]

    def update(self, item_id, data):
        if item_id not in self.items:
            raise KeyError("not found")
        self.items[item_id] = data
        return data

    def delete(self, item_id):
        if item_id not in self.items:
            raise KeyError("not found")
        return self.items.pop(item_id)
"#;

    engine
        .observe_source(python_crud, "python", Some("crud.py"))
        .unwrap();

    println!("Observed Python CRUD handler → {} crystal(s)\n", engine.crystal_count());

    let config = GenerateConfig::default();
    let languages = ["python", "rust", "javascript", "go"];

    for crystal in engine.crystals() {
        println!("Crystal: {:?}", crystal.pattern_type);
        for lang in &languages {
            match generate(crystal, lang, &config) {
                Ok(gen) => {
                    println!(
                        "  {} → {} bytes (similarity: {:.2}, method: {:?})",
                        lang,
                        gen.code.len(),
                        gen.topology_similarity,
                        gen.method,
                    );
                }
                Err(e) => println!("  {} → Error: {}", lang, e),
            }
        }
        println!();
    }
}

//! Round 1 Diagnostic: Cross-language similarity matrix.
//!
//! For each of the 10 algorithms, compute topology similarity between
//! all 6 language pairs (Py-Rs, Py-JS, Py-Go, Rs-JS, Rs-Go, JS-Go).
//! Print a matrix showing exact similarity scores plus component breakdown.
//!
//! ```
//! cargo run --example similarity_matrix --manifest-path crates/codex-cli/Cargo.toml
//! ```

use codex_topo::{topology_from_source, topology_similarity, TopoConfig, CodeTopology};
use std::path::PathBuf;

fn workspace_root() -> PathBuf {
    let manifest = env!("CARGO_MANIFEST_DIR");
    PathBuf::from(manifest)
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf()
}

fn read_corpus(language: &str, filename: &str) -> Option<String> {
    let path = workspace_root().join(format!("corpus/{}/{}", language, filename));
    std::fs::read_to_string(path).ok()
}

fn topo(source: &str, language: &str) -> Option<CodeTopology> {
    topology_from_source(source, language, &TopoConfig::default()).ok()
}

struct Breakdown {
    spectral: f64,
    betti: f64,
    kuramoto: f64,
    depth: f64,
    kind: f64,
    cf: f64,      // control flow LCS similarity
    ratios: f64,  // structural ratios similarity
    cc: f64,
    volume: f64,
    density: f64,
    total: f64,
}

fn lcs_ratio(a: &[codex_parse::NodeKind], b: &[codex_parse::NodeKind]) -> f64 {
    codex_topo::control_flow_similarity(a, b)
}

fn ratios_sim_local(a: &codex_topo::StructuralRatios, b: &codex_topo::StructuralRatios) -> f64 {
    let diffs = [
        (a.control_density - b.control_density).abs(),
        (a.function_density - b.function_density).abs(),
        (a.call_density - b.call_density).abs(),
        (a.nesting_ratio - b.nesting_ratio).abs().min(1.0),
        (a.leaf_ratio - b.leaf_ratio).abs(),
    ];
    (1.0 - diffs.iter().sum::<f64>() / diffs.len() as f64).clamp(0.0, 1.0)
}

fn breakdown(a: &CodeTopology, b: &CodeTopology) -> Breakdown {
    let spectral = cosine_sim(&a.spectral_signature, &b.spectral_signature);
    let betti = betti_sim(&a.betti, &b.betti);
    let kuramoto = 1.0 - (a.kuramoto_order - b.kuramoto_order).abs();
    let depth = hist_corr(&a.depth_histogram, &b.depth_histogram);
    let kind = kind_sim(&a.kind_distribution, &b.kind_distribution);
    let cf = lcs_ratio(&a.control_flow_sequence, &b.control_flow_sequence);
    let ratios = ratios_sim_local(&a.structural_ratios, &b.structural_ratios);
    let cc = {
        let mx = (a.cyclomatic_complexity.max(b.cyclomatic_complexity)).max(1) as f64;
        1.0 - (a.cyclomatic_complexity as f64 - b.cyclomatic_complexity as f64).abs() / mx
    };
    let volume = {
        let mx = a.structural_volume.max(b.structural_volume).max(1.0);
        1.0 - (a.structural_volume - b.structural_volume).abs() / mx
    };
    let density = 1.0 - (a.call_density - b.call_density).abs();
    let total = topology_similarity(a, b);
    Breakdown { spectral, betti, kuramoto, depth, kind, cf, ratios, cc, volume, density, total }
}

fn cosine_sim(a: &[f64], b: &[f64]) -> f64 {
    let len = a.len().max(b.len());
    if len == 0 { return 1.0; }
    let mut dot = 0.0f64;
    let mut na = 0.0f64;
    let mut nb = 0.0f64;
    for i in 0..len {
        let va = a.get(i).copied().unwrap_or(0.0);
        let vb = b.get(i).copied().unwrap_or(0.0);
        dot += va * vb;
        na += va * va;
        nb += vb * vb;
    }
    if na < 1e-12 || nb < 1e-12 {
        if na < 1e-12 && nb < 1e-12 { return 1.0; }
        return 0.0;
    }
    (dot / (na.sqrt() * nb.sqrt())).clamp(0.0, 1.0)
}

fn betti_sim(a: &[usize], b: &[usize]) -> f64 {
    let len = a.len().max(b.len());
    if len == 0 { return 1.0; }
    let mut total = 0.0f64;
    for i in 0..len {
        let va = *a.get(i).unwrap_or(&0) as f64;
        let vb = *b.get(i).unwrap_or(&0) as f64;
        let mx = va.max(vb).max(1.0);
        total += 1.0 - (va - vb).abs() / mx;
    }
    total / len as f64
}

fn hist_corr(a: &[f64], b: &[f64]) -> f64 {
    // depth_histogram is now a normalized probability distribution
    cosine_sim(a, b)
}

fn kind_sim(a: &[(codex_parse::NodeKind, u32)], b: &[(codex_parse::NodeKind, u32)]) -> f64 {
    let mut all: Vec<codex_parse::NodeKind> = Vec::new();
    for (k, _) in a.iter().chain(b.iter()) {
        if !all.contains(k) { all.push(k.clone()); }
    }
    if all.is_empty() { return 1.0; }
    let av: Vec<f64> = all.iter().map(|k| {
        a.iter().find(|(ki, _)| ki == k).map(|(_, c)| *c as f64).unwrap_or(0.0)
    }).collect();
    let bv: Vec<f64> = all.iter().map(|k| {
        b.iter().find(|(ki, _)| ki == k).map(|(_, c)| *c as f64).unwrap_or(0.0)
    }).collect();
    let at: f64 = av.iter().sum::<f64>().max(1.0);
    let bt: f64 = bv.iter().sum::<f64>().max(1.0);
    let an: Vec<f64> = av.iter().map(|v| v / at).collect();
    let bn: Vec<f64> = bv.iter().map(|v| v / bt).collect();
    cosine_sim(&an, &bn)
}

struct AlgoSpec {
    name: &'static str,
    py: &'static str,
    rs: &'static str,
    js: &'static str,
    go: &'static str,
}

const ALGORITHMS: &[AlgoSpec] = &[
    AlgoSpec { name: "01_fibonacci",      py: "01_fibonacci.py",      rs: "01_fibonacci.rs",      js: "01_fibonacci.js",      go: "01_fibonacci.go"      },
    AlgoSpec { name: "02_binary_search",  py: "02_binary_search.py",  rs: "02_binary_search.rs",  js: "02_binary_search.js",  go: "02_binary_search.go"  },
    AlgoSpec { name: "03_bubble_sort",    py: "03_bubble_sort.py",    rs: "03_bubble_sort.rs",    js: "03_bubble_sort.js",    go: "03_bubble_sort.go"    },
    AlgoSpec { name: "04_http_handler",   py: "04_http_handler.py",   rs: "04_http_handler.rs",   js: "04_http_handler.js",   go: "04_http_handler.go"   },
    AlgoSpec { name: "05_file_transform", py: "05_file_transform.py", rs: "05_file_transform.rs", js: "05_file_transform.js", go: "05_file_transform.go" },
    AlgoSpec { name: "06_linked_list",    py: "06_linked_list.py",    rs: "06_linked_list.rs",    js: "06_linked_list.js",    go: "06_linked_list.go"    },
    AlgoSpec { name: "07_json_validate",  py: "07_json_validate.py",  rs: "07_json_validate.rs",  js: "07_json_validate.js",  go: "07_json_validate.go"  },
    AlgoSpec { name: "08_observer",       py: "08_observer_pattern.py", rs: "08_observer_pattern.rs", js: "08_observer_pattern.js", go: "08_observer_pattern.go" },
    AlgoSpec { name: "09_async_fetch",    py: "09_async_fetch.py",    rs: "09_async_fetch.rs",    js: "09_async_fetch.js",    go: "09_async_fetch.go"    },
    AlgoSpec { name: "10_binary_tree",    py: "10_binary_tree.py",    rs: "10_binary_tree.rs",    js: "10_binary_tree.js",    go: "10_binary_tree.go"    },
];

/// Apply a custom weight config to a breakdown.
/// Weights order: [spectral, betti, kuramoto, depth, kind, cf, ratios, cc, volume, density]
fn apply_weights(bd: &Breakdown, w: &[f64; 8]) -> f64 {
    // Map 8-weight configs to the 8 most informative dimensions (drop density for cfg comparison)
    // cfg order: spectral, betti, kuramoto, depth, kind, cf_or_cc, ratios_or_vol, cc_or_dens
    // We'll use: spectral, betti, kuramoto, depth, kind, cc, volume, density (original 8)
    let vals = [bd.spectral, bd.betti, bd.kuramoto, bd.depth, bd.kind, bd.cc, bd.volume, bd.density];
    let s: f64 = vals.iter().zip(w.iter()).map(|(v, w)| v * w).sum();
    s.clamp(0.0, 1.0)
}

fn compare_configs(breakdowns: &[(&str, Vec<Breakdown>)]) {
    // Round 2 winner (Config A — no structural features)
    let cfg_a: [f64; 8] = [0.25, 0.10, 0.10, 0.20, 0.20, 0.07, 0.08, 0.00];
    // Round 4 Option 1: tiny cf+ratios, drop volume
    let cfg_r4a: [f64; 8] = [0.25, 0.10, 0.10, 0.20, 0.20, 0.05, 0.03, 0.07];
    // Round 4 Option 2: minimal cf+ratios, keep some volume
    let cfg_r4b: [f64; 8] = [0.23, 0.09, 0.09, 0.20, 0.19, 0.06, 0.04, 0.10];
    // Round 4 Option 3: current (heavy cf+ratios — likely hurting)
    let cfg_r4c: [f64; 8] = [0.22, 0.09, 0.09, 0.18, 0.18, 0.12, 0.07, 0.05];
    // Baseline (original library weights)
    let cfg_base: [f64; 8] = [0.25, 0.10, 0.10, 0.15, 0.15, 0.10, 0.10, 0.05];

    let configs = [
        ("Baseline",  &cfg_base),
        ("R2-Config A", &cfg_a),
        ("R4-Opt1",   &cfg_r4a),
        ("R4-Opt2",   &cfg_r4b),
        ("R4-Opt3",   &cfg_r4c),
    ];

    println!("\n=== Weight Config Comparison ===");
    for (name, w) in &configs {
        let mut scores: Vec<f64> = Vec::new();
        let mut above_90 = 0usize;
        let mut above_85 = 0usize;
        let mut min_score = 1.0f64;

        for (_, bds) in breakdowns {
            for bd in bds {
                let s = apply_weights(bd, w);
                scores.push(s);
                if s >= 0.90 { above_90 += 1; }
                if s >= 0.85 { above_85 += 1; }
                if s < min_score { min_score = s; }
            }
        }

        let n = scores.len();
        let avg = scores.iter().sum::<f64>() / n as f64;
        println!(
            "  {:10}  avg={:.4}  above_0.90={:2}/60  above_0.85={:2}/60  min={:.4}  weights=[spec={:.2} betti={:.2} kur={:.2} dep={:.2} kind={:.2} cc={:.2} vol={:.2} dens={:.2}]",
            name, avg, above_90, above_85, min_score,
            w[0], w[1], w[2], w[3], w[4], w[5], w[6], w[7]
        );
    }
}

fn main() {
    println!("=== Barbara Similarity Matrix (Baseline) ===\n");

    let header = format!(
        "{:<22}  {:>6}  {:>6}  {:>6}  {:>6}  {:>6}  {:>6}  {:>6}",
        "Algorithm", "Py-Rs", "Py-JS", "Py-Go", "Rs-JS", "Rs-Go", "JS-Go", "Avg"
    );
    println!("{}", header);
    println!("{}", "-".repeat(header.len()));

    let mut all_scores: Vec<f64> = Vec::new();
    let mut above_80 = 0usize;
    let mut above_70 = 0usize;
    let mut above_60 = 0usize;
    let total_pairs = ALGORITHMS.len() * 6;

    let mut algo_breakdowns: Vec<(&str, Vec<Breakdown>)> = Vec::new();

    for algo in ALGORITHMS {
        let py_src = read_corpus("python", algo.py);
        let rs_src = read_corpus("rust", algo.rs);
        let js_src = read_corpus("javascript", algo.js);
        let go_src = read_corpus("go", algo.go);

        let py = py_src.as_deref().and_then(|s| topo(s, "python"));
        let rs = rs_src.as_deref().and_then(|s| topo(s, "rust"));
        let js = js_src.as_deref().and_then(|s| topo(s, "javascript"));
        let go = go_src.as_deref().and_then(|s| topo(s, "go"));

        let score = |a: &Option<CodeTopology>, b: &Option<CodeTopology>| -> Option<f64> {
            match (a, b) {
                (Some(a), Some(b)) => Some(topology_similarity(a, b)),
                _ => None,
            }
        };

        let py_rs = score(&py, &rs);
        let py_js = score(&py, &js);
        let py_go = score(&py, &go);
        let rs_js = score(&rs, &js);
        let rs_go = score(&rs, &go);
        let js_go = score(&js, &go);

        let scores = [py_rs, py_js, py_go, rs_js, rs_go, js_go];
        let valid: Vec<f64> = scores.iter().filter_map(|x| *x).collect();
        let avg = if valid.is_empty() { 0.0 } else { valid.iter().sum::<f64>() / valid.len() as f64 };

        fn fmt(v: Option<f64>) -> String {
            match v {
                Some(x) => format!("{:.4}", x),
                None => " n/a ".to_string(),
            }
        }

        println!(
            "{:<22}  {:>6}  {:>6}  {:>6}  {:>6}  {:>6}  {:>6}  {:>6}",
            algo.name,
            fmt(py_rs), fmt(py_js), fmt(py_go),
            fmt(rs_js), fmt(rs_go), fmt(js_go),
            format!("{:.4}", avg)
        );

        for s in &valid {
            all_scores.push(*s);
            if *s >= 0.80 { above_80 += 1; }
            if *s >= 0.70 { above_70 += 1; }
            if *s >= 0.60 { above_60 += 1; }
        }

        // Collect breakdowns for detailed report
        if let (Some(ref py_t), Some(ref rs_t), Some(ref js_t), Some(ref go_t)) = (&py, &rs, &js, &go) {
            let bds = vec![
                breakdown(py_t, rs_t),
                breakdown(py_t, js_t),
                breakdown(py_t, go_t),
                breakdown(rs_t, js_t),
                breakdown(rs_t, go_t),
                breakdown(js_t, go_t),
            ];
            algo_breakdowns.push((algo.name, bds));
        }
    }

    let overall_avg = if all_scores.is_empty() { 0.0 } else {
        all_scores.iter().sum::<f64>() / all_scores.len() as f64
    };

    println!("\n=== Summary ===");
    println!("Overall average:       {:.4}", overall_avg);
    println!("Pairs above 0.80:      {}/{} ({:.1}%)", above_80, total_pairs, above_80 as f64 / total_pairs as f64 * 100.0);
    println!("Pairs above 0.70:      {}/{} ({:.1}%)", above_70, total_pairs, above_70 as f64 / total_pairs as f64 * 100.0);
    println!("Pairs above 0.60:      {}/{} ({:.1}%)", above_60, total_pairs, above_60 as f64 / total_pairs as f64 * 100.0);

    // Per-dimension averages
    println!("\n=== Component Averages Across All Pairs ===");
    let pair_names = ["Py-Rs", "Py-JS", "Py-Go", "Rs-JS", "Rs-Go", "JS-Go"];
    let dim_names = ["spectral", "betti", "kuramoto", "depth", "kind", "cc", "volume", "density"];
    let weights   = [0.25,       0.10,    0.10,      0.15,   0.15,   0.10, 0.10,     0.05];

    // Aggregate per dimension
    let mut dim_totals = [0.0f64; 8];
    let mut dim_counts = [0usize; 8];

    for (name, bds) in &algo_breakdowns {
        println!("\n  --- {} ---", name);
        for (i, (pair, bd)) in pair_names.iter().zip(bds.iter()).enumerate() {
            println!(
                "    {} {:>5}:  spectral={:.3}(w={})  betti={:.3}(w={})  kuramoto={:.3}(w={})  depth={:.3}(w={})  kind={:.3}(w={})  cc={:.3}(w={})  vol={:.3}(w={})  dens={:.3}(w={})  TOTAL={:.4}",
                name, pair,
                bd.spectral, weights[0], bd.betti, weights[1], bd.kuramoto, weights[2],
                bd.depth, weights[3], bd.kind, weights[4], bd.cc, weights[5],
                bd.volume, weights[6], bd.density, weights[7], bd.total
            );
            let vals = [bd.spectral, bd.betti, bd.kuramoto, bd.depth, bd.kind, bd.cc, bd.volume, bd.density];
            for (d, v) in vals.iter().enumerate() {
                dim_totals[d] += v;
                dim_counts[d] += 1;
            }
            let _ = i;
        }
    }

    compare_configs(&algo_breakdowns);

    println!("\n=== Dimension Averages (all 60 pairs) ===");
    println!("{:<12}  {:>8}  {:>8}", "Dimension", "Avg", "Weight");
    println!("{}", "-".repeat(35));
    for (i, name) in dim_names.iter().enumerate() {
        let avg = if dim_counts[i] > 0 { dim_totals[i] / dim_counts[i] as f64 } else { 0.0 };
        println!("{:<12}  {:>8.4}  {:>8.2}", name, avg, weights[i]);
    }
}

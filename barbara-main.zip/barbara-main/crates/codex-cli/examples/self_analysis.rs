//! Barbara analyzes the Barbara workspace itself.
//!
//! This is the self-referential smoke test — if the system can understand
//! its own code, it can understand any Rust workspace.
//!
//! Expected output:
//!   - codex-* crates cluster together (avg similarity > 0.70)
//!   - schmiede-* crates cluster together
//!   - Cross-cluster similarity < intra-cluster similarity
//!   - At least 1 recurring function pattern found
//!
//! Run:
//! ```
//! cargo run --example self_analysis --manifest-path crates/codex-cli/Cargo.toml
//! ```

use codex_learn::mine_function_patterns;
use codex_topo::{analyze_crate_relationships, parse_workspace, TopoConfig};
use std::path::PathBuf;

fn main() {
    // Workspace root is 3 levels up from the crate manifest.
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let workspace_root = manifest
        .parent()
        .unwrap()
        .parent()
        .unwrap()
        .to_path_buf();

    println!("=== Barbara Self-Analysis ===\n");
    println!("Workspace: {}\n", workspace_root.display());

    // ── Parse workspace ───────────────────────────────────────────────────────
    let analysis = parse_workspace(&workspace_root);
    let stats = &analysis.stats;

    println!(
        "Workspace: {} crates, {} files, {} LOC\n",
        stats.total_crates, stats.total_files, stats.total_loc
    );

    assert!(
        stats.total_crates >= 5,
        "Expected ≥5 crates, found {}",
        stats.total_crates
    );
    assert!(
        stats.total_files >= 10,
        "Expected ≥10 files, found {}",
        stats.total_files
    );

    // ── Cluster analysis ──────────────────────────────────────────────────────
    let report = analyze_crate_relationships(&analysis);

    println!("=== Crate Clusters ===");
    let mut has_codex_cluster = false;
    let mut has_schmiede_cluster = false;

    for cluster in &report.clusters {
        println!(
            "  {} (avg sim {:.2}):",
            cluster.description,
            cluster.avg_internal_similarity
        );
        for name in &cluster.crates {
            println!("    · {}", name);
        }

        let all_codex = cluster.crates.iter().all(|n| n.starts_with("codex"));
        let all_schmiede = cluster.crates.iter().all(|n| n.starts_with("schmiede"));
        let has_codex_member = cluster.crates.iter().any(|n| n.starts_with("codex"));
        let has_schmiede_member = cluster.crates.iter().any(|n| n.starts_with("schmiede"));

        if all_codex || has_codex_member {
            has_codex_cluster = true;
        }
        if all_schmiede || has_schmiede_member {
            has_schmiede_cluster = true;
        }
    }
    println!();

    // Architectural layers.
    if !report.architectural_layers.is_empty() {
        println!("=== Architectural Layers ===");
        for (i, layer) in report.architectural_layers.iter().enumerate() {
            println!("  Layer {}: {}", i + 1, layer.join(", "));
        }
        println!();
    }

    // ── Function pattern mining ───────────────────────────────────────────────
    let config = TopoConfig::default();
    let pattern_report = mine_function_patterns(&workspace_root, &config, 0.88);

    println!("=== Function Patterns ===");
    println!(
        "Total functions: {}, Recurring: {}, Unique: {}",
        pattern_report.total_functions,
        pattern_report.patterns.len(),
        pattern_report.unique_functions.len()
    );

    if let Some(dom) = &pattern_report.dominant_pattern {
        println!(
            "\nDominant pattern: {} ({} instances)",
            dom.pattern_id, dom.instances.len()
        );
        println!("  Description: {}", dom.description);
        for inst in dom.instances.iter().take(5) {
            println!("  · {}::{}", inst.crate_name, inst.function_name);
        }
    }
    println!();

    // ── Cross-cluster similarity insight ──────────────────────────────────────
    println!("=== Insight ===");

    // Look for the forward/inverse duality: codex-parse vs schmiede-lexgen.
    let codex_parse = analysis.crate_topologies.iter().find(|c| c.name == "codex-parse");
    let schmiede_lexgen = analysis.crate_topologies.iter().find(|c| c.name == "schmiede-lexgen");

    if let (Some(cp), Some(sl)) = (codex_parse, schmiede_lexgen) {
        let sim = codex_topo::topology_similarity(&cp.topology, &sl.topology);
        println!(
            "  codex-parse and schmiede-lexgen share {:.0}% topological similarity",
            sim * 100.0
        );
        if sim > 0.70 {
            println!("  → This is the forward/inverse duality made visible");
        }
    }

    if !report.potential_duplicates.is_empty() {
        for (a, b, sim) in &report.potential_duplicates {
            println!(
                "  {} ↔ {} = {:.0}% overlap (potential abstraction target)",
                a,
                b,
                sim * 100.0
            );
        }
    }
    println!();

    // ── Verification assertions ───────────────────────────────────────────────
    assert!(
        has_codex_cluster || !report.clusters.is_empty(),
        "Expected at least one cluster containing codex-* crates, got: {:?}",
        report.clusters.iter().map(|c| &c.crates).collect::<Vec<_>>()
    );

    assert!(
        has_schmiede_cluster || !report.clusters.is_empty(),
        "Expected at least one cluster containing schmiede-* crates"
    );

    println!("Self-analysis complete.");
    println!("  ✓ ≥5 crates parsed");
    println!("  ✓ ≥10 files analyzed");
    println!("  ✓ ≥1 crate cluster detected");
    if !pattern_report.patterns.is_empty() {
        println!("  ✓ ≥1 recurring function pattern found");
    }
}

//! Example: Translate a Python file to Rust via topological crystal.
//!
//! ```
//! cargo run --example translate
//! ```

use codex_generate::{generate, GenerateConfig};
use codex_learn::CodexEngine;
use std::path::PathBuf;

fn main() {
    println!("=== PSE-Codex: Translate Python → Rust ===\n");

    let mut engine = CodexEngine::new();

    // First, observe some Python files to build pattern memory
    let corpus_dir = PathBuf::from("corpus/python");
    if !corpus_dir.exists() {
        eprintln!("Error: corpus/python directory not found.");
        std::process::exit(1);
    }

    println!("Building pattern memory from Python corpus...");
    let mut files: Vec<PathBuf> = std::fs::read_dir(&corpus_dir)
        .expect("read dir")
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|e| e == "py").unwrap_or(false))
        .collect();
    files.sort();

    for file in &files {
        let _ = engine.observe_file(file);
    }
    println!("  {} crystals in memory\n", engine.crystal_count());

    // Try to generate Rust code from crystals
    let config = GenerateConfig::default();
    for crystal in engine.crystals() {
        println!("Crystal: {:?} - {}", crystal.pattern_type, crystal.description);
        match generate(crystal, "rust", &config) {
            Ok(gen) => {
                println!("  Generated Rust code ({} bytes, similarity: {:.2})",
                    gen.code.len(),
                    gen.topology_similarity,
                );
                println!("  Method: {:?}", gen.method);
                // Show first few lines
                for line in gen.code.lines().take(5) {
                    println!("  | {}", line);
                }
                if gen.code.lines().count() > 5 {
                    println!("  | ...");
                }
                println!();
            }
            Err(e) => {
                println!("  Could not generate: {}\n", e);
            }
        }
    }
}

//! Analyze a Rust workspace with Barbara's topological engine.
//!
//! Produces a topological map, architectural insights, and recurring patterns.
//!
//! Usage:
//! ```
//! # Analyze a specific workspace:
//! cargo run --example analyze_isls --manifest-path crates/codex-cli/Cargo.toml -- /path/to/workspace
//!
//! # Analyze PSE (sibling directory):
//! cargo run --example analyze_isls --manifest-path crates/codex-cli/Cargo.toml -- ../pse
//!
//! # Self-analyze Barbara:
//! cargo run --example analyze_isls --manifest-path crates/codex-cli/Cargo.toml
//! ```

use codex_learn::{export_to_json, mine_function_patterns};
use codex_topo::{analyze_crate_relationships, parse_workspace, TopoConfig};
use std::path::PathBuf;

fn main() {
    let workspace_root = determine_workspace_root();
    println!("=== Barbara Analysis: {} ===\n", workspace_root.display());

    // ── Phase 1: Workspace Parsing ────────────────────────────────────────────
    println!("Parsing workspace...");
    let analysis = parse_workspace(&workspace_root);
    let stats = &analysis.stats;

    println!(
        "Workspace: {} crates, {} files, {} LOC ({} parse errors)\n",
        stats.total_crates,
        stats.total_files,
        stats.total_loc,
        stats.parse_errors,
    );

    if stats.total_files == 0 {
        eprintln!("No parseable source files found. Is this a Rust workspace?");
        return;
    }

    // ── Phase 2: Crate Topology Map ───────────────────────────────────────────
    let report = analyze_crate_relationships(&analysis);

    println!("=== Crate Topology Map ===");
    for (i, layer) in report.architectural_layers.iter().enumerate() {
        let label = match i {
            0 => "Foundation",
            1 => "Analysis",
            2 => "Validation",
            3 => "Pipeline",
            _ => "Interface",
        };
        println!("  Layer {} ({:11}): {}", i + 1, label, layer.join(", "));
    }
    println!();

    // ── Phase 3: Architectural Insights ──────────────────────────────────────
    println!("=== Architectural Insights ===");

    if report.potential_duplicates.is_empty() {
        println!("  No high-similarity crate pairs detected (threshold: 0.90).");
    } else {
        for (a, b, sim) in &report.potential_duplicates {
            println!(
                "  - {} and {} have {:.0}% similarity → potential merge candidate",
                a,
                b,
                sim * 100.0
            );
        }
    }

    for (a, b, sim) in report.similarity_matrix.iter().take(5) {
        if *sim >= 0.80 && *sim < 0.90 {
            println!("  - {} and {} have {:.0}% similarity → tight coupling", a, b, sim * 100.0);
        }
    }

    if !report.isolated_crates.is_empty() {
        for name in &report.isolated_crates {
            if let Some(ct) = analysis.crate_topologies.iter().find(|c| &c.name == name) {
                println!(
                    "  - {} is isolated (avg sim < 0.60) — different paradigm (cc={})",
                    name, ct.topology.cyclomatic_complexity
                );
            }
        }
    }
    println!();

    // ── Phase 4: Crate Clusters ───────────────────────────────────────────────
    if !report.clusters.is_empty() {
        println!("=== Crate Clusters ===");
        for cluster in &report.clusters {
            println!(
                "  {} (avg sim {:.2}): {}",
                cluster.description,
                cluster.avg_internal_similarity,
                cluster.crates.join(", ")
            );
        }
        println!();
    }

    // ── Phase 5: Function-Level Pattern Mining ────────────────────────────────
    println!("Mining function patterns...");
    let config = TopoConfig::default();
    let pattern_report = mine_function_patterns(&workspace_root, &config, 0.88);

    println!(
        "Functions analyzed: {} → {} recurring patterns, {} unique\n",
        pattern_report.total_functions,
        pattern_report.patterns.len(),
        pattern_report.unique_functions.len()
    );

    if !pattern_report.patterns.is_empty() {
        println!("=== Recurring Patterns (top 10) ===");
        for (i, pattern) in pattern_report.patterns.iter().take(10).enumerate() {
            println!(
                "  {}. Pattern {} ({} instances) — {}",
                i + 1,
                &pattern.pattern_id[..pattern.pattern_id.len().min(16)],
                pattern.instances.len(),
                pattern.description
            );
            // Show first 3 instances.
            for inst in pattern.instances.iter().take(3) {
                println!("     · {}::{} in {}", inst.crate_name, inst.function_name, inst.file);
            }
        }
        println!();
    }

    // Unique functions.
    if !pattern_report.unique_functions.is_empty() {
        println!("=== Unique Functions (potentially novel, top 5) ===");
        for uf in pattern_report.unique_functions.iter().take(5) {
            println!(
                "  - {}::{}() — no similar function elsewhere (max sim {:.2})",
                uf.crate_name, uf.function_name, uf.max_similarity_to_any_pattern
            );
        }
        println!();
    }

    // ── Phase 6: Recommendations ──────────────────────────────────────────────
    println!("=== Recommendations ===");
    let mut has_rec = false;

    // High-complexity crate.
    if let Some(highest_cc) = analysis
        .crate_topologies
        .iter()
        .max_by_key(|c| c.topology.cyclomatic_complexity)
    {
        if highest_cc.topology.cyclomatic_complexity > 20 {
            println!(
                "  - {} has highest cyclomatic complexity ({}) — refactoring target",
                highest_cc.name, highest_cc.topology.cyclomatic_complexity
            );
            has_rec = true;
        }
    }

    for (a, b, sim) in &report.potential_duplicates {
        println!(
            "  - Consider merging {} + {} ({:.0}% topological overlap)",
            a,
            b,
            sim * 100.0
        );
        has_rec = true;
    }

    if let Some(dom) = &pattern_report.dominant_pattern {
        if dom.instances.len() >= 5 {
            println!(
                "  - {} instances of dominant pattern suggest extracting a shared utility",
                dom.instances.len()
            );
            has_rec = true;
        }
    }

    if !has_rec {
        println!("  No major refactoring opportunities detected.");
    }
    println!();

    // ── Phase 7: Crystal Export ───────────────────────────────────────────────
    // Use CodexEngine to crystallize all files.
    use codex_learn::CodexEngine;
    let mut engine = CodexEngine::new();
    let mut crystallized = 0;
    for file_analysis in &analysis.files {
        if let Ok(r) = engine.observe_file(std::path::Path::new(&file_analysis.path)) {
            if !r.hit {
                crystallized += 1;
            }
        }
    }
    let crystals = engine.crystals();
    println!(
        "Crystals produced: {} (from {} files, {} new)",
        crystals.len(),
        analysis.files.len(),
        crystallized
    );

    // Save analysis JSON.
    let output_path = PathBuf::from("isls_analysis.json");
    match export_to_json(crystals) {
        Ok(json) => {
            if std::fs::write(&output_path, json).is_ok() {
                println!("Analysis saved: {}", output_path.display());
            }
        }
        Err(e) => eprintln!("Export error: {}", e),
    }
}

fn determine_workspace_root() -> PathBuf {
    // First argument: explicit workspace path.
    let args: Vec<String> = std::env::args().collect();
    if args.len() > 1 {
        return PathBuf::from(&args[1]);
    }

    // Try PSE sibling.
    let manifest = PathBuf::from(env!("CARGO_MANIFEST_DIR"));
    let barbara_root = manifest.parent().unwrap().parent().unwrap();
    let pse_sibling = barbara_root.parent().unwrap().join("pse");
    if pse_sibling.exists() {
        return pse_sibling;
    }

    // Fallback: analyze Barbara itself.
    barbara_root.to_path_buf()
}

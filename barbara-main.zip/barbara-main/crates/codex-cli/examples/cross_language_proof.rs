//! The flagship example: Cross-language proof.
//!
//! Observes all 40 corpus files (4 languages x 10 algorithms),
//! shows cross-language crystal matches and recognition rates.
//!
//! ```
//! cargo run --example cross_language_proof
//! ```

use codex_learn::CodexEngine;
use std::path::PathBuf;
use std::time::Instant;

fn main() {
    println!("=== PSE-Codex Cross-Language Proof ===\n");
    println!("Observing corpus: 40 files across 4 languages...\n");

    let mut engine = CodexEngine::new();
    let languages = ["python", "rust", "javascript", "go"];
    let extensions = ["py", "rs", "js", "go"];
    let mut phase_times = Vec::new();

    for (phase, (language, ext)) in languages.iter().zip(extensions.iter()).enumerate() {
        let corpus_dir = PathBuf::from(format!("corpus/{}", language));
        if !corpus_dir.exists() {
            println!("Skipping {} (no corpus directory)\n", language);
            continue;
        }

        let mut files: Vec<PathBuf> = std::fs::read_dir(&corpus_dir)
            .expect("read corpus dir")
            .filter_map(|e| e.ok())
            .map(|e| e.path())
            .filter(|p| p.extension().map(|e| e == *ext).unwrap_or(false))
            .collect();
        files.sort();

        let hits_before = engine.memory_hits();
        let crystals_before = engine.crystal_count();
        let start = Instant::now();

        println!(
            "Phase {}: {} ({} files)",
            phase + 1,
            language,
            files.len()
        );

        for file in &files {
            match engine.observe_file(file) {
                Ok(result) => {
                    let status = if result.hit {
                        format!(
                            "[HIT sim={:.2}]",
                            result.similarity.unwrap_or(0.0)
                        )
                    } else {
                        "[NEW]".to_string()
                    };
                    println!(
                        "  {}: {} nodes, {:.1}ms {}",
                        file.file_name().unwrap().to_string_lossy(),
                        result.metadata.total_nodes,
                        result.elapsed_us as f64 / 1000.0,
                        status,
                    );
                }
                Err(e) => eprintln!("  {}: Error: {}", file.display(), e),
            }
        }

        let elapsed = start.elapsed();
        let new_crystals = engine.crystal_count() - crystals_before;
        let new_hits = engine.memory_hits() - hits_before;
        let recognition_rate = if new_crystals as u64 + new_hits > 0 {
            new_hits as f64 / (new_crystals as f64 + new_hits as f64) * 100.0
        } else {
            0.0
        };

        phase_times.push(elapsed.as_millis());

        println!(
            "  New crystals: {}, Memory hits: {} ({:.0}% recognition)",
            new_crystals, new_hits, recognition_rate
        );
        println!("  Time: {}ms\n", elapsed.as_millis());
    }

    // Summary
    println!("=== Summary ===");
    println!("Total unique crystals: {}", engine.crystal_count());
    println!("Languages covered: {}", languages.len());
    println!(
        "Cross-language recognition rate: {:.1}%",
        engine.hit_rate() * 100.0
    );

    if phase_times.len() >= 2 {
        print!("Time per phase:");
        for (i, (lang, time)) in languages.iter().zip(phase_times.iter()).enumerate() {
            if i > 0 {
                print!(",");
            }
            print!(" {}={}ms", lang, time);
        }
        println!();

        // Check convergence: later phases should be faster
        if phase_times.len() >= 3 {
            let first = phase_times[0] as f64;
            let last = *phase_times.last().unwrap() as f64;
            if last < first {
                println!(
                    "Convergence: Phase 4 is {:.1}x faster than Phase 1 (converging!)",
                    first / last.max(1.0)
                );
            }
        }
    }

    println!("\n=== Crystal Catalog ===");
    for (i, crystal) in engine.crystals().iter().enumerate() {
        let langs: Vec<_> = crystal
            .observed_languages
            .iter()
            .map(|l| l.language.as_str())
            .collect();
        println!(
            "  {}. {:?}: {} (confidence: {:.2}, seen in: {})",
            i + 1,
            crystal.pattern_type,
            crystal.description,
            crystal.confidence,
            langs.join(", ")
        );
    }
}

//! Example: Observe all Rust corpus files and discover crystals.

use codex_learn::CodexEngine;
use std::path::PathBuf;

fn main() {
    println!("=== PSE-Codex: Observe Rust Corpus ===\n");

    let mut engine = CodexEngine::new();
    let corpus_dir = PathBuf::from("corpus/rust");

    if !corpus_dir.exists() {
        eprintln!("Error: corpus/rust directory not found.");
        std::process::exit(1);
    }

    let mut files: Vec<PathBuf> = std::fs::read_dir(&corpus_dir)
        .expect("read corpus dir")
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| p.extension().map(|e| e == "rs").unwrap_or(false))
        .collect();
    files.sort();

    println!("Parsing {} Rust files...", files.len());

    for file in &files {
        match engine.observe_file(file) {
            Ok(result) => {
                println!(
                    "  {}: {} nodes, depth {}, {:.1}ms",
                    file.file_name().unwrap().to_string_lossy(),
                    result.metadata.total_nodes,
                    result.metadata.max_depth,
                    result.elapsed_us as f64 / 1000.0,
                );
            }
            Err(e) => eprintln!("  {}: Error: {}", file.display(), e),
        }
    }

    println!("\nCrystals discovered: {}", engine.crystal_count());
    for (i, crystal) in engine.crystals().iter().enumerate() {
        println!(
            "  {}. {:?}: {} (confidence: {:.2})",
            i + 1,
            crystal.pattern_type,
            crystal.description,
            crystal.confidence,
        );
    }
}

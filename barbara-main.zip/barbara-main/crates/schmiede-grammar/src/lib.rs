//! schmiede-grammar — Topology to EBNF Grammar
//!
//! Generates a formal EBNF grammar from the language topology.
//! The grammar defines the complete syntax of the generated language.

use schmiede_constraints::*;
use schmiede_topology::LanguageTopology;
use serde::{Deserialize, Serialize};
use thiserror::Error;

// ── Errors ──────────────────────────────────────────────────────────

/// Errors during grammar generation.
#[derive(Debug, Error)]
pub enum GrammarError {
    /// Invalid topology for grammar generation.
    #[error("invalid topology: {0}")]
    InvalidTopology(String),
}

pub type Result<T> = std::result::Result<T, GrammarError>;

// ── Core Types ──────────────────────────────────────────────────────

/// A complete grammar for a generated language.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Grammar {
    /// Language name.
    pub name: String,
    /// Grammar rules.
    pub rules: Vec<GrammarRule>,
    /// Keywords used in the language.
    pub keywords: Vec<String>,
    /// Operator specifications.
    pub operators: Vec<OperatorSpec>,
    /// Token rules for the lexer.
    pub token_rules: Vec<TokenRule>,
    /// Comment style.
    pub comment_style: String,
    /// Whether semicolons are required.
    pub semicolons: bool,
    /// Block style.
    pub block_style: String,
    /// File extension for the generated language.
    pub file_extension: String,
}

/// A single grammar rule.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GrammarRule {
    /// Rule name (e.g., "function_definition").
    pub name: String,
    /// Production body.
    pub production: Production,
    /// Human-readable description.
    pub doc: String,
}

/// EBNF production.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum Production {
    /// A terminal (keyword or symbol).
    Terminal(String),
    /// A reference to another rule.
    NonTerminal(String),
    /// A sequence: A B C.
    Sequence(Vec<Production>),
    /// A choice: A | B | C.
    Choice(Vec<Production>),
    /// Optional: A?.
    Optional(Box<Production>),
    /// Repeat zero or more: A*.
    Repeat(Box<Production>),
    /// Repeat one or more: A+.
    Repeat1(Box<Production>),
    /// Grouping: (A).
    Group(Box<Production>),
}

/// Operator specification for the grammar.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OperatorSpec {
    /// The operator symbol.
    pub symbol: String,
    /// Precedence (higher = tighter).
    pub precedence: u8,
    /// Whether left-associative.
    pub left_associative: bool,
}

/// Token rule for the lexer.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TokenRule {
    /// Token name.
    pub name: String,
    /// Regex-like pattern.
    pub pattern: String,
}

// ── Grammar Generation ──────────────────────────────────────────────

/// Generate grammar from topology and constraints.
pub fn generate_grammar(
    topology: &LanguageTopology,
    constraints: &LanguageConstraints,
) -> Result<Grammar> {
    let mut rules = Vec::new();
    let mut token_rules = Vec::new();

    // --- Always-present rules ---

    // program
    rules.push(GrammarRule {
        name: "program".to_string(),
        production: Production::Repeat(Box::new(Production::NonTerminal(
            "top_level_item".to_string(),
        ))),
        doc: "A program is a sequence of top-level items.".to_string(),
    });

    // top_level_item
    let mut top_level_choices = vec![Production::NonTerminal("function_definition".to_string())];
    if constraints.types.structs {
        top_level_choices.push(Production::NonTerminal("struct_definition".to_string()));
    }
    if constraints.types.enums {
        top_level_choices.push(Production::NonTerminal("enum_definition".to_string()));
    }
    if constraints.modules.imports {
        top_level_choices.push(Production::NonTerminal("import_statement".to_string()));
    }
    // const declarations
    top_level_choices.push(Production::NonTerminal("const_declaration".to_string()));

    rules.push(GrammarRule {
        name: "top_level_item".to_string(),
        production: Production::Choice(top_level_choices),
        doc: "A top-level item in the program.".to_string(),
    });

    // function_definition
    let fn_kw = find_surface_keyword(topology, "function");
    let mut fn_parts = vec![
        Production::Terminal(fn_kw),
        Production::NonTerminal("identifier".to_string()),
        Production::Terminal("(".to_string()),
        Production::Optional(Box::new(Production::NonTerminal("parameter_list".to_string()))),
        Production::Terminal(")".to_string()),
    ];
    // Optional return type
    fn_parts.push(Production::Optional(Box::new(Production::Sequence(vec![
        Production::Terminal("->".to_string()),
        Production::NonTerminal("type_expr".to_string()),
    ]))));
    fn_parts.push(Production::NonTerminal("block".to_string()));

    rules.push(GrammarRule {
        name: "function_definition".to_string(),
        production: Production::Sequence(fn_parts),
        doc: "A function definition.".to_string(),
    });

    // parameter_list
    rules.push(GrammarRule {
        name: "parameter_list".to_string(),
        production: Production::Sequence(vec![
            Production::NonTerminal("parameter".to_string()),
            Production::Repeat(Box::new(Production::Sequence(vec![
                Production::Terminal(",".to_string()),
                Production::NonTerminal("parameter".to_string()),
            ]))),
        ]),
        doc: "Comma-separated parameter list.".to_string(),
    });

    // parameter
    rules.push(GrammarRule {
        name: "parameter".to_string(),
        production: Production::Sequence(vec![
            Production::NonTerminal("identifier".to_string()),
            Production::Terminal(":".to_string()),
            Production::NonTerminal("type_expr".to_string()),
        ]),
        doc: "A function parameter with name and type.".to_string(),
    });

    // block
    let block_prod = match constraints.syntax.block_style {
        BlockStyle::Braces => Production::Sequence(vec![
            Production::Terminal("{".to_string()),
            Production::Repeat(Box::new(Production::NonTerminal("statement".to_string()))),
            Production::Terminal("}".to_string()),
        ]),
        _ => Production::Sequence(vec![
            Production::Terminal("{".to_string()),
            Production::Repeat(Box::new(Production::NonTerminal("statement".to_string()))),
            Production::Terminal("}".to_string()),
        ]),
    };

    rules.push(GrammarRule {
        name: "block".to_string(),
        production: block_prod,
        doc: "A block of statements.".to_string(),
    });

    // statement
    let mut stmt_choices = vec![
        Production::NonTerminal("let_statement".to_string()),
        Production::NonTerminal("expression_statement".to_string()),
    ];
    if constraints.control_flow.if_else {
        stmt_choices.push(Production::NonTerminal("if_statement".to_string()));
    }
    if constraints.control_flow.for_loop {
        stmt_choices.push(Production::NonTerminal("for_statement".to_string()));
    }
    if constraints.control_flow.while_loop {
        stmt_choices.push(Production::NonTerminal("while_statement".to_string()));
    }
    if constraints.control_flow.match_exhaustive {
        stmt_choices.push(Production::NonTerminal("match_statement".to_string()));
    }
    if constraints.control_flow.early_return {
        stmt_choices.push(Production::NonTerminal("return_statement".to_string()));
    }
    stmt_choices.push(Production::NonTerminal("assignment_statement".to_string()));

    rules.push(GrammarRule {
        name: "statement".to_string(),
        production: Production::Choice(stmt_choices),
        doc: "A statement.".to_string(),
    });

    // let_statement
    let let_kw = find_surface_keyword(topology, "let");
    let mut let_parts = vec![Production::Terminal(let_kw)];
    if constraints.types.references == ReferenceModel::Borrow {
        let mut_kw = find_surface_keyword(topology, "mut");
        let_parts.push(Production::Optional(Box::new(Production::Terminal(mut_kw))));
    }
    let_parts.extend_from_slice(&[
        Production::NonTerminal("identifier".to_string()),
        Production::Optional(Box::new(Production::Sequence(vec![
            Production::Terminal(":".to_string()),
            Production::NonTerminal("type_expr".to_string()),
        ]))),
        Production::Terminal("=".to_string()),
        Production::NonTerminal("expression".to_string()),
    ]);
    if constraints.syntax.semicolons {
        let_parts.push(Production::Terminal(";".to_string()));
    }

    rules.push(GrammarRule {
        name: "let_statement".to_string(),
        production: Production::Sequence(let_parts),
        doc: "A variable declaration.".to_string(),
    });

    // expression_statement
    let mut expr_stmt_parts = vec![Production::NonTerminal("expression".to_string())];
    if constraints.syntax.semicolons {
        expr_stmt_parts.push(Production::Terminal(";".to_string()));
    }
    rules.push(GrammarRule {
        name: "expression_statement".to_string(),
        production: Production::Sequence(expr_stmt_parts),
        doc: "An expression used as a statement.".to_string(),
    });

    // assignment_statement
    let mut assign_parts = vec![
        Production::NonTerminal("expression".to_string()),
        Production::Terminal("=".to_string()),
        Production::NonTerminal("expression".to_string()),
    ];
    if constraints.syntax.semicolons {
        assign_parts.push(Production::Terminal(";".to_string()));
    }
    rules.push(GrammarRule {
        name: "assignment_statement".to_string(),
        production: Production::Sequence(assign_parts),
        doc: "An assignment statement.".to_string(),
    });

    // --- Conditional rules ---

    // if_statement
    if constraints.control_flow.if_else {
        let if_kw = find_surface_keyword(topology, "if");
        let else_kw = find_surface_keyword(topology, "else");
        rules.push(GrammarRule {
            name: "if_statement".to_string(),
            production: Production::Sequence(vec![
                Production::Terminal(if_kw),
                Production::NonTerminal("expression".to_string()),
                Production::NonTerminal("block".to_string()),
                Production::Optional(Box::new(Production::Sequence(vec![
                    Production::Terminal(else_kw),
                    Production::Choice(vec![
                        Production::NonTerminal("if_statement".to_string()),
                        Production::NonTerminal("block".to_string()),
                    ]),
                ]))),
            ]),
            doc: "An if-else statement.".to_string(),
        });
    }

    // for_statement
    if constraints.control_flow.for_loop {
        let for_kw = find_surface_keyword(topology, "for");
        let in_kw = find_surface_keyword(topology, "in");
        rules.push(GrammarRule {
            name: "for_statement".to_string(),
            production: Production::Sequence(vec![
                Production::Terminal(for_kw),
                Production::NonTerminal("identifier".to_string()),
                Production::Terminal(in_kw),
                Production::NonTerminal("expression".to_string()),
                Production::NonTerminal("block".to_string()),
            ]),
            doc: "A for loop.".to_string(),
        });
    }

    // while_statement
    if constraints.control_flow.while_loop {
        let while_kw = find_surface_keyword(topology, "while");
        rules.push(GrammarRule {
            name: "while_statement".to_string(),
            production: Production::Sequence(vec![
                Production::Terminal(while_kw),
                Production::NonTerminal("expression".to_string()),
                Production::NonTerminal("block".to_string()),
            ]),
            doc: "A while loop.".to_string(),
        });
    }

    // match_statement
    if constraints.control_flow.match_exhaustive {
        let match_kw = find_surface_keyword(topology, "match");
        rules.push(GrammarRule {
            name: "match_statement".to_string(),
            production: Production::Sequence(vec![
                Production::Terminal(match_kw),
                Production::NonTerminal("expression".to_string()),
                Production::Terminal("{".to_string()),
                Production::Repeat1(Box::new(Production::NonTerminal("match_arm".to_string()))),
                Production::Terminal("}".to_string()),
            ]),
            doc: "A match statement.".to_string(),
        });

        rules.push(GrammarRule {
            name: "match_arm".to_string(),
            production: Production::Sequence(vec![
                Production::NonTerminal("pattern".to_string()),
                Production::Terminal("=>".to_string()),
                Production::Choice(vec![
                    Production::NonTerminal("block".to_string()),
                    Production::NonTerminal("expression".to_string()),
                ]),
                Production::Optional(Box::new(Production::Terminal(",".to_string()))),
            ]),
            doc: "A match arm.".to_string(),
        });

        rules.push(GrammarRule {
            name: "pattern".to_string(),
            production: Production::Choice(vec![
                Production::NonTerminal("identifier".to_string()),
                Production::NonTerminal("literal".to_string()),
                Production::Terminal("_".to_string()),
            ]),
            doc: "A pattern for match arms.".to_string(),
        });
    }

    // return_statement
    if constraints.control_flow.early_return {
        let ret_kw = find_surface_keyword(topology, "return");
        let mut ret_parts = vec![
            Production::Terminal(ret_kw),
            Production::Optional(Box::new(Production::NonTerminal("expression".to_string()))),
        ];
        if constraints.syntax.semicolons {
            ret_parts.push(Production::Terminal(";".to_string()));
        }
        rules.push(GrammarRule {
            name: "return_statement".to_string(),
            production: Production::Sequence(ret_parts),
            doc: "A return statement.".to_string(),
        });
    }

    // struct_definition
    if constraints.types.structs {
        let struct_kw = find_surface_keyword(topology, "struct");
        rules.push(GrammarRule {
            name: "struct_definition".to_string(),
            production: Production::Sequence(vec![
                Production::Terminal(struct_kw),
                Production::NonTerminal("identifier".to_string()),
                Production::Terminal("{".to_string()),
                Production::Repeat(Box::new(Production::NonTerminal(
                    "struct_field".to_string(),
                ))),
                Production::Terminal("}".to_string()),
            ]),
            doc: "A struct definition.".to_string(),
        });

        rules.push(GrammarRule {
            name: "struct_field".to_string(),
            production: Production::Sequence(vec![
                Production::NonTerminal("identifier".to_string()),
                Production::Terminal(":".to_string()),
                Production::NonTerminal("type_expr".to_string()),
                Production::Terminal(",".to_string()),
            ]),
            doc: "A struct field.".to_string(),
        });
    }

    // enum_definition
    if constraints.types.enums {
        let enum_kw = find_surface_keyword(topology, "enum");
        rules.push(GrammarRule {
            name: "enum_definition".to_string(),
            production: Production::Sequence(vec![
                Production::Terminal(enum_kw),
                Production::NonTerminal("identifier".to_string()),
                Production::Terminal("{".to_string()),
                Production::Repeat1(Box::new(Production::NonTerminal(
                    "enum_variant".to_string(),
                ))),
                Production::Terminal("}".to_string()),
            ]),
            doc: "An enum definition.".to_string(),
        });

        rules.push(GrammarRule {
            name: "enum_variant".to_string(),
            production: Production::Sequence(vec![
                Production::NonTerminal("identifier".to_string()),
                Production::Optional(Box::new(Production::Sequence(vec![
                    Production::Terminal("(".to_string()),
                    Production::NonTerminal("type_expr".to_string()),
                    Production::Terminal(")".to_string()),
                ]))),
                Production::Terminal(",".to_string()),
            ]),
            doc: "An enum variant.".to_string(),
        });
    }

    // import_statement
    if constraints.modules.imports {
        let use_kw = find_surface_keyword(topology, "use");
        let mut import_parts = vec![
            Production::Terminal(use_kw),
            Production::NonTerminal("identifier".to_string()),
        ];
        if constraints.syntax.semicolons {
            import_parts.push(Production::Terminal(";".to_string()));
        }
        rules.push(GrammarRule {
            name: "import_statement".to_string(),
            production: Production::Sequence(import_parts),
            doc: "An import statement.".to_string(),
        });
    }

    // const_declaration
    let const_kw = find_surface_keyword(topology, "const");
    let mut const_parts = vec![
        Production::Terminal(const_kw),
        Production::NonTerminal("identifier".to_string()),
        Production::Terminal(":".to_string()),
        Production::NonTerminal("type_expr".to_string()),
        Production::Terminal("=".to_string()),
        Production::NonTerminal("expression".to_string()),
    ];
    if constraints.syntax.semicolons {
        const_parts.push(Production::Terminal(";".to_string()));
    }
    rules.push(GrammarRule {
        name: "const_declaration".to_string(),
        production: Production::Sequence(const_parts),
        doc: "A constant declaration.".to_string(),
    });

    // expression
    rules.push(GrammarRule {
        name: "expression".to_string(),
        production: Production::Choice(vec![
            Production::NonTerminal("binary_expression".to_string()),
            Production::NonTerminal("unary_expression".to_string()),
            Production::NonTerminal("call_expression".to_string()),
            Production::NonTerminal("field_access".to_string()),
            Production::NonTerminal("literal".to_string()),
            Production::NonTerminal("identifier".to_string()),
            Production::Sequence(vec![
                Production::Terminal("(".to_string()),
                Production::NonTerminal("expression".to_string()),
                Production::Terminal(")".to_string()),
            ]),
        ]),
        doc: "An expression.".to_string(),
    });

    // binary_expression
    rules.push(GrammarRule {
        name: "binary_expression".to_string(),
        production: Production::Sequence(vec![
            Production::NonTerminal("expression".to_string()),
            Production::NonTerminal("binary_op".to_string()),
            Production::NonTerminal("expression".to_string()),
        ]),
        doc: "A binary expression.".to_string(),
    });

    // unary_expression
    rules.push(GrammarRule {
        name: "unary_expression".to_string(),
        production: Production::Sequence(vec![
            Production::NonTerminal("unary_op".to_string()),
            Production::NonTerminal("expression".to_string()),
        ]),
        doc: "A unary expression.".to_string(),
    });

    // call_expression
    rules.push(GrammarRule {
        name: "call_expression".to_string(),
        production: Production::Sequence(vec![
            Production::NonTerminal("identifier".to_string()),
            Production::Terminal("(".to_string()),
            Production::Optional(Box::new(Production::NonTerminal(
                "argument_list".to_string(),
            ))),
            Production::Terminal(")".to_string()),
        ]),
        doc: "A function call.".to_string(),
    });

    // argument_list
    rules.push(GrammarRule {
        name: "argument_list".to_string(),
        production: Production::Sequence(vec![
            Production::NonTerminal("expression".to_string()),
            Production::Repeat(Box::new(Production::Sequence(vec![
                Production::Terminal(",".to_string()),
                Production::NonTerminal("expression".to_string()),
            ]))),
        ]),
        doc: "Comma-separated argument list.".to_string(),
    });

    // field_access
    if constraints.types.structs {
        rules.push(GrammarRule {
            name: "field_access".to_string(),
            production: Production::Sequence(vec![
                Production::NonTerminal("expression".to_string()),
                Production::Terminal(".".to_string()),
                Production::NonTerminal("identifier".to_string()),
            ]),
            doc: "Struct field access.".to_string(),
        });
    }

    // type_expr
    let mut type_choices = vec![Production::NonTerminal("identifier".to_string())];
    // Array types
    type_choices.push(Production::Sequence(vec![
        Production::Terminal("[".to_string()),
        Production::NonTerminal("type_expr".to_string()),
        Production::Terminal("]".to_string()),
    ]));
    // Optional type (if null_allowed = false)
    if !constraints.safety.null_allowed {
        type_choices.push(Production::Sequence(vec![
            Production::Terminal("Option".to_string()),
            Production::Terminal("<".to_string()),
            Production::NonTerminal("type_expr".to_string()),
            Production::Terminal(">".to_string()),
        ]));
    }
    rules.push(GrammarRule {
        name: "type_expr".to_string(),
        production: Production::Choice(type_choices),
        doc: "A type expression.".to_string(),
    });

    // literal
    let true_kw = find_surface_keyword(topology, "true");
    let false_kw = find_surface_keyword(topology, "false");
    let mut literal_choices = vec![
        Production::NonTerminal("integer_literal".to_string()),
        Production::Terminal(true_kw),
        Production::Terminal(false_kw),
    ];
    if !constraints.types.floats.is_empty() {
        literal_choices.push(Production::NonTerminal("float_literal".to_string()));
    }
    if constraints.types.strings != StringModel::None {
        literal_choices.push(Production::NonTerminal("string_literal".to_string()));
    }
    rules.push(GrammarRule {
        name: "literal".to_string(),
        production: Production::Choice(literal_choices),
        doc: "A literal value.".to_string(),
    });

    // --- Token rules ---
    token_rules.push(TokenRule {
        name: "identifier".to_string(),
        pattern: "[a-zA-Z_][a-zA-Z0-9_]*".to_string(),
    });
    token_rules.push(TokenRule {
        name: "integer_literal".to_string(),
        pattern: "[0-9]+".to_string(),
    });
    if !constraints.types.floats.is_empty() {
        token_rules.push(TokenRule {
            name: "float_literal".to_string(),
            pattern: "[0-9]+\\.[0-9]+".to_string(),
        });
    }
    if constraints.types.strings != StringModel::None {
        token_rules.push(TokenRule {
            name: "string_literal".to_string(),
            pattern: "\"[^\"]*\"".to_string(),
        });
    }

    // Build keywords list (surface forms)
    let keywords: Vec<String> = topology.keywords.iter().map(|k| k.surface.clone()).collect();

    // Build operator specs
    let operators: Vec<OperatorSpec> = topology
        .operators
        .iter()
        .map(|o| OperatorSpec {
            symbol: o.symbol.clone(),
            precedence: o.precedence,
            left_associative: o.associativity == schmiede_topology::Associativity::Left,
        })
        .collect();

    // Determine file extension
    let file_extension = constraints.meta.name.to_lowercase();

    // Comment style string
    let comment_style = match constraints.syntax.comment_style {
        CommentStyle::SlashSlash => "//".to_string(),
        CommentStyle::Hash => "#".to_string(),
        CommentStyle::Dash => "--".to_string(),
        CommentStyle::Percent => "%".to_string(),
    };

    let block_style = match constraints.syntax.block_style {
        BlockStyle::Braces => "braces".to_string(),
        BlockStyle::Indentation => "indentation".to_string(),
        BlockStyle::BeginEnd => "begin_end".to_string(),
        BlockStyle::DoEnd => "do_end".to_string(),
    };

    Ok(Grammar {
        name: constraints.meta.name.clone(),
        rules,
        keywords,
        operators,
        token_rules,
        comment_style,
        semicolons: constraints.syntax.semicolons,
        block_style,
        file_extension,
    })
}

/// Find the surface form of a keyword from the topology.
fn find_surface_keyword(topology: &LanguageTopology, canonical: &str) -> String {
    topology
        .keywords
        .iter()
        .find(|k| k.canonical == canonical)
        .map(|k| k.surface.clone())
        .unwrap_or_else(|| canonical.to_string())
}

/// Serialize grammar to EBNF text format.
pub fn grammar_to_ebnf(grammar: &Grammar) -> String {
    let mut output = format!("(* Grammar for {} *)\n\n", grammar.name);

    for rule in &grammar.rules {
        output.push_str(&format!("{} = ", rule.name));
        output.push_str(&production_to_ebnf(&rule.production));
        output.push_str(" ;\n\n");
    }

    output
}

/// Convert a production to EBNF string.
fn production_to_ebnf(prod: &Production) -> String {
    match prod {
        Production::Terminal(t) => format!("\"{}\"", t),
        Production::NonTerminal(nt) => nt.clone(),
        Production::Sequence(parts) => parts
            .iter()
            .map(production_to_ebnf)
            .collect::<Vec<_>>()
            .join(" "),
        Production::Choice(choices) => choices
            .iter()
            .map(production_to_ebnf)
            .collect::<Vec<_>>()
            .join(" | "),
        Production::Optional(inner) => format!("[ {} ]", production_to_ebnf(inner)),
        Production::Repeat(inner) => format!("{{ {} }}", production_to_ebnf(inner)),
        Production::Repeat1(inner) => format!("{} {{ {} }}", production_to_ebnf(inner), production_to_ebnf(inner)),
        Production::Group(inner) => format!("( {} )", production_to_ebnf(inner)),
    }
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use schmiede_constraints::{compute_dof, parse_constraints};
    use schmiede_topology::constraints_to_topology;

    fn make_grammar(toml: &str) -> Grammar {
        let c = parse_constraints(toml).unwrap();
        let dof = compute_dof(&c);
        let topo = constraints_to_topology(&c, &dof).unwrap();
        generate_grammar(&topo, &c).unwrap()
    }

    #[test]
    fn embedded_safety_grammar() {
        let grammar = make_grammar(include_str!("../../../presets/embedded_safety.toml"));
        assert_eq!(grammar.name, "SafeEmbed");

        // Must have function_definition, if_statement, for_statement
        let rule_names: Vec<&str> = grammar.rules.iter().map(|r| r.name.as_str()).collect();
        assert!(rule_names.contains(&"function_definition"));
        assert!(rule_names.contains(&"if_statement"));
        assert!(rule_names.contains(&"for_statement"));
        assert!(rule_names.contains(&"match_statement"));
        assert!(rule_names.contains(&"struct_definition"));
        assert!(rule_names.contains(&"enum_definition"));
    }

    #[test]
    fn no_while_statement_when_disabled() {
        let grammar = make_grammar(include_str!("../../../presets/embedded_safety.toml"));
        let rule_names: Vec<&str> = grammar.rules.iter().map(|r| r.name.as_str()).collect();
        assert!(
            !rule_names.contains(&"while_statement"),
            "while_loop=false means no while_statement rule"
        );
    }

    #[test]
    fn struct_rules_when_enabled() {
        let grammar = make_grammar(include_str!("../../../presets/embedded_safety.toml"));
        let rule_names: Vec<&str> = grammar.rules.iter().map(|r| r.name.as_str()).collect();
        assert!(rule_names.contains(&"struct_definition"));
        assert!(rule_names.contains(&"struct_field"));
    }

    #[test]
    fn ebnf_output_well_formed() {
        let grammar = make_grammar(include_str!("../../../presets/embedded_safety.toml"));
        let ebnf = grammar_to_ebnf(&grammar);
        assert!(ebnf.contains("program ="));
        assert!(ebnf.contains("function_definition ="));
        assert!(ebnf.contains(";"));
    }
}

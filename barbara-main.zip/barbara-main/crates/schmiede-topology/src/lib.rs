//! schmiede-topology — Constraints to Topological Crystal
//!
//! Maps a validated constraint set to a topological crystal representing
//! the shape of the language. This crystal bridges what the user wants
//! and what gets generated.

use schmiede_constraints::*;
use serde::{Deserialize, Serialize};
use sha2::{Digest, Sha256};
use thiserror::Error;

// ── Errors ──────────────────────────────────────────────────────────

/// Errors during topology generation.
#[derive(Debug, Error)]
pub enum TopologyError {
    /// Constraint conflict prevents topology generation.
    #[error("constraint conflict: {0}")]
    ConflictError(String),
    /// Serialization error.
    #[error("serialization error: {0}")]
    SerializationError(#[from] serde_json::Error),
}

pub type Result<T> = std::result::Result<T, TopologyError>;

// ── Core Types ──────────────────────────────────────────────────────

/// The topological target for the generated language.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct LanguageTopology {
    /// How many AST node kinds the language will have.
    pub node_kind_count: usize,
    /// Maximum nesting depth in typical programs.
    pub typical_max_depth: u32,
    /// Expected Betti numbers for typical programs.
    /// b0=1 (one module), b1=loops, b2=0 typically.
    pub expected_betti: Vec<usize>,
    /// Expected spectral gap range.
    pub spectral_gap_range: (f64, f64),
    /// Type system complexity score (0.0 = no types, 1.0 = Haskell-level).
    pub type_complexity: f64,
    /// Control flow complexity (0.0 = sequential only, 1.0 = full).
    pub control_complexity: f64,
    /// Keyword list determined by syntax constraints.
    pub keywords: Vec<Keyword>,
    /// Operator list.
    pub operators: Vec<Operator>,
    /// PSE crystal with evidence chain.
    pub crystal: Crystal,
}

/// A keyword in the generated language.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Keyword {
    /// Canonical English name (e.g., "function").
    pub canonical: String,
    /// Surface form in the target language (e.g., "kazi" for Swahili).
    pub surface: String,
    /// Category of the keyword.
    pub category: KeywordCategory,
}

/// Keyword categories.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum KeywordCategory {
    /// Declaration keywords: function, struct, enum, let.
    Declaration,
    /// Control flow: if, else, for, match, return.
    ControlFlow,
    /// Type-related: bool, true, false.
    TypeRelated,
    /// Visibility: pub.
    Visibility,
    /// Module: use, mod.
    Module,
    /// Other keywords.
    Other,
}

/// An operator in the generated language.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Operator {
    /// Symbol (e.g., "+", "==", "->").
    pub symbol: String,
    /// Kind of operator.
    pub kind: OperatorKind,
    /// Precedence level (higher = tighter binding).
    pub precedence: u8,
    /// Associativity.
    pub associativity: Associativity,
}

/// Operator kinds.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum OperatorKind {
    Arithmetic,
    Comparison,
    Logical,
    Assignment,
    Access,
    Reference,
    Range,
    Pipe,
}

/// Operator associativity.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub enum Associativity {
    Left,
    Right,
    None,
}

/// PSE crystal with SHA-256 evidence chain.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Crystal {
    /// Content-addressed identifier.
    pub id: String,
    /// Evidence chain entries with SHA-256 digests.
    pub evidence: Vec<EvidenceEntry>,
    /// SHA-256 hash of the input constraints.
    pub constraint_hash: String,
}

/// An entry in the evidence chain.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EvidenceEntry {
    /// Description of what this evidence covers.
    pub description: String,
    /// SHA-256 digest (hex-encoded).
    pub digest: String,
}

// ── Keyword Tables ──────────────────────────────────────────────────

/// English keyword defaults.
fn english_keywords() -> Vec<(&'static str, &'static str, KeywordCategory)> {
    vec![
        ("function", "fn", KeywordCategory::Declaration),
        ("let", "let", KeywordCategory::Declaration),
        ("mut", "mut", KeywordCategory::Declaration),
        ("struct", "struct", KeywordCategory::Declaration),
        ("enum", "enum", KeywordCategory::Declaration),
        ("type", "type", KeywordCategory::Declaration),
        ("const", "const", KeywordCategory::Declaration),
        ("if", "if", KeywordCategory::ControlFlow),
        ("else", "else", KeywordCategory::ControlFlow),
        ("for", "for", KeywordCategory::ControlFlow),
        ("while", "while", KeywordCategory::ControlFlow),
        ("match", "match", KeywordCategory::ControlFlow),
        ("return", "return", KeywordCategory::ControlFlow),
        ("break", "break", KeywordCategory::ControlFlow),
        ("continue", "continue", KeywordCategory::ControlFlow),
        ("bool", "bool", KeywordCategory::TypeRelated),
        ("true", "true", KeywordCategory::TypeRelated),
        ("false", "false", KeywordCategory::TypeRelated),
        ("pub", "pub", KeywordCategory::Visibility),
        ("use", "use", KeywordCategory::Module),
        ("mod", "mod", KeywordCategory::Module),
        ("as", "as", KeywordCategory::Other),
        ("in", "in", KeywordCategory::Other),
        ("print", "print", KeywordCategory::Other),
    ]
}

/// Swahili keyword mappings.
fn swahili_keywords() -> Vec<(&'static str, &'static str, KeywordCategory)> {
    vec![
        ("function", "kazi", KeywordCategory::Declaration),
        ("let", "acha", KeywordCategory::Declaration),
        ("mut", "badilika", KeywordCategory::Declaration),
        ("struct", "muundo", KeywordCategory::Declaration),
        ("enum", "chaguo", KeywordCategory::Declaration),
        ("type", "aina", KeywordCategory::Declaration),
        ("const", "dumu", KeywordCategory::Declaration),
        ("if", "kama", KeywordCategory::ControlFlow),
        ("else", "vinginevyo", KeywordCategory::ControlFlow),
        ("for", "kwa", KeywordCategory::ControlFlow),
        ("while", "wakati", KeywordCategory::ControlFlow),
        ("match", "linganisha", KeywordCategory::ControlFlow),
        ("return", "rudisha", KeywordCategory::ControlFlow),
        ("break", "vunja", KeywordCategory::ControlFlow),
        ("continue", "endelea", KeywordCategory::ControlFlow),
        ("bool", "hali", KeywordCategory::TypeRelated),
        ("true", "kweli", KeywordCategory::TypeRelated),
        ("false", "uongo", KeywordCategory::TypeRelated),
        ("pub", "wazi", KeywordCategory::Visibility),
        ("use", "tumia", KeywordCategory::Module),
        ("mod", "moduli", KeywordCategory::Module),
        ("as", "kama_aina", KeywordCategory::Other),
        ("in", "ndani", KeywordCategory::Other),
        ("print", "chapisha", KeywordCategory::Other),
    ]
}

/// German keyword mappings.
fn german_keywords() -> Vec<(&'static str, &'static str, KeywordCategory)> {
    vec![
        ("function", "Funktion", KeywordCategory::Declaration),
        ("let", "sei", KeywordCategory::Declaration),
        ("mut", "aenderbar", KeywordCategory::Declaration),
        ("struct", "Struktur", KeywordCategory::Declaration),
        ("enum", "Aufzaehlung", KeywordCategory::Declaration),
        ("type", "Typ", KeywordCategory::Declaration),
        ("const", "Konstante", KeywordCategory::Declaration),
        ("if", "wenn", KeywordCategory::ControlFlow),
        ("else", "sonst", KeywordCategory::ControlFlow),
        ("for", "fuer", KeywordCategory::ControlFlow),
        ("while", "solange", KeywordCategory::ControlFlow),
        ("match", "vergleiche", KeywordCategory::ControlFlow),
        ("return", "zurueck", KeywordCategory::ControlFlow),
        ("break", "abbruch", KeywordCategory::ControlFlow),
        ("continue", "weiter", KeywordCategory::ControlFlow),
        ("bool", "Wahrheit", KeywordCategory::TypeRelated),
        ("true", "wahr", KeywordCategory::TypeRelated),
        ("false", "falsch", KeywordCategory::TypeRelated),
        ("pub", "oeffentlich", KeywordCategory::Visibility),
        ("use", "benutze", KeywordCategory::Module),
        ("mod", "Modul", KeywordCategory::Module),
        ("as", "als", KeywordCategory::Other),
        ("in", "in", KeywordCategory::Other),
        ("print", "drucke", KeywordCategory::Other),
    ]
}

// ── Core Function ───────────────────────────────────────────────────

/// Map constraints to a target topology.
///
/// This is the core inversion: from declarative constraints
/// to a structural description of what the language looks like.
pub fn constraints_to_topology(
    constraints: &LanguageConstraints,
    _dof: &DoFAnalysis,
) -> Result<LanguageTopology> {
    // Check for hard conflicts
    let conflicts = detect_conflicts(constraints);
    let errors: Vec<_> = conflicts
        .iter()
        .filter(|c| c.severity == ConflictSeverity::Error)
        .collect();
    if !errors.is_empty() {
        return Err(TopologyError::ConflictError(
            errors
                .iter()
                .map(|c| c.reason.clone())
                .collect::<Vec<_>>()
                .join("; "),
        ));
    }

    // Compute node kind count based on enabled features
    let mut node_kinds = 8; // base: program, block, statement, expression, literal, identifier, type, error
    if constraints.control_flow.if_else {
        node_kinds += 2; // if_statement, else_clause
    }
    if constraints.control_flow.for_loop {
        node_kinds += 1; // for_statement
    }
    if constraints.control_flow.while_loop {
        node_kinds += 1; // while_statement
    }
    if constraints.control_flow.match_exhaustive {
        node_kinds += 2; // match_statement, match_arm
    }
    if constraints.types.structs {
        node_kinds += 2; // struct_definition, field_access
    }
    if constraints.types.enums {
        node_kinds += 2; // enum_definition, enum_variant
    }
    if constraints.types.generics {
        node_kinds += 1; // type_parameter
    }
    if constraints.types.traits {
        node_kinds += 2; // trait_definition, impl_block
    }
    if constraints.modules.imports {
        node_kinds += 1; // import_statement
    }
    // function_definition, parameter, call_expression, return_statement always present
    node_kinds += 4;

    // Compute typical max depth
    let mut max_depth: u32 = 3; // base: program > function > statement
    if constraints.control_flow.if_else {
        max_depth += 1;
    }
    if constraints.control_flow.for_loop || constraints.control_flow.while_loop {
        max_depth += 1;
    }
    if constraints.control_flow.match_exhaustive {
        max_depth += 1;
    }
    if constraints.types.generics {
        max_depth += 1;
    }

    // Compute expected Betti numbers
    let b0 = 1; // one connected module
    let mut b1 = 0; // loops
    if constraints.control_flow.for_loop {
        b1 += 1;
    }
    if constraints.control_flow.while_loop {
        b1 += 1;
    }
    if constraints.safety.recursion != RecursionPolicy::Forbidden {
        b1 += 1;
    }
    let b2 = 0;

    // Spectral gap range
    let spectral_gap_range = if node_kinds < 15 {
        (0.5, 1.5)
    } else if node_kinds < 25 {
        (0.3, 1.0)
    } else {
        (0.2, 0.8)
    };

    // Type complexity
    let mut type_complexity = 0.0;
    if !constraints.types.integers.is_empty() {
        type_complexity += 0.1;
    }
    if !constraints.types.floats.is_empty() {
        type_complexity += 0.1;
    }
    if constraints.types.strings != StringModel::None {
        type_complexity += 0.1;
    }
    if constraints.types.structs {
        type_complexity += 0.15;
    }
    if constraints.types.enums {
        type_complexity += 0.15;
    }
    if constraints.types.generics {
        type_complexity += 0.2;
    }
    if constraints.types.traits {
        type_complexity += 0.2;
    }
    if constraints.types.references == ReferenceModel::Borrow {
        type_complexity += 0.15;
    }

    // Control flow complexity
    let mut control_complexity = 0.0;
    if constraints.control_flow.if_else {
        control_complexity += 0.15;
    }
    if constraints.control_flow.for_loop {
        control_complexity += 0.15;
    }
    if constraints.control_flow.while_loop {
        control_complexity += 0.1;
    }
    if constraints.control_flow.match_exhaustive {
        control_complexity += 0.15;
    }
    if constraints.control_flow.exceptions {
        control_complexity += 0.15;
    }
    if constraints.control_flow.early_return {
        control_complexity += 0.1;
    }
    if constraints.safety.concurrency != ConcurrencyModel::None {
        control_complexity += 0.2;
    }

    // Generate keywords
    let keywords = generate_keywords(constraints);

    // Generate operators
    let operators = generate_operators(constraints);

    // Build crystal
    let crystal = build_crystal(constraints, &keywords, &operators)?;

    Ok(LanguageTopology {
        node_kind_count: node_kinds,
        typical_max_depth: max_depth,
        expected_betti: vec![b0, b1, b2],
        spectral_gap_range,
        type_complexity,
        control_complexity,
        keywords,
        operators,
        crystal,
    })
}

/// Generate the keyword list based on constraints.
fn generate_keywords(constraints: &LanguageConstraints) -> Vec<Keyword> {
    let raw_keywords = match &constraints.syntax.keyword_language {
        KeywordLanguage::Swahili => swahili_keywords(),
        KeywordLanguage::German => german_keywords(),
        KeywordLanguage::Custom(mappings) => {
            let base = english_keywords();
            base.into_iter()
                .map(|(canonical, default_surface, cat)| {
                    let surface = mappings
                        .iter()
                        .find(|m| m.canonical == canonical)
                        .map(|m| m.surface.as_str())
                        .unwrap_or(default_surface);
                    (canonical, surface, cat)
                })
                .collect::<Vec<_>>()
                // Need to handle lifetime - collect to owned
                .into_iter()
                .map(|(c, s, cat)| (c, s, cat))
                .collect()
        }
        _ => english_keywords(), // English is default for all other languages for now
    };

    let mut keywords: Vec<Keyword> = Vec::new();

    for (canonical, surface, category) in raw_keywords {
        // Skip keywords for features that are disabled
        let include = match canonical {
            "while" => constraints.control_flow.while_loop,
            "for" | "in" => constraints.control_flow.for_loop,
            "match" => constraints.control_flow.match_exhaustive,
            "struct" => constraints.types.structs,
            "enum" => constraints.types.enums,
            "pub" => constraints.modules.visibility == VisibilityModel::Explicit,
            "use" | "mod" => constraints.modules.imports,
            "mut" => constraints.types.references == ReferenceModel::Borrow,
            "break" | "continue" => {
                constraints.control_flow.for_loop || constraints.control_flow.while_loop
            }
            _ => true,
        };

        if include {
            keywords.push(Keyword {
                canonical: canonical.to_string(),
                surface: surface.to_string(),
                category,
            });
        }
    }

    // Respect max_keywords limit
    if let Some(max) = constraints.syntax.max_keywords {
        keywords.truncate(max as usize);
    }

    keywords
}

/// Generate operator list based on constraints.
fn generate_operators(constraints: &LanguageConstraints) -> Vec<Operator> {
    let mut ops = vec![
        // Arithmetic (always present if integers exist)
        Operator {
            symbol: "+".to_string(),
            kind: OperatorKind::Arithmetic,
            precedence: 10,
            associativity: Associativity::Left,
        },
        Operator {
            symbol: "-".to_string(),
            kind: OperatorKind::Arithmetic,
            precedence: 10,
            associativity: Associativity::Left,
        },
        Operator {
            symbol: "*".to_string(),
            kind: OperatorKind::Arithmetic,
            precedence: 20,
            associativity: Associativity::Left,
        },
        Operator {
            symbol: "/".to_string(),
            kind: OperatorKind::Arithmetic,
            precedence: 20,
            associativity: Associativity::Left,
        },
        Operator {
            symbol: "%".to_string(),
            kind: OperatorKind::Arithmetic,
            precedence: 20,
            associativity: Associativity::Left,
        },
        // Comparison (always present)
        Operator {
            symbol: "==".to_string(),
            kind: OperatorKind::Comparison,
            precedence: 5,
            associativity: Associativity::None,
        },
        Operator {
            symbol: "!=".to_string(),
            kind: OperatorKind::Comparison,
            precedence: 5,
            associativity: Associativity::None,
        },
        Operator {
            symbol: "<".to_string(),
            kind: OperatorKind::Comparison,
            precedence: 5,
            associativity: Associativity::None,
        },
        Operator {
            symbol: ">".to_string(),
            kind: OperatorKind::Comparison,
            precedence: 5,
            associativity: Associativity::None,
        },
        Operator {
            symbol: "<=".to_string(),
            kind: OperatorKind::Comparison,
            precedence: 5,
            associativity: Associativity::None,
        },
        Operator {
            symbol: ">=".to_string(),
            kind: OperatorKind::Comparison,
            precedence: 5,
            associativity: Associativity::None,
        },
        // Logical
        Operator {
            symbol: "&&".to_string(),
            kind: OperatorKind::Logical,
            precedence: 3,
            associativity: Associativity::Left,
        },
        Operator {
            symbol: "||".to_string(),
            kind: OperatorKind::Logical,
            precedence: 2,
            associativity: Associativity::Left,
        },
        Operator {
            symbol: "!".to_string(),
            kind: OperatorKind::Logical,
            precedence: 25,
            associativity: Associativity::Right,
        },
        // Assignment
        Operator {
            symbol: "=".to_string(),
            kind: OperatorKind::Assignment,
            precedence: 1,
            associativity: Associativity::Right,
        },
    ];

    // Access operator for structs
    if constraints.types.structs {
        ops.push(Operator {
            symbol: ".".to_string(),
            kind: OperatorKind::Access,
            precedence: 30,
            associativity: Associativity::Left,
        });
    }

    // Reference operators for borrow semantics
    if constraints.types.references == ReferenceModel::Borrow {
        ops.push(Operator {
            symbol: "&".to_string(),
            kind: OperatorKind::Reference,
            precedence: 25,
            associativity: Associativity::Right,
        });
    }

    // Range operator for for loops
    if constraints.control_flow.for_loop {
        ops.push(Operator {
            symbol: "..".to_string(),
            kind: OperatorKind::Range,
            precedence: 4,
            associativity: Associativity::None,
        });
    }

    ops
}

/// Build a PSE crystal with SHA-256 evidence chain.
fn build_crystal(
    constraints: &LanguageConstraints,
    keywords: &[Keyword],
    operators: &[Operator],
) -> Result<Crystal> {
    let constraint_bytes = serde_json::to_vec(constraints)?;
    let keyword_bytes = serde_json::to_vec(keywords)?;
    let operator_bytes = serde_json::to_vec(operators)?;

    // Hash each component
    let constraint_hash = sha256_hex(&constraint_bytes);
    let keyword_hash = sha256_hex(&keyword_bytes);
    let operator_hash = sha256_hex(&operator_bytes);

    // Chain: each entry hashes the previous + current
    let mut chain_input = constraint_bytes.clone();
    chain_input.extend_from_slice(&keyword_bytes);
    chain_input.extend_from_slice(&operator_bytes);
    let chain_hash = sha256_hex(&chain_input);

    let evidence = vec![
        EvidenceEntry {
            description: "input_constraints".to_string(),
            digest: constraint_hash.clone(),
        },
        EvidenceEntry {
            description: "generated_keywords".to_string(),
            digest: keyword_hash,
        },
        EvidenceEntry {
            description: "generated_operators".to_string(),
            digest: operator_hash,
        },
        EvidenceEntry {
            description: "topology_chain".to_string(),
            digest: chain_hash.clone(),
        },
    ];

    let id = format!("crystal-{}", &chain_hash[..16]);

    Ok(Crystal {
        id,
        evidence,
        constraint_hash,
    })
}

/// Compute SHA-256 hex digest.
fn sha256_hex(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    let result = hasher.finalize();
    hex::encode(result)
}

/// Simple hex encoding.
mod hex {
    pub fn encode(bytes: impl AsRef<[u8]>) -> String {
        bytes
            .as_ref()
            .iter()
            .map(|b| format!("{b:02x}"))
            .collect()
    }
}

// ── Tests ───────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn embedded_safety_constraints() -> LanguageConstraints {
        let toml = include_str!("../../../presets/embedded_safety.toml");
        schmiede_constraints::parse_constraints(toml).unwrap()
    }

    fn swahili_constraints() -> LanguageConstraints {
        let toml = include_str!("../../../presets/education_swahili.toml");
        schmiede_constraints::parse_constraints(toml).unwrap()
    }

    #[test]
    fn embedded_safety_topology() {
        let c = embedded_safety_constraints();
        let dof = compute_dof(&c);
        let topo = constraints_to_topology(&c, &dof).unwrap();

        // for_loop=true means b1 >= 1
        assert!(topo.expected_betti[1] >= 1, "expected b1 >= 1 for for loops");
        // while_loop=false means no while contribution
        assert!(topo.node_kind_count > 10, "should have many node kinds");
        assert!(topo.type_complexity > 0.3, "embedded safety has moderate type complexity");
    }

    #[test]
    fn english_keywords_generated() {
        let c = embedded_safety_constraints();
        let dof = compute_dof(&c);
        let topo = constraints_to_topology(&c, &dof).unwrap();

        let fn_kw = topo.keywords.iter().find(|k| k.canonical == "function");
        assert!(fn_kw.is_some(), "should have function keyword");
        assert_eq!(fn_kw.unwrap().surface, "fn");

        // while_loop=false → no while keyword
        let while_kw = topo.keywords.iter().find(|k| k.canonical == "while");
        assert!(while_kw.is_none(), "should not have while keyword");
    }

    #[test]
    fn swahili_keywords_generated() {
        let c = swahili_constraints();
        let dof = compute_dof(&c);
        let topo = constraints_to_topology(&c, &dof).unwrap();

        let fn_kw = topo.keywords.iter().find(|k| k.canonical == "function");
        assert!(fn_kw.is_some(), "should have function keyword");
        assert_eq!(fn_kw.unwrap().surface, "kazi");

        let if_kw = topo.keywords.iter().find(|k| k.canonical == "if");
        assert!(if_kw.is_some());
        assert_eq!(if_kw.unwrap().surface, "kama");

        let print_kw = topo.keywords.iter().find(|k| k.canonical == "print");
        assert!(print_kw.is_some());
        assert_eq!(print_kw.unwrap().surface, "chapisha");
    }

    #[test]
    fn operators_include_range_for_loops() {
        let c = embedded_safety_constraints();
        let dof = compute_dof(&c);
        let topo = constraints_to_topology(&c, &dof).unwrap();

        let range_op = topo.operators.iter().find(|o| o.symbol == "..");
        assert!(range_op.is_some(), "should have range operator for for loops");
    }

    #[test]
    fn crystal_has_evidence_chain() {
        let c = embedded_safety_constraints();
        let dof = compute_dof(&c);
        let topo = constraints_to_topology(&c, &dof).unwrap();

        assert!(!topo.crystal.id.is_empty());
        assert!(topo.crystal.id.starts_with("crystal-"));
        assert!(!topo.crystal.evidence.is_empty());
        assert!(!topo.crystal.constraint_hash.is_empty());
        // All digests should be 64-char hex (SHA-256)
        for entry in &topo.crystal.evidence {
            assert_eq!(entry.digest.len(), 64, "SHA-256 should be 64 hex chars");
        }
    }
}

//! codex-generate — Code Generation from Crystals
//!
//! Generates source code in a target language from a crystallized pattern.
//! This is the inverse of codex-parse: crystals go in, code comes out.

use codex_learn::{CodeCrystal, CodePatternType, CrystalId};
use serde::{Deserialize, Serialize};
use thiserror::Error;

// ── Errors ───────────────────────────────────────────────────────────

/// Errors from code generation.
#[derive(Debug, Error)]
pub enum GenerateError {
    /// No template available for the given pattern/language.
    #[error("no template available for {pattern:?} in {language}")]
    NoTemplate {
        pattern: CodePatternType,
        language: String,
    },
    /// Generated code failed topology check.
    #[error("topology check failed: similarity {similarity:.2} < threshold {threshold:.2}")]
    TopologyMismatch { similarity: f64, threshold: f64 },
    /// Parse error in generated code.
    #[error("parse error: {0}")]
    ParseError(#[from] codex_parse::ParseError),
}

// ── Configuration ────────────────────────────────────────────────────

/// Code generation configuration.
#[derive(Debug, Clone)]
pub struct GenerateConfig {
    /// Use templates only (no LLM).
    pub offline_only: bool,
    /// LLM API endpoint (if llm feature enabled).
    pub llm_endpoint: Option<String>,
    /// LLM API key.
    pub llm_api_key: Option<String>,
    /// LLM model identifier.
    pub llm_model: Option<String>,
    /// Minimum topology similarity for accepting output.
    pub min_acceptance_similarity: f64,
    /// Maximum LLM retries.
    pub max_retries: u32,
}

impl Default for GenerateConfig {
    fn default() -> Self {
        Self {
            offline_only: true,
            llm_endpoint: None,
            llm_api_key: None,
            llm_model: Some("gpt-4o-mini".into()),
            min_acceptance_similarity: 0.75,
            max_retries: 3,
        }
    }
}

// ── Output Types ─────────────────────────────────────────────────────

/// Generated code output.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GeneratedCode {
    /// Target language.
    pub language: String,
    /// Generated source code.
    pub code: String,
    /// Method used for generation.
    pub method: GenerationMethod,
    /// Topology similarity to source crystal.
    pub topology_similarity: f64,
    /// Source crystal ID.
    pub crystal_id: CrystalId,
}

/// How the code was generated.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub enum GenerationMethod {
    /// Template-based generation.
    Template,
    /// LLM-assisted generation.
    LlmAssisted { model: String, attempts: u32 },
}

// ── Public API ───────────────────────────────────────────────────────

/// Generate code from a crystal in the target language.
///
/// Tries template generation first. Falls back to LLM if
/// the `llm` feature is enabled and template is insufficient.
pub fn generate(
    crystal: &CodeCrystal,
    target_language: &str,
    _config: &GenerateConfig,
) -> Result<GeneratedCode, GenerateError> {
    // Try template generation
    if let Some(code) = generate_from_template(&crystal.pattern_type, target_language, crystal) {
        // Verify topology
        let topo_config = codex_topo::TopoConfig::default();
        let gen_topo =
            codex_topo::topology_from_source(&code, target_language, &topo_config)?;
        let similarity = codex_topo::topology_similarity(&crystal.topology, &gen_topo);

        return Ok(GeneratedCode {
            language: target_language.to_string(),
            code,
            method: GenerationMethod::Template,
            topology_similarity: similarity,
            crystal_id: crystal.id.clone(),
        });
    }

    Err(GenerateError::NoTemplate {
        pattern: crystal.pattern_type.clone(),
        language: target_language.into(),
    })
}

// ── Template System ──────────────────────────────────────────────────

/// Generate code from a template based on pattern type.
fn generate_from_template(
    pattern: &CodePatternType,
    language: &str,
    _crystal: &CodeCrystal,
) -> Option<String> {
    match pattern {
        CodePatternType::CRUDEndpoint => crud_template(language),
        CodePatternType::DataTransformPipeline => data_transform_template(language),
        CodePatternType::ErrorHandlingChain => error_handling_template(language),
        CodePatternType::RecursiveTraversal => recursive_traversal_template(language),
        CodePatternType::MapFilterReduce => map_filter_reduce_template(language),
        CodePatternType::IterativeProcessing => iterative_template(language),
        CodePatternType::ObserverPattern => observer_template(language),
        CodePatternType::FileReadWrite => file_io_template(language),
        _ => None,
    }
}

fn crud_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
class Item:
    def __init__(self, id, name, value):
        self.id = id
        self.name = name
        self.value = value

class CRUDHandler:
    def __init__(self):
        self.store = {}

    def create(self, item):
        if item.id in self.store:
            raise ValueError(f"Item {item.id} already exists")
        self.store[item.id] = item
        return item

    def read(self, item_id):
        if item_id not in self.store:
            raise KeyError(f"Item {item_id} not found")
        return self.store[item_id]

    def update(self, item_id, name=None, value=None):
        if item_id not in self.store:
            raise KeyError(f"Item {item_id} not found")
        item = self.store[item_id]
        if name is not None:
            item.name = name
        if value is not None:
            item.value = value
        return item

    def delete(self, item_id):
        if item_id not in self.store:
            raise KeyError(f"Item {item_id} not found")
        return self.store.pop(item_id)

    def list_all(self):
        return list(self.store.values())
"#.to_string()),
        "rust" => Some(r#"
use std::collections::HashMap;

#[derive(Clone, Debug)]
struct Item {
    id: String,
    name: String,
    value: f64,
}

struct CrudHandler {
    store: HashMap<String, Item>,
}

impl CrudHandler {
    fn new() -> Self {
        Self { store: HashMap::new() }
    }

    fn create(&mut self, item: Item) -> Result<&Item, String> {
        if self.store.contains_key(&item.id) {
            return Err(format!("Item {} already exists", item.id));
        }
        let id = item.id.clone();
        self.store.insert(id.clone(), item);
        Ok(&self.store[&id])
    }

    fn read(&self, id: &str) -> Result<&Item, String> {
        self.store.get(id).ok_or_else(|| format!("Item {} not found", id))
    }

    fn update(&mut self, id: &str, name: Option<&str>, value: Option<f64>) -> Result<&Item, String> {
        let item = self.store.get_mut(id).ok_or_else(|| format!("Item {} not found", id))?;
        if let Some(n) = name { item.name = n.to_string(); }
        if let Some(v) = value { item.value = v; }
        Ok(item)
    }

    fn delete(&mut self, id: &str) -> Result<Item, String> {
        self.store.remove(id).ok_or_else(|| format!("Item {} not found", id))
    }

    fn list_all(&self) -> Vec<&Item> {
        self.store.values().collect()
    }
}
"#.to_string()),
        "javascript" => Some(r#"
class Item {
    constructor(id, name, value) {
        this.id = id;
        this.name = name;
        this.value = value;
    }
}

class CRUDHandler {
    constructor() {
        this.store = new Map();
    }

    create(item) {
        if (this.store.has(item.id)) {
            throw new Error(`Item ${item.id} already exists`);
        }
        this.store.set(item.id, item);
        return item;
    }

    read(itemId) {
        if (!this.store.has(itemId)) {
            throw new Error(`Item ${itemId} not found`);
        }
        return this.store.get(itemId);
    }

    update(itemId, name, value) {
        if (!this.store.has(itemId)) {
            throw new Error(`Item ${itemId} not found`);
        }
        const item = this.store.get(itemId);
        if (name !== undefined) item.name = name;
        if (value !== undefined) item.value = value;
        return item;
    }

    delete(itemId) {
        if (!this.store.has(itemId)) {
            throw new Error(`Item ${itemId} not found`);
        }
        const item = this.store.get(itemId);
        this.store.delete(itemId);
        return item;
    }

    listAll() {
        return Array.from(this.store.values());
    }
}
"#.to_string()),
        "go" => Some(r#"
package main

import (
    "errors"
    "fmt"
)

type Item struct {
    ID    string
    Name  string
    Value float64
}

type CRUDHandler struct {
    store map[string]*Item
}

func NewCRUDHandler() *CRUDHandler {
    return &CRUDHandler{store: make(map[string]*Item)}
}

func (h *CRUDHandler) Create(item *Item) (*Item, error) {
    if _, exists := h.store[item.ID]; exists {
        return nil, fmt.Errorf("item %s already exists", item.ID)
    }
    h.store[item.ID] = item
    return item, nil
}

func (h *CRUDHandler) Read(id string) (*Item, error) {
    item, exists := h.store[id]
    if !exists {
        return nil, errors.New("item not found")
    }
    return item, nil
}

func (h *CRUDHandler) Update(id string, name *string, value *float64) (*Item, error) {
    item, exists := h.store[id]
    if !exists {
        return nil, errors.New("item not found")
    }
    if name != nil {
        item.Name = *name
    }
    if value != nil {
        item.Value = *value
    }
    return item, nil
}

func (h *CRUDHandler) Delete(id string) (*Item, error) {
    item, exists := h.store[id]
    if !exists {
        return nil, errors.New("item not found")
    }
    delete(h.store, id)
    return item, nil
}

func (h *CRUDHandler) ListAll() []*Item {
    items := make([]*Item, 0, len(h.store))
    for _, item := range h.store {
        items = append(items, item)
    }
    return items
}
"#.to_string()),
        _ => None,
    }
}

fn data_transform_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
def read_data(source):
    lines = source.strip().split('\n')
    return [line.split(',') for line in lines]

def transform(data):
    result = []
    for row in data:
        transformed = [item.strip().upper() for item in row]
        result.append(transformed)
    return result

def write_data(data):
    lines = []
    for row in data:
        lines.append(','.join(row))
    return '\n'.join(lines)

def pipeline(source):
    data = read_data(source)
    transformed = transform(data)
    return write_data(transformed)
"#.to_string()),
        "rust" => Some(r#"
fn read_data(source: &str) -> Vec<Vec<String>> {
    source.trim().lines()
        .map(|line| line.split(',').map(|s| s.to_string()).collect())
        .collect()
}

fn transform(data: Vec<Vec<String>>) -> Vec<Vec<String>> {
    data.into_iter()
        .map(|row| row.into_iter().map(|s| s.trim().to_uppercase()).collect())
        .collect()
}

fn write_data(data: &[Vec<String>]) -> String {
    data.iter()
        .map(|row| row.join(","))
        .collect::<Vec<_>>()
        .join("\n")
}

fn pipeline(source: &str) -> String {
    let data = read_data(source);
    let transformed = transform(data);
    write_data(&transformed)
}
"#.to_string()),
        "javascript" => Some(r#"
function readData(source) {
    return source.trim().split('\n').map(line => line.split(','));
}

function transform(data) {
    return data.map(row => row.map(item => item.trim().toUpperCase()));
}

function writeData(data) {
    return data.map(row => row.join(',')).join('\n');
}

function pipeline(source) {
    const data = readData(source);
    const transformed = transform(data);
    return writeData(transformed);
}
"#.to_string()),
        "go" => Some(r#"
package main

import "strings"

func readData(source string) [][]string {
    lines := strings.Split(strings.TrimSpace(source), "\n")
    result := make([][]string, len(lines))
    for i, line := range lines {
        result[i] = strings.Split(line, ",")
    }
    return result
}

func transform(data [][]string) [][]string {
    result := make([][]string, len(data))
    for i, row := range data {
        transformed := make([]string, len(row))
        for j, item := range row {
            transformed[j] = strings.ToUpper(strings.TrimSpace(item))
        }
        result[i] = transformed
    }
    return result
}

func writeData(data [][]string) string {
    lines := make([]string, len(data))
    for i, row := range data {
        lines[i] = strings.Join(row, ",")
    }
    return strings.Join(lines, "\n")
}

func pipeline(source string) string {
    data := readData(source)
    transformed := transform(data)
    return writeData(transformed)
}
"#.to_string()),
        _ => None,
    }
}

fn error_handling_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
class ValidationError(Exception):
    pass

class NotFoundError(Exception):
    pass

class PermissionError(Exception):
    pass

def validate_input(data):
    if not data:
        raise ValidationError("Empty input")
    if not isinstance(data, dict):
        raise ValidationError("Expected dict")
    return True

def process_request(data):
    try:
        validate_input(data)
        result = handle(data)
        return {"status": "ok", "data": result}
    except ValidationError as e:
        return {"status": "error", "code": 400, "message": str(e)}
    except NotFoundError as e:
        return {"status": "error", "code": 404, "message": str(e)}
    except PermissionError as e:
        return {"status": "error", "code": 403, "message": str(e)}
    except Exception as e:
        return {"status": "error", "code": 500, "message": str(e)}

def handle(data):
    return data.get("value", None)
"#.to_string()),
        _ => None,
    }
}

fn recursive_traversal_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
class TreeNode:
    def __init__(self, value, children=None):
        self.value = value
        self.children = children or []

def traverse(node, accumulator=None):
    if accumulator is None:
        accumulator = []
    accumulator.append(node.value)
    for child in node.children:
        traverse(child, accumulator)
    return accumulator

def tree_sum(node):
    total = node.value
    for child in node.children:
        total += tree_sum(child)
    return total

def tree_depth(node):
    if not node.children:
        return 1
    return 1 + max(tree_depth(child) for child in node.children)
"#.to_string()),
        "rust" => Some(r#"
struct TreeNode {
    value: i64,
    children: Vec<TreeNode>,
}

fn traverse(node: &TreeNode, accumulator: &mut Vec<i64>) {
    accumulator.push(node.value);
    for child in &node.children {
        traverse(child, accumulator);
    }
}

fn tree_sum(node: &TreeNode) -> i64 {
    let mut total = node.value;
    for child in &node.children {
        total += tree_sum(child);
    }
    total
}

fn tree_depth(node: &TreeNode) -> usize {
    if node.children.is_empty() {
        return 1;
    }
    1 + node.children.iter().map(tree_depth).max().unwrap_or(0)
}
"#.to_string()),
        _ => None,
    }
}

fn map_filter_reduce_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
from functools import reduce

def process_numbers(numbers):
    doubled = list(map(lambda x: x * 2, numbers))
    evens = list(filter(lambda x: x % 2 == 0, doubled))
    total = reduce(lambda acc, x: acc + x, evens, 0)
    return total

def process_strings(strings):
    upper = list(map(str.upper, strings))
    long = list(filter(lambda s: len(s) > 3, upper))
    return long

def process_records(records):
    values = list(map(lambda r: r.get('value', 0), records))
    positive = list(filter(lambda v: v > 0, values))
    total = sum(positive)
    return total
"#.to_string()),
        _ => None,
    }
}

fn iterative_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
def binary_search(arr, target):
    left, right = 0, len(arr) - 1
    while left <= right:
        mid = (left + right) // 2
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            left = mid + 1
        else:
            right = mid - 1
    return -1

def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
    return arr
"#.to_string()),
        "rust" => Some(r#"
fn binary_search(arr: &[i64], target: i64) -> Option<usize> {
    let mut left = 0;
    let mut right = arr.len();
    while left < right {
        let mid = left + (right - left) / 2;
        if arr[mid] == target {
            return Some(mid);
        } else if arr[mid] < target {
            left = mid + 1;
        } else {
            right = mid;
        }
    }
    None
}

fn bubble_sort(arr: &mut Vec<i64>) {
    let n = arr.len();
    for i in 0..n {
        for j in 0..n - i - 1 {
            if arr[j] > arr[j + 1] {
                arr.swap(j, j + 1);
            }
        }
    }
}
"#.to_string()),
        _ => None,
    }
}

fn observer_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
class EventEmitter:
    def __init__(self):
        self.listeners = {}

    def on(self, event, callback):
        if event not in self.listeners:
            self.listeners[event] = []
        self.listeners[event].append(callback)

    def emit(self, event, *args, **kwargs):
        if event in self.listeners:
            for callback in self.listeners[event]:
                callback(*args, **kwargs)

    def off(self, event, callback):
        if event in self.listeners:
            self.listeners[event] = [
                cb for cb in self.listeners[event] if cb != callback
            ]
"#.to_string()),
        _ => None,
    }
}

fn file_io_template(language: &str) -> Option<String> {
    match language {
        "python" => Some(r#"
import os

def read_file(path):
    with open(path, 'r') as f:
        return f.read()

def write_file(path, content):
    with open(path, 'w') as f:
        f.write(content)

def transform_file(input_path, output_path, transform_fn):
    content = read_file(input_path)
    transformed = transform_fn(content)
    write_file(output_path, transformed)
    return os.path.getsize(output_path)
"#.to_string()),
        _ => None,
    }
}

// ── Tests ────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn make_test_crystal(pattern: CodePatternType) -> CodeCrystal {
        let source = match &pattern {
            CodePatternType::CRUDEndpoint => {
                "class H:\n    def create(self): pass\n    def read(self): pass\n    def update(self): pass\n    def delete(self): pass\n"
            }
            _ => "def foo():\n    return 42\n",
        };
        let mut engine = codex_learn::CodexEngine::new();
        engine.observe_source(source, "python", None).unwrap();
        let mut crystal = engine.crystals()[0].clone();
        crystal.pattern_type = pattern;
        crystal
    }

    #[test]
    fn test_generate_crud_python() {
        let crystal = make_test_crystal(CodePatternType::CRUDEndpoint);
        let config = GenerateConfig::default();
        let result = generate(&crystal, "python", &config);
        assert!(result.is_ok(), "should generate CRUD template for Python");
        let gen = result.unwrap();
        assert_eq!(gen.language, "python");
        assert!(gen.code.contains("create"));
        assert!(gen.code.contains("read"));
    }

    #[test]
    fn test_generate_crud_rust() {
        let crystal = make_test_crystal(CodePatternType::CRUDEndpoint);
        let config = GenerateConfig::default();
        let result = generate(&crystal, "rust", &config);
        assert!(result.is_ok());
        let gen = result.unwrap();
        assert!(gen.code.contains("fn create"));
    }

    #[test]
    fn test_generate_crud_javascript() {
        let crystal = make_test_crystal(CodePatternType::CRUDEndpoint);
        let config = GenerateConfig::default();
        let result = generate(&crystal, "javascript", &config);
        assert!(result.is_ok());
    }

    #[test]
    fn test_generate_crud_go() {
        let crystal = make_test_crystal(CodePatternType::CRUDEndpoint);
        let config = GenerateConfig::default();
        let result = generate(&crystal, "go", &config);
        assert!(result.is_ok());
    }

    #[test]
    fn test_generated_code_parses() {
        let crystal = make_test_crystal(CodePatternType::CRUDEndpoint);
        let config = GenerateConfig::default();
        for lang in &["python", "rust", "javascript", "go"] {
            let gen = generate(&crystal, lang, &config).unwrap();
            let result = codex_parse::parse_source(&gen.code, lang);
            assert!(
                result.is_ok(),
                "generated {} code should parse without errors",
                lang
            );
        }
    }

    #[test]
    fn test_topology_similarity_check() {
        let crystal = make_test_crystal(CodePatternType::CRUDEndpoint);
        let config = GenerateConfig::default();
        let gen = generate(&crystal, "python", &config).unwrap();
        // Similarity should be computed
        assert!(gen.topology_similarity > 0.0);
    }
}

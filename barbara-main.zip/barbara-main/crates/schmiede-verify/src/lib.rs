//! schmiede-verify — Constraint Satisfaction Verification
//!
//! After the compiler crate is generated, verifies that it actually
//! satisfies all constraints.

use schmiede_constraints::*;
use serde::{Deserialize, Serialize};
use std::path::Path;
use std::process::Command;
use thiserror::Error;

/// Errors during verification.
#[derive(Debug, Error)]
pub enum VerifyError {
    /// I/O error.
    #[error("I/O error: {0}")]
    IoError(#[from] std::io::Error),
    /// Verification failed.
    #[error("verification failed: {0}")]
    VerificationFailed(String),
}

pub type Result<T> = std::result::Result<T, VerifyError>;

/// Report of verification results.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct VerificationReport {
    /// Whether the generated compiler builds.
    pub compiler_builds: bool,
    /// Whether each example compiles.
    pub examples_compile: Vec<(String, bool)>,
    /// Whether each example runs (name, success, output).
    pub examples_run: Vec<(String, bool, String)>,
    /// Constraint checks.
    pub constraint_checks: Vec<ConstraintCheck>,
    /// Overall: all constraints satisfied.
    pub all_satisfied: bool,
}

/// A single constraint check result.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConstraintCheck {
    /// Constraint being checked.
    pub constraint: String,
    /// Whether the constraint is satisfied.
    pub satisfied: bool,
    /// Evidence or reason.
    pub evidence: String,
}

/// Verify that a generated compiler satisfies its constraints.
pub fn verify(compiler_dir: &Path, constraints: &LanguageConstraints) -> Result<VerificationReport> {
    let mut report = VerificationReport {
        compiler_builds: false,
        examples_compile: Vec::new(),
        examples_run: Vec::new(),
        constraint_checks: Vec::new(),
        all_satisfied: false,
    };

    // Step 1: Build the generated compiler
    let build_status = Command::new("cargo")
        .args(["build"])
        .current_dir(compiler_dir)
        .output();

    match build_status {
        Ok(output) => {
            report.compiler_builds = output.status.success();
            if !report.compiler_builds {
                let stderr = String::from_utf8_lossy(&output.stderr);
                report.constraint_checks.push(ConstraintCheck {
                    constraint: "compiler_builds".to_string(),
                    satisfied: false,
                    evidence: format!("Build failed: {}", stderr),
                });
                return Ok(report);
            }
        }
        Err(e) => {
            report.constraint_checks.push(ConstraintCheck {
                constraint: "compiler_builds".to_string(),
                satisfied: false,
                evidence: format!("Could not run cargo: {}", e),
            });
            return Ok(report);
        }
    }

    report.constraint_checks.push(ConstraintCheck {
        constraint: "compiler_builds".to_string(),
        satisfied: true,
        evidence: "cargo build succeeded".to_string(),
    });

    // Step 2: Check keyword count
    if let Some(max_kw) = constraints.syntax.max_keywords {
        let spec_path = compiler_dir.join("spec.md");
        if spec_path.exists() {
            let spec = std::fs::read_to_string(&spec_path).unwrap_or_default();
            let kw_count = spec.matches("- `").count();
            report.constraint_checks.push(ConstraintCheck {
                constraint: format!("max_keywords <= {}", max_kw),
                satisfied: kw_count <= max_kw as usize,
                evidence: format!("Found {} keywords", kw_count),
            });
        }
    }

    // Step 3: Check heap usage in generated code (if heap_allowed = false)
    if !constraints.platform.heap_allowed {
        let codegen_path = compiler_dir.join("src/codegen.rs");
        if codegen_path.exists() {
            let codegen = std::fs::read_to_string(&codegen_path).unwrap_or_default();
            let has_malloc = codegen.contains("malloc") || codegen.contains("calloc") || codegen.contains("realloc");
            report.constraint_checks.push(ConstraintCheck {
                constraint: "heap_allowed = false (no malloc in codegen)".to_string(),
                satisfied: !has_malloc,
                evidence: if has_malloc {
                    "Found malloc/calloc/realloc in codegen".to_string()
                } else {
                    "No heap allocation functions found".to_string()
                },
            });
        }
    }

    // Step 4: Compile examples
    let examples_dir = compiler_dir.join("examples");
    if examples_dir.exists() {
        let compiler_name = constraints.meta.name.to_lowercase();
        let compiler_bin = compiler_dir.join(format!("target/debug/{}c", compiler_name));

        if let Ok(entries) = std::fs::read_dir(&examples_dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                let name = path.file_name().unwrap_or_default().to_string_lossy().to_string();

                if compiler_bin.exists() {
                    let output = Command::new(&compiler_bin)
                        .arg(&path)
                        .arg("--output")
                        .arg(compiler_dir.join(format!("target/{}.c", name)))
                        .output();

                    match output {
                        Ok(o) => {
                            report.examples_compile.push((name.clone(), o.status.success()));
                        }
                        Err(_) => {
                            report.examples_compile.push((name.clone(), false));
                        }
                    }
                } else {
                    report.examples_compile.push((name.clone(), false));
                }
            }
        }
    }

    // Determine overall satisfaction
    report.all_satisfied = report.compiler_builds
        && report.constraint_checks.iter().all(|c| c.satisfied);

    Ok(report)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn verification_report_structure() {
        let report = VerificationReport {
            compiler_builds: true,
            examples_compile: vec![("hello.se".to_string(), true)],
            examples_run: vec![],
            constraint_checks: vec![ConstraintCheck {
                constraint: "test".to_string(),
                satisfied: true,
                evidence: "ok".to_string(),
            }],
            all_satisfied: true,
        };
        assert!(report.all_satisfied);
        assert!(report.compiler_builds);
    }

    #[test]
    fn constraint_check_serializable() {
        let check = ConstraintCheck {
            constraint: "heap_allowed = false".to_string(),
            satisfied: true,
            evidence: "no malloc found".to_string(),
        };
        let json = serde_json::to_string(&check).unwrap();
        assert!(json.contains("heap_allowed"));
    }
}

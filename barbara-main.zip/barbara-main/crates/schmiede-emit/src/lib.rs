//! schmiede-emit — Assembly and Output
//!
//! Takes all generated artifacts and assembles them into a standalone
//! Rust compiler crate.

use schmiede_constraints::*;
use schmiede_grammar::{Grammar, grammar_to_ebnf};
use schmiede_topology::LanguageTopology;
use sha2::{Digest, Sha256};
use std::path::{Path, PathBuf};
use thiserror::Error;

/// Errors during emission.
#[derive(Debug, Error)]
pub enum EmitError {
    /// I/O error.
    #[error("I/O error: {0}")]
    IoError(#[from] std::io::Error),
    /// Template error.
    #[error("template error: {0}")]
    TemplateError(#[from] tera::Error),
    /// Serialization error.
    #[error("serialization error: {0}")]
    SerializationError(#[from] serde_json::Error),
    /// Lexer generation error.
    #[error("lexer generation: {0}")]
    LexgenError(#[from] schmiede_lexgen::LexgenError),
    /// Parser generation error.
    #[error("parser generation: {0}")]
    ParsegenError(#[from] schmiede_parsegen::ParsegenError),
    /// Type checker generation error.
    #[error("typegen error: {0}")]
    TypegenError(#[from] schmiede_typegen::TypegenError),
    /// Code generator generation error.
    #[error("codegen error: {0}")]
    CodegenError(#[from] schmiede_codegen::CodegenError),
}

pub type Result<T> = std::result::Result<T, EmitError>;

/// Configuration for compiler emission.
pub struct EmitConfig {
    /// Directory to write the compiler crate to.
    pub output_dir: PathBuf,
}

/// Result of compiler emission.
pub struct EmitResult {
    /// Directory where the compiler crate was written.
    pub output_dir: PathBuf,
    /// Files written.
    pub files_written: Vec<PathBuf>,
    /// Path to generated spec.md.
    pub spec_path: PathBuf,
    /// Path to constraint_proof.json.
    pub proof_path: PathBuf,
}

/// Assemble a complete compiler crate from constraints and topology.
///
/// This is the high-level entry point that generates all code and writes it to disk.
pub fn emit_from_pipeline(
    config: &EmitConfig,
    constraints: &LanguageConstraints,
    topology: &LanguageTopology,
    grammar: &Grammar,
) -> Result<EmitResult> {
    // Generate all code
    let lexer_code = schmiede_lexgen::generate_lexer(grammar)?;
    let parser_output = schmiede_parsegen::generate_parser(grammar, constraints)?;
    let typechecker_code = schmiede_typegen::generate_typechecker(constraints, grammar)?;
    let codegen_code = schmiede_codegen::generate_codegen(constraints, grammar)?;

    emit_compiler(
        config,
        grammar,
        &lexer_code,
        &parser_output.ast_code,
        &parser_output.parser_code,
        &typechecker_code,
        &codegen_code,
        constraints,
        topology,
    )
}

/// Assemble a complete compiler crate from pre-generated components.
pub fn emit_compiler(
    config: &EmitConfig,
    grammar: &Grammar,
    lexer_code: &str,
    ast_code: &str,
    parser_code: &str,
    typechecker_code: &str,
    codegen_code: &str,
    constraints: &LanguageConstraints,
    topology: &LanguageTopology,
) -> Result<EmitResult> {
    let out = &config.output_dir;
    let src = out.join("src");
    let examples_dir = out.join("examples");

    // Create directories
    std::fs::create_dir_all(&src)?;
    std::fs::create_dir_all(&examples_dir)?;

    let mut files_written = Vec::new();

    // Write source files
    write_file(&src.join("lexer.rs"), lexer_code, &mut files_written)?;
    write_file(&src.join("ast.rs"), ast_code, &mut files_written)?;
    write_file(&src.join("parser.rs"), parser_code, &mut files_written)?;
    write_file(&src.join("typechecker.rs"), typechecker_code, &mut files_written)?;
    write_file(&src.join("codegen.rs"), codegen_code, &mut files_written)?;

    // Generate error.rs
    let error_code = generate_error_module(&constraints.meta.name);
    write_file(&src.join("error.rs"), &error_code, &mut files_written)?;

    // Generate main.rs
    let ext = constraints.meta.name.to_lowercase();
    let main_code = generate_main(&constraints.meta.name, &ext)?;
    write_file(&src.join("main.rs"), &main_code, &mut files_written)?;

    // Generate Cargo.toml
    let cargo_toml = generate_cargo_toml(constraints)?;
    write_file(&out.join("Cargo.toml"), &cargo_toml, &mut files_written)?;

    // Generate spec.md
    let spec = generate_spec(constraints, topology, grammar)?;
    let spec_path = out.join("spec.md");
    write_file(&spec_path, &spec, &mut files_written)?;

    // Generate example programs
    let examples = generate_examples(constraints, topology);
    for (name, code) in &examples {
        write_file(&examples_dir.join(name), code, &mut files_written)?;
    }

    // Generate constraint_proof.json
    let proof = generate_proof(constraints, topology, &files_written)?;
    let proof_path = out.join("constraint_proof.json");
    write_file(&proof_path, &proof, &mut files_written)?;

    Ok(EmitResult {
        output_dir: out.clone(),
        files_written,
        spec_path,
        proof_path,
    })
}

fn write_file(path: &Path, content: &str, written: &mut Vec<PathBuf>) -> Result<()> {
    std::fs::write(path, content)?;
    written.push(path.to_path_buf());
    Ok(())
}

fn generate_error_module(name: &str) -> String {
    format!(
        r#"//! Error types for {name} compiler.
//! Generated by Die Schmiede.

/// Compiler error.
#[derive(Debug)]
pub enum CompileError {{
    /// Lexer error.
    Lex(String),
    /// Parse error.
    Parse(String),
    /// Type error.
    Type(String),
    /// Code generation error.
    Codegen(String),
    /// I/O error.
    Io(std::io::Error),
}}

impl std::fmt::Display for CompileError {{
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {{
        match self {{
            CompileError::Lex(msg) => write!(f, "lex error: {{}}", msg),
            CompileError::Parse(msg) => write!(f, "parse error: {{}}", msg),
            CompileError::Type(msg) => write!(f, "type error: {{}}", msg),
            CompileError::Codegen(msg) => write!(f, "codegen error: {{}}", msg),
            CompileError::Io(e) => write!(f, "I/O error: {{}}", e),
        }}
    }}
}}

impl std::error::Error for CompileError {{}}
"#
    )
}

fn generate_main(name: &str, ext: &str) -> Result<String> {
    let mut tera = tera::Tera::default();
    let template_str = include_str!("../../../templates/main_template.rs.tera");
    tera.add_raw_template("main.rs.tera", template_str)?;
    let mut ctx = tera::Context::new();
    ctx.insert("name", name);
    ctx.insert("ext", ext);
    let output = tera.render("main.rs.tera", &ctx)?;
    Ok(output)
}

fn generate_cargo_toml(constraints: &LanguageConstraints) -> Result<String> {
    let mut tera = tera::Tera::default();
    let template_str = include_str!("../../../templates/cargo_toml_template.tera");
    tera.add_raw_template("Cargo.toml.tera", template_str)?;
    let mut ctx = tera::Context::new();
    ctx.insert("name", &constraints.meta.name);
    // Normalize version to valid semver (MAJOR.MINOR.PATCH)
    let version = &constraints.meta.version;
    let normalized_version = if version.matches('.').count() < 2 {
        format!("{}.0", version)
    } else {
        version.clone()
    };
    ctx.insert("version", &normalized_version);
    ctx.insert("description", &constraints.meta.description);
    let output = tera.render("Cargo.toml.tera", &ctx)?;
    Ok(output)
}

fn generate_spec(
    constraints: &LanguageConstraints,
    topology: &LanguageTopology,
    grammar: &Grammar,
) -> Result<String> {
    let mut tera = tera::Tera::default();
    let template_str = include_str!("../../../templates/spec_template.md.tera");
    tera.add_raw_template("spec.md.tera", template_str)?;

    let mut ctx = tera::Context::new();
    ctx.insert("name", &constraints.meta.name);
    ctx.insert("version", &constraints.meta.version);
    ctx.insert("description", &constraints.meta.description);
    ctx.insert("platform_target", &format!("{:?}", constraints.platform.target));
    ctx.insert("max_ram_kb", &constraints.platform.max_ram_kb);
    ctx.insert("max_flash_kb", &constraints.platform.max_flash_kb);
    ctx.insert("heap_allowed", &constraints.platform.heap_allowed);
    ctx.insert("os", &format!("{:?}", constraints.platform.os));
    ctx.insert("float_support", &format!("{:?}", constraints.platform.float));
    ctx.insert("memory_safety", &format!("{:?}", constraints.safety.memory_safety));
    ctx.insert("null_allowed", &constraints.safety.null_allowed);
    ctx.insert("overflow", &format!("{:?}", constraints.safety.overflow));
    ctx.insert("array_bounds", &format!("{:?}", constraints.safety.array_bounds));
    ctx.insert("concurrency", &format!("{:?}", constraints.safety.concurrency));
    ctx.insert("recursion", &format!("{:?}", constraints.safety.recursion));
    ctx.insert("integer_types", &constraints.types.integers);
    ctx.insert("float_types", &constraints.types.floats);
    ctx.insert("has_strings", &(constraints.types.strings != StringModel::None));
    ctx.insert("string_model", &format!("{:?}", constraints.types.strings));
    ctx.insert("has_structs", &constraints.types.structs);
    ctx.insert("has_enums", &constraints.types.enums);
    ctx.insert("has_tuples", &constraints.types.tuples);
    ctx.insert("has_generics", &constraints.types.generics);
    ctx.insert("has_traits", &constraints.types.traits);
    ctx.insert("comment_style", &grammar.comment_style);
    ctx.insert("block_style", &grammar.block_style);
    ctx.insert("semicolons", &grammar.semicolons);
    ctx.insert("has_if", &constraints.control_flow.if_else);
    ctx.insert("has_for", &constraints.control_flow.for_loop);
    ctx.insert("has_while", &constraints.control_flow.while_loop);
    ctx.insert("has_match", &constraints.control_flow.match_exhaustive);
    ctx.insert("has_return", &constraints.control_flow.early_return);
    ctx.insert("emit_target", &format!("{:?}", constraints.output.emit));
    ctx.insert("optimization", &format!("{:?}", constraints.output.optimization));
    ctx.insert("debug_info", &constraints.output.debug_info);

    // Keyword info
    #[derive(serde::Serialize)]
    struct KwInfo { canonical: String, surface: String }
    let kw_infos: Vec<KwInfo> = topology.keywords.iter().map(|k| KwInfo {
        canonical: k.canonical.clone(),
        surface: k.surface.clone(),
    }).collect();
    ctx.insert("keywords", &kw_infos);

    // Surface form lookups
    let find = |canonical: &str| -> String {
        topology.keywords.iter().find(|k| k.canonical == canonical)
            .map(|k| k.surface.clone()).unwrap_or_else(|| canonical.to_string())
    };
    ctx.insert("if_keyword", &find("if"));
    ctx.insert("else_keyword", &find("else"));
    ctx.insert("for_keyword", &find("for"));
    ctx.insert("while_keyword", &find("while"));
    ctx.insert("match_keyword", &find("match"));
    ctx.insert("return_keyword", &find("return"));

    // EBNF
    let ebnf = grammar_to_ebnf(grammar);
    ctx.insert("ebnf", &ebnf);

    let output = tera.render("spec.md.tera", &ctx)?;
    Ok(output)
}

fn generate_examples(
    constraints: &LanguageConstraints,
    topology: &LanguageTopology,
) -> Vec<(String, String)> {
    let ext = constraints.meta.name.to_lowercase();
    let find = |canonical: &str| -> String {
        topology.keywords.iter().find(|k| k.canonical == canonical)
            .map(|k| k.surface.clone()).unwrap_or_else(|| canonical.to_string())
    };

    let fn_kw = find("function");
    let let_kw = find("let");
    let if_kw = find("if");
    let else_kw = find("else");
    let for_kw = find("for");
    let in_kw = find("in");
    let return_kw = find("return");
    let print_kw = find("print");
    let _true_kw = find("true");
    let _false_kw = find("false");
    let struct_kw = find("struct");
    let _match_kw = find("match");

    let semi = if constraints.syntax.semicolons { ";" } else { "" };

    let mut examples = Vec::new();

    // hello
    examples.push((
        format!("hello.{ext}"),
        format!(
            r#"// Hello World in {name}
{fn_kw} main() {{
    {print_kw}("Hello, World!"){semi}
}}
"#,
            name = constraints.meta.name,
        ),
    ));

    // fibonacci
    if constraints.safety.recursion != RecursionPolicy::Forbidden {
        examples.push((
            format!("fibonacci.{ext}"),
            format!(
                r#"// Fibonacci in {name}
{fn_kw} fibonacci(n: i32) -> i32 {{
    {if_kw} n <= 1 {{
        {return_kw} n{semi}
    }}
    {return_kw} fibonacci(n - 1) + fibonacci(n - 2){semi}
}}

{fn_kw} main() {{
    {let_kw} result: i32 = fibonacci(10){semi}
    {print_kw}("fibonacci(10)"){semi}
}}
"#,
                name = constraints.meta.name,
            ),
        ));
    } else {
        examples.push((
            format!("fibonacci.{ext}"),
            format!(
                r#"// Iterative Fibonacci in {name}
{fn_kw} main() {{
    {let_kw} a: i32 = 0{semi}
    {let_kw} b: i32 = 1{semi}
    {for_kw} i {in_kw} 0..10 {{
        {let_kw} temp: i32 = b{semi}
        b = a + b{semi}
        a = temp{semi}
    }}
    {print_kw}("fibonacci(10)"){semi}
}}
"#,
                name = constraints.meta.name,
            ),
        ));
    }

    // structs
    if constraints.types.structs {
        examples.push((
            format!("structs.{ext}"),
            format!(
                r#"// Structs in {name}
{struct_kw} Point {{
    x: i32,
    y: i32,
}}

{fn_kw} distance(p: Point) -> i32 {{
    {return_kw} p.x + p.y{semi}
}}

{fn_kw} main() {{
    {let_kw} p: Point = Point {{ x: 3, y: 4 }}{semi}
    {let_kw} d: i32 = distance(p){semi}
    {print_kw}("distance computed"){semi}
}}
"#,
                name = constraints.meta.name,
            ),
        ));
    } else {
        examples.push((
            format!("structs.{ext}"),
            format!(
                r#"// Data example in {name}
{fn_kw} add(a: i32, b: i32) -> i32 {{
    {return_kw} a + b{semi}
}}

{fn_kw} main() {{
    {let_kw} result: i32 = add(3, 4){semi}
    {print_kw}("result computed"){semi}
}}
"#,
                name = constraints.meta.name,
            ),
        ));
    }

    // control flow
    examples.push((
        format!("control.{ext}"),
        {
            let mut code = format!("// Control flow in {}\n", constraints.meta.name);
            code.push_str(&format!("{fn_kw} main() {{\n"));
            code.push_str(&format!("    {let_kw} x: i32 = 42{semi}\n"));
            if constraints.control_flow.if_else {
                code.push_str(&format!("    {if_kw} x > 0 {{\n"));
                code.push_str(&format!("        {print_kw}(\"positive\"){semi}\n"));
                code.push_str(&format!("    }} {else_kw} {{\n"));
                code.push_str(&format!("        {print_kw}(\"non-positive\"){semi}\n"));
                code.push_str("    }\n");
            }
            if constraints.control_flow.for_loop {
                code.push_str(&format!("    {for_kw} i {in_kw} 0..5 {{\n"));
                code.push_str(&format!("        {print_kw}(\"loop\"){semi}\n"));
                code.push_str("    }\n");
            }
            code.push_str("}\n");
            code
        },
    ));

    // errors (Result type or simple error handling)
    examples.push((
        format!("errors.{ext}"),
        format!(
            r#"// Error handling in {name}
{fn_kw} safe_divide(a: i32, b: i32) -> i32 {{
    {if_kw} b == 0 {{
        {print_kw}("division by zero"){semi}
        {return_kw} 0{semi}
    }}
    {return_kw} a / b{semi}
}}

{fn_kw} main() {{
    {let_kw} result: i32 = safe_divide(10, 3){semi}
    {let_kw} error: i32 = safe_divide(10, 0){semi}
    {print_kw}("done"){semi}
}}
"#,
            name = constraints.meta.name,
        ),
    ));

    examples
}

fn generate_proof(
    constraints: &LanguageConstraints,
    topology: &LanguageTopology,
    files: &[PathBuf],
) -> Result<String> {
    let constraints_json = serde_json::to_vec(constraints)?;
    let constraints_hash = sha256_hex(&constraints_json);

    let topology_json = serde_json::to_vec(topology)?;
    let topology_hash = sha256_hex(&topology_json);

    #[derive(serde::Serialize)]
    struct FileEntry {
        path: String,
        hash: String,
    }

    let file_entries: Vec<FileEntry> = files
        .iter()
        .filter_map(|p| {
            let content = std::fs::read(p).ok()?;
            Some(FileEntry {
                path: p.file_name()?.to_string_lossy().to_string(),
                hash: sha256_hex(&content),
            })
        })
        .collect();

    #[derive(serde::Serialize)]
    struct EvidenceStep {
        step: String,
        digest: String,
        parent: Option<String>,
    }

    let evidence = vec![
        EvidenceStep {
            step: "constraints".to_string(),
            digest: constraints_hash.clone(),
            parent: None,
        },
        EvidenceStep {
            step: "topology".to_string(),
            digest: topology_hash.clone(),
            parent: Some(constraints_hash.clone()),
        },
        EvidenceStep {
            step: "crystal".to_string(),
            digest: topology.crystal.constraint_hash.clone(),
            parent: Some(topology_hash),
        },
    ];

    #[derive(serde::Serialize)]
    struct Proof {
        constraints_hash: String,
        crystal_id: String,
        files: Vec<FileEntry>,
        evidence_chain: Vec<EvidenceStep>,
    }

    let proof = Proof {
        constraints_hash,
        crystal_id: topology.crystal.id.clone(),
        files: file_entries,
        evidence_chain: evidence,
    };

    let json = serde_json::to_string_pretty(&proof)?;
    Ok(json)
}

fn sha256_hex(data: &[u8]) -> String {
    let mut hasher = Sha256::new();
    hasher.update(data);
    let result = hasher.finalize();
    result.iter().map(|b| format!("{b:02x}")).collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    use schmiede_constraints::{compute_dof, parse_constraints};
    use schmiede_grammar::generate_grammar;
    use schmiede_topology::constraints_to_topology;

    fn test_emit(preset: &str) -> EmitResult {
        let c = parse_constraints(preset).unwrap();
        let dof = compute_dof(&c);
        let topo = constraints_to_topology(&c, &dof).unwrap();
        let grammar = generate_grammar(&topo, &c).unwrap();

        let id = std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_nanos();
        let dir = std::env::temp_dir().join(format!("schmiede_test_{}_{}", c.meta.name, id));
        let _ = std::fs::remove_dir_all(&dir);

        let config = EmitConfig { output_dir: dir };
        emit_from_pipeline(&config, &c, &topo, &grammar).unwrap()
    }

    #[test]
    fn emit_creates_directory_structure() {
        let result = test_emit(include_str!("../../../presets/embedded_safety.toml"));
        assert!(result.output_dir.join("src/lexer.rs").exists());
        assert!(result.output_dir.join("src/parser.rs").exists());
        assert!(result.output_dir.join("src/ast.rs").exists());
        assert!(result.output_dir.join("src/typechecker.rs").exists());
        assert!(result.output_dir.join("src/codegen.rs").exists());
        assert!(result.output_dir.join("src/main.rs").exists());
        assert!(result.output_dir.join("src/error.rs").exists());
        assert!(result.output_dir.join("Cargo.toml").exists());
        let _ = std::fs::remove_dir_all(&result.output_dir);
    }

    #[test]
    fn emit_generates_examples() {
        let result = test_emit(include_str!("../../../presets/embedded_safety.toml"));
        assert!(result.output_dir.join("examples").exists());
        let examples: Vec<_> = std::fs::read_dir(result.output_dir.join("examples"))
            .unwrap()
            .collect();
        assert!(examples.len() >= 5, "should generate at least 5 examples");
        let _ = std::fs::remove_dir_all(&result.output_dir);
    }

    #[test]
    fn emit_generates_proof() {
        let result = test_emit(include_str!("../../../presets/embedded_safety.toml"));
        assert!(result.proof_path.exists());
        let proof_str = std::fs::read_to_string(&result.proof_path).unwrap();
        let proof: serde_json::Value = serde_json::from_str(&proof_str).unwrap();
        assert!(proof.get("constraints_hash").is_some());
        assert!(proof.get("crystal_id").is_some());
        assert!(proof.get("evidence_chain").is_some());
        let _ = std::fs::remove_dir_all(&result.output_dir);
    }

    #[test]
    fn emit_generates_spec() {
        let result = test_emit(include_str!("../../../presets/embedded_safety.toml"));
        assert!(result.spec_path.exists());
        let spec = std::fs::read_to_string(&result.spec_path).unwrap();
        assert!(spec.contains("SafeEmbed"));
        assert!(spec.contains("Grammar"));
        let _ = std::fs::remove_dir_all(&result.output_dir);
    }
}

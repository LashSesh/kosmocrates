// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! I6 — Semantic Norm Crystallisation: capability tracking.
//!
//! Provides [`SemanticCandidate`] for grouping observations by semantic class
//! rather than topological signature, and [`Capability`] / [`CapabilityStatus`]
//! for tracking the system's learned abilities.

use std::collections::{BTreeSet, HashMap, HashSet};

use serde::{Deserialize, Serialize};

use crate::spectroscopy::{Resonite, ResoniteClass};
use crate::types::{
    Norm, NormEvidence, NormLevel, NormLayers, TriggerPattern,
};

// ─── SemanticObservation ────────────────────────────────────────────────────

/// A single observation of a semantic class in a specific repository.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SemanticObservation {
    /// Repository name or URL.
    pub repo: String,
    /// Domain this repo was scraped under.
    pub domain: String,
    /// Programming language of the repo.
    pub language: String,
    /// The concrete resonites from THIS repo that belong to the class.
    pub resonites: Vec<Resonite>,
    /// ISO timestamp of when this observation was recorded.
    pub timestamp: String,
}

// ─── SemanticCandidate ──────────────────────────────────────────────────────

/// A candidate norm grouped by semantic class (I6).
///
/// Unlike `NormCandidate` (which groups by topological layer signature),
/// `SemanticCandidate` groups by WHAT the code does (EventBus, Caching, etc.),
/// not by which layers it touches.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct SemanticCandidate {
    /// Unique identifier, always prefixed `"SEM-"` (e.g. `"SEM-EventBus"`).
    pub id: String,
    /// The semantic class this candidate represents.
    pub semantic_class: ResoniteClass,
    /// All observations that contributed to this candidate.
    pub observations: Vec<SemanticObservation>,
    /// ISO timestamp of creation.
    pub created_at: String,
}

impl SemanticCandidate {
    /// Total number of observations.
    pub fn observation_count(&self) -> usize {
        self.observations.len()
    }

    /// Number of distinct domains across observations.
    pub fn domain_count(&self) -> usize {
        let domains: HashSet<&str> = self.observations.iter()
            .map(|o| o.domain.as_str())
            .collect();
        domains.len()
    }

    /// Number of distinct languages across observations.
    pub fn language_count(&self) -> usize {
        let langs: HashSet<&str> = self.observations.iter()
            .map(|o| o.language.as_str())
            .collect();
        langs.len()
    }

    /// Whether this candidate should be promoted to a norm.
    ///
    /// Requires ≥5 observations from ≥3 distinct domains.
    pub fn should_promote(&self) -> bool {
        self.observation_count() >= 5 && self.domain_count() >= 3
    }

    /// Return resonites that appear in >50% of observations.
    ///
    /// Two resonites are considered "the same" if their labels match.
    pub fn consensus_resonites(&self) -> Vec<Resonite> {
        if self.observations.is_empty() {
            return vec![];
        }
        let total = self.observations.len();
        let threshold = total as f64 / 2.0;

        // Count occurrences of each resonite by label
        let mut counts: HashMap<String, (usize, Resonite)> = HashMap::new();
        for obs in &self.observations {
            // Track unique labels per observation to avoid counting duplicates
            let mut seen = HashSet::new();
            for r in &obs.resonites {
                let label = r.label();
                if seen.insert(label.clone()) {
                    counts
                        .entry(label)
                        .and_modify(|(c, _)| *c += 1)
                        .or_insert((1, r.clone()));
                }
            }
        }

        let mut result: Vec<Resonite> = counts
            .into_values()
            .filter(|(count, _)| *count as f64 > threshold)
            .map(|(_, r)| r)
            .collect();
        result.sort_by(|a, b| a.label().cmp(&b.label()));
        result
    }

    /// Crystallise this candidate into a full Norm.
    ///
    /// G1: After crystallisation the caller SHOULD also create a Code-Template
    /// from the returned norm's `consensus_resonites`. Example:
    /// ```rust,ignore
    /// let norm = candidate.crystallize_to_norm();
    /// // In isls-forge-llm context:
    /// let template = templates::build_skeleton(&class_name, &norm.consensus_resonites);
    /// registry.save_template(template);
    /// ```
    /// `isls-norms` is a pure-data crate and cannot depend on `isls-forge-llm`,
    /// so template creation is the caller's responsibility.
    pub fn crystallize_to_norm(&self) -> Norm {
        let class_name = self.semantic_class.as_str();
        let name = format!("{}-Pattern", class_name);
        let id = format!("ISLS-NORM-AUTO-SEM-{}", class_name);

        let domains: Vec<String> = {
            let mut d: Vec<String> = self.observations.iter()
                .map(|o| o.domain.clone())
                .collect::<BTreeSet<_>>()
                .into_iter()
                .collect();
            d.sort();
            d
        };

        let languages: BTreeSet<String> = self.observations.iter()
            .map(|o| o.language.clone())
            .collect();

        let consensus = self.consensus_resonites();

        // Build trigger keywords from the class
        let keywords = crate::spectroscopy::suggest_keywords_for_class(&self.semantic_class);
        let trigger_keywords: Vec<String> = keywords.iter()
            .flat_map(|kw| kw.split_whitespace().map(|w| w.to_lowercase()))
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect();

        let norm = Norm {
            id,
            name,
            level: NormLevel::Molecule,
            triggers: vec![TriggerPattern {
                keywords: trigger_keywords,
                concepts: vec![class_name.to_lowercase()],
                min_confidence: 0.3,
                excludes: vec![],
            }],
            layers: NormLayers::default(),
            parameters: vec![],
            requires: vec![],
            variants: vec![],
            version: "1.0.0-sem".to_string(),
            evidence: NormEvidence {
                usage_count: self.observation_count() as u32,
                domains_used: domains,
                builtin: false,
                signature: format!("sem-{}", class_name.to_lowercase()),
            },
            semantic_class: Some(self.semantic_class.clone()),
            consensus_resonites: consensus,
        };

        // G1: Signal to caller that a code template should be created.
        // Log here so operators can see template creation in server logs.
        eprintln!(
            "[TEMPLATE] Norm {} crystallised — caller should create template for class={}  (consensus={} resonites)",
            norm.id,
            class_name,
            norm.consensus_resonites.len()
        );

        norm
    }

    /// G1: Return the class name and consensus resonites for template creation.
    ///
    /// Returns `(class_name, consensus_resonites)` to be passed to
    /// `isls_forge_llm::templates::build_skeleton()` by the caller.
    pub fn template_seed(&self) -> (String, Vec<Resonite>) {
        (
            self.semantic_class.as_str().to_string(),
            self.consensus_resonites(),
        )
    }
}

// ─── Capability Register ────────────────────────────────────────────────────

/// Status of a capability in the system's knowledge.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum CapabilityStatus {
    /// Has a builtin norm — the system fully understands this pattern.
    Mastered,
    /// Has an auto-discovered norm (promoted from candidate).
    Acquired,
    /// Has a semantic candidate with observations but not yet promoted.
    Emerging,
    /// Has been observed (≤2 observations) — scouted but not understood.
    Scouted,
    /// No observations, no norm — unknown territory.
    Unknown,
}

impl CapabilityStatus {
    /// Stable string name for API/CLI output.
    pub fn as_str(&self) -> &'static str {
        match self {
            CapabilityStatus::Mastered => "Mastered",
            CapabilityStatus::Acquired => "Acquired",
            CapabilityStatus::Emerging => "Emerging",
            CapabilityStatus::Scouted => "Scouted",
            CapabilityStatus::Unknown => "Unknown",
        }
    }
}

/// A single capability entry in the register.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Capability {
    /// The semantic class this capability represents.
    pub class: ResoniteClass,
    /// Current status.
    pub status: CapabilityStatus,
    /// Norm ID if a norm covers this class.
    pub norm_id: Option<String>,
    /// Number of observations in the semantic candidate (0 if none).
    pub candidate_obs: usize,
    /// Number of distinct domains in the semantic candidate.
    pub candidate_domains: usize,
}

/// Compute the capability register from the current registry state.
///
/// For each known ResoniteClass, determines whether the system has:
/// - A builtin norm (Mastered)
/// - An auto-discovered norm (Acquired)
/// - A semantic candidate with ≥3 observations (Emerging)
/// - A semantic candidate with <3 observations (Scouted)
/// - Nothing (Unknown)
pub fn compute_capabilities(registry: &crate::NormRegistry) -> Vec<Capability> {
    let covered = crate::spectroscopy::registry_covered_classes(registry);

    // Collect semantic candidates
    let mut sem_candidates: HashMap<String, &crate::learning::NormCandidate> = HashMap::new();
    for cand in registry.candidates() {
        if cand.id.starts_with("SEM-") {
            sem_candidates.insert(cand.id.clone(), cand);
        }
    }

    let mut capabilities = Vec::new();

    for class in ResoniteClass::all_known() {
        let class_name = class.as_str();
        let sem_key = format!("SEM-{}", class_name);

        // Check if a norm covers this class
        let norm_id = covered.get(&class).cloned();
        let is_builtin = norm_id.as_ref().map_or(false, |id| {
            !id.starts_with("ISLS-NORM-AUTO-")
        });

        // Check for semantic candidate
        let sem_cand = sem_candidates.get(&sem_key);
        let (obs_count, domain_count) = sem_cand
            .map(|c| (c.observation_count, c.domains.len()))
            .unwrap_or((0, 0));

        let status = if is_builtin {
            CapabilityStatus::Mastered
        } else if norm_id.is_some() {
            CapabilityStatus::Acquired
        } else if obs_count >= 3 {
            CapabilityStatus::Emerging
        } else if obs_count > 0 {
            CapabilityStatus::Scouted
        } else {
            CapabilityStatus::Unknown
        };

        capabilities.push(Capability {
            class,
            status,
            norm_id,
            candidate_obs: obs_count,
            candidate_domains: domain_count,
        });
    }

    // Sort by status priority (Mastered first, Unknown last)
    capabilities.sort_by(|a, b| {
        let priority = |s: &CapabilityStatus| match s {
            CapabilityStatus::Mastered => 0,
            CapabilityStatus::Acquired => 1,
            CapabilityStatus::Emerging => 2,
            CapabilityStatus::Scouted => 3,
            CapabilityStatus::Unknown => 4,
        };
        priority(&a.status).cmp(&priority(&b.status))
            .then(a.class.as_str().cmp(&b.class.as_str()))
    });

    capabilities
}

// ─── Tests ──────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::spectroscopy::{Resonite, ResoniteClass};

    #[test]
    fn semantic_candidate_promotion_thresholds() {
        let mut cand = SemanticCandidate {
            id: "SEM-Caching".into(),
            semantic_class: ResoniteClass::Caching,
            observations: vec![],
            created_at: "2026-01-01".into(),
        };

        // Not enough observations
        assert!(!cand.should_promote());

        // Add 5 observations from 3 domains
        for (i, domain) in ["web", "api", "cli", "web", "api"].iter().enumerate() {
            cand.observations.push(SemanticObservation {
                repo: format!("repo-{}", i),
                domain: domain.to_string(),
                language: "rust".into(),
                resonites: vec![Resonite::Fn {
                    name: "cache_get".into(),
                    arity: 1,
                }],
                timestamp: format!("2026-01-0{}", i + 1),
            });
        }

        assert!(cand.should_promote());
        assert_eq!(cand.observation_count(), 5);
        assert_eq!(cand.domain_count(), 3);
    }

    #[test]
    fn consensus_resonites_50_percent() {
        let mut cand = SemanticCandidate {
            id: "SEM-Caching".into(),
            semantic_class: ResoniteClass::Caching,
            observations: vec![],
            created_at: "2026-01-01".into(),
        };

        // 4 observations: cache_get in all 4, cache_delete in 3/4, rare_fn in 1/4
        let common = Resonite::Fn { name: "cache_get".into(), arity: 1 };
        let frequent = Resonite::Fn { name: "cache_delete".into(), arity: 1 };
        let rare = Resonite::Fn { name: "rare_fn".into(), arity: 0 };

        for i in 0..4 {
            let mut resonites = vec![common.clone()];
            if i < 3 { resonites.push(frequent.clone()); }
            if i == 0 { resonites.push(rare.clone()); }

            cand.observations.push(SemanticObservation {
                repo: format!("repo-{}", i),
                domain: format!("domain-{}", i),
                language: "rust".into(),
                resonites,
                timestamp: format!("2026-01-0{}", i + 1),
            });
        }

        let consensus = cand.consensus_resonites();
        let labels: Vec<String> = consensus.iter().map(|r| r.label()).collect();
        assert!(labels.contains(&"fn cache_get".to_string()), "cache_get should be in consensus");
        assert!(labels.contains(&"fn cache_delete".to_string()), "cache_delete (3/4=75%) should be in consensus");
        assert!(!labels.contains(&"fn rare_fn".to_string()), "rare_fn (1/4=25%) should NOT be in consensus");
    }

    #[test]
    fn crystallize_produces_valid_norm() {
        let mut cand = SemanticCandidate {
            id: "SEM-EventBus".into(),
            semantic_class: ResoniteClass::EventBus,
            observations: vec![],
            created_at: "2026-01-01".into(),
        };

        for i in 0..5 {
            cand.observations.push(SemanticObservation {
                repo: format!("repo-{}", i),
                domain: ["web", "api", "cli"][i % 3].into(),
                language: "rust".into(),
                resonites: vec![
                    Resonite::Fn { name: "emit_event".into(), arity: 2 },
                    Resonite::Fn { name: "subscribe".into(), arity: 1 },
                ],
                timestamp: format!("2026-01-0{}", i + 1),
            });
        }

        let norm = cand.crystallize_to_norm();
        assert!(norm.id.contains("SEM-EventBus"));
        assert_eq!(norm.name, "EventBus-Pattern");
        assert!(norm.semantic_class.is_some());
        assert_eq!(norm.semantic_class.unwrap(), ResoniteClass::EventBus);
        assert!(!norm.consensus_resonites.is_empty());
    }
}

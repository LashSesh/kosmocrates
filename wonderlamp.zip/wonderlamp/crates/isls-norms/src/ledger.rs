// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Append-only ledger for norm persistence.
//!
//! Norms are persisted as an append-only JSONL ledger (`~/.isls/norm_ledger.jsonl`).
//! Events are never overwritten or deleted. A snapshot (`~/.isls/norms_snapshot.json`)
//! serves as a read cache and is rebuilt from the ledger if stale or corrupt.

use std::fs::{self, File, OpenOptions};
use std::io::{BufRead, BufReader, Write};
use std::path::PathBuf;

use serde::{Deserialize, Serialize};

use crate::injection::INJECT_PREFIX;
use crate::learning::{CrossLayerPattern, NormCandidate};
use crate::spectroscopy::ResoniteClass;
use crate::types::Norm;
use crate::{NormError, Result};

// ─── Events ──────────────────────────────────────────────────────────────────

/// A single norm-system event, appended to the ledger.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(tag = "event")]
pub enum NormEvent {
    /// An auto-discovered norm was created via promotion.
    NormAdded { timestamp: String, norm: Norm },
    /// A norm was injected via blueprint.
    NormInjected { timestamp: String, norm: Norm },
    /// A new candidate was created from its first observation.
    CandidateCreated {
        timestamp: String,
        candidate_id: String,
        signature: String,
        pattern: CrossLayerPattern,
    },
    /// An existing candidate received a new observation.
    ObservationRecorded {
        timestamp: String,
        candidate_id: String,
        signature: String,
        pattern: CrossLayerPattern,
    },
    /// A candidate was promoted to a full norm.
    NormPromoted {
        timestamp: String,
        candidate_id: String,
        norm: Norm,
    },
    /// The auto-ID counter was updated.
    AutoIdCounterUpdated { timestamp: String, counter: u32 },
    /// I6: A semantic observation was recorded for a class.
    SemanticObservation {
        timestamp: String,
        candidate_id: String,
        class: ResoniteClass,
        repo: String,
        domain: String,
    },
    /// I6: A norm was removed during deduplication.
    NormRemoved {
        timestamp: String,
        norm_id: String,
        reason: String,
    },
    /// E1: Genesis event — starts a new hash chain.
    Genesis {
        timestamp: String,
        version: String,
        builtin_count: usize,
    },
    /// E1: MCI measurement recorded by auto-evolve or manual run.
    MciMeasured {
        timestamp: String,
        app: String,
        mci_global: f64,
        mci_structural: f64,
        mci_oracle: f64,
    },
    /// I7: An emergent class was discovered via prefix clustering.
    EmergentClassDiscovered {
        timestamp: String,
        prefix: String,
        class_name: String,
        function_count: usize,
        domain_count: usize,
        repo_count: usize,
    },
}

// ─── Paths ───────────────────────────────────────────────────────────────────

fn isls_home() -> Option<PathBuf> {
    std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .ok()
        .map(|h| PathBuf::from(h).join(".isls"))
}

fn ledger_path() -> Option<PathBuf> {
    isls_home().map(|d| d.join("norm_ledger.jsonl"))
}

fn snapshot_path() -> Option<PathBuf> {
    isls_home().map(|d| d.join("norms_snapshot.json"))
}

fn old_norms_path() -> Option<PathBuf> {
    isls_home().map(|d| d.join("norms.json"))
}

fn now_iso() -> String {
    chrono::Local::now()
        .format("%Y-%m-%dT%H:%M:%S")
        .to_string()
}

// ─── Append ──────────────────────────────────────────────────────────────────

/// Append a single event to the ledger. Uses append mode and fsync.
///
/// Returns `Ok(())` silently if the persistence path cannot be determined
/// (e.g. `$HOME` is unset).
pub fn append_event(event: &NormEvent) -> Result<()> {
    let path = match ledger_path() {
        Some(p) => p,
        None => return Ok(()),
    };
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let mut file = OpenOptions::new()
        .create(true)
        .append(true) // APPEND — never truncate
        .open(&path)?;
    let json = serde_json::to_string(event)?;
    writeln!(file, "{}", json)?;
    file.sync_all()?; // fsync — force to disk
    Ok(())
}

/// Append a single event to a ledger at a custom path (for testing).
pub fn append_event_to(path: &std::path::Path, event: &NormEvent) -> Result<()> {
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let mut file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(path)?;
    let json = serde_json::to_string(event)?;
    writeln!(file, "{}", json)?;
    file.sync_all()?;
    Ok(())
}

// ─── Replay ──────────────────────────────────────────────────────────────────

/// Replay the ledger to reconstruct auto-discovered norms, candidates, and
/// the auto-ID counter. Built-in norms are NOT included — the caller must
/// load those separately.
///
/// Corrupt or empty lines are silently skipped.
pub fn load_registry_from_ledger() -> Result<LedgerState> {
    let path = match ledger_path() {
        Some(p) => p,
        None => return Ok(LedgerState::default()),
    };
    load_registry_from_ledger_path(&path)
}

/// Replay a ledger at a custom path (for testing).
pub fn load_registry_from_ledger_path(path: &std::path::Path) -> Result<LedgerState> {
    let mut state = LedgerState::default();

    if !path.exists() {
        return Ok(state);
    }

    let file = File::open(path)?;
    let reader = BufReader::new(file);

    for line in reader.lines() {
        let line = match line {
            Ok(l) => l,
            Err(_) => continue, // corrupt line
        };
        if line.trim().is_empty() {
            continue;
        }

        let event: NormEvent = match serde_json::from_str(&line) {
            Ok(e) => e,
            Err(_) => continue, // corrupt event
        };

        state.apply(event);
    }

    Ok(state)
}

/// State reconstructed from ledger replay.
#[derive(Debug, Default)]
pub struct LedgerState {
    /// Auto-discovered and injected norms (keyed by norm ID).
    pub norms: std::collections::HashMap<String, Norm>,
    /// Candidate pool (keyed by pattern signature).
    pub candidates: std::collections::HashMap<String, NormCandidate>,
    /// I6: Semantic candidates (keyed by `SEM-{ClassName}`).
    pub semantic_candidates: std::collections::HashMap<String, crate::capabilities::SemanticCandidate>,
    /// Auto-ID counter for generating norm IDs.
    pub auto_id_counter: u32,
}

impl LedgerState {
    fn apply(&mut self, event: NormEvent) {
        match event {
            NormEvent::NormAdded { norm, .. } | NormEvent::NormInjected { norm, .. } => {
                self.norms.insert(norm.id.clone(), norm);
            }
            NormEvent::NormPromoted {
                candidate_id, norm, ..
            } => {
                self.norms.insert(norm.id.clone(), norm);
                // Mark candidate as promoted
                for cand in self.candidates.values_mut() {
                    if cand.id == candidate_id {
                        cand.status = crate::learning::CandidateStatus::Promoted;
                    }
                }
            }
            NormEvent::CandidateCreated {
                candidate_id,
                signature,
                pattern,
                ..
            } => {
                let cand = NormCandidate::new(candidate_id, &pattern);
                self.candidates.insert(signature, cand);
            }
            NormEvent::ObservationRecorded {
                signature, pattern, ..
            } => {
                if let Some(cand) = self.candidates.get_mut(&signature) {
                    cand.observe(pattern);
                }
            }
            NormEvent::AutoIdCounterUpdated { counter, .. } => {
                self.auto_id_counter = counter;
            }
            NormEvent::SemanticObservation {
                timestamp,
                candidate_id,
                class,
                repo,
                domain,
            } => {
                let cand = self.semantic_candidates
                    .entry(candidate_id.clone())
                    .or_insert_with(|| crate::capabilities::SemanticCandidate {
                        id: candidate_id,
                        semantic_class: class,
                        observations: vec![],
                        created_at: timestamp.clone(),
                    });
                // Cap at 20 — evict oldest to prevent unbounded growth during replay
                const MAX_SEM_OBS: usize = 20;
                if cand.observations.len() >= MAX_SEM_OBS {
                    cand.observations.remove(0);
                }
                cand.observations.push(crate::capabilities::SemanticObservation {
                    repo,
                    domain,
                    language: "unknown".into(),
                    resonites: vec![],
                    timestamp,
                });
            }
            NormEvent::NormRemoved { norm_id, .. } => {
                self.norms.remove(&norm_id);
            }
            // E1/I7: chain-only events — no state change needed during replay
            NormEvent::Genesis { .. }
            | NormEvent::MciMeasured { .. }
            | NormEvent::EmergentClassDiscovered { .. } => {}
        }
    }

    /// Count of auto-discovered norms (prefix `ISLS-NORM-AUTO-`).
    pub fn auto_norms_count(&self) -> usize {
        self.norms
            .keys()
            .filter(|id| id.starts_with("ISLS-NORM-AUTO-"))
            .count()
    }

    /// Count of injected norms (prefix `ISLS-NORM-INJECT-`).
    pub fn injected_norms_count(&self) -> usize {
        self.norms
            .keys()
            .filter(|id| id.starts_with(INJECT_PREFIX))
            .count()
    }
}

// ─── Snapshot ────────────────────────────────────────────────────────────────

/// Save a snapshot atomically (write to tmp, then rename).
///
/// Includes a plausibility check: refuses to save if the new snapshot would
/// contain fewer auto-norms than the existing ledger.
pub fn save_snapshot(
    auto_norms: &[&Norm],
    injected_norms: &[&Norm],
    candidates: &[&NormCandidate],
    semantic_candidates: &[&crate::capabilities::SemanticCandidate],
    auto_id_counter: u32,
) -> Result<()> {
    let snap = match snapshot_path() {
        Some(p) => p,
        None => return Ok(()),
    };

    // Plausibility check: never save fewer auto-norms than ledger has
    if let Ok(ledger_state) = load_registry_from_ledger() {
        let new_auto = auto_norms
            .iter()
            .filter(|n| n.id.starts_with("ISLS-NORM-AUTO-"))
            .count();
        if new_auto < ledger_state.auto_norms_count() {
            eprintln!(
                "[NORM LEDGER] REFUSED snapshot save: would lose {} auto-norms ({} -> {})",
                ledger_state.auto_norms_count() - new_auto,
                ledger_state.auto_norms_count(),
                new_auto,
            );
            return Err(NormError::Conflict(format!(
                "snapshot would lose {} auto-norms",
                ledger_state.auto_norms_count() - new_auto,
            )));
        }
    }

    // Trim semantic candidate observations to MAX 5 before writing to disk
    let trimmed_sem: Vec<crate::capabilities::SemanticCandidate> = semantic_candidates
        .iter()
        .map(|sc| {
            let mut cloned = (*sc).clone();
            if cloned.observations.len() > 5 {
                let drop = cloned.observations.len() - 5;
                cloned.observations.drain(0..drop);
            }
            cloned
        })
        .collect();

    let payload = serde_json::json!({
        "auto_norms": auto_norms,
        "injected_norms": injected_norms,
        "candidates": candidates,
        "semantic_candidates": trimmed_sem,
        "auto_id_counter": auto_id_counter,
    });

    if let Some(parent) = snap.parent() {
        fs::create_dir_all(parent)?;
    }

    let tmp = snap.with_extension("json.tmp");
    fs::write(&tmp, serde_json::to_string_pretty(&payload)?)?;
    fs::rename(&tmp, &snap)?; // atomic swap

    Ok(())
}

/// Try loading the snapshot, returning `None` if it is stale, corrupt, or
/// missing.
pub fn load_snapshot() -> Option<SnapshotData> {
    let snap = snapshot_path()?;
    let ledger = ledger_path()?;

    if !snap.exists() {
        return None;
    }

    // Staleness check: snapshot must be at least as fresh as ledger
    if ledger.exists() {
        let snap_mod = fs::metadata(&snap).ok()?.modified().ok()?;
        let ledger_mod = fs::metadata(&ledger).ok()?.modified().ok()?;
        if snap_mod < ledger_mod {
            return None; // stale
        }
    }

    let content = fs::read_to_string(&snap).ok()?;
    let payload: serde_json::Value = serde_json::from_str(&content).ok()?;

    let mut data = SnapshotData::default();

    if let Some(norms) = payload["auto_norms"].as_array() {
        for v in norms {
            if let Ok(norm) = serde_json::from_value::<Norm>(v.clone()) {
                data.norms.push(norm);
            }
        }
    }
    if let Some(norms) = payload["injected_norms"].as_array() {
        for v in norms {
            if let Ok(norm) = serde_json::from_value::<Norm>(v.clone()) {
                data.norms.push(norm);
            }
        }
    }
    if let Some(cands) = payload["candidates"].as_array() {
        for v in cands {
            if let Ok(cand) = serde_json::from_value::<NormCandidate>(v.clone()) {
                data.candidates.push(cand);
            }
        }
    }
    if let Some(sem_cands) = payload["semantic_candidates"].as_array() {
        for v in sem_cands {
            if let Ok(sc) = serde_json::from_value::<crate::capabilities::SemanticCandidate>(v.clone()) {
                data.semantic_candidates.push(sc);
            }
        }
    }
    if let Some(counter) = payload["auto_id_counter"].as_u64() {
        data.auto_id_counter = counter as u32;
    }

    Some(data)
}

/// Data loaded from a snapshot file.
#[derive(Debug, Default)]
pub struct SnapshotData {
    pub norms: Vec<Norm>,
    pub candidates: Vec<NormCandidate>,
    pub semantic_candidates: Vec<crate::capabilities::SemanticCandidate>,
    pub auto_id_counter: u32,
}

// ─── High-level load ─────────────────────────────────────────────────────────

/// Load auto-discovered norms, candidates, and auto_id_counter.
///
/// Tries the snapshot first (fast path). Falls back to full ledger replay.
/// After a ledger replay, updates the snapshot for next time.
pub fn load_persisted() -> Result<LedgerState> {
    // Fast path: snapshot
    if let Some(snap) = load_snapshot() {
        let mut state = LedgerState::default();
        for norm in snap.norms {
            state.norms.insert(norm.id.clone(), norm);
        }
        for cand in snap.candidates {
            let key = cand
                .observations
                .first()
                .map(|o| o.signature.clone())
                .unwrap_or_else(|| cand.id.clone());
            state.candidates.insert(key, cand);
        }
        for mut sc in snap.semantic_candidates {
            // ALWAYS trim — old snapshots may have unbounded observations
            const MAX_OBS: usize = 20;
            if sc.observations.len() > MAX_OBS {
                let drop = sc.observations.len() - MAX_OBS;
                sc.observations.drain(0..drop);
                sc.observations.shrink_to_fit();
            }
            state.semantic_candidates.insert(sc.id.clone(), sc);
        }
        state.auto_id_counter = snap.auto_id_counter;
        return Ok(state);
    }

    // Slow path: replay ledger
    let mut state = load_registry_from_ledger()?;

    // Trim observations BEFORE saving snapshot to prevent bloat
    for (_, sc) in state.semantic_candidates.iter_mut() {
        const MAX_SEM_OBS: usize = 20;
        if sc.observations.len() > MAX_SEM_OBS {
            let drop = sc.observations.len() - MAX_SEM_OBS;
            sc.observations.drain(0..drop);
            sc.observations.shrink_to_fit();
        }
    }
    for (_, cand) in state.candidates.iter_mut() {
        const MAX_CAND_OBS: usize = 50;
        if cand.observations.len() > MAX_CAND_OBS {
            let drop = cand.observations.len() - MAX_CAND_OBS;
            cand.observations.drain(0..drop);
        }
    }

    // Update snapshot for next time (best-effort)
    let auto: Vec<&Norm> = state
        .norms
        .values()
        .filter(|n| n.id.starts_with("ISLS-NORM-AUTO-"))
        .collect();
    let injected: Vec<&Norm> = state
        .norms
        .values()
        .filter(|n| n.id.starts_with(INJECT_PREFIX))
        .collect();
    let cands: Vec<&NormCandidate> = state.candidates.values().collect();
    let sem_cands: Vec<&crate::capabilities::SemanticCandidate> =
        state.semantic_candidates.values().collect();
    let _ = save_snapshot(&auto, &injected, &cands, &sem_cands, state.auto_id_counter);

    Ok(state)
}

// ─── Migration ───────────────────────────────────────────────────────────────

/// Migrate an existing `norms.json` to the append-only ledger.
///
/// No-op if the ledger already exists or there is no `norms.json` to migrate.
pub fn migrate_to_ledger() -> Result<()> {
    let ledger = match ledger_path() {
        Some(p) => p,
        None => return Ok(()),
    };
    let old = match old_norms_path() {
        Some(p) => p,
        None => return Ok(()),
    };

    if ledger.exists() || !old.exists() {
        return Ok(()); // already migrated or nothing to migrate
    }

    let content = fs::read_to_string(&old)?;
    let payload: serde_json::Value = serde_json::from_str(&content)?;

    let ts = now_iso();
    let mut event_count = 0usize;

    // Migrate auto norms
    if let Some(norms) = payload["auto_norms"].as_array() {
        for v in norms {
            if let Ok(norm) = serde_json::from_value::<Norm>(v.clone()) {
                append_event_to(
                    &ledger,
                    &NormEvent::NormAdded {
                        timestamp: ts.clone(),
                        norm,
                    },
                )?;
                event_count += 1;
            }
        }
    }

    // Migrate injected norms
    if let Some(norms) = payload["injected_norms"].as_array() {
        for v in norms {
            if let Ok(norm) = serde_json::from_value::<Norm>(v.clone()) {
                append_event_to(
                    &ledger,
                    &NormEvent::NormInjected {
                        timestamp: ts.clone(),
                        norm,
                    },
                )?;
                event_count += 1;
            }
        }
    }

    // Migrate candidates — replay their observations
    if let Some(cands) = payload["candidates"].as_array() {
        for v in cands {
            if let Ok(cand) = serde_json::from_value::<NormCandidate>(v.clone()) {
                let sig = cand
                    .observations
                    .first()
                    .map(|o| o.signature.clone())
                    .unwrap_or_else(|| cand.id.clone());

                if let Some(first) = cand.observations.first() {
                    append_event_to(
                        &ledger,
                        &NormEvent::CandidateCreated {
                            timestamp: ts.clone(),
                            candidate_id: cand.id.clone(),
                            signature: sig.clone(),
                            pattern: first.clone(),
                        },
                    )?;
                    event_count += 1;
                }

                for obs in cand.observations.iter().skip(1) {
                    append_event_to(
                        &ledger,
                        &NormEvent::ObservationRecorded {
                            timestamp: ts.clone(),
                            candidate_id: cand.id.clone(),
                            signature: sig.clone(),
                            pattern: obs.clone(),
                        },
                    )?;
                    event_count += 1;
                }
            }
        }
    }

    // Migrate auto_id_counter
    if let Some(counter) = payload["auto_id_counter"].as_u64() {
        append_event_to(
            &ledger,
            &NormEvent::AutoIdCounterUpdated {
                timestamp: ts,
                counter: counter as u32,
            },
        )?;
        event_count += 1;
    }

    eprintln!(
        "[NORM LEDGER] Migrated {} events from norms.json to ledger",
        event_count
    );

    // Rename old file so migration doesn't re-run
    let migrated = old.with_extension("json.migrated");
    fs::rename(&old, &migrated)?;

    Ok(())
}

// ─── Helpers for observe_and_learn ───────────────────────────────────────────

/// Create a `NormEvent::CandidateCreated` event with the current timestamp.
pub fn candidate_created_event(
    candidate_id: &str,
    signature: &str,
    pattern: &CrossLayerPattern,
) -> NormEvent {
    NormEvent::CandidateCreated {
        timestamp: now_iso(),
        candidate_id: candidate_id.to_string(),
        signature: signature.to_string(),
        pattern: pattern.clone(),
    }
}

/// Create a `NormEvent::ObservationRecorded` event with the current timestamp.
pub fn observation_recorded_event(
    candidate_id: &str,
    signature: &str,
    pattern: &CrossLayerPattern,
) -> NormEvent {
    NormEvent::ObservationRecorded {
        timestamp: now_iso(),
        candidate_id: candidate_id.to_string(),
        signature: signature.to_string(),
        pattern: pattern.clone(),
    }
}

/// Create a `NormEvent::NormPromoted` event with the current timestamp.
pub fn norm_promoted_event(candidate_id: &str, norm: &Norm) -> NormEvent {
    NormEvent::NormPromoted {
        timestamp: now_iso(),
        candidate_id: candidate_id.to_string(),
        norm: norm.clone(),
    }
}

/// Create a `NormEvent::AutoIdCounterUpdated` event with the current timestamp.
pub fn auto_id_counter_event(counter: u32) -> NormEvent {
    NormEvent::AutoIdCounterUpdated {
        timestamp: now_iso(),
        counter,
    }
}

/// Create a `NormEvent::NormInjected` event with the current timestamp.
pub fn norm_injected_event(norm: &Norm) -> NormEvent {
    NormEvent::NormInjected {
        timestamp: now_iso(),
        norm: norm.clone(),
    }
}

// ─── Tests ───────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::learning::ObservedArtifact;
    use crate::types::LayerType;

    fn test_dir() -> PathBuf {
        let dir = std::env::temp_dir()
            .join("isls-ledger-test")
            .join(format!("{}", std::process::id()))
            .join(format!("{}", std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()));
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    fn make_pattern(entity: &str, domain: &str, run_id: &str) -> CrossLayerPattern {
        CrossLayerPattern {
            signature: format!("sig-{}", entity),
            layers_present: vec![LayerType::Model, LayerType::Database],
            artifacts: vec![ObservedArtifact {
                layer: LayerType::Model,
                artifact_type: "struct".into(),
                name: entity.into(),
                signature: format!("art-{}", entity),
                field_names: vec!["name".into(), "id".into()],
            }],
            observed_on: entity.to_lowercase(),
            domain: domain.into(),
            run_id: run_id.into(),
        }
    }

    fn make_norm(id: &str, name: &str) -> Norm {
        Norm {
            id: id.into(),
            name: name.into(),
            level: crate::types::NormLevel::Molecule,
            triggers: vec![],
            layers: crate::types::NormLayers::default(),
            parameters: vec![],
            requires: vec![],
            variants: vec![],
            version: "1.0.0".into(),
            evidence: crate::types::NormEvidence {
                usage_count: 0,
                domains_used: vec![],
                builtin: false,
                signature: "test-sig".into(),
            },
            semantic_class: None,
            consensus_resonites: vec![],
        }
    }

    #[test]
    fn test_append_and_replay() {
        let dir = test_dir();
        let ledger = dir.join("norm_ledger.jsonl");

        let norm = make_norm("ISLS-NORM-AUTO-0001", "Test Norm");
        append_event_to(
            &ledger,
            &NormEvent::NormAdded {
                timestamp: "2026-01-01T00:00:00".into(),
                norm: norm.clone(),
            },
        )
        .unwrap();

        let pattern = make_pattern("Product", "warehouse", "run1");
        append_event_to(
            &ledger,
            &NormEvent::CandidateCreated {
                timestamp: "2026-01-01T00:00:01".into(),
                candidate_id: "ISLS-CAND-0001".into(),
                signature: "sig-Product".into(),
                pattern,
            },
        )
        .unwrap();

        append_event_to(
            &ledger,
            &NormEvent::AutoIdCounterUpdated {
                timestamp: "2026-01-01T00:00:02".into(),
                counter: 1,
            },
        )
        .unwrap();

        let state = load_registry_from_ledger_path(&ledger).unwrap();
        assert_eq!(state.norms.len(), 1);
        assert!(state.norms.contains_key("ISLS-NORM-AUTO-0001"));
        assert_eq!(state.candidates.len(), 1);
        assert!(state.candidates.contains_key("sig-Product"));
        assert_eq!(state.auto_id_counter, 1);
    }

    #[test]
    fn test_corrupt_line_tolerance() {
        let dir = test_dir();
        let ledger = dir.join("norm_ledger.jsonl");

        let norm = make_norm("ISLS-NORM-AUTO-0001", "Before Corrupt");
        append_event_to(
            &ledger,
            &NormEvent::NormAdded {
                timestamp: "2026-01-01T00:00:00".into(),
                norm,
            },
        )
        .unwrap();

        // Write a corrupt line manually
        let mut file = OpenOptions::new().append(true).open(&ledger).unwrap();
        writeln!(file, "{{this is not valid json}}").unwrap();
        writeln!(file, "").unwrap(); // empty line
        drop(file);

        let norm2 = make_norm("ISLS-NORM-AUTO-0002", "After Corrupt");
        append_event_to(
            &ledger,
            &NormEvent::NormAdded {
                timestamp: "2026-01-01T00:00:01".into(),
                norm: norm2,
            },
        )
        .unwrap();

        let state = load_registry_from_ledger_path(&ledger).unwrap();
        assert_eq!(state.norms.len(), 2, "both norms should survive corrupt line");
    }

    #[test]
    fn test_observation_replay() {
        let dir = test_dir();
        let ledger = dir.join("norm_ledger.jsonl");

        let p1 = make_pattern("Product", "warehouse", "run1");
        append_event_to(
            &ledger,
            &NormEvent::CandidateCreated {
                timestamp: "t1".into(),
                candidate_id: "ISLS-CAND-0001".into(),
                signature: "sig-Product".into(),
                pattern: p1,
            },
        )
        .unwrap();

        // Second observation from a different domain/run
        let p2 = CrossLayerPattern {
            signature: "sig-Product".into(),
            layers_present: vec![LayerType::Model, LayerType::Database],
            artifacts: vec![ObservedArtifact {
                layer: LayerType::Model,
                artifact_type: "struct".into(),
                name: "Item".into(),
                signature: "art-Item".into(),
                field_names: vec!["name".into(), "id".into()],
            }],
            observed_on: "item".to_string(),
            domain: "ecommerce".into(),
            run_id: "run2".into(),
        };
        append_event_to(
            &ledger,
            &NormEvent::ObservationRecorded {
                timestamp: "t2".into(),
                candidate_id: "ISLS-CAND-0001".into(),
                signature: "sig-Product".into(),
                pattern: p2,
            },
        )
        .unwrap();

        let state = load_registry_from_ledger_path(&ledger).unwrap();
        let cand = state.candidates.get("sig-Product").unwrap();
        assert_eq!(cand.observation_count, 2);
        assert_eq!(cand.domains.len(), 2);
    }

    #[test]
    fn test_promotion_replay() {
        let dir = test_dir();
        let ledger = dir.join("norm_ledger.jsonl");

        let p1 = make_pattern("Product", "warehouse", "run1");
        append_event_to(
            &ledger,
            &NormEvent::CandidateCreated {
                timestamp: "t1".into(),
                candidate_id: "ISLS-CAND-0001".into(),
                signature: "sig-Product".into(),
                pattern: p1,
            },
        )
        .unwrap();

        let promoted_norm = make_norm("ISLS-NORM-AUTO-0001", "Product Pattern");
        append_event_to(
            &ledger,
            &NormEvent::NormPromoted {
                timestamp: "t2".into(),
                candidate_id: "ISLS-CAND-0001".into(),
                norm: promoted_norm,
            },
        )
        .unwrap();

        let state = load_registry_from_ledger_path(&ledger).unwrap();
        assert!(state.norms.contains_key("ISLS-NORM-AUTO-0001"));
        let cand = state.candidates.get("sig-Product").unwrap();
        assert_eq!(cand.status, crate::learning::CandidateStatus::Promoted);
    }

    #[test]
    fn test_empty_ledger() {
        let dir = test_dir();
        let ledger = dir.join("norm_ledger.jsonl");
        // File doesn't exist
        let state = load_registry_from_ledger_path(&ledger).unwrap();
        assert!(state.norms.is_empty());
        assert!(state.candidates.is_empty());
        assert_eq!(state.auto_id_counter, 0);
    }

    #[test]
    fn test_migration() {
        let dir = test_dir();
        let old = dir.join("norms.json");
        let ledger = dir.join("norm_ledger.jsonl");

        // Write an old-style norms.json
        let payload = serde_json::json!({
            "auto_norms": [
                make_norm("ISLS-NORM-AUTO-0001", "Migrated Norm"),
            ],
            "injected_norms": [],
            "candidates": [],
            "auto_id_counter": 1,
        });
        fs::write(&old, serde_json::to_string_pretty(&payload).unwrap()).unwrap();

        // Run migration using the path-based functions
        // (We can't use migrate_to_ledger() directly because it uses fixed paths)
        // Instead verify the event format is correct by manually replaying
        let content = fs::read_to_string(&old).unwrap();
        let parsed: serde_json::Value = serde_json::from_str(&content).unwrap();
        if let Some(norms) = parsed["auto_norms"].as_array() {
            for v in norms {
                if let Ok(norm) = serde_json::from_value::<Norm>(v.clone()) {
                    append_event_to(
                        &ledger,
                        &NormEvent::NormAdded {
                            timestamp: "migration".into(),
                            norm,
                        },
                    )
                    .unwrap();
                }
            }
        }

        let state = load_registry_from_ledger_path(&ledger).unwrap();
        assert_eq!(state.norms.len(), 1);
        assert!(state.norms.contains_key("ISLS-NORM-AUTO-0001"));
    }
}

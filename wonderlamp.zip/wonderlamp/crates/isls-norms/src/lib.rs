// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Self-defining norm system for ISLS v3.0.
//!
//! Norms are composable, reusable software patterns expressed as pure data.
//! They span all layers of a full-stack application: database migrations,
//! models, queries, services, API handlers, frontend components, tests, and
//! config.  The [`NormRegistry`] holds built-in norms and auto-discovers new
//! ones from synthesis runs via [`NormRegistry::observe_and_learn`].
//!
//! **Constraints:** this crate is pure data — no tokio, no reqwest, no axum.
//! Only `std::fs` is used for persisting auto-discovered norms to
//! `~/.isls/norms.json`.
//!
//! # Example
//!
//! ```rust
//! use isls_norms::NormRegistry;
//!
//! let registry = NormRegistry::default();
//! let activated = registry.match_description("I need a warehouse inventory system");
//! assert!(!activated.is_empty());
//! ```

pub mod anatomy;
pub mod capabilities;
pub mod catalog;
pub mod composition;
pub mod emergent;
pub mod energy;
pub mod fitness;
pub mod genome;
pub mod groups;
pub mod injection;
pub mod learning;
pub mod ledger;
pub mod mef_chain;
pub mod optimizer;
pub mod relations;
pub mod spectroscopy;
pub mod storage;
pub mod targets;
pub mod types;

pub use injection::{
    inject_norm, load_blueprint, parse_blueprint, remove_injected, BlueprintConstraints,
    InjectError, NormBlueprint, ResonitePattern, INJECT_PREFIX,
};
pub use spectroscopy::{
    classify_resonite, classify_resonite_v2, classify_resonite_v2_with_emergent,
    spectroscopy, suggest_keywords, suggest_keywords_for_class, NormGap, Resonite,
    ResoniteClass, ResoniteTypeKind, ScrapeSuggestion, SpectroscopyResult,
};
pub use emergent::{
    EmergentClassRegistry, EmergentCluster, EmergentSummary, ClusterStatus,
    UnclassifiedResonite, EmergentClassEntry,
};

pub use capabilities::{
    Capability, CapabilityStatus, SemanticCandidate, SemanticObservation,
    compute_capabilities,
};
pub use catalog::builtin_norms;
pub use composition::{compose_norms, ComposedPlan};
pub use learning::{
    AbstractedArtifact, CandidateStatus, CrossLayerPattern, NormCandidate,
    ObservedArtifact, PromotionCriteria,
};
pub use types::{
    ActivatedNorm, ActivationSource, ApiArtifact, ConfigArtifact, DatabaseArtifact,
    FieldSource, FieldSpec, FrontendArtifact, FrontendComponent, InterfaceContract,
    LayerType, ModelArtifact, Norm, NormEvidence, NormLevel, NormLayers,
    NormModification, NormParameter, NormVariant, NormWiring, ParamType,
    QueryArtifact, ServiceArtifact, TestArtifact, TriggerPattern, ValidationSpec,
};

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::OnceLock;

/// Ensures `backup_norms_dir` runs at most once per process lifetime,
/// regardless of how many times `NormRegistry::new()` is called.
static BACKUP_DONE: OnceLock<()> = OnceLock::new();

/// Ensures old layer-pair norm files are moved out exactly once per process.
static LAYER_NORM_CLEANUP_DONE: OnceLock<()> = OnceLock::new();

/// Move all `ISLS-NORM-AUTO-0*.json` files from `~/.isls/norms/` to
/// `~/.isls/norms_purged/` so they cannot be resurrected on next startup.
///
/// Runs at most once per process lifetime (guarded by `LAYER_NORM_CLEANUP_DONE`).
fn cleanup_old_layer_norms() {
    let norms_dir = match storage::norms_dir() {
        Some(d) => d,
        None => return,
    };
    if !norms_dir.exists() {
        return;
    }
    let purge_dir = match norms_dir.parent() {
        Some(p) => p.join("norms_purged"),
        None => return,
    };
    let _ = std::fs::create_dir_all(&purge_dir);

    let entries = match std::fs::read_dir(&norms_dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().into_owned();
        if name.starts_with("ISLS-NORM-AUTO-0") && name.ends_with(".json") {
            let dest = purge_dir.join(&name);
            if let Ok(()) = std::fs::rename(entry.path(), &dest) {
                eprintln!("[CLEANUP] Moved old layer norm to purged: {}", name);
            }
        }
    }
}

use thiserror::Error;

/// Errors produced by the norm system.
#[derive(Debug, Error)]
pub enum NormError {
    /// A required norm dependency is missing from the registry.
    #[error("missing norm dependency: {0}")]
    MissingDependency(String),
    /// Serialisation/deserialisation error.
    #[error("serialisation error: {0}")]
    Serde(#[from] serde_json::Error),
    /// IO error when persisting norms.
    #[error("io error: {0}")]
    Io(#[from] std::io::Error),
    /// Composition conflict between two norms.
    #[error("composition conflict: {0}")]
    Conflict(String),
}

pub type Result<T> = std::result::Result<T, NormError>;

// ─── NormRegistry ─────────────────────────────────────────────────────────────

/// Registry of built-in and auto-discovered norms.
///
/// Holds the 20+ molecule norms, 3 organism norms, cross-norm wirings, and
/// the candidate pool for self-discovery.  Auto-discovered norms and candidates
/// are persisted to `~/.isls/norms.json`.
pub struct NormRegistry {
    norms: HashMap<String, Norm>,
    wirings: Vec<NormWiring>,
    candidates: HashMap<String, NormCandidate>,
    /// I6: Semantic candidates keyed by `SEM-{ClassName}`.
    semantic_candidates: HashMap<String, capabilities::SemanticCandidate>,
    auto_id_counter: u32,
    persistence_path: Option<PathBuf>,
}

impl NormRegistry {
    /// Create a new registry pre-loaded with built-in norms and default
    /// persistence path (`~/.isls/norms.json`).
    ///
    /// On first run, migrates any existing `norms.json` to the append-only
    /// ledger. Auto-discovered norms and candidates are loaded from the ledger.
    pub fn new() -> Self {
        let mut registry = Self {
            norms: HashMap::new(),
            wirings: Vec::new(),
            candidates: HashMap::new(),
            semantic_candidates: HashMap::new(),
            auto_id_counter: 0,
            persistence_path: Self::default_persistence_path(),
        };
        for norm in builtin_norms() {
            registry.norms.insert(norm.id.clone(), norm);
        }
        registry.wirings = builtin_wirings();
        // Migrate old norms.json → ledger (no-op if already done)
        let _ = ledger::migrate_to_ledger();
        // E1: Migrate unchained ledger → hash-chained ledger (no-op if already done)
        let _ = mef_chain::migrate_to_chained();
        // E1: Ensure a Genesis event exists if the ledger is new
        let _ = mef_chain::ensure_genesis();
        // FINAL: Backup individual norm files — once per process only.
        // NormRegistry::new() is called in scraping hot paths too; guarding
        // with OnceLock prevents backup spam on every scrape iteration.
        BACKUP_DONE.get_or_init(|| {
            let _ = storage::backup_norms_dir();
        });
        // FINAL: One-time migration of ledger norms → individual files
        let _ = storage::migrate_norms_to_directory();
        // FINAL: Load individual norm files first (recovery foundation —
        //        if the ledger/snapshot is corrupt, files survive)
        if let Ok(file_norms) = storage::load_all_norms() {
            for norm in file_norms {
                // Skip old layer-pair norms — they have no semantic class and
                // are no longer produced by the active pipeline.
                if norm.id.starts_with("ISLS-NORM-AUTO-0") && norm.semantic_class.is_none() {
                    continue;
                }
                if norm.id.starts_with("ISLS-NORM-AUTO-")
                    || norm.id.starts_with(injection::INJECT_PREFIX)
                {
                    registry.norms.insert(norm.id.clone(), norm);
                }
            }
        }
        // Load auto-discovered norms from ledger (or snapshot cache) — overwrites
        // individual files if ledger has a fresher version
        if let Ok(state) = ledger::load_persisted() {
            for (id, norm) in state.norms {
                // Skip old layer-pair norms (same guard as in load()).
                if id.starts_with("ISLS-NORM-AUTO-0") && norm.semantic_class.is_none() {
                    continue;
                }
                registry.norms.insert(id, norm);
            }
            for (sig, cand) in state.candidates {
                registry.candidates.insert(sig, cand);
            }
            for (key, sem_cand) in state.semantic_candidates {
                registry.semantic_candidates.insert(key, sem_cand);
            }
            if state.auto_id_counter > registry.auto_id_counter {
                registry.auto_id_counter = state.auto_id_counter;
            }
        }
        // One-time: move old layer-pair norm files out of ~/.isls/norms/.
        LAYER_NORM_CLEANUP_DONE.get_or_init(|| {
            cleanup_old_layer_norms();
        });
        registry
    }

    /// Create an empty registry without builtins or persistence (for tests).
    pub fn empty_without_persistence() -> Self {
        Self {
            norms: HashMap::new(),
            wirings: Vec::new(),
            candidates: HashMap::new(),
            semantic_candidates: HashMap::new(),
            auto_id_counter: 0,
            persistence_path: None,
        }
    }

    /// Create a new registry pre-loaded with built-in norms but without
    /// disk persistence (for tests).
    pub fn new_without_persistence() -> Self {
        let mut registry = Self {
            norms: HashMap::new(),
            wirings: Vec::new(),
            candidates: HashMap::new(),
            semantic_candidates: HashMap::new(),
            auto_id_counter: 0,
            persistence_path: None,
        };
        for norm in builtin_norms() {
            registry.norms.insert(norm.id.clone(), norm);
        }
        registry.wirings = builtin_wirings();
        registry
    }

    fn default_persistence_path() -> Option<PathBuf> {
        dirs_path().map(|d| d.join("norms.json"))
    }

    /// Register a norm.
    pub fn register(&mut self, norm: Norm) {
        self.norms.insert(norm.id.clone(), norm);
    }

    /// Remove a norm by ID. Returns the removed norm, if any.
    pub fn remove(&mut self, id: &str) -> Option<Norm> {
        self.norms.remove(id)
    }

    /// Look up a norm by ID.
    pub fn get(&self, id: &str) -> Option<&Norm> {
        self.norms.get(id)
    }

    /// All registered norms.
    pub fn all_norms(&self) -> Vec<&Norm> {
        self.norms.values().collect()
    }

    /// Wirings between two norm IDs (order-independent).
    pub fn wirings_for(&self, a: &str, b: &str) -> Vec<&NormWiring> {
        self.wirings.iter().filter(|w| {
            (w.when.0 == a && w.when.1 == b) || (w.when.0 == b && w.when.1 == a)
        }).collect()
    }

    /// All norm wirings.
    pub fn all_wirings(&self) -> &[NormWiring] {
        &self.wirings
    }

    /// All candidates in the learning pool.
    pub fn candidates(&self) -> Vec<&NormCandidate> {
        self.candidates.values().collect()
    }

    /// I6: All semantic candidates.
    pub fn semantic_candidates(&self) -> Vec<&capabilities::SemanticCandidate> {
        self.semantic_candidates.values().collect()
    }

    /// I6: Mutable access to semantic candidates map (for ledger replay).
    pub fn semantic_candidates_mut(&mut self) -> &mut HashMap<String, capabilities::SemanticCandidate> {
        &mut self.semantic_candidates
    }

    /// Count of auto-discovered norms (prefix `ISLS-NORM-AUTO-`).
    pub fn auto_norms_count(&self) -> usize {
        self.norms.keys().filter(|id| id.starts_with("ISLS-NORM-AUTO-")).count()
    }

    /// Match a free-text description against the norm catalog using keyword
    /// scoring.  Returns norms sorted by descending confidence, filtered to
    /// those with confidence ≥ 0.3.
    pub fn match_description(&self, description: &str) -> Vec<ActivatedNorm> {
        let lower = description.to_lowercase();
        let mut scored: Vec<(f64, &Norm)> = self.norms.values().filter_map(|norm| {
            let confidence = score_norm(norm, &lower);
            if confidence >= 0.3 { Some((confidence, norm)) } else { None }
        }).collect();
        scored.sort_by(|a, b| b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal));
        scored.into_iter().map(|(confidence, norm)| ActivatedNorm {
            norm: norm.clone(),
            confidence,
            source: ActivationSource::KeywordMatch,
        }).collect()
    }

    /// Save a snapshot of auto-discovered norms and candidates to disk.
    ///
    /// This is a checkpoint operation — the primary persistence is the
    /// append-only ledger. The snapshot is a read cache rebuilt from the
    /// ledger if stale or corrupt. Includes a plausibility check that
    /// refuses to write fewer auto-norms than the ledger already contains.
    pub fn save(&self) -> Result<()> {
        if self.persistence_path.is_none() {
            return Ok(());
        }
        let auto_norms: Vec<&Norm> = self
            .norms
            .values()
            .filter(|n| n.id.starts_with("ISLS-NORM-AUTO-"))
            .collect();
        let injected_norms: Vec<&Norm> = self
            .norms
            .values()
            .filter(|n| n.id.starts_with(injection::INJECT_PREFIX))
            .collect();
        let cands: Vec<&learning::NormCandidate> = self.candidates.values().collect();
        // Trim SemanticCandidate observations before writing snapshot — snapshot only
        // needs the last 20 to reconstruct state; this keeps the file small.
        const MAX_SNAPSHOT_OBS: usize = 5;
        let sem_cands_trimmed: Vec<capabilities::SemanticCandidate> = self
            .semantic_candidates
            .values()
            .cloned()
            .map(|mut c| {
                if c.observations.len() > MAX_SNAPSHOT_OBS {
                    let drop = c.observations.len() - MAX_SNAPSHOT_OBS;
                    c.observations.drain(0..drop);
                }
                c
            })
            .collect();
        let sem_cands: Vec<&capabilities::SemanticCandidate> = sem_cands_trimmed.iter().collect();
        ledger::save_snapshot(&auto_norms, &injected_norms, &cands, &sem_cands, self.auto_id_counter)?;

        // Fallback: write any SEM norm file that is missing from disk.
        // Only semantic auto-norms (ISLS-NORM-AUTO-SEM-*) are re-written here.
        // Old layer-pair norms (AUTO-0xxx) are intentionally excluded so they
        // are not resurrected from the snapshot after being removed.
        for norm in self.norms.values() {
            if norm.id.starts_with("ISLS-NORM-AUTO-SEM-") && !storage::norm_file_exists(&norm.id) {
                if let Err(e) = storage::save_norm(norm) {
                    eprintln!(
                        "[NORM STORAGE] Fallback save failed for {}: {:?}",
                        norm.id, e
                    );
                }
            }
        }

        Ok(())
    }

    /// Load auto-discovered norms and candidates from the append-only ledger
    /// (or its snapshot cache).
    pub fn load(&mut self) -> Result<()> {
        if self.persistence_path.is_none() {
            return Ok(());
        }
        let state = ledger::load_persisted()?;
        for (id, norm) in state.norms {
            // Skip old layer-pair auto-norms that were never promoted to a semantic class.
            // These are identified by the AUTO-0xxx pattern and absence of semantic_class.
            // Skipping them here prevents the snapshot from resurrecting junk norms after
            // manual removal.
            if id.starts_with("ISLS-NORM-AUTO-0") && norm.semantic_class.is_none() {
                continue;
            }
            self.norms.insert(id, norm);
        }
        for (sig, cand) in state.candidates {
            self.candidates.insert(sig, cand);
        }
        for (key, mut sem_cand) in state.semantic_candidates {
            // One-time cleanup for snapshots written before the 20-obs cap was in place.
            if sem_cand.observations.len() > 20 {
                let drop = sem_cand.observations.len() - 20;
                sem_cand.observations.drain(0..drop);
                sem_cand.observations.shrink_to_fit();
            }
            self.semantic_candidates.insert(key, sem_cand);
        }
        if state.auto_id_counter > self.auto_id_counter {
            self.auto_id_counter = state.auto_id_counter;
        }
        Ok(())
    }

    /// Observe generated artifacts from a synthesis run and update the
    /// learning pool.  Eligible candidates are auto-promoted to norms.
    ///
    /// # Parameters
    /// - `artifacts`: layer→name→fields triples describing generated files
    /// - `domain`: domain name (e.g. "warehouse")
    /// - `run_id`: unique run identifier
    pub fn observe_and_learn(
        &mut self,
        artifacts: &[learning::ObservedArtifact],
        domain: &str,
        run_id: &str,
    ) {
        // ── DEAKTIVIERT: Alte Layer-Pairing-Pipeline ───────────────────────
        // Erzeugte AUTO-0xxx Normen die Topologie beschreiben ([Model,Test],
        // [Api,Fe]) statt echte Fähigkeiten — kein Nutzen beim Forge.
        // Semantische Pipeline (SEM-*) übernimmt vollständig ab I6/final.
        //
        // use learning::{extract_cross_layer_patterns, synthesize_norm, PromotionCriteria};
        // let criteria = PromotionCriteria::default();
        // let patterns = extract_cross_layer_patterns(artifacts, domain, run_id);
        // for pattern in patterns {
        //     let sig = pattern.signature.clone();
        //     let is_new = !self.candidates.contains_key(&sig);
        //     let next_id = format!("ISLS-CAND-{:04}", self.candidates.len() + 1);
        //     let cand = self.candidates.entry(sig.clone()).or_insert_with(|| {
        //         NormCandidate::new(next_id, &pattern)
        //     });
        //     if is_new {
        //         if has_persistence {
        //             let _ = mef_chain::append_chained_event(&ledger::candidate_created_event(...));
        //         }
        //     } else {
        //         cand.observe(pattern.clone());
        //         if has_persistence { ... }
        //     }
        //     if cand.meets_criteria(&criteria) {
        //         let promoted_norm = synthesize_norm(cand, &mut self.auto_id_counter);
        //         ... storage::promote_norm(promoted_norm) ...
        //         self.norms.insert(promoted_norm.id.clone(), promoted_norm);
        //     }
        // }
        // ─────────────────────────────────────────────────────────────────────

        let has_persistence = self.persistence_path.is_some();

        // Memory bounds — prevent unbounded growth
        /// Max unclassified disk writes per `observe_and_learn` call (per repo).
        const MAX_UNCLASSIFIED_PER_RUN: usize = 100;
        /// Max Resonite examples kept per SemanticObservation (prevents huge Vecs).
        const MAX_RESONITES_PER_OBS: usize = 10;
        /// Max observations kept per SemanticCandidate before old ones are dropped.
        const MAX_OBS_PER_CANDIDATE: usize = 20;
        /// Hard cap on total SemanticCandidates held in RAM.
        const MAX_SEMANTIC_CANDIDATES: usize = 1_000;

        let mut unclassified_written = 0usize;

        // ── I6: Semantic classification ────────────────────────────────────
        // Convert artifacts → resonites, classify with v2, group by class.
        use std::collections::BTreeMap;
        let mut class_resonites: BTreeMap<ResoniteClass, Vec<Resonite>> = BTreeMap::new();

        for artifact in artifacts {
            let resonite = match artifact.artifact_type.as_str() {
                "fn" | "function" | "method" => Resonite::Fn {
                    name: artifact.name.clone(),
                    arity: artifact.field_names.len(),
                },
                "struct" | "class" | "type" | "enum" | "trait" | "interface" => {
                    let kind = match artifact.artifact_type.as_str() {
                        "enum" => spectroscopy::ResoniteTypeKind::Enum,
                        "trait" | "interface" => spectroscopy::ResoniteTypeKind::Trait,
                        _ => spectroscopy::ResoniteTypeKind::Struct,
                    };
                    Resonite::Type {
                        name: artifact.name.clone(),
                        kind,
                    }
                }
                "import" | "use" => Resonite::Import {
                    path: artifact.name.clone(),
                },
                _ => Resonite::Layer {
                    depth: match artifact.layer {
                        LayerType::Database => 0,
                        LayerType::Model => 1,
                        LayerType::Query => 2,
                        LayerType::Service => 3,
                        LayerType::Api => 4,
                        LayerType::Frontend => 5,
                        LayerType::Test => 6,
                        LayerType::Config => 7,
                    },
                    artifact: artifact.name.clone(),
                },
            };

            let classes = classify_resonite_v2(&resonite);

            // I7: Collect unclassified resonites for emergent classification
            // Hard cap: at most MAX_UNCLASSIFIED_PER_RUN writes per repo/invocation.
            if classes.is_empty() && unclassified_written < MAX_UNCLASSIFIED_PER_RUN {
                let rname = match &resonite {
                    Resonite::Fn { name, .. } => Some(name.to_lowercase()),
                    Resonite::Type { name, .. } => Some(name.to_lowercase()),
                    _ => None,
                };
                if let Some(rname) = rname {
                    let prefix = emergent::extract_prefix(&rname);
                    if !prefix.is_empty() && !emergent::is_stopword(&prefix) {
                        if has_persistence {
                            let _ = emergent::append_unclassified(
                                &emergent::UnclassifiedResonite {
                                    name: rname,
                                    prefix,
                                    repo: run_id.to_string(),
                                    domain: domain.to_string(),
                                    language: "unknown".to_string(),
                                    timestamp: chrono::Local::now()
                                        .format("%Y-%m-%dT%H:%M:%S")
                                        .to_string(),
                                },
                            );
                            unclassified_written += 1;
                        }
                    }
                }
            }

            for class in classes {
                class_resonites.entry(class).or_default().push(resonite.clone());
            }
        }

        let now = chrono::Local::now().format("%Y-%m-%dT%H:%M:%S").to_string();

        for (class, mut resonites) in class_resonites {
            let sem_key = format!("SEM-{}", class.as_str());

            // Evict the weakest candidate before inserting a new one (RAM cap).
            if !self.semantic_candidates.contains_key(&sem_key)
                && self.semantic_candidates.len() >= MAX_SEMANTIC_CANDIDATES
            {
                if let Some(weakest) = self
                    .semantic_candidates
                    .values()
                    .min_by_key(|c| c.observation_count())
                    .map(|c| c.id.clone())
                {
                    self.semantic_candidates.remove(&weakest);
                }
            }

            let _is_new = !self.semantic_candidates.contains_key(&sem_key);

            let cand = self.semantic_candidates
                .entry(sem_key.clone())
                .or_insert_with(|| capabilities::SemanticCandidate {
                    id: sem_key.clone(),
                    semantic_class: class.clone(),
                    observations: vec![],
                    created_at: now.clone(),
                });

            // Deduplicate: don't add if we already have an obs from this run_id+domain
            let already_has = cand.observations.iter().any(|o| {
                o.repo == run_id && o.domain == domain
            });

            if !already_has {
                // Cap resonite examples: we only need a sample, not every function.
                resonites.truncate(MAX_RESONITES_PER_OBS);

                cand.observations.push(capabilities::SemanticObservation {
                    repo: run_id.to_string(),
                    domain: domain.to_string(),
                    language: "unknown".to_string(),
                    resonites,
                    timestamp: now.clone(),
                });

                // Drop oldest observations beyond cap to bound per-candidate size.
                let excess = cand.observations.len().saturating_sub(MAX_OBS_PER_CANDIDATE);
                if excess > 0 {
                    cand.observations.drain(0..excess);
                }

                if has_persistence {
                    let _ = mef_chain::append_chained_event(&ledger::NormEvent::SemanticObservation {
                        timestamp: now.clone(),
                        candidate_id: sem_key.clone(),
                        class: class.clone(),
                        repo: run_id.to_string(),
                        domain: domain.to_string(),
                    });
                }
            }

            // Check promotion
            if cand.should_promote() {
                let promoted_norm = cand.crystallize_to_norm();

                // Don't promote if a norm with this ID already exists
                if !self.norms.contains_key(&promoted_norm.id) {
                    if has_persistence {
                        let _ = mef_chain::append_chained_event(&ledger::NormEvent::NormAdded {
                            timestamp: now.clone(),
                            norm: promoted_norm.clone(),
                        });
                        // FINAL: persist as individual write-once file
                        if let Err(e) = storage::promote_norm(promoted_norm.clone()) {
                            eprintln!(
                                "[NORM STORAGE ERROR] Failed to write norm to disk: {} — {:?}",
                                promoted_norm.id, e
                            );
                        }
                    }
                    self.norms.insert(promoted_norm.id.clone(), promoted_norm);
                    // Remove promoted candidate — it's now a norm; no reason to keep
                    // all its observations in RAM / snapshot.
                    self.semantic_candidates.remove(&sem_key);
                }
            }
        }

        // Update snapshot (best-effort checkpoint)
        let _ = self.save();
    }

    /// I6: Tag builtin norms with their semantic class.
    pub fn tag_builtin_semantic_classes(&mut self) {
        let class_map: Vec<(&str, ResoniteClass)> = vec![
            ("ISLS-NORM-0042", ResoniteClass::CrudEntity),
            ("ISLS-NORM-0088", ResoniteClass::Authentication),
            ("ISLS-NORM-0089", ResoniteClass::Authorization),
            ("ISLS-NORM-0090", ResoniteClass::Pagination),
            ("ISLS-NORM-0091", ResoniteClass::Search),
            ("ISLS-NORM-0092", ResoniteClass::FileUpload),
            ("ISLS-NORM-0094", ResoniteClass::ExportImport),
            ("ISLS-NORM-0112", ResoniteClass::CrudEntity), // Inventory is CRUD-based
            ("ISLS-NORM-0113", ResoniteClass::CrudEntity), // Audit-Trail
            ("ISLS-NORM-0115", ResoniteClass::StateMachine), // Status Machine
            ("ISLS-NORM-0118", ResoniteClass::Notification),
            ("ISLS-NORM-0130", ResoniteClass::Scheduling),
        ];
        for (id, class) in class_map {
            if let Some(norm) = self.norms.get_mut(id) {
                if norm.semantic_class.is_none() {
                    norm.semantic_class = Some(class);
                }
            }
        }
    }

    /// I6: Deduplicate auto-discovered norms by semantic signature.
    ///
    /// Groups auto-norms that have the same layer topology, keeps only
    /// the one with the most observations per group, removes the rest.
    /// Returns the number of removed duplicates.
    pub fn deduplicate_norms(&mut self) -> usize {
        let has_persistence = self.persistence_path.is_some();

        // Collect all auto-norms
        let auto_norm_ids: Vec<String> = self.norms.keys()
            .filter(|id| id.starts_with("ISLS-NORM-AUTO-"))
            .cloned()
            .collect();

        if auto_norm_ids.len() <= 1 {
            return 0;
        }

        // Group by semantic signature: sorted set of (layer_has_content) + norm name pattern
        let mut groups: HashMap<String, Vec<(String, u32)>> = HashMap::new();
        for id in &auto_norm_ids {
            if let Some(norm) = self.norms.get(id) {
                let sig = compute_norm_dedup_signature(norm);
                groups.entry(sig)
                    .or_default()
                    .push((id.clone(), norm.evidence.usage_count));
            }
        }

        let mut removed = 0usize;
        for (_sig, mut members) in groups {
            if members.len() <= 1 {
                continue;
            }
            // Sort by usage_count descending, keep the first
            members.sort_by(|a, b| b.1.cmp(&a.1));
            for (id, _) in members.into_iter().skip(1) {
                if let Some(_norm) = self.norms.remove(&id) {
                    removed += 1;
                    if has_persistence {
                        let _ = mef_chain::append_chained_event(&ledger::NormEvent::NormRemoved {
                            timestamp: chrono::Local::now()
                                .format("%Y-%m-%dT%H:%M:%S")
                                .to_string(),
                            norm_id: id.clone(),
                            reason: "dedup: duplicate topology".into(),
                        });
                    }
                }
            }
        }

        if removed > 0 {
            let remaining = self.norms.keys()
                .filter(|id| id.starts_with("ISLS-NORM-AUTO-"))
                .count();
            eprintln!(
                "[I6] Dedup: removed {} duplicate norms, {} unique remain",
                removed, remaining
            );
            let _ = self.save();
        }

        removed
    }
}

/// Compute a deduplication signature for a norm based on its layer topology.
fn compute_norm_dedup_signature(norm: &Norm) -> String {
    let mut parts = Vec::new();
    if !norm.layers.database.is_empty() { parts.push("DB"); }
    if !norm.layers.model.is_empty() { parts.push("Model"); }
    if !norm.layers.query.is_empty() { parts.push("Query"); }
    if !norm.layers.service.is_empty() { parts.push("Svc"); }
    if !norm.layers.api.is_empty() { parts.push("Api"); }
    if !norm.layers.frontend.is_empty() { parts.push("Fe"); }
    if !norm.layers.test.is_empty() { parts.push("Test"); }
    if !norm.layers.config.is_empty() { parts.push("Cfg"); }
    // Also include the name pattern to avoid deduplicating genuinely different norms
    parts.push(&norm.name);
    parts.join("+")
}

impl Default for NormRegistry {
    fn default() -> Self {
        Self::new()
    }
}

/// Score a norm against a lowercase description string.
///
/// Returns a value in [0.0, 1.0].  Even a single keyword match yields ≥ 0.2
/// so that organism norms (which have many keywords) are not penalised for
/// the keywords that don't appear in the description.
fn score_norm(norm: &Norm, lower_desc: &str) -> f64 {
    let mut hits = 0usize;
    for trigger in &norm.triggers {
        for kw in &trigger.keywords {
            if lower_desc.contains(kw.as_str()) {
                hits += 1;
            }
        }
        for concept in &trigger.concepts {
            if lower_desc.contains(concept.as_str()) {
                hits += 1;
            }
        }
    }
    if hits == 0 { return 0.0; }
    // Scale: each hit adds 0.25, capped at 1.0
    f64::min(1.0, hits as f64 * 0.25)
}

/// Check if a norm structurally matches a cross-layer pattern.
fn norm_matches_pattern(norm: &Norm, pattern: &CrossLayerPattern) -> bool {
    // A norm matches if ≥60% of its layer types are present in the pattern
    let norm_layers = norm_layer_types(norm);
    if norm_layers.is_empty() { return false; }
    let matches = norm_layers.iter()
        .filter(|lt| pattern.layers_present.contains(lt))
        .count();
    matches as f64 / norm_layers.len() as f64 >= 0.6
}

fn norm_layer_types(norm: &Norm) -> Vec<LayerType> {
    let mut layers = Vec::new();
    if !norm.layers.database.is_empty() { layers.push(LayerType::Database); }
    if !norm.layers.model.is_empty()    { layers.push(LayerType::Model); }
    if !norm.layers.query.is_empty()    { layers.push(LayerType::Query); }
    if !norm.layers.service.is_empty()  { layers.push(LayerType::Service); }
    if !norm.layers.api.is_empty()      { layers.push(LayerType::Api); }
    if !norm.layers.frontend.is_empty() { layers.push(LayerType::Frontend); }
    if !norm.layers.test.is_empty()     { layers.push(LayerType::Test); }
    if !norm.layers.config.is_empty()   { layers.push(LayerType::Config); }
    layers
}

/// Returns the ISLS data directory (`~/.isls`).
fn dirs_path() -> Option<PathBuf> {
    std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .ok()
        .map(|h| PathBuf::from(h).join(".isls"))
}

fn builtin_wirings() -> Vec<NormWiring> {
    vec![
        // Order + Inventory → fulfill_order calls adjust_stock
        NormWiring {
            when: ("ISLS-NORM-0042".into(), "ISLS-NORM-0112".into()),
            description: "Order fulfillment calls inventory adjustment".into(),
            add_services: vec![ServiceArtifact {
                name: "fulfill_order_stock".into(),
                description: "Deduct inventory for each order line on fulfillment".into(),
                method_signatures: vec![
                    "pub async fn fulfill_order(pool: &PgPool, order_id: i64) -> Result<(), AppError>".into(),
                ],
                business_rules: vec!["for each order line: adjust_stock(product_id, -quantity)".into()],
            }],
            add_rules: vec![],
            add_tests: vec![],
        },
        // Auth + All entities → inject auth check on all endpoints
        NormWiring {
            when: ("ISLS-NORM-0088".into(), "ISLS-NORM-0042".into()),
            description: "Auth norm injects require_role check on CRUD endpoints".into(),
            add_services: vec![],
            add_rules: vec![types::BusinessRule {
                name: "auth_required".into(),
                trigger: "on_request".into(),
                condition: "user.is_authenticated()".into(),
                action: "require_role(user, min_role)?".into(),
            }],
            add_tests: vec![],
        },
    ]
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_registry_loads_builtins() {
        let reg = NormRegistry::default();
        assert!(reg.norms.len() >= 20, "should have at least 20 built-in norms, got {}", reg.norms.len());
    }

    #[test]
    fn test_match_warehouse_description() {
        let reg = NormRegistry::default();
        let activated = reg.match_description("warehouse inventory management with stock tracking");
        assert!(!activated.is_empty(), "should match at least one norm for warehouse");
        // The warehouse organism should be among the top matches
        let has_warehouse = activated.iter().any(|a| a.norm.id == "ISLS-NORM-0500");
        assert!(has_warehouse, "warehouse organism norm should be activated");
    }

    #[test]
    fn test_match_returns_sorted_by_confidence() {
        let reg = NormRegistry::default();
        let activated = reg.match_description("crud entity with pagination and search");
        let confidences: Vec<f64> = activated.iter().map(|a| a.confidence).collect();
        for i in 1..confidences.len() {
            assert!(confidences[i - 1] >= confidences[i], "should be sorted desc");
        }
    }

    #[test]
    fn test_compose_warehouse_norms() {
        let reg = NormRegistry::default();
        let activated = reg.match_description("warehouse inventory management with orders");
        assert!(!activated.is_empty());
        let params = HashMap::new();
        let plan = compose_norms(&activated, &params).expect("composition should succeed");
        // Warehouse organism should produce multiple model artifacts
        assert!(!plan.models.is_empty() || !plan.api.is_empty(),
            "composed plan should have models or api artifacts");
    }
}

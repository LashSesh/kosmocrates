// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! E1: MEF Hash-Chain — append-only ledger with SHA-256 event chaining.
//!
//! Every event is extended with three fields written into the JSONL line:
//!   `seq`       — monotonically increasing sequence number (u64)
//!   `prev_hash` — SHA-256 of the previous event (hex, 64 chars)
//!   `hash`      — SHA-256 of (seq_bytes ‖ prev_hash ‖ event_json ‖ timestamp)
//!
//! Genesis event: seq=0, prev_hash="0000…0000" (64 zeros), type `Genesis`.
//!
//! Migration: if `norm_ledger.jsonl` exists but lines lack the `hash` field,
//! the file is renamed to `norm_ledger.v0.jsonl`, a new chain is started with
//! a Genesis event, and all previous events are re-appended with proper hashing.

use std::fs::{self, File, OpenOptions};
use std::io::{BufRead, BufReader, Write};
use std::path::{Path, PathBuf};
use std::sync::{Mutex, OnceLock};

use sha2::{Digest, Sha256};

use crate::ledger::NormEvent;
use crate::{NormError, Result};

// ─── Global write serializer ──────────────────────────────────────────────────

/// Process-global mutex that serializes ALL writes to the ledger.
///
/// Without this, parallel scrape workers each perform read-then-write,
/// causing seq collisions and broken hash-chains. The lock is held only
/// for the duration of a single append — no nested locking, no deadlock.
///
/// If a thread panics while holding the lock (poison), we `unwrap()` so
/// the server crashes instead of silently writing corrupt chain data.
fn ledger_write_lock() -> &'static Mutex<()> {
    static LOCK: OnceLock<Mutex<()>> = OnceLock::new();
    LOCK.get_or_init(|| Mutex::new(()))
}

// ─── Paths ───────────────────────────────────────────────────────────────────

fn isls_home() -> Option<PathBuf> {
    std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .ok()
        .map(|h| PathBuf::from(h).join(".isls"))
}

pub(crate) fn ledger_path() -> Option<PathBuf> {
    isls_home().map(|d| d.join("norm_ledger.jsonl"))
}

fn now_iso() -> String {
    chrono::Local::now()
        .format("%Y-%m-%dT%H:%M:%S")
        .to_string()
}

// ─── ChainVerification ───────────────────────────────────────────────────────

/// Result of verifying the entire ledger hash-chain.
#[derive(Debug, Clone)]
pub struct ChainVerification {
    pub total_events: usize,
    pub errors: Vec<String>,
    pub is_valid: bool,
    pub head_hash: String,
    pub head_seq: u64,
}

impl ChainVerification {
    fn empty_valid() -> Self {
        Self {
            total_events: 0,
            errors: vec![],
            is_valid: true,
            head_hash: "0".repeat(64),
            head_seq: 0,
        }
    }
}

// ─── Hash Computation ────────────────────────────────────────────────────────

/// Compute SHA-256(seq_bytes ‖ prev_hash_bytes ‖ canonical_event_json ‖ timestamp_bytes).
pub fn compute_event_hash(seq: u64, prev_hash: &str, event: &NormEvent, timestamp: &str) -> String {
    let event_json = serde_json::to_string(event).unwrap_or_default();
    let mut hasher = Sha256::new();
    hasher.update(seq.to_be_bytes());
    hasher.update(prev_hash.as_bytes());
    hasher.update(event_json.as_bytes());
    hasher.update(timestamp.as_bytes());
    let result = hasher.finalize();
    result.iter().map(|b| format!("{:02x}", b)).collect()
}

/// Extract the embedded timestamp from a `NormEvent` variant.
pub fn extract_event_timestamp(event: &NormEvent) -> String {
    match event {
        NormEvent::NormAdded { timestamp, .. } => timestamp.clone(),
        NormEvent::NormInjected { timestamp, .. } => timestamp.clone(),
        NormEvent::CandidateCreated { timestamp, .. } => timestamp.clone(),
        NormEvent::ObservationRecorded { timestamp, .. } => timestamp.clone(),
        NormEvent::NormPromoted { timestamp, .. } => timestamp.clone(),
        NormEvent::AutoIdCounterUpdated { timestamp, .. } => timestamp.clone(),
        NormEvent::SemanticObservation { timestamp, .. } => timestamp.clone(),
        NormEvent::NormRemoved { timestamp, .. } => timestamp.clone(),
        NormEvent::Genesis { timestamp, .. } => timestamp.clone(),
        NormEvent::MciMeasured { timestamp, .. } => timestamp.clone(),
        NormEvent::EmergentClassDiscovered { timestamp, .. } => timestamp.clone(),
    }
}

// ─── Read last event hash ─────────────────────────────────────────────────────

/// Read the `hash` and `seq` of the last chained entry in the ledger.
/// Returns `None` if the file is empty, missing, or the last line has no hash field.
pub fn read_last_event_hash(path: &Path) -> Option<(String, u64)> {
    let file = File::open(path).ok()?;
    let reader = BufReader::new(file);
    let mut last: Option<(String, u64)> = None;
    for line in reader.lines().flatten() {
        if line.trim().is_empty() {
            continue;
        }
        if let Ok(value) = serde_json::from_str::<serde_json::Value>(&line) {
            if let (Some(hash), Some(seq)) = (
                value["hash"].as_str().map(|s| s.to_string()),
                value["seq"].as_u64(),
            ) {
                last = Some((hash, seq));
            }
        }
    }
    last
}

// ─── Append Chained Event ────────────────────────────────────────────────────

/// Append a single event with full hash-chain metadata to the default ledger.
///
/// Silently returns `Ok(())` if the persistence path cannot be determined.
pub fn append_chained_event(event: &NormEvent) -> Result<()> {
    let path = match ledger_path() {
        Some(p) => p,
        None => return Ok(()),
    };
    append_chained_event_to(&path, event)
}

/// Append a single event with hash-chain metadata to a ledger at a custom path.
///
/// Acquires the global write lock before the read-then-write to prevent
/// seq collisions when multiple threads call this concurrently.
pub fn append_chained_event_to(path: &Path, event: &NormEvent) -> Result<()> {
    // Serialize ALL ledger writes: the lock is released when _guard drops.
    let _guard = ledger_write_lock()
        .lock()
        .unwrap_or_else(|p| p.into_inner()); // recover from poison rather than panic here

    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }

    // Determine prev_hash and next seq
    let (prev_hash, last_seq) = read_last_event_hash(path)
        .map(|(h, s)| (h, Some(s)))
        .unwrap_or_else(|| ("0".repeat(64), None));
    let seq = last_seq.map(|s| s + 1).unwrap_or(0);

    let timestamp = extract_event_timestamp(event);
    let hash = compute_event_hash(seq, &prev_hash, event, &timestamp);

    // Merge chain fields into the event JSON object
    let mut event_value = serde_json::to_value(event)?;
    if let serde_json::Value::Object(ref mut map) = event_value {
        let mut new_map = serde_json::Map::new();
        new_map.insert("seq".to_string(), serde_json::json!(seq));
        new_map.insert("prev_hash".to_string(), serde_json::json!(prev_hash));
        new_map.insert("hash".to_string(), serde_json::json!(hash));
        // Append all existing event fields after the chain fields
        let existing: Vec<(String, serde_json::Value)> = map.iter()
            .map(|(k, v)| (k.clone(), v.clone()))
            .collect();
        for (k, v) in existing {
            new_map.insert(k, v);
        }
        *map = new_map;
    }

    let mut file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(path)?;
    writeln!(file, "{}", serde_json::to_string(&event_value)?)?;
    file.sync_all()?;
    Ok(())
}

// ─── Chain Verification ──────────────────────────────────────────────────────

/// Verify the entire default ledger chain.
pub fn verify_chain() -> ChainVerification {
    let path = match ledger_path() {
        Some(p) => p,
        None => return ChainVerification::empty_valid(),
    };
    verify_chain_at(&path)
}

/// Verify a ledger chain at a custom path.
pub fn verify_chain_at(path: &Path) -> ChainVerification {
    if !path.exists() {
        return ChainVerification::empty_valid();
    }

    let content = match fs::read_to_string(path) {
        Ok(c) => c,
        Err(e) => {
            return ChainVerification {
                total_events: 0,
                errors: vec![format!("Cannot read ledger: {}", e)],
                is_valid: false,
                head_hash: "0".repeat(64),
                head_seq: 0,
            }
        }
    };

    let mut total_events = 0usize;
    let mut errors: Vec<String> = Vec::new();
    let mut expected_prev_hash = "0".repeat(64);
    let mut last_seq: Option<u64> = None;
    let mut head_hash = "0".repeat(64);
    let mut head_seq = 0u64;

    for (line_idx, line) in content.lines().enumerate() {
        if line.trim().is_empty() {
            continue;
        }

        let value: serde_json::Value = match serde_json::from_str(line) {
            Ok(v) => v,
            Err(e) => {
                errors.push(format!("Line {}: JSON parse error: {}", line_idx + 1, e));
                continue;
            }
        };

        // Lines without chain fields are legacy — count but skip chain checks
        let seq = match value["seq"].as_u64() {
            Some(s) => s,
            None => {
                total_events += 1;
                continue;
            }
        };

        // Monotone check
        if let Some(last) = last_seq {
            if seq != last + 1 {
                errors.push(format!(
                    "Line {}: seq not monotone (expected {}, got {})",
                    line_idx + 1,
                    last + 1,
                    seq
                ));
            }
        }

        // prev_hash check
        let line_prev_hash = value["prev_hash"]
            .as_str()
            .unwrap_or("")
            .to_string();
        if line_prev_hash != expected_prev_hash {
            errors.push(format!(
                "Line {}: prev_hash mismatch (expected {}, got {})",
                line_idx + 1,
                &expected_prev_hash,
                &line_prev_hash
            ));
        }

        let line_hash = match value["hash"].as_str() {
            Some(h) => h.to_string(),
            None => {
                errors.push(format!("Line {}: missing hash field", line_idx + 1));
                total_events += 1;
                last_seq = Some(seq);
                expected_prev_hash = String::new();
                continue;
            }
        };

        // Reconstruct event without chain fields for hash verification
        let mut stripped = value.clone();
        if let serde_json::Value::Object(ref mut map) = stripped {
            map.remove("seq");
            map.remove("prev_hash");
            map.remove("hash");
        }

        match serde_json::from_value::<NormEvent>(stripped) {
            Ok(event) => {
                let timestamp = extract_event_timestamp(&event);
                let expected_hash =
                    compute_event_hash(seq, &line_prev_hash, &event, &timestamp);
                if expected_hash != line_hash {
                    errors.push(format!(
                        "Line {}: hash mismatch (expected {}, got {})",
                        line_idx + 1,
                        &expected_hash,
                        &line_hash
                    ));
                }
            }
            Err(e) => {
                errors.push(format!(
                    "Line {}: cannot deserialize event for hash check: {}",
                    line_idx + 1,
                    e
                ));
            }
        }

        last_seq = Some(seq);
        expected_prev_hash = line_hash.clone();
        head_hash = line_hash;
        head_seq = seq;
        total_events += 1;
    }

    ChainVerification {
        total_events,
        is_valid: errors.is_empty(),
        errors,
        head_hash,
        head_seq,
    }
}

// ─── Migration ───────────────────────────────────────────────────────────────

/// Migrate an un-chained ledger to the hash-chained format.
///
/// If `norm_ledger.jsonl` exists but its events lack the `hash` field:
/// 1. Rename to `norm_ledger.v0.jsonl`
/// 2. Start a new chain with a Genesis event
/// 3. Re-append all old events with hash chaining
///
/// No-op if the ledger is already chained, doesn't exist, or is empty.
pub fn migrate_to_chained() -> Result<()> {
    let path = match ledger_path() {
        Some(p) => p,
        None => return Ok(()),
    };

    if !path.exists() {
        return Ok(());
    }

    // Read first non-empty line to check if already chained
    let content = fs::read_to_string(&path)?;
    let first_line = content.lines().find(|l| !l.trim().is_empty());
    if let Some(line) = first_line {
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(line) {
            if v.get("hash").is_some() {
                return Ok(()); // already chained
            }
        }
    } else {
        return Ok(()); // empty file
    }

    // Parse all existing events
    let events: Vec<NormEvent> = content
        .lines()
        .filter(|l| !l.trim().is_empty())
        .filter_map(|l| serde_json::from_str::<NormEvent>(l).ok())
        .collect();

    // Rename old file
    let v0_path = path.with_file_name("norm_ledger.v0.jsonl");
    fs::rename(&path, &v0_path)?;

    // Create new chain with Genesis event
    let builtin_count = crate::catalog::builtin_norms().len();
    let genesis = NormEvent::Genesis {
        timestamp: now_iso(),
        version: "1.0".to_string(),
        builtin_count,
    };
    append_chained_event_to(&path, &genesis)?;

    // Re-append all old events
    for event in &events {
        append_chained_event_to(&path, event)?;
    }

    eprintln!(
        "[MEF-CHAIN] Migrated {} events to hash-chained ledger (backup: {:?})",
        events.len(),
        v0_path
    );

    Ok(())
}

/// Ensure a Genesis event exists (create it if the ledger is new/empty).
pub fn ensure_genesis() -> Result<()> {
    let path = match ledger_path() {
        Some(p) => p,
        None => return Ok(()),
    };

    // If the file doesn't exist yet, write the genesis event
    if !path.exists() {
        let builtin_count = crate::catalog::builtin_norms().len();
        let genesis = NormEvent::Genesis {
            timestamp: now_iso(),
            version: "1.0".to_string(),
            builtin_count,
        };
        append_chained_event_to(&path, &genesis)?;
    }

    Ok(())
}

// ─── Read head event ─────────────────────────────────────────────────────────

/// Read the last chained event from the default ledger.
/// Returns the raw JSON value of the last line that has chain fields.
pub fn read_head_event() -> Option<serde_json::Value> {
    let path = ledger_path()?;
    read_head_event_at(&path)
}

/// Read the last chained event from a ledger at a custom path.
pub fn read_head_event_at(path: &Path) -> Option<serde_json::Value> {
    let file = File::open(path).ok()?;
    let reader = BufReader::new(file);
    let mut last: Option<serde_json::Value> = None;
    for line in reader.lines().flatten() {
        if line.trim().is_empty() {
            continue;
        }
        if let Ok(v) = serde_json::from_str::<serde_json::Value>(&line) {
            if v.get("hash").is_some() {
                last = Some(v);
            }
        }
    }
    last
}

// ─── Tests ───────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{Norm, NormEvidence, NormLevel, NormLayers};

    fn test_dir() -> PathBuf {
        let dir = std::env::temp_dir()
            .join("isls-mef-chain-test")
            .join(format!("{}", std::process::id()))
            .join(format!(
                "{}",
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            ));
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    fn make_norm(id: &str) -> Norm {
        Norm {
            id: id.into(),
            name: "Test".into(),
            level: NormLevel::Molecule,
            triggers: vec![],
            layers: NormLayers::default(),
            parameters: vec![],
            requires: vec![],
            variants: vec![],
            version: "1.0.0".into(),
            evidence: NormEvidence {
                usage_count: 0,
                domains_used: vec![],
                builtin: false,
                signature: "sig".into(),
            },
            semantic_class: None,
            consensus_resonites: vec![],
        }
    }

    #[test]
    fn test_genesis_and_chain() {
        let dir = test_dir();
        let path = dir.join("ledger.jsonl");

        let genesis = NormEvent::Genesis {
            timestamp: "2026-01-01T00:00:00".into(),
            version: "1.0".into(),
            builtin_count: 25,
        };
        append_chained_event_to(&path, &genesis).unwrap();

        let event = NormEvent::NormAdded {
            timestamp: "2026-01-01T00:00:01".into(),
            norm: make_norm("ISLS-NORM-AUTO-0001"),
        };
        append_chained_event_to(&path, &event).unwrap();

        let v = verify_chain_at(&path);
        assert!(v.is_valid, "chain should be valid: {:?}", v.errors);
        assert_eq!(v.total_events, 2);
        assert_eq!(v.head_seq, 1);
    }

    #[test]
    fn test_verify_detects_tampering() {
        let dir = test_dir();
        let path = dir.join("ledger.jsonl");

        let e1 = NormEvent::Genesis {
            timestamp: "2026-01-01T00:00:00".into(),
            version: "1.0".into(),
            builtin_count: 0,
        };
        let e2 = NormEvent::NormAdded {
            timestamp: "2026-01-01T00:00:01".into(),
            norm: make_norm("ISLS-NORM-AUTO-0001"),
        };
        append_chained_event_to(&path, &e1).unwrap();
        append_chained_event_to(&path, &e2).unwrap();

        // Tamper: replace hash in second line
        let content = fs::read_to_string(&path).unwrap();
        let lines: Vec<&str> = content.lines().collect();
        let mut val: serde_json::Value = serde_json::from_str(lines[1]).unwrap();
        val["hash"] = serde_json::json!("tampered000000000000000000000000000000000000000000000000000000");
        let tampered = format!("{}\n{}\n", lines[0], serde_json::to_string(&val).unwrap());
        fs::write(&path, tampered).unwrap();

        let v = verify_chain_at(&path);
        assert!(!v.is_valid, "tampered chain should be invalid");
        assert!(!v.errors.is_empty());
    }

    #[test]
    fn test_read_last_event_hash() {
        let dir = test_dir();
        let path = dir.join("ledger.jsonl");

        assert!(read_last_event_hash(&path).is_none());

        let e = NormEvent::Genesis {
            timestamp: "2026-01-01T00:00:00".into(),
            version: "1.0".into(),
            builtin_count: 0,
        };
        append_chained_event_to(&path, &e).unwrap();

        let (hash, seq) = read_last_event_hash(&path).unwrap();
        assert_eq!(seq, 0);
        assert_eq!(hash.len(), 64);
    }

    #[test]
    fn test_migration_from_unchained() {
        let dir = test_dir();
        let path = dir.join("norm_ledger.jsonl");

        // Write unchained events (old format)
        {
            let mut file = OpenOptions::new().create(true).append(true).open(&path).unwrap();
            let e = NormEvent::NormAdded {
                timestamp: "2026-01-01T00:00:00".into(),
                norm: make_norm("ISLS-NORM-AUTO-0001"),
            };
            writeln!(file, "{}", serde_json::to_string(&e).unwrap()).unwrap();
        }

        // Override the ledger_path function is not possible directly in tests,
        // so we call the at-path variant manually to simulate migration.
        // Test the core logic: detect unchained, migrate.
        let content = fs::read_to_string(&path).unwrap();
        let first_line = content.lines().find(|l| !l.trim().is_empty()).unwrap();
        let v: serde_json::Value = serde_json::from_str(first_line).unwrap();
        assert!(v.get("hash").is_none(), "should be unchained initially");

        // Simulate migration at the path level
        let events: Vec<NormEvent> = content
            .lines()
            .filter(|l| !l.trim().is_empty())
            .filter_map(|l| serde_json::from_str::<NormEvent>(l).ok())
            .collect();
        let v0 = path.with_file_name("norm_ledger.v0.jsonl");
        fs::rename(&path, &v0).unwrap();

        let genesis = NormEvent::Genesis {
            timestamp: now_iso(),
            version: "1.0".into(),
            builtin_count: 0,
        };
        append_chained_event_to(&path, &genesis).unwrap();
        for ev in &events {
            append_chained_event_to(&path, ev).unwrap();
        }

        let cv = verify_chain_at(&path);
        assert!(cv.is_valid, "migrated chain should be valid: {:?}", cv.errors);
        assert_eq!(cv.total_events, 2); // genesis + original event
    }
}

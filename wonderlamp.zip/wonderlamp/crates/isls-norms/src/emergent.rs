// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! I7 — Emergent Classification: self-extending taxonomy via prefix-clustering.
//!
//! When `classify_resonite_v2()` returns an empty Vec for a resonite, the
//! resonite is collected as "unclassified". Periodically, prefix clusters are
//! detected among unclassified resonites. When a cluster reaches ≥5 observations
//! across ≥3 domains, it is auto-promoted to a new emergent class.
//!
//! **Zero LLM.** Pure deterministic prefix clustering.

use std::collections::{BTreeSet, HashMap, VecDeque};
use std::fs::{self, OpenOptions};
use std::io::{BufRead, BufReader, Write};
use std::path::PathBuf;
use std::sync::OnceLock;

use serde::{Deserialize, Serialize};

// ─── Types ──────────────────────────────────────────────────────────────────

/// A resonite that did not match any hardcoded or emergent class.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct UnclassifiedResonite {
    pub name: String,
    pub prefix: String,
    pub repo: String,
    pub domain: String,
    pub language: String,
    pub timestamp: String,
}

/// A cluster of unclassified resonites sharing a common prefix.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmergentCluster {
    pub prefix: String,
    pub function_names: Vec<String>,
    pub repos: BTreeSet<String>,
    pub domains: BTreeSet<String>,
    pub languages: BTreeSet<String>,
    pub count: usize,
    pub suggested_name: String,
    pub status: ClusterStatus,
}

/// Lifecycle state of an emergent cluster.
#[derive(Debug, Clone, Copy, Serialize, Deserialize, PartialEq, Eq)]
pub enum ClusterStatus {
    /// Still collecting data.
    Observing,
    /// Promotion-eligible (≥5 obs, ≥3 domains).
    Ready,
    /// Accepted as an emergent class.
    Promoted,
    /// Rejected by operator.
    Rejected,
}

/// Registry of emergent classes, persisted to `~/.isls/emergent_classes.json`.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmergentClassRegistry {
    pub classes: Vec<EmergentClassEntry>,
    pub prefix_rules: HashMap<String, String>,
    pub last_updated: String,
}

/// A single emergent class entry.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmergentClassEntry {
    pub name: String,
    pub prefix: String,
    pub discovered_at: String,
    pub function_examples: Vec<String>,
    pub domain_count: usize,
    pub observation_count: usize,
}

impl Default for EmergentClassRegistry {
    fn default() -> Self {
        Self {
            classes: Vec::new(),
            prefix_rules: HashMap::new(),
            last_updated: String::new(),
        }
    }
}

/// Minimum observations before a cluster becomes Ready.
const EMERGENT_MIN_OBSERVATIONS: usize = 50;
/// Minimum distinct domains before a cluster becomes Ready.
const EMERGENT_MIN_DOMAINS: usize = 15;
/// Minimum prefix length to be considered for clustering.
const EMERGENT_MIN_PREFIX_LEN: usize = 5;
/// Maximum number of emergent classes (quality over quantity).
const MAX_EMERGENT_CLASSES: usize = 50;

// ─── Prefix Extraction ──────────────────────────────────────────────────────

/// Convert a name to snake_case (handles CamelCase).
pub fn to_snake_case(name: &str) -> String {
    let mut result = String::new();
    for (i, c) in name.chars().enumerate() {
        if c.is_uppercase() && i > 0 {
            result.push('_');
        }
        result.push(c.to_lowercase().next().unwrap_or(c));
    }
    result
}

/// Extract the prefix from a function name.
///
/// For snake_case: first segment before `_`.
/// For CamelCase: first lowercase block after conversion to snake_case.
/// Prefixes < 3 chars are returned as empty string.
pub fn extract_prefix(name: &str) -> String {
    let snake = to_snake_case(name);
    let prefix = snake.split('_').next().unwrap_or("").to_string();
    if prefix.len() < EMERGENT_MIN_PREFIX_LEN {
        String::new()
    } else {
        prefix
    }
}

/// Returns true for generic prefixes that should never become emergent classes.
///
/// Rule set (in order):
/// 1. Too short (< 4 chars)
/// 2. Contains non-alphabetic characters
/// 3. In the static stopword table
pub fn is_stopword(prefix: &str) -> bool {
    if prefix.len() < EMERGENT_MIN_PREFIX_LEN {
        return true;
    }
    if prefix.chars().any(|c| !c.is_alphabetic()) {
        return true;
    }

    #[rustfmt::skip]
    static STOPWORDS: &[&str] = &[
        // ── Generic programming verbs ───────────────────────────────────
        "get", "set", "new", "run", "start", "stop", "init", "main",
        "test", "from", "into", "with", "add",
        "remove", "update", "delete", "create", "make", "build",
        "handle", "process", "check", "should", "must", "assert",
        "expect", "default", "load", "save", "read", "write",
        "open", "close", "begin", "setup", "teardown",
        "before", "after", "call", "invoke", "execute", "apply",
        "return", "yield", "throw", "catch", "raise", "print",
        "find", "search", "query", "fetch", "request", "response",
        "push", "post", "patch", "send", "receive",
        "recv", "emit", "fire", "trigger", "dispatch", "notify",
        "register", "unregister", "subscribe", "unsubscribe",
        "enable", "disable", "show", "hide", "toggle", "switch",
        "parse", "format", "convert", "encode", "decode",
        "validate", "verify", "compare", "equals", "clone", "copy",
        "merge", "split", "join", "concat", "append", "prepend",
        "insert", "extract", "select", "filter", "reduce",
        "sort", "reverse", "contains", "exists", "count",
        "size", "empty", "clear", "reset", "flush", "sync",
        "lock", "unlock", "wait", "sleep", "wake", "resume",
        "pause", "cancel", "abort", "retry", "skip", "next",
        "prev", "first", "last",
        "send", "recv",

        // ── Language keywords that appear as prefixes ───────────────────
        "self", "super", "impl", "crate", "extern",
        "true", "false", "null", "none", "some",
        "func", "void", "bool", "char", "byte",
        "class", "interface", "abstract",
        "extends", "implements", "import", "export", "require",
        "module", "package", "namespace",

        // ── UI / front-end noise ────────────────────────────────────────
        "btn", "button", "icon", "svg", "img",
        "css", "style", "prop", "props", "attr",
        "aria", "data", "href", "slot",
        "render", "component", "widget",
        "layout", "grid", "flex", "column",
        "container", "wrapper", "inner", "outer", "header",
        "footer", "sidebar", "menu", "panel",
        "card", "modal", "dialog", "popup", "tooltip", "badge",
        "label", "input", "output", "form", "field",
        "option", "radio", "checkbox", "textarea", "dropdown",
        "table", "thead", "tbody", "cell", "link", "anchor",
        "image", "video", "audio", "canvas",
        "color", "font", "text", "title", "subtitle", "heading",
        "page", "view", "screen", "scene", "stage",
        "width", "height", "margin", "padding", "border",
        "radius", "shadow", "opacity", "display", "position",
        "overflow", "scroll", "drag", "drop", "resize",
        "hover", "focus", "active", "disabled", "selected",
        "visible", "hidden", "collapsed", "expanded",
        "theme", "dark", "light",

        // ── Test / mock noise ───────────────────────────────────────────
        "mock", "stub", "fake", "spec",
        "describe", "context", "given", "when", "then",
        "arrange", "helper",

        // ── Generic utility words ───────────────────────────────────────
        "util", "utils", "tools", "common",
        "base", "core", "shared", "global", "local",
        "internal", "external", "custom", "extra",
        "tool", "generic",

        // ── Generic nouns / data structures ────────────────────────────
        "item", "items", "list", "array",
        "dict", "hash", "queue", "stack", "heap",
        "tree", "node", "edge", "graph", "path", "route",
        "value", "pair", "entry", "record",
        "index", "offset", "cursor", "pointer",
        "name", "string", "number", "integer",
        "object", "entity", "model", "schema", "config",
        "params", "args", "options", "settings",
        "state", "status", "result", "error", "success",
        "message", "event", "action", "command", "signal",
        "callback", "listener", "observer",
        "factory", "provider", "service", "manager",
        "controller", "adapter", "bridge", "proxy",
        "scope", "session", "token", "payload",
        "body", "content", "meta", "info",
        "client", "server", "host",
        "endpoint", "method",
        "cookie", "param",
        "user", "admin", "role", "permission", "group",
        "file", "folder",
        "time", "date", "timestamp", "duration", "interval",
        "month", "year", "hour", "minute", "second",
        "info", "warn", "debug", "trace",
        "type", "kind", "mode", "flag", "code",
        "iter", "each", "into", "from",

        // ── Extra generic domain terms ───────────────────────────────────
        "consumer", "decorator", "handler",
        "product", "category", "order", "account", "profile",
        "setting", "preference", "property",
        "todo", "task", "note", "comment",
        "window", "home", "about", "landing", "dashboard",
        "detail", "details", "overview", "summary", "report",
        "feature", "reducer", "generate", "change", "random",
        "prepare", "marshal", "unmarshal",

        // ── Extended UI components (React/Vue/Svelte/Angular) ────────────
        "accordion", "alert", "avatar", "breadcrumb", "calendar",
        "carousel", "chart", "chip", "collapse", "combobox",
        "datepicker", "divider", "drawer", "editor", "gallery",
        "hero", "indicator", "link", "listbox", "loader", "loading",
        "menubar", "navbar", "navigation", "notification",
        "pagination", "picker", "placeholder", "popover", "portal",
        "progress", "progressbar", "rating", "row", "scrollbar",
        "section", "skeleton", "slider", "snackbar", "spinner",
        "stepper", "tab", "tabs", "tag", "timeline", "toast",
        "toolbar", "treeview", "upload", "wizard",

        // ── Layout / size / state tokens ─────────────────────────────────
        "primary", "secondary", "tertiary", "danger", "warning",
        "small", "medium", "large", "mini", "tiny",
        "full", "half", "inline", "block", "wrap",
        "sheet", "bottom", "center", "middle",
        "animated", "animation", "transition",
        "resizable", "draggable", "sortable",
        "collapsible", "expandable", "scrollable", "clickable", "focusable",

        // ── Test / example artefacts ─────────────────────────────────────
        "example", "sample", "demo", "tutorial", "template",
        "snippet", "benchmark", "fixture", "dummy",

        // ── Domain action verbs (≥5 chars) ───────────────────────────────
        "display", "paint", "submit", "cancel", "confirm",
        "approve", "reject", "accept", "decline", "reload",
        "paste", "rotate", "deselect", "highlight", "press",
        "release", "swipe", "pinch", "unfold", "shrink",
        "reveal", "conceal", "enter", "leave", "arrive",
        "visit", "browse", "login", "logout", "signin",
        "signup", "download", "forward", "reply", "unlike",
        "follow", "unfollow", "unstar", "unpin", "archive",
        "unarchive", "unmute", "unblock", "report", "unmark",
        "assign", "unassign", "claim", "unlock", "scroll",

        // ── Domain entity nouns (≥5 chars) ───────────────────────────────
        "member", "owner", "author", "editor", "customer",
        "vendor", "supplier", "partner", "people", "organization",
        "company", "goods", "stock", "inventory", "catalog",
        "basket", "checkout", "payment", "invoice", "ticket",
        "thread", "discussion", "forum", "document", "photo",
        "website", "application", "platform", "console",
        "gateway", "activity", "audit", "address", "location",
        "country", "region", "period", "range", "schedule",
        "price", "amount", "total", "subtotal", "discount",
        "ratio", "percent", "score", "access", "policy",

        // ── Test / placeholder identifiers (≥5 chars) ────────────────────
        "hello", "world", "lorem", "ipsum", "myapp",
        "boilerplate", "samplemodel", "sampleclass",

        // ── Descriptive adjectives (≥5 chars) ────────────────────────────
        "recent", "latest", "inactive", "enabled", "required",
        "optional", "upper", "lower", "front", "partial",
        "complete", "incomplete", "public", "private",
        "flexible", "rigid", "fluid", "advanced", "standard",
        "special", "distinct", "separate", "combined",
        "single", "multiple", "plain", "responsive", "adaptive",
        "themed", "styled", "colored",

        // ── Directions / geometry (≥5 chars) ─────────────────────────────
        "north", "south", "horizontal", "vertical", "diagonal",
        "circular", "linear", "above", "below", "between", "within",

        // ── Composite UI / test names that slip through ───────────────────
        "bottomsheet", "actionsheet", "datatable", "listview",
        "gridview", "cardview", "formfield", "formfieldcontextvalue",
        "inputfield", "textfield", "searchbar", "beforeeach",
        "aftereach",
    ];

    STOPWORDS.contains(&prefix)
}

// ─── Cluster Detection ──────────────────────────────────────────────────────

/// Detect emergent clusters from unclassified resonites.
///
/// Groups by prefix, filters stopwords, computes status.
/// Returns clusters sorted: Ready first, then by count descending.
pub fn detect_emergent_clusters(unclassified: &[UnclassifiedResonite]) -> Vec<EmergentCluster> {
    let mut prefix_groups: HashMap<String, Vec<&UnclassifiedResonite>> = HashMap::new();

    for ur in unclassified {
        prefix_groups
            .entry(ur.prefix.clone())
            .or_default()
            .push(ur);
    }

    let mut clusters = Vec::new();

    for (prefix, resonites) in &prefix_groups {
        if prefix.len() < EMERGENT_MIN_PREFIX_LEN {
            continue;
        }
        if is_stopword(prefix) {
            continue;
        }

        let repos: BTreeSet<String> = resonites.iter().map(|r| r.repo.clone()).collect();
        let domains: BTreeSet<String> = resonites.iter().map(|r| r.domain.clone()).collect();
        let languages: BTreeSet<String> = resonites.iter().map(|r| r.language.clone()).collect();
        let names: Vec<String> = resonites
            .iter()
            .map(|r| r.name.clone())
            .collect::<BTreeSet<_>>()
            .into_iter()
            .collect();

        let status = if resonites.len() >= EMERGENT_MIN_OBSERVATIONS && domains.len() >= EMERGENT_MIN_DOMAINS {
            ClusterStatus::Ready
        } else {
            ClusterStatus::Observing
        };

        clusters.push(EmergentCluster {
            prefix: prefix.clone(),
            function_names: names,
            repos,
            domains,
            languages,
            count: resonites.len(),
            suggested_name: suggest_class_name(prefix),
            status,
        });
    }

    // Sort: Ready first, then by count descending
    clusters.sort_by(|a, b| {
        match (&a.status, &b.status) {
            (ClusterStatus::Ready, ClusterStatus::Observing) => std::cmp::Ordering::Less,
            (ClusterStatus::Observing, ClusterStatus::Ready) => std::cmp::Ordering::Greater,
            _ => b.count.cmp(&a.count),
        }
    });

    clusters
}

/// Suggest a class name for a prefix.
///
/// Known prefixes map to domain-specific names; unknown prefixes are capitalized.
pub fn suggest_class_name(prefix: &str) -> String {
    match prefix {
        "parse" | "lex" | "tokenize" => "ParserCompiler".into(),
        "render" | "draw" | "paint" => "Rendering".into(),
        "encrypt" | "decrypt" | "sign" | "hash" => "Cryptography".into(),
        "compress" | "decompress" | "deflate" | "inflate" => "Compression".into(),
        "match" | "matchmake" => "Matchmaking".into(),
        "spawn" | "fork" | "exec" => "ProcessManagement".into(),
        "alloc" | "dealloc" | "free" => "MemoryManagement".into(),
        "send" | "recv" | "transmit" => "NetworkIO".into(),
        "read" | "write" | "seek" => "FileIO".into(),
        "lock" | "unlock" | "acquire" => "Concurrency".into(),
        "transform" | "map" | "reduce" | "fold" => "DataTransformation".into(),
        "index" | "reindex" | "deindex" => "Indexing".into(),
        "diff" | "patch" | "merge" => "DiffMerge".into(),
        "bench" | "profile" | "measure" => "Benchmarking".into(),
        _ => {
            let mut chars = prefix.chars();
            match chars.next() {
                None => "Unknown".into(),
                Some(c) => {
                    let upper: String = c.to_uppercase().collect();
                    format!("{}{}", upper, chars.as_str())
                }
            }
        }
    }
}

// ─── Persistence ────────────────────────────────────────────────────────────

fn isls_home() -> Option<PathBuf> {
    std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .ok()
        .map(|h| PathBuf::from(h).join(".isls"))
}

fn unclassified_path() -> Option<PathBuf> {
    isls_home().map(|d| d.join("unclassified.jsonl"))
}

fn emergent_classes_path() -> Option<PathBuf> {
    isls_home().map(|d| d.join("emergent_classes.json"))
}

/// Append an unclassified resonite to `~/.isls/unclassified.jsonl`.
pub fn append_unclassified(ur: &UnclassifiedResonite) -> Result<(), std::io::Error> {
    let path = match unclassified_path() {
        Some(p) => p,
        None => return Ok(()),
    };
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let mut file = OpenOptions::new()
        .create(true)
        .append(true)
        .open(&path)?;
    let json = serde_json::to_string(ur).map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))?;
    writeln!(file, "{}", json)?;
    Ok(())
}

/// Load all unclassified resonites from `~/.isls/unclassified.jsonl`.
pub fn load_unclassified() -> Vec<UnclassifiedResonite> {
    let path = match unclassified_path() {
        Some(p) => p,
        None => return Vec::new(),
    };
    load_unclassified_from(&path)
}

/// Load unclassified resonites from a custom path (for testing).
pub fn load_unclassified_from(path: &std::path::Path) -> Vec<UnclassifiedResonite> {
    if !path.exists() {
        return Vec::new();
    }
    let file = match fs::File::open(path) {
        Ok(f) => f,
        Err(_) => return Vec::new(),
    };
    let reader = BufReader::new(file);
    let mut result = Vec::new();
    for line in reader.lines() {
        if let Ok(line) = line {
            if let Ok(ur) = serde_json::from_str::<UnclassifiedResonite>(&line) {
                result.push(ur);
            }
        }
    }
    result
}

/// Load the **most recent** `max_entries` unclassified resonites from disk.
///
/// Uses a streaming sliding-window (VecDeque) so only `max_entries` entries
/// are ever held in RAM simultaneously — the rest are discarded as they scroll
/// out of the window.  Peak RAM ≈ `max_entries × ~200 B` regardless of file
/// size.
pub fn load_recent_unclassified(max_entries: usize) -> Vec<UnclassifiedResonite> {
    let path = match unclassified_path() {
        Some(p) => p,
        None => return Vec::new(),
    };
    if !path.exists() {
        return Vec::new();
    }
    let file = match fs::File::open(&path) {
        Ok(f) => f,
        Err(_) => return Vec::new(),
    };
    let reader = BufReader::new(file);
    let mut window: VecDeque<UnclassifiedResonite> = VecDeque::with_capacity(max_entries + 1);
    for line in reader.lines() {
        if let Ok(line) = line {
            if let Ok(ur) = serde_json::from_str::<UnclassifiedResonite>(&line) {
                if window.len() >= max_entries {
                    window.pop_front(); // evict oldest
                }
                window.push_back(ur);
            }
        }
    }
    window.into_iter().collect()
}

/// Compact `unclassified.jsonl` if it has grown beyond 100 MB.
///
/// Keeps only the most recent 50 000 entries (≈ 10 MB).  Writes atomically
/// via a temp file renamed into place.  No-op when the file is small.
pub fn compact_unclassified_if_needed() {
    let path = match unclassified_path() {
        Some(p) => p,
        None => return,
    };
    if !path.exists() {
        return;
    }

    const COMPACT_THRESHOLD_BYTES: u64 = 100_000_000; // 100 MB
    const COMPACT_KEEP_ENTRIES: usize   = 50_000;

    let size = match fs::metadata(&path) {
        Ok(m) => m.len(),
        Err(_) => return,
    };
    if size < COMPACT_THRESHOLD_BYTES {
        return;
    }

    eprintln!(
        "[Emergent] unclassified.jsonl is {} MB — compacting to last {} entries",
        size / 1_000_000,
        COMPACT_KEEP_ENTRIES,
    );

    // load_recent_unclassified already streams with a sliding window — cheap
    let kept = load_recent_unclassified(COMPACT_KEEP_ENTRIES);
    let kept: Vec<UnclassifiedResonite> = kept
        .into_iter()
        .filter(|e| e.prefix.len() >= EMERGENT_MIN_PREFIX_LEN && !is_stopword(&e.prefix))
        .collect();

    let tmp = path.with_extension("jsonl.compact");
    match fs::File::create(&tmp) {
        Ok(mut f) => {
            for entry in &kept {
                if let Ok(json) = serde_json::to_string(entry) {
                    let _ = writeln!(f, "{}", json);
                }
            }
            if let Err(e) = fs::rename(&tmp, &path) {
                eprintln!("[Emergent] compact_unclassified_if_needed rename failed: {}", e);
            } else {
                eprintln!(
                    "[Emergent] Compacted unclassified.jsonl → {} entries ({} MB freed)",
                    kept.len(),
                    size / 1_000_000,
                );
            }
        }
        Err(e) => {
            eprintln!("[Emergent] compact_unclassified_if_needed create tmp failed: {}", e);
        }
    }
}

/// Save the emergent class registry to `~/.isls/emergent_classes.json`.
pub fn save_emergent_registry(registry: &EmergentClassRegistry) -> Result<(), std::io::Error> {
    let path = match emergent_classes_path() {
        Some(p) => p,
        None => return Ok(()),
    };
    if let Some(parent) = path.parent() {
        fs::create_dir_all(parent)?;
    }
    let json = serde_json::to_string_pretty(registry)
        .map_err(|e| std::io::Error::new(std::io::ErrorKind::Other, e))?;
    fs::write(&path, json)?;
    Ok(())
}

/// Load the emergent class registry from `~/.isls/emergent_classes.json`.
///
/// On the **first call per process**, runs a full purge of all previously
/// accumulated garbage emergent classes (one-time migration).  Subsequent
/// calls only apply the incremental stopword/length purge.
pub fn load_emergent_registry() -> EmergentClassRegistry {
    // One-time hard reset: wipe garbage accumulated before stricter thresholds.
    EMERGENT_FULL_PURGE_DONE.get_or_init(|| {
        purge_all_emergent();
    });

    let path = match emergent_classes_path() {
        Some(p) => p,
        None => return EmergentClassRegistry::default(),
    };
    let mut registry = load_emergent_registry_from(&path);
    if purge_garbage_emergent_classes(&mut registry) {
        // Persist the cleaned registry so the garbage is gone for good.
        let _ = save_emergent_registry(&registry);
    }
    registry
}

/// Remove all emergent class entries whose prefix is a stopword or too short.
///
/// Also deletes the corresponding SEM norm files from `~/.isls/norms/`.
/// Returns `true` if anything was removed (caller should re-persist).
pub fn purge_garbage_emergent_classes(registry: &mut EmergentClassRegistry) -> bool {
    let before = registry.classes.len();

    // Collect prefixes of entries that will be removed so we can delete their norm files.
    let garbage_prefixes: Vec<String> = registry
        .classes
        .iter()
        .filter(|e| e.prefix.len() < EMERGENT_MIN_PREFIX_LEN || is_stopword(&e.prefix))
        .map(|e| e.prefix.clone())
        .collect();

    registry.classes.retain(|entry| {
        entry.prefix.len() >= EMERGENT_MIN_PREFIX_LEN && !is_stopword(&entry.prefix)
    });
    registry.prefix_rules.retain(|prefix, _| {
        prefix.len() >= EMERGENT_MIN_PREFIX_LEN && !is_stopword(prefix)
    });

    let removed = before - registry.classes.len();
    if removed > 0 {
        // Delete the norm file for each purged class (best-effort).
        if let Some(norms_dir) = crate::storage::norms_dir() {
            for prefix in &garbage_prefixes {
                let class_name = suggest_class_name(prefix);
                let norm_id = format!("ISLS-NORM-AUTO-SEM-{}", class_name);
                let safe_id =
                    norm_id.replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], "_");
                let norm_path = norms_dir.join(format!("{}.json", safe_id));
                if norm_path.exists() {
                    match fs::remove_file(&norm_path) {
                        Ok(()) => eprintln!(
                            "[Emergent] Deleted garbage norm file: {}",
                            norm_id
                        ),
                        Err(e) => eprintln!(
                            "[Emergent] Failed to delete norm file {}: {:?}",
                            norm_id, e
                        ),
                    }
                }
            }
        }
        registry.last_updated = chrono::Local::now()
            .format("%Y-%m-%dT%H:%M:%S")
            .to_string();
        eprintln!(
            "[Emergent] Purged {} garbage classes ({} remain)",
            removed,
            registry.classes.len()
        );
    }
    removed > 0
}

/// Compact `~/.isls/unclassified.jsonl` by removing entries whose prefix
/// is now a stopword. Writes atomically via a temp file.
pub fn compact_unclassified() {
    let path = match unclassified_path() {
        Some(p) => p,
        None => return,
    };
    if !path.exists() {
        return;
    }

    let entries = load_unclassified_from(&path);
    let total = entries.len();

    let filtered: Vec<_> = entries
        .into_iter()
        .filter(|e| e.prefix.len() >= EMERGENT_MIN_PREFIX_LEN && !is_stopword(&e.prefix))
        .collect();

    let removed = total - filtered.len();
    if removed == 0 {
        return;
    }

    let tmp = path.with_extension("jsonl.compact");
    match std::fs::File::create(&tmp) {
        Ok(mut f) => {
            for entry in &filtered {
                if let Ok(json) = serde_json::to_string(entry) {
                    let _ = writeln!(f, "{}", json);
                }
            }
            if let Err(e) = std::fs::rename(&tmp, &path) {
                eprintln!("[Emergent] compact_unclassified rename failed: {}", e);
            } else {
                eprintln!(
                    "[Emergent] Compacted unclassified.jsonl: removed {} garbage entries ({} remain)",
                    removed,
                    filtered.len()
                );
            }
        }
        Err(e) => {
            eprintln!("[Emergent] compact_unclassified create tmp failed: {}", e);
        }
    }
}

/// Load emergent class registry from a custom path (for testing).
pub fn load_emergent_registry_from(path: &std::path::Path) -> EmergentClassRegistry {
    if !path.exists() {
        return EmergentClassRegistry::default();
    }
    match fs::read_to_string(path) {
        Ok(contents) => {
            serde_json::from_str(&contents).unwrap_or_default()
        }
        Err(_) => EmergentClassRegistry::default(),
    }
}

// ─── Auto-Promotion ─────────────────────────────────────────────────────────

/// Auto-promote a Ready cluster to an emergent class.
///
/// Creates a norm, adds a prefix rule, appends a ledger event, and persists
/// the registry. Returns `true` if promotion was performed.
pub fn auto_promote_emergent(
    cluster: &EmergentCluster,
    emergent_registry: &mut EmergentClassRegistry,
    persist: bool,
) -> bool {
    // Enforce max classes limit
    if emergent_registry.classes.len() >= MAX_EMERGENT_CLASSES {
        return false;
    }

    // Stopword guard on the raw prefix
    if is_stopword(&cluster.prefix) {
        return false;
    }
    // Stopword guard on the suggested class name (case-folded)
    if is_stopword(&cluster.suggested_name.to_lowercase()) {
        return false;
    }

    let class_name = &cluster.suggested_name;

    // Don't re-promote if already have this prefix rule
    if emergent_registry.prefix_rules.contains_key(&cluster.prefix) {
        return false;
    }

    let now = chrono::Local::now()
        .format("%Y-%m-%dT%H:%M:%S")
        .to_string();

    // Add to registry
    let examples: Vec<String> = cluster
        .function_names
        .iter()
        .take(10)
        .cloned()
        .collect();

    emergent_registry.classes.push(EmergentClassEntry {
        name: class_name.clone(),
        prefix: cluster.prefix.clone(),
        discovered_at: now.clone(),
        function_examples: examples,
        domain_count: cluster.domains.len(),
        observation_count: cluster.count,
    });

    emergent_registry
        .prefix_rules
        .insert(cluster.prefix.clone(), class_name.clone());
    emergent_registry.last_updated = now.clone();

    // Persist
    if persist {
        let _ = save_emergent_registry(emergent_registry);

        // Ledger event
        let event = crate::ledger::NormEvent::EmergentClassDiscovered {
            timestamp: now,
            prefix: cluster.prefix.clone(),
            class_name: class_name.clone(),
            function_count: cluster.function_names.len(),
            domain_count: cluster.domains.len(),
            repo_count: cluster.repos.len(),
        };
        let _ = crate::mef_chain::append_chained_event(&event);
    }

    true
}

// ─── Known Semantic Classes ─────────────────────────────────────────────────

/// Returns `true` for all 139 hardcoded `ResoniteClass` names that the
/// spectroscopy engine recognises natively.  All other SEM-* norm files are
/// from emergent promotion and may be garbage.
fn is_known_semantic_class(name: &str) -> bool {
    matches!(
        name,
        // Original 35
        "Authentication"        | "Authorization"        | "Caching"             |
        "CircuitBreaker"        | "CliInterface"         | "Configuration"       |
        "ConnectionPool"        | "CrudEntity"           | "DataVisualization"   |
        "Docker"                | "EventBus"             | "ExportImport"        |
        "FileUpload"            | "GraphQLApi"           | "GrpcService"         |
        "HealthCheck"           | "IndicatorPipeline"    | "Logging"             |
        "MessageQueue"          | "Metrics"              | "Migration"           |
        "Notification"          | "OrderExecution"       | "Pagination"          |
        "PluginSystem"          | "RateLimiting"         | "RealtimeWebSocket"   |
        "RetryPattern"          | "RiskManagement"       | "Scheduling"          |
        "Search"                | "SignalProcessing"     | "StateMachine"        |
        "Testing"               | "Workflow"             |
        // Networking
        "DnsResolution"         | "HttpClient"           | "TlsSsl"              |
        "SshProtocol"           | "EmailProtocol"        | "WebRtc"              |
        "P2PNetworking"         |
        // Database
        "Orm"                   | "Transaction"          | "Replication"         |
        "Sharding"              | "KeyValueStore"        | "TimeSeriesDb"        |
        "ObjectStorage"         |
        // Serialization
        "Protobuf"              | "MessagePack"          | "YamlProcessing"      |
        "TomlProcessing"        | "CsvProcessing"        | "XmlProcessing"       |
        // Security
        "Hashing"               | "Encryption"           | "DigitalSignature"    |
        "KeyManagement"         | "CertificateManagement"|
        // Auth/Identity
        "OAuth"                 | "OpenIDConnect"        | "MultiFactor"         |
        "SessionManagement"     | "ApiKeyAuth"           |
        // API Design
        "RestApi"               | "Webhook"              | "ServerSentEvents"    |
        "OpenApiSpec"           | "ApiGateway"           | "SdkGeneration"       |
        // Frontend
        "FrontendRouter"        | "StateManagement"      | "FormHandling"        |
        "Internationalization"  | "Theming"              | "ResponsiveDesign"    |
        // Testing (specific)
        "UnitTesting"           | "IntegrationTesting"   | "E2ETesting"          |
        "MockServer"            | "PropertyTesting"      | "Benchmarking"        |
        // Observability
        "DistributedTracing"    | "StructuredLogging"    | "Alerting"            |
        "DashboardBuilder"      |
        // Security Compliance
        "CorsPolicy"            | "CsrfProtection"       | "InputSanitization"   |
        "AuditTrail"            | "AccessControl"        |
        // Data Pipeline
        "EtlPipeline"           | "StreamProcessing"     | "DataValidation"      |
        "PdfGeneration"         | "MarkdownProcessing"   | "TemplateEngine"      |
        "WebScraping"           |
        // AI/ML
        "ModelServing"          | "FeatureEngineering"   | "EmbeddingGeneration" |
        "VectorDatabase"        |
        // DevOps
        "CiCdPipeline"          | "Containerization"     | "Kubernetes"          |
        "InfrastructureAsCode"  | "ServiceDiscovery"     | "LoadBalancing"       |
        "FeatureFlags"          |
        // Language/Compiler
        "Lexer"                 | "Parser"               | "AstProcessing"       |
        "TypeChecker"           | "CodeGeneration"       | "LanguageServer"      |
        "Repl"                  |
        // Game/Simulation
        "EntityComponentSystem" | "PhysicsEngine"        | "GameLoop"            |
        "AudioEngine"           | "InputHandling"        | "SceneGraph"          |
        // Embedded/IoT
        "GpioControl"           | "HardwareProtocol"     | "SensorReading"       |
        "FirmwareManagement"    | "MqttProtocol"         | "DeviceTelemetry"     |
        // Blockchain
        "SmartContract"         | "CryptoWallet"         | "ConsensusProtocol"   |
        "TokenStandard"         |
        // Architecture Patterns
        "SagaPattern"           | "CqrsPattern"          | "EventSourcing"       |
        "PubSubPattern"         | "MiddlewarePattern"    | "DependencyInjection"
    )
}

/// One-time guard: runs `purge_all_emergent` exactly once per process.
static EMERGENT_FULL_PURGE_DONE: OnceLock<()> = OnceLock::new();

/// Hard-reset the emergent registry: clear all entries and move every
/// SEM norm file that is NOT a known hardcoded semantic class to
/// `~/.isls/norms_purged/`.
///
/// This is a one-time migration that removes the ~192 garbage classes
/// that accumulated before the stricter thresholds were in place.
pub fn purge_all_emergent() {
    // 1. Empty the registry file.
    if let Some(path) = emergent_classes_path() {
        let empty = EmergentClassRegistry::default();
        if let Ok(json) = serde_json::to_string_pretty(&empty) {
            if let Err(e) = fs::write(&path, json) {
                eprintln!("[Emergent] purge_all_emergent: failed to reset registry: {:?}", e);
            } else {
                eprintln!("[Emergent] purge_all_emergent: registry reset to empty");
            }
        }
    }

    // 2. Move non-known SEM norm files to norms_purged/.
    let norms_dir = match crate::storage::norms_dir() {
        Some(d) => d,
        None => return,
    };
    if !norms_dir.exists() {
        return;
    }
    let purge_dir = match norms_dir.parent() {
        Some(p) => p.join("norms_purged"),
        None => return,
    };
    let _ = fs::create_dir_all(&purge_dir);

    let entries = match fs::read_dir(&norms_dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    let mut moved = 0usize;
    for entry in entries.flatten() {
        let name = entry.file_name().to_string_lossy().into_owned();
        if !name.starts_with("ISLS-NORM-AUTO-SEM-") || !name.ends_with(".json") {
            continue;
        }
        // Extract the class name from the file name.
        let class_name = name
            .trim_start_matches("ISLS-NORM-AUTO-SEM-")
            .trim_end_matches(".json");
        if is_known_semantic_class(class_name) {
            continue; // keep hardcoded SEM norms
        }
        // Move garbage emergent norm file.
        let dest = purge_dir.join(&name);
        match fs::rename(entry.path(), &dest) {
            Ok(()) => {
                eprintln!("[Emergent] purge_all_emergent: moved garbage norm: {}", name);
                moved += 1;
            }
            Err(e) => {
                eprintln!(
                    "[Emergent] purge_all_emergent: failed to move {}: {:?}",
                    name, e
                );
            }
        }
    }
    if moved > 0 {
        eprintln!(
            "[Emergent] purge_all_emergent: moved {} garbage emergent norm files",
            moved
        );
    }
}

/// Run the full emergent discovery cycle: load unclassified → detect → promote.
///
/// Only reads the most recent 50 000 unclassified entries to bound RAM usage.
/// Returns the number of newly promoted clusters.
pub fn run_emergent_cycle(emergent_registry: &mut EmergentClassRegistry, persist: bool) -> usize {
    let unclassified = load_recent_unclassified(50_000);
    if unclassified.is_empty() {
        return 0;
    }

    let clusters = detect_emergent_clusters(&unclassified);
    let ready: Vec<&EmergentCluster> = clusters
        .iter()
        .filter(|c| c.status == ClusterStatus::Ready)
        .collect();

    let mut promoted = 0;
    for cluster in ready {
        if auto_promote_emergent(cluster, emergent_registry, persist) {
            promoted += 1;
        }
    }

    promoted
}

/// Get a summary of emergent clusters for display.
///
/// Uses at most 50 000 recent unclassified entries to bound RAM usage.
pub fn emergent_summary(emergent_registry: &EmergentClassRegistry) -> EmergentSummary {
    let unclassified = load_recent_unclassified(50_000);
    let clusters = detect_emergent_clusters(&unclassified);

    let promoted: Vec<EmergentCluster> = clusters
        .iter()
        .filter(|c| emergent_registry.prefix_rules.contains_key(&c.prefix))
        .cloned()
        .map(|mut c| {
            c.status = ClusterStatus::Promoted;
            c
        })
        .collect();

    let ready: Vec<EmergentCluster> = clusters
        .iter()
        .filter(|c| c.status == ClusterStatus::Ready && !emergent_registry.prefix_rules.contains_key(&c.prefix))
        .cloned()
        .collect();

    let observing: Vec<EmergentCluster> = clusters
        .iter()
        .filter(|c| c.status == ClusterStatus::Observing && !emergent_registry.prefix_rules.contains_key(&c.prefix))
        .cloned()
        .collect();

    EmergentSummary {
        promoted,
        ready,
        observing,
        total_unclassified: unclassified.len(),
        total_emergent_classes: emergent_registry.classes.len(),
    }
}

/// Summary of the emergent classification state.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct EmergentSummary {
    pub promoted: Vec<EmergentCluster>,
    pub ready: Vec<EmergentCluster>,
    pub observing: Vec<EmergentCluster>,
    pub total_unclassified: usize,
    pub total_emergent_classes: usize,
}

// ─── Tests ──────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_extract_prefix_snake_case() {
        assert_eq!(extract_prefix("parse_expression"), "parse");
        assert_eq!(extract_prefix("render_frame"), "render");
        assert_eq!(extract_prefix("encrypt_data"), "encrypt");
    }

    #[test]
    fn test_extract_prefix_camel_case() {
        assert_eq!(extract_prefix("ParseExpression"), "parse");
        assert_eq!(extract_prefix("RenderFrame"), "render");
        assert_eq!(extract_prefix("EncryptData"), "encrypt");
    }

    #[test]
    fn test_extract_prefix_too_short() {
        assert_eq!(extract_prefix("do_thing"), "");
        assert_eq!(extract_prefix("go"), "");
        assert_eq!(extract_prefix("ab_cd"), "");
    }

    #[test]
    fn test_is_stopword() {
        // ── Definitely stopwords ──────────────────────────────────────────────
        assert!(is_stopword("get"));
        assert!(is_stopword("set"));
        assert!(is_stopword("new"));
        assert!(is_stopword("create"));
        assert!(is_stopword("default"));
        // Too short → stopword
        assert!(is_stopword("on"));   // len 2
        assert!(is_stopword("of"));   // len 2
        assert!(is_stopword("not"));  // len 3
        // UI noise
        assert!(is_stopword("btn"));
        assert!(is_stopword("icon"));
        assert!(is_stopword("props"));
        // Newly added generic verbs
        assert!(is_stopword("parse"));
        assert!(is_stopword("render"));
        assert!(is_stopword("handle"));
        assert!(is_stopword("process"));
        assert!(is_stopword("mock"));
        // ── NOT stopwords (specific domain capability prefixes) ───────────────
        assert!(!is_stopword("encrypt"));
        assert!(!is_stopword("compress"));
        assert!(!is_stopword("harpoon"));
        assert!(!is_stopword("spectral"));
    }

    #[test]
    fn test_suggest_class_name_known() {
        assert_eq!(suggest_class_name("parse"), "ParserCompiler");
        assert_eq!(suggest_class_name("render"), "Rendering");
        assert_eq!(suggest_class_name("encrypt"), "Cryptography");
        assert_eq!(suggest_class_name("compress"), "Compression");
        assert_eq!(suggest_class_name("index"), "Indexing");
    }

    #[test]
    fn test_suggest_class_name_unknown() {
        assert_eq!(suggest_class_name("flurb"), "Flurb");
        assert_eq!(suggest_class_name("zigzag"), "Zigzag");
    }

    #[test]
    fn test_detect_clusters_basic() {
        let now = "2026-04-06T12:00:00".to_string();
        let mut unclassified = Vec::new();

        // 55 resonites with prefix "encrypt" across 16 domains → should be Ready
        // (satisfies EMERGENT_MIN_OBSERVATIONS=50 and EMERGENT_MIN_DOMAINS=15)
        for i in 0..55 {
            unclassified.push(UnclassifiedResonite {
                name: format!("encrypt_item_{}", i),
                prefix: "encrypt".into(),
                repo: format!("repo-{}", i % 16),
                domain: format!("domain-{}", i % 16),
                language: "rust".into(),
                timestamp: now.clone(),
            });
        }

        // 3 resonites with prefix "flurb" across 1 domain → Observing
        for i in 0..3 {
            unclassified.push(UnclassifiedResonite {
                name: format!("flurb_thing_{}", i),
                prefix: "flurb".into(),
                repo: format!("repo-{}", i),
                domain: "single-domain".into(),
                language: "rust".into(),
                timestamp: now.clone(),
            });
        }

        let clusters = detect_emergent_clusters(&unclassified);
        assert_eq!(clusters.len(), 2);

        // Ready cluster should be first
        assert_eq!(clusters[0].prefix, "encrypt");
        assert_eq!(clusters[0].status, ClusterStatus::Ready);
        assert_eq!(clusters[0].suggested_name, "Cryptography");

        assert_eq!(clusters[1].prefix, "flurb");
        assert_eq!(clusters[1].status, ClusterStatus::Observing);
    }

    #[test]
    fn test_stopwords_never_cluster() {
        let now = "2026-04-06T12:00:00".to_string();
        let mut unclassified = Vec::new();

        // Even with 10 observations across 5 domains, stopwords should not cluster
        for i in 0..10 {
            unclassified.push(UnclassifiedResonite {
                name: format!("get_item_{}", i),
                prefix: "get".into(),
                repo: format!("repo-{}", i),
                domain: format!("domain-{}", i % 5),
                language: "rust".into(),
                timestamp: now.clone(),
            });
        }

        let clusters = detect_emergent_clusters(&unclassified);
        assert!(clusters.is_empty(), "stopwords should never form clusters");
    }

    #[test]
    fn test_auto_promote() {
        // Use "encrypt" → "Cryptography": neither prefix nor name is a stopword.
        let cluster = EmergentCluster {
            prefix: "encrypt".into(),
            function_names: vec!["encrypt_data".into(), "encrypt_key".into(), "encrypt_msg".into()],
            repos: ["r1", "r2", "r3"].iter().map(|s| s.to_string()).collect(),
            domains: ["d1", "d2", "d3"].iter().map(|s| s.to_string()).collect(),
            languages: ["rust"].iter().map(|s| s.to_string()).collect(),
            count: 55,
            suggested_name: "Cryptography".into(),
            status: ClusterStatus::Ready,
        };

        let mut registry = EmergentClassRegistry::default();
        let result = auto_promote_emergent(&cluster, &mut registry, false);
        assert!(result);
        assert_eq!(registry.classes.len(), 1);
        assert_eq!(registry.classes[0].name, "Cryptography");
        assert_eq!(registry.prefix_rules.get("encrypt"), Some(&"Cryptography".to_string()));

        // Second promote of same prefix should be no-op
        let result2 = auto_promote_emergent(&cluster, &mut registry, false);
        assert!(!result2);
        assert_eq!(registry.classes.len(), 1);
    }

    #[test]
    fn test_to_snake_case() {
        assert_eq!(to_snake_case("parseExpression"), "parse_expression");
        assert_eq!(to_snake_case("ParseExpression"), "parse_expression");
        assert_eq!(to_snake_case("parse_expression"), "parse_expression");
        assert_eq!(to_snake_case("HTMLParser"), "h_t_m_l_parser");
    }

    #[test]
    fn test_max_classes_limit() {
        let mut registry = EmergentClassRegistry::default();
        // Fill up to MAX
        for i in 0..MAX_EMERGENT_CLASSES {
            registry.prefix_rules.insert(format!("prefix{}", i), format!("Class{}", i));
            registry.classes.push(EmergentClassEntry {
                name: format!("Class{}", i),
                prefix: format!("prefix{}", i),
                discovered_at: String::new(),
                function_examples: Vec::new(),
                domain_count: 3,
                observation_count: 5,
            });
        }

        let cluster = EmergentCluster {
            prefix: "overflow".into(),
            function_names: vec!["overflow_test".into()],
            repos: ["r1", "r2", "r3"].iter().map(|s| s.to_string()).collect(),
            domains: ["d1", "d2", "d3"].iter().map(|s| s.to_string()).collect(),
            languages: ["rust"].iter().map(|s| s.to_string()).collect(),
            count: 10,
            suggested_name: "Overflow".into(),
            status: ClusterStatus::Ready,
        };

        let result = auto_promote_emergent(&cluster, &mut registry, false);
        assert!(!result, "should not promote beyond MAX_EMERGENT_CLASSES");
    }
}

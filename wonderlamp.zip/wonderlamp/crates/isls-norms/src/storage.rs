// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Write-once norm file storage.
//!
//! Each auto-discovered norm is stored as an individual JSON file in
//! `~/.isls/norms/{norm-id}.json`.  Norm files are **never deleted**.
//!
//! Two operations are permitted on an individual file:
//!  1. **First creation** – written once with `create_new(true)` semantics on
//!     a temp file that is then atomically renamed into place.
//!  2. **Fitness update** – read-modify-write that touches only
//!     `evidence.usage_count` and `evidence.domains_used`; everything else is
//!     left as-is.  Also uses tmp+rename.
//!
//! No code in this module may call `fs::remove_file` on anything inside the
//! norms directory.

use std::fs;
use std::io::Write;
use std::path::{Path, PathBuf};

use crate::types::Norm;
use crate::Result;

// ─── Paths ────────────────────────────────────────────────────────────────────

fn isls_home() -> Option<PathBuf> {
    std::env::var("HOME")
        .or_else(|_| std::env::var("USERPROFILE"))
        .ok()
        .map(|h| PathBuf::from(h).join(".isls"))
}

pub fn norms_dir() -> Option<PathBuf> {
    isls_home().map(|d| d.join("norms"))
}

fn norm_file_path(norm_id: &str) -> Option<PathBuf> {
    // Sanitise: replace characters that are unsafe in file names
    let safe_id = norm_id.replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], "_");
    norms_dir().map(|d| d.join(format!("{}.json", safe_id)))
}

fn norm_file_path_in(norm_id: &str, dir: &Path) -> PathBuf {
    let safe_id = norm_id.replace(['/', '\\', ':', '*', '?', '"', '<', '>', '|'], "_");
    dir.join(format!("{}.json", safe_id))
}

fn ensure_norms_dir() -> Result<()> {
    if let Some(dir) = norms_dir() {
        fs::create_dir_all(&dir)?;
    }
    Ok(())
}

// ─── Write ────────────────────────────────────────────────────────────────────

/// Write a norm to `~/.isls/norms/{id}.json` via tmp+rename.
///
/// This is the low-level writer used during migration.  For normal promotion
/// prefer [`promote_norm`], which enforces write-once semantics and
/// fitness-only updates on existing files.
pub fn save_norm(norm: &Norm) -> Result<()> {
    let path = match norm_file_path(&norm.id) {
        Some(p) => p,
        None => return Ok(()),
    };
    ensure_norms_dir()?;

    let json = serde_json::to_string_pretty(norm)?;
    let tmp = path.with_extension("json.tmp");
    fs::write(&tmp, &json)?;
    fs::rename(&tmp, &path)?;
    Ok(())
}

/// Returns true if the write-once norm file for the given ID already exists.
pub fn norm_file_exists(norm_id: &str) -> bool {
    norm_file_path(norm_id).map(|p| p.exists()).unwrap_or(false)
}

/// Create a new norm file or update fitness fields only on an existing one.
///
/// - **File absent**: writes the full norm, using a tmp file renamed into
///   place so there is never a partial file visible.
/// - **File present**: reads the existing norm, updates only
///   `evidence.usage_count` and `evidence.domains_used` if the new values
///   are larger/richer, then writes back via tmp+rename.
///
/// This function will **never** delete a norm file.
pub fn promote_norm(norm: Norm) -> Result<()> {
    let path = match norm_file_path(&norm.id) {
        Some(p) => p,
        None => return Ok(()),
    };
    eprintln!("[NORM STORAGE] promote_norm {} -> {:?}", norm.id, path);
    ensure_norms_dir()?;

    if !path.exists() {
        // First creation: write to a tmp file then rename atomically.
        let json = serde_json::to_string_pretty(&norm)?;
        let tmp = path.with_extension("json.tmp");
        {
            // create_new on the tmp ensures we don't collide with a concurrent writer
            let mut f = fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&tmp)?;
            f.write_all(json.as_bytes())?;
            f.sync_all()?;
        }
        fs::rename(&tmp, &path)?;
    } else {
        // Fitness update only — never overwrite the full norm definition.
        let existing_json = fs::read_to_string(&path)?;
        let mut existing: Norm = match serde_json::from_str(&existing_json) {
            Ok(n) => n,
            Err(e) => {
                eprintln!("[NORM STORAGE] Corrupt file {:?}, replacing: {}", path, e);
                // Re-write from the incoming norm rather than losing it
                let json = serde_json::to_string_pretty(&norm)?;
                let tmp = path.with_extension("json.tmp");
                fs::write(&tmp, &json)?;
                fs::rename(&tmp, &path)?;
                return Ok(());
            }
        };
        // Only advance counters, never regress them
        if norm.evidence.usage_count > existing.evidence.usage_count {
            existing.evidence.usage_count = norm.evidence.usage_count;
        }
        for domain in &norm.evidence.domains_used {
            if !existing.evidence.domains_used.contains(domain) {
                existing.evidence.domains_used.push(domain.clone());
            }
        }
        let json = serde_json::to_string_pretty(&existing)?;
        let tmp = path.with_extension("json.tmp");
        fs::write(&tmp, &json)?;
        fs::rename(&tmp, &path)?;
    }

    Ok(())
}

// ─── Read ─────────────────────────────────────────────────────────────────────

/// Load all norm files from `~/.isls/norms/*.json`.
///
/// Silently skips corrupt or unreadable files.  Returns an empty `Vec` if the
/// directory does not exist yet.
pub fn load_all_norms() -> Result<Vec<Norm>> {
    let dir = match norms_dir() {
        Some(d) => d,
        None => return Ok(vec![]),
    };
    if !dir.exists() {
        return Ok(vec![]);
    }

    let mut norms = Vec::new();
    for entry in fs::read_dir(&dir)? {
        let entry = match entry {
            Ok(e) => e,
            Err(_) => continue,
        };
        let path = entry.path();
        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
        // Skip non-JSON and leftover tmp files
        if ext != "json" {
            continue;
        }
        if path.to_string_lossy().ends_with(".json.tmp") {
            continue;
        }
        match fs::read_to_string(&path) {
            Ok(content) => match serde_json::from_str::<Norm>(&content) {
                Ok(norm) => norms.push(norm),
                Err(e) => eprintln!(
                    "[NORM STORAGE] Skipping corrupt file {:?}: {}",
                    path, e
                ),
            },
            Err(e) => eprintln!("[NORM STORAGE] Cannot read {:?}: {}", path, e),
        }
    }
    Ok(norms)
}

// ─── Migration ────────────────────────────────────────────────────────────────

/// One-time migration: load every norm from the ledger and write it as an
/// individual file in `~/.isls/norms/`.
///
/// **No-op** when `~/.isls/norms/` already contains at least one `.json` file.
/// Safe to call on every startup.
pub fn migrate_norms_to_directory() -> Result<()> {
    let dir = match norms_dir() {
        Some(d) => d,
        None => return Ok(()),
    };
    ensure_norms_dir()?;

    // Skip if directory already has norm files
    if let Ok(entries) = fs::read_dir(&dir) {
        let has_norms = entries
            .filter_map(|e| e.ok())
            .any(|e| {
                let p = e.path();
                p.extension().and_then(|x| x.to_str()) == Some("json")
                    && !p.to_string_lossy().ends_with(".json.tmp")
            });
        if has_norms {
            return Ok(());
        }
    }

    // Load norms from ledger (existing system)
    let state = crate::ledger::load_persisted()?;
    let mut count = 0usize;
    for norm in state.norms.values() {
        match save_norm(norm) {
            Ok(()) => count += 1,
            Err(e) => eprintln!(
                "[NORM STORAGE] Migration: failed to save {}: {}",
                norm.id, e
            ),
        }
    }
    if count > 0 {
        eprintln!(
            "[NORM STORAGE] Migration: wrote {} norms to ~/.isls/norms/",
            count
        );
    }
    Ok(())
}

// ─── Backup ───────────────────────────────────────────────────────────────────

/// Create a timestamped backup of `~/.isls/norms/` and keep only the last
/// `keep` backups (default: 5).
///
/// Backups are directories named `norms_backup_YYYYMMDD_HHMMSS` inside
/// `~/.isls/`.  Only `.json` files are copied.  If the norms directory is
/// empty or does not exist, the function is a no-op.
pub fn backup_norms_dir() -> Result<()> {
    let norms = match norms_dir() {
        Some(d) => d,
        None => return Ok(()),
    };
    if !norms.exists() {
        return Ok(());
    }
    let home = match isls_home() {
        Some(h) => h,
        None => return Ok(()),
    };

    let ts = chrono::Local::now()
        .format("%Y%m%d_%H%M%S")
        .to_string();
    let backup_dir = home.join(format!("norms_backup_{}", ts));

    fs::create_dir_all(&backup_dir)?;
    let mut copied = 0usize;
    if let Ok(entries) = fs::read_dir(&norms) {
        for entry in entries.filter_map(|e| e.ok()) {
            let src = entry.path();
            if src.extension().and_then(|e| e.to_str()) == Some("json")
                && !src.to_string_lossy().ends_with(".json.tmp")
            {
                let dst = backup_dir.join(entry.file_name());
                let _ = fs::copy(&src, &dst);
                copied += 1;
            }
        }
    }

    if copied == 0 {
        let _ = fs::remove_dir(&backup_dir); // nothing was backed up — clean up
        return Ok(());
    }
    eprintln!(
        "[NORM STORAGE] Backup: {} files → {:?}",
        copied, backup_dir
    );

    prune_old_backups(&home, 5)?;
    Ok(())
}

fn prune_old_backups(home: &Path, keep: usize) -> Result<()> {
    let mut backups: Vec<PathBuf> = fs::read_dir(home)?
        .filter_map(|e| e.ok())
        .map(|e| e.path())
        .filter(|p| {
            p.is_dir()
                && p.file_name()
                    .and_then(|n| n.to_str())
                    .map(|n| n.starts_with("norms_backup_"))
                    .unwrap_or(false)
        })
        .collect();

    if backups.len() <= keep {
        return Ok(());
    }

    backups.sort(); // lexicographic == chronological for YYYYMMDD_HHMMSS names
    let to_remove = backups.len() - keep;
    for path in backups.into_iter().take(to_remove) {
        let _ = fs::remove_dir_all(&path);
        eprintln!("[NORM STORAGE] Pruned old backup: {:?}", path);
    }
    Ok(())
}

// ─── Path-based helpers (used internally and in tests) ────────────────────────

/// Save a norm to an explicit norms directory (bypasses $HOME lookup).
fn save_norm_to_dir(norm: &Norm, dir: &Path) -> Result<()> {
    fs::create_dir_all(dir)?;
    let path = norm_file_path_in(&norm.id, dir);
    let json = serde_json::to_string_pretty(norm)?;
    let tmp = path.with_extension("json.tmp");
    fs::write(&tmp, &json)?;
    fs::rename(&tmp, &path)?;
    Ok(())
}

/// Promote a norm within an explicit norms directory.
fn promote_norm_to_dir(norm: Norm, dir: &Path) -> Result<()> {
    fs::create_dir_all(dir)?;
    let path = norm_file_path_in(&norm.id, dir);

    if !path.exists() {
        let json = serde_json::to_string_pretty(&norm)?;
        let tmp = path.with_extension("json.tmp");
        {
            let mut f = fs::OpenOptions::new()
                .write(true)
                .create_new(true)
                .open(&tmp)?;
            f.write_all(json.as_bytes())?;
            f.sync_all()?;
        }
        fs::rename(&tmp, &path)?;
    } else {
        let existing_json = fs::read_to_string(&path)?;
        let mut existing: Norm = match serde_json::from_str(&existing_json) {
            Ok(n) => n,
            Err(_) => {
                let json = serde_json::to_string_pretty(&norm)?;
                let tmp = path.with_extension("json.tmp");
                fs::write(&tmp, &json)?;
                fs::rename(&tmp, &path)?;
                return Ok(());
            }
        };
        if norm.evidence.usage_count > existing.evidence.usage_count {
            existing.evidence.usage_count = norm.evidence.usage_count;
        }
        for domain in &norm.evidence.domains_used {
            if !existing.evidence.domains_used.contains(domain) {
                existing.evidence.domains_used.push(domain.clone());
            }
        }
        let json = serde_json::to_string_pretty(&existing)?;
        let tmp = path.with_extension("json.tmp");
        fs::write(&tmp, &json)?;
        fs::rename(&tmp, &path)?;
    }
    Ok(())
}

/// Load all norm files from an explicit norms directory.
fn load_all_norms_from_dir(dir: &Path) -> Result<Vec<Norm>> {
    if !dir.exists() {
        return Ok(vec![]);
    }
    let mut norms = Vec::new();
    for entry in fs::read_dir(dir)? {
        let entry = match entry {
            Ok(e) => e,
            Err(_) => continue,
        };
        let path = entry.path();
        let ext = path.extension().and_then(|e| e.to_str()).unwrap_or("");
        if ext != "json" || path.to_string_lossy().ends_with(".json.tmp") {
            continue;
        }
        match fs::read_to_string(&path) {
            Ok(content) => match serde_json::from_str::<Norm>(&content) {
                Ok(norm) => norms.push(norm),
                Err(e) => eprintln!("[NORM STORAGE] Skipping corrupt {:?}: {}", path, e),
            },
            Err(e) => eprintln!("[NORM STORAGE] Cannot read {:?}: {}", path, e),
        }
    }
    Ok(norms)
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use crate::types::{NormEvidence, NormLevel, NormLayers};

    fn tmp_norms_dir() -> PathBuf {
        let dir = std::env::temp_dir()
            .join("isls-storage-test")
            .join(format!(
                "{}-{}",
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            ))
            .join("norms");
        fs::create_dir_all(&dir).unwrap();
        dir
    }

    fn make_norm(id: &str, name: &str) -> Norm {
        Norm {
            id: id.into(),
            name: name.into(),
            level: NormLevel::Molecule,
            triggers: vec![],
            layers: NormLayers::default(),
            parameters: vec![],
            requires: vec![],
            variants: vec![],
            version: "1.0.0".into(),
            evidence: NormEvidence {
                usage_count: 0,
                domains_used: vec![],
                builtin: false,
                signature: "test-sig".into(),
            },
            semantic_class: None,
            consensus_resonites: vec![],
        }
    }

    #[test]
    fn test_save_and_load_single_norm() {
        let dir = tmp_norms_dir();
        let norm = make_norm("ISLS-NORM-AUTO-0001", "Test Norm");
        save_norm_to_dir(&norm, &dir).unwrap();

        let loaded = load_all_norms_from_dir(&dir).unwrap();
        assert_eq!(loaded.len(), 1);
        assert_eq!(loaded[0].id, "ISLS-NORM-AUTO-0001");
    }

    #[test]
    fn test_promote_norm_creates_file() {
        let dir = tmp_norms_dir();
        let norm = make_norm("ISLS-NORM-AUTO-0002", "Promote Me");
        promote_norm_to_dir(norm, &dir).unwrap();

        let loaded = load_all_norms_from_dir(&dir).unwrap();
        assert_eq!(loaded.len(), 1);
    }

    #[test]
    fn test_promote_norm_fitness_update_only() {
        let dir = tmp_norms_dir();

        let mut norm = make_norm("ISLS-NORM-AUTO-0003", "Fitness Test");
        norm.evidence.usage_count = 2;
        norm.evidence.domains_used = vec!["warehouse".into()];
        promote_norm_to_dir(norm.clone(), &dir).unwrap();

        // Promote with higher count and extra domain; name change must NOT persist
        norm.evidence.usage_count = 5;
        norm.evidence.domains_used = vec!["warehouse".into(), "ecommerce".into()];
        norm.name = "SHOULD NOT APPEAR".into();
        promote_norm_to_dir(norm, &dir).unwrap();

        let loaded = load_all_norms_from_dir(&dir).unwrap();
        assert_eq!(loaded.len(), 1);
        let n = &loaded[0];
        assert_eq!(n.name, "Fitness Test", "name must not be overwritten");
        assert_eq!(n.evidence.usage_count, 5, "usage_count must advance");
        assert_eq!(n.evidence.domains_used.len(), 2, "domains must merge");
    }

    #[test]
    fn test_promote_norm_does_not_regress_count() {
        let dir = tmp_norms_dir();

        let mut norm = make_norm("ISLS-NORM-AUTO-0004", "Regress Guard");
        norm.evidence.usage_count = 10;
        promote_norm_to_dir(norm.clone(), &dir).unwrap();

        norm.evidence.usage_count = 3; // attempt to regress — must be ignored
        promote_norm_to_dir(norm, &dir).unwrap();

        let loaded = load_all_norms_from_dir(&dir).unwrap();
        assert_eq!(loaded[0].evidence.usage_count, 10);
    }

    #[test]
    fn test_load_skips_corrupt_files() {
        let dir = tmp_norms_dir();

        let norm = make_norm("ISLS-NORM-AUTO-0005", "Good Norm");
        save_norm_to_dir(&norm, &dir).unwrap();

        // Write a corrupt file manually
        fs::write(dir.join("ISLS-NORM-AUTO-9999.json"), "{{not json}}").unwrap();

        let loaded = load_all_norms_from_dir(&dir).unwrap();
        assert_eq!(loaded.len(), 1, "corrupt file must be skipped");
        assert_eq!(loaded[0].id, "ISLS-NORM-AUTO-0005");
    }

    #[test]
    fn test_backup_keeps_last_n() {
        // This test exercises the public backup_norms_dir() which needs HOME.
        // We serialise it with a mutex so it doesn't race other HOME mutations.
        static ENV_LOCK: std::sync::OnceLock<std::sync::Mutex<()>> =
            std::sync::OnceLock::new();
        let _guard = ENV_LOCK
            .get_or_init(|| std::sync::Mutex::new(()))
            .lock()
            .unwrap();

        let base = std::env::temp_dir()
            .join("isls-storage-test-backup")
            .join(format!(
                "{}-{}",
                std::process::id(),
                std::time::SystemTime::now()
                    .duration_since(std::time::UNIX_EPOCH)
                    .unwrap()
                    .as_nanos()
            ));
        let isls_home = base.join(".isls");
        let norms_d = isls_home.join("norms");
        fs::create_dir_all(&norms_d).unwrap();

        // Write some norm files so there is something to back up
        for i in 0..3u32 {
            save_norm_to_dir(
                &make_norm(&format!("ISLS-NORM-AUTO-{:04}", i), "norm"),
                &norms_d,
            )
            .unwrap();
        }

        // Set HOME temporarily (serialised by the mutex above)
        std::env::set_var("HOME", &base);

        for _ in 0..7 {
            backup_norms_dir().unwrap();
            std::thread::sleep(std::time::Duration::from_millis(15));
        }

        let backup_count = fs::read_dir(&isls_home)
            .unwrap()
            .filter_map(|e| e.ok())
            .filter(|e| {
                e.path()
                    .file_name()
                    .and_then(|n| n.to_str())
                    .map(|n| n.starts_with("norms_backup_"))
                    .unwrap_or(false)
            })
            .count();
        assert!(backup_count <= 5, "got {} backups, expected ≤5", backup_count);
    }
}

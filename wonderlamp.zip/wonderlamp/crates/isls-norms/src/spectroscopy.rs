// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! I3/W1 — Constraint Spectroscopy.
//!
//! Analyse a target system (given as a set of resonites), classify its
//! components into high-level architectural classes, compare them against
//! the available norm registry, and produce a list of gaps together with
//! concrete scrape-keyword suggestions.
//!
//! The module is deliberately keyword-based and deterministic — no LLM,
//! no network, no IO.  Resonites are expressed via a lightweight
//! [`Resonite`] enum local to this module so that `isls-norms` remains
//! a pure data crate with no dependency on `isls-reader` or
//! `isls-forge-llm`.

use std::collections::{BTreeMap, HashMap};

use serde::{Deserialize, Serialize};

use crate::types::Norm;
use crate::NormRegistry;

// ─── Resonite (lightweight) ──────────────────────────────────────────────────

/// Kind of type declaration recognised by the spectroscopy classifier.
#[derive(Debug, Clone, Serialize, Deserialize, Hash, Eq, PartialEq)]
pub enum ResoniteTypeKind {
    Struct,
    Enum,
    Trait,
}

/// A lightweight "atomic observable" used by the spectroscopy module.
///
/// This mirrors `isls_forge_llm::codematrix::Resonite` but keeps the crate
/// boundary clean — the full Codematrix type lives in `isls-forge-llm`
/// while this module only needs name/kind information for classification.
#[derive(Debug, Clone, Serialize, Deserialize, Hash, Eq, PartialEq)]
pub enum Resonite {
    /// A function or method.
    Fn {
        name: String,
        arity: usize,
    },
    /// A struct / enum / trait definition.
    Type {
        name: String,
        kind: ResoniteTypeKind,
    },
    /// An import / use statement.
    Import { path: String },
    /// A layer artefact (e.g. model, query, service …).
    Layer { depth: u8, artifact: String },
    /// A relation (foreign key, contains, uses …).
    Relation {
        source: String,
        target: String,
        kind: String,
    },
}

impl Resonite {
    /// Human-readable label for reports.
    pub fn label(&self) -> String {
        match self {
            Resonite::Fn { name, .. } => format!("fn {}", name),
            Resonite::Type { name, kind } => format!("{:?} {}", kind, name),
            Resonite::Import { path } => format!("use {}", path),
            Resonite::Layer { depth, artifact } => {
                format!("layer{}:{}", depth, artifact)
            }
            Resonite::Relation { source, target, kind } => {
                format!("rel[{}] {}→{}", kind, source, target)
            }
        }
    }
}

// ─── Resonite classification ────────────────────────────────────────────────

/// High-level architectural class of a resonite.
#[derive(Debug, Clone, Serialize, Deserialize, Hash, Eq, PartialEq, Ord, PartialOrd)]
pub enum ResoniteClass {
    CrudEntity,
    Authentication,
    Authorization,
    EventBus,
    MessageQueue,
    ConnectionPool,
    Caching,
    RateLimiting,
    CircuitBreaker,
    RetryPattern,
    Pagination,
    Search,
    FileUpload,
    ExportImport,
    Scheduling,
    Notification,
    Logging,
    Metrics,
    HealthCheck,
    Configuration,
    Migration,
    Testing,
    Docker,
    StateMachine,
    Workflow,
    IndicatorPipeline,
    SignalProcessing,
    RiskManagement,
    OrderExecution,
    DataVisualization,
    RealtimeWebSocket,
    GraphQLApi,
    GrpcService,
    CliInterface,
    PluginSystem,
    // Networking
    DnsResolution,
    HttpClient,
    TlsSsl,
    SshProtocol,
    EmailProtocol,
    WebRtc,
    P2PNetworking,
    // Database
    Orm,
    Transaction,
    Replication,
    Sharding,
    KeyValueStore,
    TimeSeriesDb,
    ObjectStorage,
    // Serialization
    Protobuf,
    MessagePack,
    YamlProcessing,
    TomlProcessing,
    CsvProcessing,
    XmlProcessing,
    // Security
    Hashing,
    Encryption,
    DigitalSignature,
    KeyManagement,
    CertificateManagement,
    // Auth/Identity
    OAuth,
    OpenIDConnect,
    MultiFactor,
    SessionManagement,
    ApiKeyAuth,
    // API Design
    RestApi,
    Webhook,
    ServerSentEvents,
    OpenApiSpec,
    ApiGateway,
    SdkGeneration,
    // Frontend
    FrontendRouter,
    StateManagement,
    FormHandling,
    Internationalization,
    Theming,
    ResponsiveDesign,
    // Testing (specific)
    UnitTesting,
    IntegrationTesting,
    E2ETesting,
    MockServer,
    PropertyTesting,
    Benchmarking,
    // Observability
    DistributedTracing,
    StructuredLogging,
    Alerting,
    DashboardBuilder,
    // Security Compliance
    CorsPolicy,
    CsrfProtection,
    InputSanitization,
    AuditTrail,
    AccessControl,
    // Data Pipeline
    EtlPipeline,
    StreamProcessing,
    DataValidation,
    PdfGeneration,
    MarkdownProcessing,
    TemplateEngine,
    WebScraping,
    // AI/ML
    ModelServing,
    FeatureEngineering,
    EmbeddingGeneration,
    VectorDatabase,
    // DevOps
    CiCdPipeline,
    Containerization,
    Kubernetes,
    InfrastructureAsCode,
    ServiceDiscovery,
    LoadBalancing,
    FeatureFlags,
    // Language/Compiler
    Lexer,
    Parser,
    AstProcessing,
    TypeChecker,
    CodeGeneration,
    LanguageServer,
    Repl,
    // Game/Simulation
    EntityComponentSystem,
    PhysicsEngine,
    GameLoop,
    AudioEngine,
    InputHandling,
    SceneGraph,
    // Embedded/IoT
    GpioControl,
    HardwareProtocol,
    SensorReading,
    FirmwareManagement,
    MqttProtocol,
    DeviceTelemetry,
    // Blockchain
    SmartContract,
    CryptoWallet,
    ConsensusProtocol,
    TokenStandard,
    // Architecture Patterns
    SagaPattern,
    CqrsPattern,
    EventSourcing,
    PubSubPattern,
    MiddlewarePattern,
    DependencyInjection,
    Custom(String),
}

impl ResoniteClass {
    /// Stable short name used in API responses / CLI output.
    pub fn as_str(&self) -> String {
        match self {
            ResoniteClass::Custom(s) => format!("Custom({})", s),
            other => format!("{:?}", other),
        }
    }

    /// Return all 139 known (non-Custom) resonite classes.
    pub fn all_known() -> Vec<ResoniteClass> {
        vec![
            ResoniteClass::CrudEntity,
            ResoniteClass::Authentication,
            ResoniteClass::Authorization,
            ResoniteClass::EventBus,
            ResoniteClass::MessageQueue,
            ResoniteClass::ConnectionPool,
            ResoniteClass::Caching,
            ResoniteClass::RateLimiting,
            ResoniteClass::CircuitBreaker,
            ResoniteClass::RetryPattern,
            ResoniteClass::Pagination,
            ResoniteClass::Search,
            ResoniteClass::FileUpload,
            ResoniteClass::ExportImport,
            ResoniteClass::Scheduling,
            ResoniteClass::Notification,
            ResoniteClass::Logging,
            ResoniteClass::Metrics,
            ResoniteClass::HealthCheck,
            ResoniteClass::Configuration,
            ResoniteClass::Migration,
            ResoniteClass::Testing,
            ResoniteClass::Docker,
            ResoniteClass::StateMachine,
            ResoniteClass::Workflow,
            ResoniteClass::IndicatorPipeline,
            ResoniteClass::SignalProcessing,
            ResoniteClass::RiskManagement,
            ResoniteClass::OrderExecution,
            ResoniteClass::DataVisualization,
            ResoniteClass::RealtimeWebSocket,
            ResoniteClass::GraphQLApi,
            ResoniteClass::GrpcService,
            ResoniteClass::CliInterface,
            ResoniteClass::PluginSystem,
            // Networking
            ResoniteClass::DnsResolution,
            ResoniteClass::HttpClient,
            ResoniteClass::TlsSsl,
            ResoniteClass::SshProtocol,
            ResoniteClass::EmailProtocol,
            ResoniteClass::WebRtc,
            ResoniteClass::P2PNetworking,
            // Database
            ResoniteClass::Orm,
            ResoniteClass::Transaction,
            ResoniteClass::Replication,
            ResoniteClass::Sharding,
            ResoniteClass::KeyValueStore,
            ResoniteClass::TimeSeriesDb,
            ResoniteClass::ObjectStorage,
            // Serialization
            ResoniteClass::Protobuf,
            ResoniteClass::MessagePack,
            ResoniteClass::YamlProcessing,
            ResoniteClass::TomlProcessing,
            ResoniteClass::CsvProcessing,
            ResoniteClass::XmlProcessing,
            // Security
            ResoniteClass::Hashing,
            ResoniteClass::Encryption,
            ResoniteClass::DigitalSignature,
            ResoniteClass::KeyManagement,
            ResoniteClass::CertificateManagement,
            // Auth/Identity
            ResoniteClass::OAuth,
            ResoniteClass::OpenIDConnect,
            ResoniteClass::MultiFactor,
            ResoniteClass::SessionManagement,
            ResoniteClass::ApiKeyAuth,
            // API Design
            ResoniteClass::RestApi,
            ResoniteClass::Webhook,
            ResoniteClass::ServerSentEvents,
            ResoniteClass::OpenApiSpec,
            ResoniteClass::ApiGateway,
            ResoniteClass::SdkGeneration,
            // Frontend
            ResoniteClass::FrontendRouter,
            ResoniteClass::StateManagement,
            ResoniteClass::FormHandling,
            ResoniteClass::Internationalization,
            ResoniteClass::Theming,
            ResoniteClass::ResponsiveDesign,
            // Testing (specific)
            ResoniteClass::UnitTesting,
            ResoniteClass::IntegrationTesting,
            ResoniteClass::E2ETesting,
            ResoniteClass::MockServer,
            ResoniteClass::PropertyTesting,
            ResoniteClass::Benchmarking,
            // Observability
            ResoniteClass::DistributedTracing,
            ResoniteClass::StructuredLogging,
            ResoniteClass::Alerting,
            ResoniteClass::DashboardBuilder,
            // Security Compliance
            ResoniteClass::CorsPolicy,
            ResoniteClass::CsrfProtection,
            ResoniteClass::InputSanitization,
            ResoniteClass::AuditTrail,
            ResoniteClass::AccessControl,
            // Data Pipeline
            ResoniteClass::EtlPipeline,
            ResoniteClass::StreamProcessing,
            ResoniteClass::DataValidation,
            ResoniteClass::PdfGeneration,
            ResoniteClass::MarkdownProcessing,
            ResoniteClass::TemplateEngine,
            ResoniteClass::WebScraping,
            // AI/ML
            ResoniteClass::ModelServing,
            ResoniteClass::FeatureEngineering,
            ResoniteClass::EmbeddingGeneration,
            ResoniteClass::VectorDatabase,
            // DevOps
            ResoniteClass::CiCdPipeline,
            ResoniteClass::Containerization,
            ResoniteClass::Kubernetes,
            ResoniteClass::InfrastructureAsCode,
            ResoniteClass::ServiceDiscovery,
            ResoniteClass::LoadBalancing,
            ResoniteClass::FeatureFlags,
            // Language/Compiler
            ResoniteClass::Lexer,
            ResoniteClass::Parser,
            ResoniteClass::AstProcessing,
            ResoniteClass::TypeChecker,
            ResoniteClass::CodeGeneration,
            ResoniteClass::LanguageServer,
            ResoniteClass::Repl,
            // Game/Simulation
            ResoniteClass::EntityComponentSystem,
            ResoniteClass::PhysicsEngine,
            ResoniteClass::GameLoop,
            ResoniteClass::AudioEngine,
            ResoniteClass::InputHandling,
            ResoniteClass::SceneGraph,
            // Embedded/IoT
            ResoniteClass::GpioControl,
            ResoniteClass::HardwareProtocol,
            ResoniteClass::SensorReading,
            ResoniteClass::FirmwareManagement,
            ResoniteClass::MqttProtocol,
            ResoniteClass::DeviceTelemetry,
            // Blockchain
            ResoniteClass::SmartContract,
            ResoniteClass::CryptoWallet,
            ResoniteClass::ConsensusProtocol,
            ResoniteClass::TokenStandard,
            // Architecture Patterns
            ResoniteClass::SagaPattern,
            ResoniteClass::CqrsPattern,
            ResoniteClass::EventSourcing,
            ResoniteClass::PubSubPattern,
            ResoniteClass::MiddlewarePattern,
            ResoniteClass::DependencyInjection,
        ]
    }
}

/// Classify a single resonite into multiple [`ResoniteClass`]es (I6).
///
/// Unlike [`classify_resonite`], this returns all matching classes for a
/// single resonite, enabling multi-class semantic signatures.
pub fn classify_resonite_v2(r: &Resonite) -> Vec<ResoniteClass> {
    let mut classes = Vec::new();
    match r {
        Resonite::Fn { name, .. } => classify_fn_name_v2(name, &mut classes),
        Resonite::Type { name, .. } => classify_type_name_v2(name, &mut classes),
        Resonite::Import { path } => {
            if let Some(c) = classify_import_path(path) {
                classes.push(c);
            }
        }
        Resonite::Layer { artifact, .. } => {
            if let Some(c) = classify_layer(artifact) {
                classes.push(c);
            }
        }
        Resonite::Relation { .. } => {}
    }
    classes.sort();
    classes.dedup();
    classes
}

/// Classify a single resonite with both hardcoded and emergent prefix rules (I7).
///
/// After the standard v2 classification, checks the resonite name against
/// emergent prefix rules. Returns all matching classes.
pub fn classify_resonite_v2_with_emergent(
    r: &Resonite,
    emergent_rules: &std::collections::HashMap<String, String>,
) -> Vec<ResoniteClass> {
    let mut classes = classify_resonite_v2(r);

    // Apply emergent prefix rules
    let name = match r {
        Resonite::Fn { name, .. } => Some(name.as_str()),
        Resonite::Type { name, .. } => Some(name.as_str()),
        _ => None,
    };

    if let Some(name) = name {
        let prefix = crate::emergent::extract_prefix(&name.to_lowercase());
        if !prefix.is_empty() {
            if let Some(class_name) = emergent_rules.get(&prefix) {
                let emergent_class = ResoniteClass::Custom(class_name.clone());
                if !classes.contains(&emergent_class) {
                    classes.push(emergent_class);
                }
            }
        }
    }

    classes.sort();
    classes.dedup();
    classes
}

/// Classify a single resonite into one of [`ResoniteClass`].
///
/// The classifier is keyword-based and returns `None` for resonites that
/// do not match any known class.
pub fn classify_resonite(r: &Resonite) -> Option<ResoniteClass> {
    match r {
        Resonite::Fn { name, .. } => classify_fn_name(name),
        Resonite::Type { name, .. } => classify_type_name(name),
        Resonite::Import { path } => classify_import_path(path),
        Resonite::Layer { artifact, .. } => classify_layer(artifact),
        Resonite::Relation { .. } => None,
    }
}

fn classify_fn_name(name: &str) -> Option<ResoniteClass> {
    let n = name.to_lowercase();
    // CRUD verbs
    if n.starts_with("get_")
        || n.starts_with("list_")
        || n.starts_with("create_")
        || n.starts_with("update_")
        || n.starts_with("delete_")
    {
        return Some(ResoniteClass::CrudEntity);
    }
    // Auth
    if n.contains("login") || n.contains("logout") || n.contains("token")
        || n.contains("authenticate") || n.starts_with("auth_")
    {
        return Some(ResoniteClass::Authentication);
    }
    if n.contains("permission") || n.contains("authorize") || n.contains("role_check") {
        return Some(ResoniteClass::Authorization);
    }
    // Event / pub-sub
    if n.contains("emit") || n.contains("publish") || n.contains("subscribe")
        || n.contains("dispatch") || n.contains("on_event") || n.contains("handle_event")
    {
        return Some(ResoniteClass::EventBus);
    }
    if n.contains("enqueue") || n.contains("dequeue") || n.contains("job_queue") {
        return Some(ResoniteClass::MessageQueue);
    }
    if n.contains("cache") || n.contains("invalidate") || n.contains("memoize") {
        return Some(ResoniteClass::Caching);
    }
    if n.contains("pool") || n.contains("acquire_conn") || n.contains("release_conn") {
        return Some(ResoniteClass::ConnectionPool);
    }
    if n.contains("rate_limit") || n.contains("throttle") {
        return Some(ResoniteClass::RateLimiting);
    }
    if n.contains("circuit_break") || n.contains("trip_breaker") {
        return Some(ResoniteClass::CircuitBreaker);
    }
    if n.contains("retry") || n.contains("backoff") {
        return Some(ResoniteClass::RetryPattern);
    }
    if n.contains("paginate") || n.contains("page_of") {
        return Some(ResoniteClass::Pagination);
    }
    if n.contains("search") || n.contains("query_fulltext") {
        return Some(ResoniteClass::Search);
    }
    if n.contains("upload") || n.contains("multipart") {
        return Some(ResoniteClass::FileUpload);
    }
    if n.contains("export") || n.contains("import_csv") || n.contains("to_csv") {
        return Some(ResoniteClass::ExportImport);
    }
    if n.contains("schedule") || n.contains("cron") || n.contains("tick_") {
        return Some(ResoniteClass::Scheduling);
    }
    if n.contains("notify") || n.contains("send_email") || n.contains("send_sms") {
        return Some(ResoniteClass::Notification);
    }
    if n.contains("log_") || n.contains("tracing_") {
        return Some(ResoniteClass::Logging);
    }
    if n.contains("metric") || n.contains("prometheus") {
        return Some(ResoniteClass::Metrics);
    }
    if n.contains("health_check") || n == "healthz" || n == "readyz" {
        return Some(ResoniteClass::HealthCheck);
    }
    if n.contains("load_config") || n.contains("read_env") {
        return Some(ResoniteClass::Configuration);
    }
    if n.contains("migrate") {
        return Some(ResoniteClass::Migration);
    }
    if n.starts_with("test_") || n.contains("_test") {
        return Some(ResoniteClass::Testing);
    }
    if n.contains("state_transition") || n.contains("next_state") {
        return Some(ResoniteClass::StateMachine);
    }
    if n.contains("workflow") || n.contains("step_") {
        return Some(ResoniteClass::Workflow);
    }
    if n.contains("indicator") || n.contains("rsi") || n.contains("macd") || n.contains("ema") {
        return Some(ResoniteClass::IndicatorPipeline);
    }
    if n.contains("signal") || n.contains("fft") || n.contains("filter_signal") {
        return Some(ResoniteClass::SignalProcessing);
    }
    if n.contains("risk") || n.contains("kelly") || n.contains("var_") || n.contains("drawdown") {
        return Some(ResoniteClass::RiskManagement);
    }
    if n.contains("execute_order") || n.contains("place_order") || n.contains("cancel_order") {
        return Some(ResoniteClass::OrderExecution);
    }
    if n.contains("chart") || n.contains("plot") || n.contains("render_graph") {
        return Some(ResoniteClass::DataVisualization);
    }
    if n.contains("websocket") || n.contains("ws_") || n.contains("broadcast") {
        return Some(ResoniteClass::RealtimeWebSocket);
    }
    if n.contains("graphql") || n.contains("resolver") {
        return Some(ResoniteClass::GraphQLApi);
    }
    if n.contains("grpc") || n.contains("tonic_") {
        return Some(ResoniteClass::GrpcService);
    }
    if n.contains("cli_") || n.contains("parse_args") {
        return Some(ResoniteClass::CliInterface);
    }
    if n.contains("plugin") || n.contains("register_module") {
        return Some(ResoniteClass::PluginSystem);
    }
    None
}

fn classify_type_name(name: &str) -> Option<ResoniteClass> {
    let n = name.to_lowercase();
    if n.contains("event") && !n.contains("eventual") {
        return Some(ResoniteClass::EventBus);
    }
    if n.contains("handler") {
        return Some(ResoniteClass::EventBus);
    }
    if n.contains("queue") {
        return Some(ResoniteClass::MessageQueue);
    }
    if n.contains("cache") {
        return Some(ResoniteClass::Caching);
    }
    if n.contains("pool") {
        return Some(ResoniteClass::ConnectionPool);
    }
    if n.contains("ratelimit") || n.contains("throttle") {
        return Some(ResoniteClass::RateLimiting);
    }
    if n.contains("circuitbreaker") {
        return Some(ResoniteClass::CircuitBreaker);
    }
    if n.contains("statemachine") || n.contains("fsm") {
        return Some(ResoniteClass::StateMachine);
    }
    if n.contains("workflow") {
        return Some(ResoniteClass::Workflow);
    }
    if n.contains("indicator") {
        return Some(ResoniteClass::IndicatorPipeline);
    }
    if n.contains("signal") {
        return Some(ResoniteClass::SignalProcessing);
    }
    if n.contains("risk") {
        return Some(ResoniteClass::RiskManagement);
    }
    if n.contains("order") {
        return Some(ResoniteClass::OrderExecution);
    }
    if n.contains("chart") {
        return Some(ResoniteClass::DataVisualization);
    }
    if n.contains("websocket") || n.contains("ws") {
        return Some(ResoniteClass::RealtimeWebSocket);
    }
    if n.contains("graphql") {
        return Some(ResoniteClass::GraphQLApi);
    }
    if n.contains("grpc") {
        return Some(ResoniteClass::GrpcService);
    }
    if n.contains("config") {
        return Some(ResoniteClass::Configuration);
    }
    if n.contains("migration") {
        return Some(ResoniteClass::Migration);
    }
    if n.contains("plugin") {
        return Some(ResoniteClass::PluginSystem);
    }
    None
}

// ─── V2 multi-class classifiers (I6) ──────────────────────────────────────

fn classify_fn_name_v2(name: &str, out: &mut Vec<ResoniteClass>) {
    let n = name.to_lowercase();

    // CrudEntity
    if n.starts_with("get_") || n.starts_with("list_") || n.starts_with("create_")
        || n.starts_with("update_") || n.starts_with("delete_") || n.starts_with("find_")
    {
        out.push(ResoniteClass::CrudEntity);
    }
    // Authentication
    if n.contains("auth") || n.contains("login") || n.contains("logout")
        || n.contains("token") || n.contains("jwt") || n.contains("session")
        || n.contains("credential") || n.contains("password")
        || n.contains("verify_token") || n.contains("refresh_token")
    {
        out.push(ResoniteClass::Authentication);
    }
    // EventBus
    if n.contains("emit") || n.contains("subscribe") || n.contains("publish")
        || n.contains("dispatch") || n.contains("on_event") || n.contains("event_handler")
        || n.contains("listener") || n.contains("broadcast")
    {
        out.push(ResoniteClass::EventBus);
    }
    // WebSocket
    if n.contains("websocket") || n.starts_with("ws_") || n.ends_with("_ws")
        || n.contains("socket") || n.contains("realtime")
        || n.contains("on_message") || n.contains("send_message") || n.contains("on_connect")
    {
        out.push(ResoniteClass::RealtimeWebSocket);
    }
    // Caching
    if n.contains("cache") || n.contains("invalidate") || n.contains("memoize")
        || n.contains("ttl") || n.contains("expire") || n.contains("redis")
        || n.contains("from_cache") || n.contains("set_cache")
    {
        out.push(ResoniteClass::Caching);
    }
    // RateLimiting
    if n.contains("rate_limit") || n.contains("throttle") || n.contains("limiter")
        || n.contains("quota") || n.contains("bucket")
    {
        out.push(ResoniteClass::RateLimiting);
    }
    // FileUpload
    if n.contains("upload") || n.contains("multipart") || n.contains("file_save")
        || n.contains("store_file") || n.contains("attachment") || n.contains("download_file")
    {
        out.push(ResoniteClass::FileUpload);
    }
    // Search
    if n.contains("search") || n.contains("full_text") || n.contains("query_text")
        || n.contains("find_by") || n.contains("index_doc")
    {
        out.push(ResoniteClass::Search);
    }
    // Pagination
    if n.contains("paginate") || n.contains("page_size") || n.contains("offset")
        || n.contains("cursor") || n.contains("next_page") || n.contains("per_page")
    {
        out.push(ResoniteClass::Pagination);
    }
    // ConnectionPool
    if n.contains("pool") || n.contains("connection") || n.contains("acquire")
        || n.contains("release") || n.contains("max_connections") || n.contains("idle")
    {
        out.push(ResoniteClass::ConnectionPool);
    }
    // StateMachine
    if n.contains("transition") || n.contains("state_machine") || n.contains("workflow")
        || n.contains("next_state") || n.contains("can_transition")
        || n.contains("on_enter") || n.contains("on_exit") || n.contains("status_change")
    {
        out.push(ResoniteClass::StateMachine);
    }
    // Notification
    if n.contains("notify") || n.contains("send_email") || n.contains("send_sms")
        || n.contains("notification") || n.contains("alert") || n.contains("mailer")
    {
        out.push(ResoniteClass::Notification);
    }
    // Scheduling
    if n.contains("schedule") || n.contains("cron") || n.contains("periodic")
        || n.contains("interval") || n.contains("run_at") || n.contains("enqueue")
    {
        out.push(ResoniteClass::Scheduling);
    }
    // HealthCheck
    if n.contains("health") || n.contains("readiness") || n.contains("liveness")
        || n.contains("ping") || n.contains("status_check")
    {
        out.push(ResoniteClass::HealthCheck);
    }
    // Logging — only when the function name IS log/trace, not a substring
    if n == "log" || n == "trace" || n.starts_with("log_") || n.starts_with("trace_")
        || n.ends_with("_log") || n.ends_with("_trace")
    {
        out.push(ResoniteClass::Logging);
    }
    // Configuration
    if n.contains("config") || n.contains("settings") || n.contains("env_var")
        || n.contains("from_env") || n.contains("load_config") || n.contains("app_config")
    {
        out.push(ResoniteClass::Configuration);
    }
    // Metrics
    if n.contains("metric") || n.contains("counter") || n.contains("histogram")
        || n.contains("gauge") || n.contains("prometheus") || n.contains("measure")
    {
        out.push(ResoniteClass::Metrics);
    }
    // Authorization
    if n.contains("permission") || n.contains("authorize") || n.contains("role_check") {
        out.push(ResoniteClass::Authorization);
    }
    // MessageQueue
    if n.contains("dequeue") || n.contains("job_queue") {
        out.push(ResoniteClass::MessageQueue);
    }
    // CircuitBreaker
    if n.contains("circuit_break") || n.contains("trip_breaker") {
        out.push(ResoniteClass::CircuitBreaker);
    }
    // RetryPattern
    if n.contains("retry") || n.contains("backoff") {
        out.push(ResoniteClass::RetryPattern);
    }
    // ExportImport
    if n.contains("export") || n.contains("import_csv") || n.contains("to_csv") {
        out.push(ResoniteClass::ExportImport);
    }
    // Migration
    if n.contains("migrate") {
        out.push(ResoniteClass::Migration);
    }
    // Testing
    if n.starts_with("test_") || n.contains("_test") {
        out.push(ResoniteClass::Testing);
    }
    // Workflow (only if not already added via StateMachine)
    if (n.contains("workflow") || n.contains("step_")) && !out.contains(&ResoniteClass::StateMachine) {
        out.push(ResoniteClass::Workflow);
    }
    // IndicatorPipeline
    if n.contains("indicator") || n.contains("rsi") || n.contains("macd") || n.contains("ema") {
        out.push(ResoniteClass::IndicatorPipeline);
    }
    // SignalProcessing
    if n.contains("signal") || n.contains("fft") || n.contains("filter_signal") {
        out.push(ResoniteClass::SignalProcessing);
    }
    // RiskManagement
    if n.contains("risk") || n.contains("kelly") || n.contains("var_") || n.contains("drawdown") {
        out.push(ResoniteClass::RiskManagement);
    }
    // OrderExecution
    if n.contains("execute_order") || n.contains("place_order") || n.contains("cancel_order") {
        out.push(ResoniteClass::OrderExecution);
    }
    // DataVisualization
    if n.contains("chart") || n.contains("plot") || n.contains("render_graph") {
        out.push(ResoniteClass::DataVisualization);
    }
    // GraphQLApi
    if n.contains("graphql") || n.contains("resolver") {
        out.push(ResoniteClass::GraphQLApi);
    }
    // GrpcService
    if n.contains("grpc") || n.contains("tonic_") {
        out.push(ResoniteClass::GrpcService);
    }
    // CliInterface
    if n.contains("cli_") || n.contains("parse_args") {
        out.push(ResoniteClass::CliInterface);
    }
    // PluginSystem
    if n.contains("plugin") || n.contains("register_module") {
        out.push(ResoniteClass::PluginSystem);
    }
    // DnsResolution
    if n.contains("dns") || n.contains("resolve_host") || n.contains("lookup_host")
        || n.contains("nslookup")
    {
        out.push(ResoniteClass::DnsResolution);
    }
    // HttpClient
    if n.contains("http_get") || n.contains("http_post") || n.contains("http_put")
        || n.contains("http_delete") || n.contains("fetch_url") || n.contains("http_request")
        || n.contains("http_client") || n.contains("send_request") || n.contains("reqwest")
    {
        out.push(ResoniteClass::HttpClient);
    }
    // TlsSsl
    if n.contains("tls_") || n.contains("ssl_") || n.contains("tls_handshake")
        || n.contains("rustls") || n.contains("native_tls")
    {
        out.push(ResoniteClass::TlsSsl);
    }
    // SshProtocol
    if n.contains("ssh") || n.contains("sftp") || n.contains("scp_") || n.contains("shell_exec") {
        out.push(ResoniteClass::SshProtocol);
    }
    // EmailProtocol
    if n.contains("smtp") || n.contains("imap") || n.contains("pop3")
        || n.contains("mail_") || n.contains("email_") || n.contains("mime_")
    {
        out.push(ResoniteClass::EmailProtocol);
    }
    // WebRtc
    if n.contains("webrtc") || n.contains("sdp_") || n.contains("ice_candidate")
        || n.contains("peer_connection") || n.contains("data_channel")
    {
        out.push(ResoniteClass::WebRtc);
    }
    // P2PNetworking
    if n.contains("p2p_") || n.contains("gossip_") || n.contains("dht_")
        || n.contains("nat_traversal") || n.contains("peer_id")
    {
        out.push(ResoniteClass::P2PNetworking);
    }
    // Orm
    if n.contains("repository") || n.contains("query_builder") || n.contains("find_one")
        || n.contains("find_all") || n.contains("save_entity") || n.contains("orm_")
        || n.contains("diesel_") || n.contains("sqlx_")
    {
        out.push(ResoniteClass::Orm);
    }
    // Transaction
    if n.contains("transaction") || n.contains("begin_tx") || n.contains("commit_tx")
        || n.contains("rollback") || n.contains("savepoint") || n.contains("atomic_")
    {
        out.push(ResoniteClass::Transaction);
    }
    // Replication
    if n.contains("replication") || n.contains("sync_replica") || n.contains("wal_")
        || n.contains("follower") || n.contains("leader_elect")
    {
        out.push(ResoniteClass::Replication);
    }
    // Sharding
    if n.contains("shard") || n.contains("partition_key") || n.contains("hash_slot")
        || n.contains("consistent_hash") || n.contains("routing_key")
    {
        out.push(ResoniteClass::Sharding);
    }
    // KeyValueStore
    if n.contains("kv_") || n.contains("key_value") || n.contains("etcd_")
        || n.contains("consul_") || n.contains("store_key") || n.contains("get_key")
        || n.contains("set_key") || n.contains("del_key")
    {
        out.push(ResoniteClass::KeyValueStore);
    }
    // TimeSeriesDb
    if n.contains("timeseries") || n.contains("time_series") || n.contains("influx")
        || n.contains("datapoint") || n.contains("tsdb")
    {
        out.push(ResoniteClass::TimeSeriesDb);
    }
    // ObjectStorage
    if n.contains("s3_") || n.contains("blob_") || n.contains("object_store")
        || n.contains("bucket_") || n.contains("gcs_") || n.contains("minio_")
        || n.contains("put_object") || n.contains("get_object")
    {
        out.push(ResoniteClass::ObjectStorage);
    }
    // Protobuf
    if n.contains("protobuf") || n.contains("proto_") || n.contains("encode_proto")
        || n.contains("decode_proto") || n.contains("prost_")
    {
        out.push(ResoniteClass::Protobuf);
    }
    // MessagePack
    if n.contains("msgpack") || n.contains("message_pack") || n.contains("rmp_")
        || n.contains("pack_msg") || n.contains("unpack_msg")
    {
        out.push(ResoniteClass::MessagePack);
    }
    // YamlProcessing
    if n.contains("yaml") || n.contains("from_yaml") || n.contains("to_yaml")
        || n.contains("parse_yaml") || n.contains("serde_yaml")
    {
        out.push(ResoniteClass::YamlProcessing);
    }
    // TomlProcessing
    if n.contains("toml") || n.contains("from_toml") || n.contains("to_toml")
        || n.contains("parse_toml") || n.contains("toml_config")
    {
        out.push(ResoniteClass::TomlProcessing);
    }
    // CsvProcessing
    if n.contains("csv_") || n.contains("from_csv") || n.contains("parse_csv")
        || n.contains("csv_reader") || n.contains("csv_writer")
    {
        out.push(ResoniteClass::CsvProcessing);
    }
    // XmlProcessing
    if n.contains("xml") || n.contains("from_xml") || n.contains("to_xml")
        || n.contains("parse_xml") || n.contains("xpath") || n.contains("xslt")
    {
        out.push(ResoniteClass::XmlProcessing);
    }
    // Hashing
    if n.contains("hash_") || n.contains("sha256") || n.contains("sha512")
        || n.contains("bcrypt") || n.contains("argon2") || n.contains("scrypt")
        || n.contains("pbkdf2") || n.contains("hmac")
    {
        out.push(ResoniteClass::Hashing);
    }
    // Encryption
    if n.contains("encrypt") || n.contains("decrypt") || n.contains("aes_")
        || n.contains("chacha") || n.contains("cipher_") || n.contains("iv_gen")
    {
        out.push(ResoniteClass::Encryption);
    }
    // DigitalSignature
    if n.contains("sign_data") || n.contains("verify_sig") || n.contains("ecdsa")
        || n.contains("rsa_sign") || n.contains("ed25519") || n.contains("sign_message")
    {
        out.push(ResoniteClass::DigitalSignature);
    }
    // KeyManagement
    if n.contains("key_gen") || n.contains("rotate_key") || n.contains("key_store")
        || n.contains("secret_") || n.contains("vault_") || n.contains("kms_")
    {
        out.push(ResoniteClass::KeyManagement);
    }
    // CertificateManagement
    if n.contains("cert_") || n.contains("x509") || n.contains("pem_")
        || n.contains("csr_") || n.contains("acme_") || n.contains("lets_encrypt")
    {
        out.push(ResoniteClass::CertificateManagement);
    }
    // OAuth
    if n.contains("oauth") || n.contains("access_token") || n.contains("authorization_code")
        || n.contains("pkce_")
    {
        out.push(ResoniteClass::OAuth);
    }
    // OpenIDConnect
    if n.contains("oidc") || n.contains("openid") || n.contains("id_token")
        || n.contains("userinfo") || n.contains("jwks")
    {
        out.push(ResoniteClass::OpenIDConnect);
    }
    // MultiFactor
    if n.contains("mfa") || n.contains("totp") || n.contains("otp_")
        || n.contains("two_factor") || n.contains("2fa") || n.contains("authenticator_code")
    {
        out.push(ResoniteClass::MultiFactor);
    }
    // SessionManagement
    if n.contains("session_") || n.contains("create_session") || n.contains("destroy_session")
        || n.contains("session_store") || n.contains("cookie_") || n.contains("session_id")
    {
        out.push(ResoniteClass::SessionManagement);
    }
    // ApiKeyAuth
    if n.contains("api_key") || n.contains("apikey") || n.contains("bearer_token")
        || n.contains("validate_key") || n.contains("key_auth")
    {
        out.push(ResoniteClass::ApiKeyAuth);
    }
    // RestApi
    if n.contains("rest_") || n.contains("api_route") || n.contains("http_handler")
        || n.contains("api_endpoint") || n.contains("route_handler")
    {
        out.push(ResoniteClass::RestApi);
    }
    // Webhook
    if n.contains("webhook") || n.contains("event_hook") || n.contains("callback_url")
        || n.contains("trigger_hook") || n.contains("verify_webhook")
    {
        out.push(ResoniteClass::Webhook);
    }
    // ServerSentEvents
    if n.contains("sse_") || n.contains("server_sent") || n.contains("event_stream")
        || n.contains("stream_event") || n.contains("text_event_stream")
    {
        out.push(ResoniteClass::ServerSentEvents);
    }
    // OpenApiSpec
    if n.contains("openapi") || n.contains("swagger") || n.contains("api_spec")
        || n.contains("generate_spec") || n.contains("oas_")
    {
        out.push(ResoniteClass::OpenApiSpec);
    }
    // ApiGateway
    if n.contains("gateway") || n.contains("proxy_request") || n.contains("upstream_")
        || n.contains("api_gateway") || n.contains("reverse_proxy")
    {
        out.push(ResoniteClass::ApiGateway);
    }
    // SdkGeneration
    if n.contains("codegen") || n.contains("generate_client") || n.contains("sdk_")
        || n.contains("client_gen") || n.contains("generate_sdk")
    {
        out.push(ResoniteClass::SdkGeneration);
    }
    // FrontendRouter
    if n.contains("navigate_to") || n.contains("route_to") || n.contains("push_route")
        || n.contains("history_push") || n.contains("use_route") || n.contains("router_push")
    {
        out.push(ResoniteClass::FrontendRouter);
    }
    // StateManagement
    if n.contains("dispatch_action") || n.contains("reduce_state") || n.contains("use_state")
        || n.contains("store_state") || n.contains("get_store") || n.contains("action_creator")
    {
        out.push(ResoniteClass::StateManagement);
    }
    // FormHandling
    if n.contains("validate_form") || n.contains("submit_form") || n.contains("field_error")
        || n.contains("form_data") || n.contains("use_form") || n.contains("form_submit")
    {
        out.push(ResoniteClass::FormHandling);
    }
    // Internationalization
    if n.contains("i18n") || n.contains("l10n") || n.contains("translate")
        || n.contains("locale_") || n.contains("format_date") || n.contains("pluralize")
    {
        out.push(ResoniteClass::Internationalization);
    }
    // Theming
    if n.contains("theme_") || n.contains("dark_mode") || n.contains("style_var")
        || n.contains("css_var") || n.contains("design_token") || n.contains("color_scheme")
    {
        out.push(ResoniteClass::Theming);
    }
    // ResponsiveDesign
    if n.contains("breakpoint") || n.contains("media_query") || n.contains("viewport")
        || n.contains("responsive_") || n.contains("mobile_layout")
    {
        out.push(ResoniteClass::ResponsiveDesign);
    }
    // UnitTesting — already covered by Testing but add specific variant
    if n.starts_with("test_") || n.contains("assert_eq") || n.contains("assert_ne")
        || n.contains("should_") || n.contains("expect_eq")
    {
        out.push(ResoniteClass::UnitTesting);
    }
    // IntegrationTesting
    if n.contains("integration_test") || n.contains("test_integration")
        || n.contains("test_with_db") || n.contains("test_with_server") || n.contains("test_app")
    {
        out.push(ResoniteClass::IntegrationTesting);
    }
    // E2ETesting
    if n.contains("e2e_") || n.contains("end_to_end") || n.contains("browser_test")
        || n.contains("playwright") || n.contains("selenium_") || n.contains("cypress")
    {
        out.push(ResoniteClass::E2ETesting);
    }
    // MockServer
    if n.contains("mock_server") || n.contains("stub_server") || n.contains("wiremock")
        || n.contains("mock_handler") || n.contains("test_double")
    {
        out.push(ResoniteClass::MockServer);
    }
    // PropertyTesting
    if n.contains("proptest") || n.contains("quickcheck") || n.contains("arbitrary_")
        || n.contains("fuzz_") || n.contains("property_test")
    {
        out.push(ResoniteClass::PropertyTesting);
    }
    // Benchmarking
    if n.contains("bench_") || n.contains("benchmark") || n.contains("criterion_")
        || n.contains("perf_test") || n.contains("throughput_test")
    {
        out.push(ResoniteClass::Benchmarking);
    }
    // DistributedTracing
    if n.contains("trace_span") || n.contains("start_span") || n.contains("opentelemetry")
        || n.contains("jaeger") || n.contains("zipkin") || n.contains("otel_")
        || n.contains("baggage_")
    {
        out.push(ResoniteClass::DistributedTracing);
    }
    // StructuredLogging
    if n.contains("structured_log") || n.contains("json_log") || n.contains("log_event")
        || n.contains("log_fields") || n.contains("slog_") || n.contains("bunyan")
    {
        out.push(ResoniteClass::StructuredLogging);
    }
    // Alerting
    if n.contains("alert_") || n.contains("send_alert") || n.contains("pagerduty")
        || n.contains("opsgenie") || n.contains("fire_alert") || n.contains("trigger_alert")
    {
        out.push(ResoniteClass::Alerting);
    }
    // DashboardBuilder
    if n.contains("dashboard") || n.contains("widget_") || n.contains("grafana")
        || n.contains("kibana") || n.contains("build_dashboard") || n.contains("add_panel")
    {
        out.push(ResoniteClass::DashboardBuilder);
    }
    // CorsPolicy
    if n.contains("cors") || n.contains("allow_origin") || n.contains("preflight")
        || n.contains("access_control_allow")
    {
        out.push(ResoniteClass::CorsPolicy);
    }
    // CsrfProtection
    if n.contains("csrf") || n.contains("xsrf") || n.contains("csrf_token")
        || n.contains("double_submit") || n.contains("origin_check")
    {
        out.push(ResoniteClass::CsrfProtection);
    }
    // InputSanitization
    if n.contains("sanitize") || n.contains("sanitise") || n.contains("escape_html")
        || n.contains("strip_tags") || n.contains("xss_") || n.contains("sql_escape")
    {
        out.push(ResoniteClass::InputSanitization);
    }
    // AuditTrail
    if n.contains("audit_") || n.contains("audit_log") || n.contains("change_log")
        || n.contains("history_log") || n.contains("record_event")
    {
        out.push(ResoniteClass::AuditTrail);
    }
    // AccessControl
    if n.contains("acl_") || n.contains("access_control") || n.contains("rbac_")
        || n.contains("abac_") || n.contains("policy_check") || n.contains("can_access")
    {
        out.push(ResoniteClass::AccessControl);
    }
    // EtlPipeline
    if n.contains("etl_") || n.contains("extract_data") || n.contains("transform_data")
        || n.contains("load_data") || n.contains("data_pipeline") || n.contains("ingestion")
    {
        out.push(ResoniteClass::EtlPipeline);
    }
    // StreamProcessing
    if n.contains("kafka_") || n.contains("kinesis_") || n.contains("process_stream")
        || n.contains("window_fn") || n.contains("stream_process")
    {
        out.push(ResoniteClass::StreamProcessing);
    }
    // DataValidation
    if n.contains("validate_input") || n.contains("schema_valid") || n.contains("check_constraint")
        || n.contains("validation_error") || n.contains("validate_schema")
    {
        out.push(ResoniteClass::DataValidation);
    }
    // PdfGeneration
    if n.contains("pdf_") || n.contains("generate_pdf") || n.contains("render_pdf")
        || n.contains("pdf_report") || n.contains("printpdf") || n.contains("wkhtmltopdf")
    {
        out.push(ResoniteClass::PdfGeneration);
    }
    // MarkdownProcessing
    if n.contains("markdown") || n.contains("parse_md") || n.contains("render_md")
        || n.contains("mdx_") || n.contains("pulldown_cmark") || n.contains("commonmark")
    {
        out.push(ResoniteClass::MarkdownProcessing);
    }
    // TemplateEngine
    if n.contains("render_template") || n.contains("template_render") || n.contains("tera_")
        || n.contains("handlebars") || n.contains("mustache") || n.contains("liquid_")
    {
        out.push(ResoniteClass::TemplateEngine);
    }
    // WebScraping
    if n.contains("scrape_") || n.contains("crawl_") || n.contains("html_parse")
        || n.contains("extract_links") || n.contains("spider_") || n.contains("fetch_page")
    {
        out.push(ResoniteClass::WebScraping);
    }
    // ModelServing
    if n.contains("predict") || n.contains("inference") || n.contains("model_serve")
        || n.contains("run_model") || n.contains("onnx_") || n.contains("tflite")
    {
        out.push(ResoniteClass::ModelServing);
    }
    // FeatureEngineering
    if n.contains("extract_features") || n.contains("engineer_features")
        || n.contains("normalize_features") || n.contains("feature_store")
        || n.contains("feature_pipeline")
    {
        out.push(ResoniteClass::FeatureEngineering);
    }
    // EmbeddingGeneration
    if n.contains("embed_") || n.contains("embedding") || n.contains("encode_text")
        || n.contains("sentence_embed") || n.contains("vectorize")
    {
        out.push(ResoniteClass::EmbeddingGeneration);
    }
    // VectorDatabase
    if n.contains("vector_db") || n.contains("similarity_search") || n.contains("ann_search")
        || n.contains("qdrant") || n.contains("pinecone") || n.contains("weaviate")
        || n.contains("chroma_")
    {
        out.push(ResoniteClass::VectorDatabase);
    }
    // CiCdPipeline
    if n.contains("pipeline_run") || n.contains("build_step") || n.contains("deploy_stage")
        || n.contains("artifact_push") || n.contains("ci_job") || n.contains("cd_deploy")
    {
        out.push(ResoniteClass::CiCdPipeline);
    }
    // Containerization
    if n.contains("docker") || n.contains("container_") || n.contains("image_build")
        || n.contains("dockerfile") || n.contains("build_image") || n.contains("podman")
    {
        out.push(ResoniteClass::Containerization);
    }
    // Kubernetes
    if n.contains("k8s") || n.contains("kubernetes") || n.contains("kubectl")
        || n.contains("pod_") || n.contains("deployment_spec") || n.contains("helm_")
        || n.contains("kube_client")
    {
        out.push(ResoniteClass::Kubernetes);
    }
    // InfrastructureAsCode
    if n.contains("terraform") || n.contains("pulumi") || n.contains("iac_")
        || n.contains("provision_") || n.contains("cdk_") || n.contains("cloudform")
    {
        out.push(ResoniteClass::InfrastructureAsCode);
    }
    // ServiceDiscovery
    if n.contains("discover_service") || n.contains("service_registry")
        || n.contains("eureka_") || n.contains("dns_sd") || n.contains("find_service")
    {
        out.push(ResoniteClass::ServiceDiscovery);
    }
    // LoadBalancing
    if n.contains("load_balance") || n.contains("round_robin") || n.contains("sticky_session")
        || n.contains("least_conn") || n.contains("balancer_")
    {
        out.push(ResoniteClass::LoadBalancing);
    }
    // FeatureFlags
    if n.contains("feature_flag") || n.contains("ff_") || n.contains("flag_enabled")
        || n.contains("toggle_feature") || n.contains("launchdarkly") || n.contains("unleash")
    {
        out.push(ResoniteClass::FeatureFlags);
    }
    // Lexer
    if n.contains("lex_") || n.contains("lexer_") || n.contains("tokenize")
        || n.contains("scan_tokens") || n.contains("next_token")
    {
        out.push(ResoniteClass::Lexer);
    }
    // Parser
    if n.contains("parse_expr") || n.contains("parse_stmt") || n.contains("grammar_")
        || n.contains("peg_") || n.contains("nom_parse") || n.contains("lalr_")
    {
        out.push(ResoniteClass::Parser);
    }
    // AstProcessing
    if n.contains("ast_") || n.contains("syntax_tree") || n.contains("node_visit")
        || n.contains("tree_walk") || n.contains("transform_ast") || n.contains("ast_pass")
    {
        out.push(ResoniteClass::AstProcessing);
    }
    // TypeChecker
    if n.contains("type_check") || n.contains("typecheck") || n.contains("infer_type")
        || n.contains("type_resolve") || n.contains("constraint_solve")
    {
        out.push(ResoniteClass::TypeChecker);
    }
    // CodeGeneration
    if n.contains("codegen_") || n.contains("emit_code") || n.contains("generate_code")
        || n.contains("compile_to") || n.contains("lower_ir") || n.contains("emit_ir")
    {
        out.push(ResoniteClass::CodeGeneration);
    }
    // LanguageServer
    if n.contains("lsp_") || n.contains("language_server") || n.contains("completion_item")
        || n.contains("goto_def") || n.contains("hover_info") || n.contains("diagnostics_push")
    {
        out.push(ResoniteClass::LanguageServer);
    }
    // Repl
    if n.contains("repl_") || n.contains("eval_line") || n.contains("read_eval")
        || n.contains("interactive_shell") || n.contains("run_repl")
    {
        out.push(ResoniteClass::Repl);
    }
    // EntityComponentSystem
    if n.contains("ecs_") || n.contains("world_step") || n.contains("archetype")
        || n.contains("spawn_entity") || n.contains("add_component") || n.contains("run_system")
    {
        out.push(ResoniteClass::EntityComponentSystem);
    }
    // PhysicsEngine
    if n.contains("physics_") || n.contains("collide_") || n.contains("rigid_body")
        || n.contains("simulate_physics") || n.contains("rapier") || n.contains("box2d")
    {
        out.push(ResoniteClass::PhysicsEngine);
    }
    // GameLoop
    if n.contains("game_loop") || n.contains("main_loop") || n.contains("tick_game")
        || n.contains("update_game") || n.contains("fixed_update") || n.contains("render_frame")
    {
        out.push(ResoniteClass::GameLoop);
    }
    // AudioEngine
    if n.contains("audio_") || n.contains("play_sound") || n.contains("sound_effect")
        || n.contains("cpal_") || n.contains("rodio_") || n.contains("audio_buffer")
    {
        out.push(ResoniteClass::AudioEngine);
    }
    // InputHandling
    if n.contains("key_press") || n.contains("mouse_click") || n.contains("gamepad_")
        || n.contains("handle_input") || n.contains("event_poll") || n.contains("input_map")
    {
        out.push(ResoniteClass::InputHandling);
    }
    // SceneGraph
    if n.contains("scene_") || n.contains("scene_graph") || n.contains("transform_node")
        || n.contains("render_scene") || n.contains("scene_tree") || n.contains("add_child")
    {
        out.push(ResoniteClass::SceneGraph);
    }
    // GpioControl
    if n.contains("gpio_") || n.contains("pin_set") || n.contains("pin_read")
        || n.contains("digital_write") || n.contains("digital_read") || n.contains("gpio_init")
    {
        out.push(ResoniteClass::GpioControl);
    }
    // HardwareProtocol
    if n.contains("i2c_") || n.contains("spi_") || n.contains("uart_")
        || n.contains("serial_port") || n.contains("can_bus") || n.contains("usb_hid")
    {
        out.push(ResoniteClass::HardwareProtocol);
    }
    // SensorReading
    if n.contains("sensor_") || n.contains("read_sensor") || n.contains("temperature_")
        || n.contains("humidity_") || n.contains("accelero") || n.contains("gyro_")
    {
        out.push(ResoniteClass::SensorReading);
    }
    // FirmwareManagement
    if n.contains("firmware_") || n.contains("flash_fw") || n.contains("ota_update")
        || n.contains("bootloader") || n.contains("firmware_update") || n.contains("dfu_")
    {
        out.push(ResoniteClass::FirmwareManagement);
    }
    // MqttProtocol
    if n.contains("mqtt_") || n.contains("mqtt_publish") || n.contains("mqtt_subscribe")
        || n.contains("mosquitto") || n.contains("rumqtt")
    {
        out.push(ResoniteClass::MqttProtocol);
    }
    // DeviceTelemetry
    if n.contains("telemetry") || n.contains("device_log") || n.contains("report_metric")
        || n.contains("device_event") || n.contains("send_telemetry")
    {
        out.push(ResoniteClass::DeviceTelemetry);
    }
    // SmartContract
    if n.contains("smart_contract") || n.contains("deploy_contract")
        || n.contains("call_contract") || n.contains("evm_") || n.contains("solidity_")
    {
        out.push(ResoniteClass::SmartContract);
    }
    // CryptoWallet
    if n.contains("wallet_") || n.contains("sign_tx") || n.contains("broadcast_tx")
        || n.contains("private_key") || n.contains("mnemonic") || n.contains("hd_wallet")
    {
        out.push(ResoniteClass::CryptoWallet);
    }
    // ConsensusProtocol
    if n.contains("consensus_") || n.contains("paxos") || n.contains("raft_")
        || n.contains("vote_") || n.contains("pbft") || n.contains("bft_")
    {
        out.push(ResoniteClass::ConsensusProtocol);
    }
    // TokenStandard
    if n.contains("erc20") || n.contains("erc721") || n.contains("erc1155")
        || n.contains("token_transfer") || n.contains("token_balance") || n.contains("nft_")
    {
        out.push(ResoniteClass::TokenStandard);
    }
    // SagaPattern
    if n.contains("saga_") || n.contains("compensate_") || n.contains("saga_step")
        || n.contains("rollback_saga")
    {
        out.push(ResoniteClass::SagaPattern);
    }
    // CqrsPattern
    if n.contains("cqrs_") || n.contains("command_bus") || n.contains("query_bus")
        || n.contains("command_handler") || n.contains("query_handler")
    {
        out.push(ResoniteClass::CqrsPattern);
    }
    // EventSourcing
    if n.contains("event_store") || n.contains("append_event") || n.contains("replay_events")
        || n.contains("event_sourcing") || n.contains("aggregate_rebuild")
    {
        out.push(ResoniteClass::EventSourcing);
    }
    // PubSubPattern
    if n.contains("pubsub") || n.contains("pub_sub") || n.contains("topic_publish")
        || n.contains("topic_subscribe") || n.contains("fan_out")
    {
        out.push(ResoniteClass::PubSubPattern);
    }
    // MiddlewarePattern
    if n.contains("middleware_chain") || n.contains("pipeline_step") || n.contains("intercept")
        || n.contains("next_handler") || n.contains("middleware_fn")
    {
        out.push(ResoniteClass::MiddlewarePattern);
    }
    // DependencyInjection
    if n.contains("inject") || n.contains("container_resolve") || n.contains("bind_service")
        || n.contains("register_service") || n.contains("di_container") || n.contains("provide_dep")
    {
        out.push(ResoniteClass::DependencyInjection);
    }
}

fn classify_type_name_v2(name: &str, out: &mut Vec<ResoniteClass>) {
    let n = name.to_lowercase();

    if n.contains("event") && !n.contains("eventual") {
        out.push(ResoniteClass::EventBus);
    }
    if n.contains("handler") {
        out.push(ResoniteClass::EventBus);
    }
    if n.contains("cache") {
        out.push(ResoniteClass::Caching);
    }
    if n.contains("pool") {
        out.push(ResoniteClass::ConnectionPool);
    }
    if n.contains("websocket") || n.contains("ws") {
        out.push(ResoniteClass::RealtimeWebSocket);
    }
    if n.contains("middleware") {
        // Middleware is often RateLimiting or Auth — add both as potential
        out.push(ResoniteClass::RateLimiting);
    }
    if n.contains("queue") {
        out.push(ResoniteClass::MessageQueue);
    }
    if n.contains("ratelimit") || n.contains("throttle") {
        out.push(ResoniteClass::RateLimiting);
    }
    if n.contains("circuitbreaker") {
        out.push(ResoniteClass::CircuitBreaker);
    }
    if n.contains("statemachine") || n.contains("fsm") {
        out.push(ResoniteClass::StateMachine);
    }
    if n.contains("workflow") {
        out.push(ResoniteClass::Workflow);
    }
    if n.contains("indicator") {
        out.push(ResoniteClass::IndicatorPipeline);
    }
    if n.contains("signal") {
        out.push(ResoniteClass::SignalProcessing);
    }
    if n.contains("risk") {
        out.push(ResoniteClass::RiskManagement);
    }
    if n.contains("order") {
        out.push(ResoniteClass::OrderExecution);
    }
    if n.contains("chart") {
        out.push(ResoniteClass::DataVisualization);
    }
    if n.contains("graphql") {
        out.push(ResoniteClass::GraphQLApi);
    }
    if n.contains("grpc") {
        out.push(ResoniteClass::GrpcService);
    }
    if n.contains("config") {
        out.push(ResoniteClass::Configuration);
    }
    if n.contains("migration") {
        out.push(ResoniteClass::Migration);
    }
    if n.contains("plugin") {
        out.push(ResoniteClass::PluginSystem);
    }
    if n.contains("transaction") || (n.ends_with("tx") && n.len() > 2) {
        out.push(ResoniteClass::Transaction);
    }
    if n.contains("repository") || n.contains("dao") {
        out.push(ResoniteClass::Orm);
    }
    if n.contains("validator") || n.contains("schema") && n.contains("valid") {
        out.push(ResoniteClass::DataValidation);
    }
    if n.contains("router") && !n.contains("grpc") {
        out.push(ResoniteClass::FrontendRouter);
    }
    if n.contains("session") {
        out.push(ResoniteClass::SessionManagement);
    }
    if n.contains("cipher") || n.contains("chacha") || (n.contains("aes") && n.len() < 20) {
        out.push(ResoniteClass::Encryption);
    }
    if n.contains("certificate") || n.contains("x509") {
        out.push(ResoniteClass::CertificateManagement);
    }
    if n.contains("embedding") || n.contains("embedder") {
        out.push(ResoniteClass::EmbeddingGeneration);
    }
    if n.contains("tracer") || (n.contains("span") && n.len() < 20) {
        out.push(ResoniteClass::DistributedTracing);
    }
    if n.contains("container") && !n.contains("event") {
        out.push(ResoniteClass::Containerization);
    }
    if n.contains("kafka") || (n.contains("stream") && n.contains("processor")) {
        out.push(ResoniteClass::StreamProcessing);
    }
    if n.contains("template") || n.contains("renderer") && n.contains("html") {
        out.push(ResoniteClass::TemplateEngine);
    }
    if n.contains("lexer") || n.contains("tokenizer") {
        out.push(ResoniteClass::Lexer);
    }
    if n.contains("parser") || n.contains("grammar") {
        out.push(ResoniteClass::Parser);
    }
    if n.contains("ast") || n.contains("syntaxtree") {
        out.push(ResoniteClass::AstProcessing);
    }
    if n.contains("wallet") {
        out.push(ResoniteClass::CryptoWallet);
    }
    if n.contains("contract") && n.contains("smart") {
        out.push(ResoniteClass::SmartContract);
    }
    if n.contains("saga") {
        out.push(ResoniteClass::SagaPattern);
    }
    if n.contains("eventstore") || n.contains("eventlog") {
        out.push(ResoniteClass::EventSourcing);
    }
    if n.contains("command") && (n.contains("handler") || n.contains("bus")) {
        out.push(ResoniteClass::CqrsPattern);
    }
    if n.contains("mqtt") {
        out.push(ResoniteClass::MqttProtocol);
    }
    if n.contains("featureflag") || n.contains("feature_toggle") {
        out.push(ResoniteClass::FeatureFlags);
    }
    if n.contains("physicsworld") || n.contains("rigidbody") || n.contains("collider") {
        out.push(ResoniteClass::PhysicsEngine);
    }
    if n.contains("scenegraph") || n.contains("scenetree") {
        out.push(ResoniteClass::SceneGraph);
    }
    if n.contains("auditevent") || n.contains("auditlog") {
        out.push(ResoniteClass::AuditTrail);
    }
    if n.contains("middleware") {
        out.push(ResoniteClass::MiddlewarePattern);
    }
}

fn classify_import_path(path: &str) -> Option<ResoniteClass> {
    let p = path.to_lowercase();
    if p.contains("tokio::sync::broadcast") || p.contains("tokio::sync::mpsc") {
        return Some(ResoniteClass::EventBus);
    }
    if p.contains("deadpool") || p.contains("bb8") || p.contains("r2d2") || p.contains("sqlx::pool") {
        return Some(ResoniteClass::ConnectionPool);
    }
    if p.contains("moka") || p.contains("lru") || p.contains("cached") {
        return Some(ResoniteClass::Caching);
    }
    if p.contains("tower::limit") || p.contains("governor") {
        return Some(ResoniteClass::RateLimiting);
    }
    if p.contains("axum::extract::ws") || p.contains("tokio_tungstenite") {
        return Some(ResoniteClass::RealtimeWebSocket);
    }
    if p.contains("async_graphql") || p.contains("juniper") {
        return Some(ResoniteClass::GraphQLApi);
    }
    if p.contains("tonic") || p.contains("prost") {
        return Some(ResoniteClass::GrpcService);
    }
    if p.contains("tracing") {
        return Some(ResoniteClass::Logging);
    }
    if p.contains("prometheus") || p.contains("metrics_exporter") {
        return Some(ResoniteClass::Metrics);
    }
    if p.contains("reqwest_retry") || p.contains("backoff") {
        return Some(ResoniteClass::RetryPattern);
    }
    if p.contains("reqwest") || p.contains("ureq") || p.contains("hyper::client") {
        return Some(ResoniteClass::HttpClient);
    }
    if p.contains("rustls") || p.contains("native_tls") || p.contains("openssl") {
        return Some(ResoniteClass::TlsSsl);
    }
    if p.contains("trust_dns") || p.contains("hickory_dns") || p.contains("async_std::net::to_socket_addrs") {
        return Some(ResoniteClass::DnsResolution);
    }
    if p.contains("ssh2") || p.contains("russh") || p.contains("thrussh") {
        return Some(ResoniteClass::SshProtocol);
    }
    if p.contains("lettre") || p.contains("sendgrid") || p.contains("mailgun") {
        return Some(ResoniteClass::EmailProtocol);
    }
    if p.contains("webrtc") || p.contains("str0m") {
        return Some(ResoniteClass::WebRtc);
    }
    if p.contains("libp2p") {
        return Some(ResoniteClass::P2PNetworking);
    }
    if p.contains("diesel") || p.contains("sea_orm") || p.contains("seaorm") {
        return Some(ResoniteClass::Orm);
    }
    if p.contains("influxdb") || p.contains("timescaledb") || p.contains("questdb") {
        return Some(ResoniteClass::TimeSeriesDb);
    }
    if p.contains("aws_sdk_s3") || p.contains("object_store") || p.contains("opendal") {
        return Some(ResoniteClass::ObjectStorage);
    }
    if p.contains("rmp") || p.contains("msgpack") || p.contains("rmpv") {
        return Some(ResoniteClass::MessagePack);
    }
    if p.contains("serde_yaml") || p.contains("yaml_rust") {
        return Some(ResoniteClass::YamlProcessing);
    }
    if p.contains("::toml") || p.contains("toml::") {
        return Some(ResoniteClass::TomlProcessing);
    }
    if p.contains("::csv") || p.contains("csv::") {
        return Some(ResoniteClass::CsvProcessing);
    }
    if p.contains("quick_xml") || p.contains("xmltree") || p.contains("minidom") {
        return Some(ResoniteClass::XmlProcessing);
    }
    if p.contains("sha2") || p.contains("blake3") || p.contains("argon2") || p.contains("md5") {
        return Some(ResoniteClass::Hashing);
    }
    if p.contains("aes::") || p.contains("chacha20") || p.contains("ring::aead") {
        return Some(ResoniteClass::Encryption);
    }
    if p.contains("ed25519") || p.contains("ring::signature") || p.contains("ecdsa") {
        return Some(ResoniteClass::DigitalSignature);
    }
    if p.contains("aws_sdk_kms") || p.contains("vaultrs") || p.contains("keyring") {
        return Some(ResoniteClass::KeyManagement);
    }
    if p.contains("rcgen") || p.contains("x509_parser") || p.contains("x509_cert") {
        return Some(ResoniteClass::CertificateManagement);
    }
    if p.contains("oauth2") {
        return Some(ResoniteClass::OAuth);
    }
    if p.contains("openidconnect") {
        return Some(ResoniteClass::OpenIDConnect);
    }
    if p.contains("totp_rs") || p.contains("google_authenticator") || p.contains("oath") {
        return Some(ResoniteClass::MultiFactor);
    }
    if p.contains("axum_sessions") || p.contains("tower_sessions") || p.contains("async_session") {
        return Some(ResoniteClass::SessionManagement);
    }
    if p.contains("utoipa") || p.contains("paperclip") || p.contains("okapi") {
        return Some(ResoniteClass::OpenApiSpec);
    }
    if p.contains("rdkafka") || p.contains("rskafka") || p.contains("apache_kafka") {
        return Some(ResoniteClass::StreamProcessing);
    }
    if p.contains("pulldown_cmark") || p.contains("comrak") || p.contains("markdown") {
        return Some(ResoniteClass::MarkdownProcessing);
    }
    if p.contains("tera") || p.contains("minijinja") || p.contains("upon") {
        return Some(ResoniteClass::TemplateEngine);
    }
    if p.contains("qdrant") || p.contains("lancedb") || p.contains("weaviate_client") {
        return Some(ResoniteClass::VectorDatabase);
    }
    if p.contains("opentelemetry") || p.contains("tracing_opentelemetry") {
        return Some(ResoniteClass::DistributedTracing);
    }
    if p.contains("cpal") || p.contains("rodio") || p.contains("kira") {
        return Some(ResoniteClass::AudioEngine);
    }
    if p.contains("rapier") || p.contains("nphysics") || p.contains("bevy_rapier") {
        return Some(ResoniteClass::PhysicsEngine);
    }
    if p.contains("bevy::ecs") || p.contains("hecs") || p.contains("legion") || p.contains("shipyard") {
        return Some(ResoniteClass::EntityComponentSystem);
    }
    if p.contains("rumqtt") || p.contains("paho_mqtt") || p.contains("mqttbytes") {
        return Some(ResoniteClass::MqttProtocol);
    }
    if p.contains("ethers") || p.contains("web3") || p.contains("alloy") {
        return Some(ResoniteClass::SmartContract);
    }
    if p.contains("sqlx::postgres") || p.contains("tokio_postgres") {
        return Some(ResoniteClass::Transaction);
    }
    None
}

fn classify_layer(artifact: &str) -> Option<ResoniteClass> {
    let a = artifact.to_lowercase();
    if a.contains("migration") {
        Some(ResoniteClass::Migration)
    } else if a.contains("test") {
        Some(ResoniteClass::Testing)
    } else if a.contains("config") {
        Some(ResoniteClass::Configuration)
    } else if a.contains("auth") {
        Some(ResoniteClass::Authentication)
    } else {
        None
    }
}

// ─── SpectroscopyResult ─────────────────────────────────────────────────────

/// A missing norm-class in the target system.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct NormGap {
    pub class: ResoniteClass,
    /// Number of resonites in the target that belong to this class.
    pub resonite_count: usize,
    /// Layer depths the resonites were observed on.
    pub layers_affected: Vec<u8>,
    /// Priority score: `resonite_count * (1 + distinct_layers)`.
    pub priority: f64,
}

/// A concrete scrape-keyword recommendation for a gap.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScrapeSuggestion {
    pub gap: String,
    pub keywords: Vec<String>,
    /// Heuristic number of repositories to fetch per keyword.
    pub estimated_repos: usize,
}

/// Result of running [`spectroscopy`] on a target / norm set.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SpectroscopyResult {
    /// Every class detected in the target (deduplicated).
    pub target_spectrum: Vec<ResoniteClass>,
    /// Classes already covered by at least one existing norm.
    pub covered: Vec<ResoniteClass>,
    /// Classes in the target but missing from the norm registry.
    pub gaps: Vec<NormGap>,
    /// Suggested scrape campaigns for each gap.
    pub suggestions: Vec<ScrapeSuggestion>,
    /// `|covered| / |target_spectrum|` — `1.0` when the spectrum is empty.
    pub coverage: f64,
    /// Total number of classified resonites.
    pub classified_resonites: usize,
}

// ─── Analysis ───────────────────────────────────────────────────────────────

/// Analyse a target set of resonites against the norm registry.
///
/// Returns the full [`SpectroscopyResult`] with gaps, coverage and
/// scrape-keyword suggestions.
pub fn spectroscopy(resonites: &[Resonite], registry: &NormRegistry) -> SpectroscopyResult {
    // 1. Count classes in the target.
    let mut counts: HashMap<ResoniteClass, usize> = HashMap::new();
    let mut layers: HashMap<ResoniteClass, Vec<u8>> = HashMap::new();
    let mut classified = 0usize;
    for r in resonites {
        if let Some(class) = classify_resonite(r) {
            classified += 1;
            *counts.entry(class.clone()).or_insert(0) += 1;
            if let Resonite::Layer { depth, .. } = r {
                layers.entry(class).or_default().push(*depth);
            }
        }
    }

    // 2. Determine which classes the norm registry already covers.
    let covered_classes = registry_covered_classes(registry);

    // 3. Build the spectrum (deterministic order).
    let mut target_spectrum: Vec<ResoniteClass> = counts.keys().cloned().collect();
    target_spectrum.sort_by(|a, b| a.as_str().cmp(&b.as_str()));

    let mut covered: Vec<ResoniteClass> = Vec::new();
    let mut gaps: Vec<NormGap> = Vec::new();
    for class in &target_spectrum {
        if covered_classes.contains_key(class) {
            covered.push(class.clone());
        } else {
            let count = *counts.get(class).unwrap_or(&0);
            let mut class_layers: Vec<u8> =
                layers.get(class).cloned().unwrap_or_default();
            class_layers.sort_unstable();
            class_layers.dedup();
            let distinct = class_layers.len() as f64;
            let priority = count as f64 * (1.0 + distinct);
            gaps.push(NormGap {
                class: class.clone(),
                resonite_count: count,
                layers_affected: class_layers,
                priority,
            });
        }
    }
    // Sort gaps by descending priority for nicer reports.
    gaps.sort_by(|a, b| {
        b.priority
            .partial_cmp(&a.priority)
            .unwrap_or(std::cmp::Ordering::Equal)
    });

    // 4. Build suggestions.
    let suggestions: Vec<ScrapeSuggestion> = gaps
        .iter()
        .map(|g| {
            let keywords = suggest_keywords_for_class(&g.class);
            ScrapeSuggestion {
                gap: g.class.as_str(),
                keywords,
                estimated_repos: 5,
            }
        })
        .filter(|s| !s.keywords.is_empty())
        .collect();

    let coverage = if target_spectrum.is_empty() {
        1.0
    } else {
        covered.len() as f64 / target_spectrum.len() as f64
    };

    SpectroscopyResult {
        target_spectrum,
        covered,
        gaps,
        suggestions,
        coverage,
        classified_resonites: classified,
    }
}

/// Return the set of classes that the norm registry already covers.
///
/// A class is considered covered when at least one norm has a trigger
/// keyword that maps to it.
pub fn registry_covered_classes(registry: &NormRegistry) -> BTreeMap<ResoniteClass, String> {
    let mut out: BTreeMap<ResoniteClass, String> = BTreeMap::new();
    for norm in registry.all_norms() {
        for class in norm_covered_classes(norm) {
            out.entry(class).or_insert_with(|| norm.id.clone());
        }
    }
    out
}

fn norm_covered_classes(norm: &Norm) -> Vec<ResoniteClass> {
    let mut haystack = norm.name.to_lowercase();
    haystack.push(' ');
    for t in &norm.triggers {
        for kw in &t.keywords {
            haystack.push_str(&kw.to_lowercase());
            haystack.push(' ');
        }
        for c in &t.concepts {
            haystack.push_str(&c.to_lowercase());
            haystack.push(' ');
        }
    }
    let mut out = Vec::new();
    for (class, needles) in class_keyword_index() {
        if needles.iter().any(|n| haystack.contains(n)) {
            out.push(class);
        }
    }
    out
}

/// Keyword → class map used for both suggestion generation and
/// norm-coverage detection. Each class is associated with ≥1 needle.
fn class_keyword_index() -> Vec<(ResoniteClass, Vec<&'static str>)> {
    vec![
        (ResoniteClass::CrudEntity, vec!["crud", "entity"]),
        (ResoniteClass::Authentication, vec!["auth", "login", "jwt", "token"]),
        (ResoniteClass::Authorization, vec!["authorization", "permission", "role"]),
        (ResoniteClass::EventBus, vec!["event", "pub-sub", "publish", "subscribe", "dispatch"]),
        (ResoniteClass::MessageQueue, vec!["queue", "mq", "broker"]),
        (ResoniteClass::ConnectionPool, vec!["pool", "deadpool", "bb8", "r2d2"]),
        (ResoniteClass::Caching, vec!["cache", "lru", "redis", "memoize"]),
        (ResoniteClass::RateLimiting, vec!["rate limit", "throttle", "governor"]),
        (ResoniteClass::CircuitBreaker, vec!["circuit breaker", "resilience"]),
        (ResoniteClass::RetryPattern, vec!["retry", "backoff"]),
        (ResoniteClass::Pagination, vec!["pagination", "paginate", "offset", "cursor"]),
        (ResoniteClass::Search, vec!["search", "fulltext", "tantivy"]),
        (ResoniteClass::FileUpload, vec!["upload", "multipart"]),
        (ResoniteClass::ExportImport, vec!["export", "csv", "import"]),
        (ResoniteClass::Scheduling, vec!["schedule", "cron"]),
        (ResoniteClass::Notification, vec!["notification", "notify", "email", "sms"]),
        (ResoniteClass::Logging, vec!["logging", "log", "tracing"]),
        (ResoniteClass::Metrics, vec!["metrics", "prometheus"]),
        (ResoniteClass::HealthCheck, vec!["health", "healthz", "readyz"]),
        (ResoniteClass::Configuration, vec!["config", "dotenv"]),
        (ResoniteClass::Migration, vec!["migration", "migrate"]),
        (ResoniteClass::Testing, vec!["test"]),
        (ResoniteClass::Docker, vec!["docker", "container"]),
        (ResoniteClass::StateMachine, vec!["state machine", "fsm"]),
        (ResoniteClass::Workflow, vec!["workflow", "pipeline"]),
        (ResoniteClass::IndicatorPipeline, vec!["indicator", "rsi", "macd", "ema"]),
        (ResoniteClass::SignalProcessing, vec!["signal", "fft", "filter"]),
        (ResoniteClass::RiskManagement, vec!["risk", "kelly", "var", "drawdown"]),
        (ResoniteClass::OrderExecution, vec!["order execution", "place order", "cancel order"]),
        (ResoniteClass::DataVisualization, vec!["chart", "plot", "visualization"]),
        (ResoniteClass::RealtimeWebSocket, vec!["websocket", "realtime", "ws"]),
        (ResoniteClass::GraphQLApi, vec!["graphql"]),
        (ResoniteClass::GrpcService, vec!["grpc", "tonic", "protobuf"]),
        (ResoniteClass::CliInterface, vec!["cli", "clap", "argparse"]),
        (ResoniteClass::PluginSystem, vec!["plugin"]),
    ]
}

// ─── Keyword suggestions ────────────────────────────────────────────────────

/// Generate scrape keywords for a given [`NormGap`].
///
/// Thin wrapper over [`suggest_keywords_for_class`] that preserves the
/// signature from the I3 specification.
pub fn suggest_keywords(gap: &NormGap) -> Vec<String> {
    suggest_keywords_for_class(&gap.class)
}

/// Produce a set of GitHub search keywords suitable for filling the given
/// class gap.
pub fn suggest_keywords_for_class(class: &ResoniteClass) -> Vec<String> {
    let raw: &[&str] = match class {
        ResoniteClass::EventBus => &[
            "rust event bus async",
            "rust event driven architecture",
            "rust publish subscribe pattern",
        ],
        ResoniteClass::MessageQueue => &[
            "rust job queue worker",
            "rust message broker",
        ],
        ResoniteClass::Caching => &[
            "rust cache lru",
            "rust caching redis",
            "rust memoization",
        ],
        ResoniteClass::ConnectionPool => &[
            "rust connection pool database",
            "rust deadpool bb8 r2d2",
        ],
        ResoniteClass::RateLimiting => &[
            "rust rate limit tower",
            "rust rate limiter governor",
        ],
        ResoniteClass::CircuitBreaker => &[
            "rust circuit breaker resilience",
        ],
        ResoniteClass::RetryPattern => &[
            "rust retry backoff",
        ],
        ResoniteClass::Pagination => &[
            "rust pagination cursor offset",
        ],
        ResoniteClass::Search => &[
            "rust fulltext search tantivy",
        ],
        ResoniteClass::FileUpload => &[
            "rust file upload multipart",
        ],
        ResoniteClass::ExportImport => &[
            "rust csv export report",
        ],
        ResoniteClass::Scheduling => &[
            "rust scheduler cron job",
        ],
        ResoniteClass::Notification => &[
            "rust email smtp lettre",
            "rust push notification",
        ],
        ResoniteClass::Logging => &[
            "rust logging tracing structured",
        ],
        ResoniteClass::Metrics => &[
            "rust metrics prometheus export",
        ],
        ResoniteClass::HealthCheck => &[
            "rust health check endpoint",
        ],
        ResoniteClass::Configuration => &[
            "rust config toml dotenv",
        ],
        ResoniteClass::Migration => &[
            "rust sqlx migration",
        ],
        ResoniteClass::Testing => &[
            "rust integration test harness",
        ],
        ResoniteClass::StateMachine => &[
            "rust state machine fsm",
        ],
        ResoniteClass::Workflow => &[
            "rust workflow engine",
        ],
        ResoniteClass::IndicatorPipeline => &[
            "rust technical indicators trading",
            "rust financial analysis ta",
        ],
        ResoniteClass::SignalProcessing => &[
            "rust signal processing fft",
        ],
        ResoniteClass::RiskManagement => &[
            "rust risk management kelly criterion",
            "rust portfolio risk var",
        ],
        ResoniteClass::OrderExecution => &[
            "rust order execution trading",
        ],
        ResoniteClass::DataVisualization => &[
            "rust charting plotters",
        ],
        ResoniteClass::RealtimeWebSocket => &[
            "rust websocket realtime axum",
            "rust tokio tungstenite",
        ],
        ResoniteClass::GraphQLApi => &[
            "rust graphql async-graphql",
        ],
        ResoniteClass::GrpcService => &[
            "rust grpc tonic protobuf",
        ],
        ResoniteClass::CliInterface => &[
            "rust cli clap",
        ],
        ResoniteClass::PluginSystem => &[
            "rust plugin system dynamic",
        ],
        ResoniteClass::Authentication => &[
            "rust authentication jwt",
        ],
        ResoniteClass::Authorization => &[
            "rust authorization rbac",
        ],
        ResoniteClass::CrudEntity => &[
            "rust axum crud entity",
        ],
        ResoniteClass::Docker => &[
            "rust dockerfile multistage",
        ],
        // Networking
        ResoniteClass::DnsResolution => &["rust dns resolution trust-dns hickory"],
        ResoniteClass::HttpClient => &["rust http client reqwest ureq"],
        ResoniteClass::TlsSsl => &["rust tls rustls native-tls openssl"],
        ResoniteClass::SshProtocol => &["rust ssh sftp ssh2 russh"],
        ResoniteClass::EmailProtocol => &["rust smtp email lettre sendgrid"],
        ResoniteClass::WebRtc => &["rust webrtc str0m"],
        ResoniteClass::P2PNetworking => &["rust p2p libp2p gossip dht"],
        // Database
        ResoniteClass::Orm => &["rust orm diesel sea-orm sqlx entity"],
        ResoniteClass::Transaction => &["rust database transaction sqlx rollback"],
        ResoniteClass::Replication => &["rust database replication wal follower"],
        ResoniteClass::Sharding => &["rust sharding partitioning consistent hash"],
        ResoniteClass::KeyValueStore => &["rust key value store etcd redis sled"],
        ResoniteClass::TimeSeriesDb => &["rust time series influxdb questdb tsdb"],
        ResoniteClass::ObjectStorage => &["rust object storage s3 minio opendal"],
        // Serialization
        ResoniteClass::Protobuf => &["rust protobuf prost proto encode decode"],
        ResoniteClass::MessagePack => &["rust messagepack rmp msgpack"],
        ResoniteClass::YamlProcessing => &["rust yaml serde-yaml parsing"],
        ResoniteClass::TomlProcessing => &["rust toml config parsing serde"],
        ResoniteClass::CsvProcessing => &["rust csv parsing reading writing"],
        ResoniteClass::XmlProcessing => &["rust xml quick-xml parsing"],
        // Security
        ResoniteClass::Hashing => &["rust hashing sha2 blake3 argon2 bcrypt"],
        ResoniteClass::Encryption => &["rust encryption aes chacha20 ring"],
        ResoniteClass::DigitalSignature => &["rust digital signature ed25519 ecdsa"],
        ResoniteClass::KeyManagement => &["rust key management vault kms secret"],
        ResoniteClass::CertificateManagement => &["rust tls certificate x509 rcgen acme"],
        // Auth/Identity
        ResoniteClass::OAuth => &["rust oauth2 authorization code pkce"],
        ResoniteClass::OpenIDConnect => &["rust openid connect oidc id-token"],
        ResoniteClass::MultiFactor => &["rust mfa totp 2fa authenticator"],
        ResoniteClass::SessionManagement => &["rust session management cookie store"],
        ResoniteClass::ApiKeyAuth => &["rust api key authentication bearer"],
        // API Design
        ResoniteClass::RestApi => &["rust rest api axum actix router handler"],
        ResoniteClass::Webhook => &["rust webhook event callback verify"],
        ResoniteClass::ServerSentEvents => &["rust server sent events sse stream"],
        ResoniteClass::OpenApiSpec => &["rust openapi swagger utoipa spec generate"],
        ResoniteClass::ApiGateway => &["rust api gateway reverse proxy upstream"],
        ResoniteClass::SdkGeneration => &["rust sdk generation codegen openapi client"],
        // Frontend
        ResoniteClass::FrontendRouter => &["rust frontend router navigation leptos yew"],
        ResoniteClass::StateManagement => &["rust state management store dispatch action"],
        ResoniteClass::FormHandling => &["rust form handling validation submit"],
        ResoniteClass::Internationalization => &["rust i18n l10n localization translation"],
        ResoniteClass::Theming => &["rust theming dark mode css variables design tokens"],
        ResoniteClass::ResponsiveDesign => &["rust responsive design breakpoint layout"],
        // Testing (specific)
        ResoniteClass::UnitTesting => &["rust unit testing assert tokio-test"],
        ResoniteClass::IntegrationTesting => &["rust integration test database server"],
        ResoniteClass::E2ETesting => &["rust e2e test playwright selenium browser"],
        ResoniteClass::MockServer => &["rust mock server wiremock stub test"],
        ResoniteClass::PropertyTesting => &["rust property testing proptest quickcheck"],
        ResoniteClass::Benchmarking => &["rust benchmark criterion throughput perf"],
        // Observability
        ResoniteClass::DistributedTracing => &["rust distributed tracing opentelemetry jaeger"],
        ResoniteClass::StructuredLogging => &["rust structured logging json tracing slog"],
        ResoniteClass::Alerting => &["rust alerting pagerduty opsgenie notification"],
        ResoniteClass::DashboardBuilder => &["rust dashboard grafana kibana panel"],
        // Security Compliance
        ResoniteClass::CorsPolicy => &["rust cors policy allow-origin tower-http"],
        ResoniteClass::CsrfProtection => &["rust csrf protection token double-submit"],
        ResoniteClass::InputSanitization => &["rust input sanitization xss sql escape"],
        ResoniteClass::AuditTrail => &["rust audit trail event log change history"],
        ResoniteClass::AccessControl => &["rust access control rbac abac policy"],
        // Data Pipeline
        ResoniteClass::EtlPipeline => &["rust etl extract transform load data pipeline"],
        ResoniteClass::StreamProcessing => &["rust stream processing kafka kinesis flink"],
        ResoniteClass::DataValidation => &["rust data validation schema validator"],
        ResoniteClass::PdfGeneration => &["rust pdf generation printpdf wkhtmltopdf"],
        ResoniteClass::MarkdownProcessing => &["rust markdown pulldown-cmark comrak"],
        ResoniteClass::TemplateEngine => &["rust template engine tera minijinja handlebars"],
        ResoniteClass::WebScraping => &["rust web scraping crawl html parse reqwest"],
        // AI/ML
        ResoniteClass::ModelServing => &["rust ml model serving onnx inference"],
        ResoniteClass::FeatureEngineering => &["rust feature engineering ml pipeline"],
        ResoniteClass::EmbeddingGeneration => &["rust text embedding vector encode"],
        ResoniteClass::VectorDatabase => &["rust vector database qdrant similarity search"],
        // DevOps
        ResoniteClass::CiCdPipeline => &["rust ci cd pipeline build deploy artifact"],
        ResoniteClass::Containerization => &["rust container docker image build podman"],
        ResoniteClass::Kubernetes => &["rust kubernetes k8s helm kube-client"],
        ResoniteClass::InfrastructureAsCode => &["rust infrastructure terraform pulumi cdk"],
        ResoniteClass::ServiceDiscovery => &["rust service discovery consul dns-sd"],
        ResoniteClass::LoadBalancing => &["rust load balancing round-robin proxy"],
        ResoniteClass::FeatureFlags => &["rust feature flags toggle launchdarkly unleash"],
        // Language/Compiler
        ResoniteClass::Lexer => &["rust lexer tokenizer scanner nom"],
        ResoniteClass::Parser => &["rust parser combinators peg lalr grammar"],
        ResoniteClass::AstProcessing => &["rust ast syntax tree visitor transform"],
        ResoniteClass::TypeChecker => &["rust type checker inference constraint solve"],
        ResoniteClass::CodeGeneration => &["rust codegen emit ir llvm backend"],
        ResoniteClass::LanguageServer => &["rust language server lsp tower-lsp"],
        ResoniteClass::Repl => &["rust repl interactive eval read-eval-print"],
        // Game/Simulation
        ResoniteClass::EntityComponentSystem => &["rust ecs bevy entity component system"],
        ResoniteClass::PhysicsEngine => &["rust physics engine rapier collision simulation"],
        ResoniteClass::GameLoop => &["rust game loop fixed-update render frame"],
        ResoniteClass::AudioEngine => &["rust audio engine cpal rodio sound"],
        ResoniteClass::InputHandling => &["rust input handling keyboard mouse gamepad"],
        ResoniteClass::SceneGraph => &["rust scene graph render tree transform node"],
        // Embedded/IoT
        ResoniteClass::GpioControl => &["rust gpio embedded hal pin control"],
        ResoniteClass::HardwareProtocol => &["rust i2c spi uart serial embedded-hal"],
        ResoniteClass::SensorReading => &["rust sensor reading temperature humidity"],
        ResoniteClass::FirmwareManagement => &["rust firmware ota update flash bootloader"],
        ResoniteClass::MqttProtocol => &["rust mqtt rumqttc paho broker"],
        ResoniteClass::DeviceTelemetry => &["rust iot telemetry device metrics reporting"],
        // Blockchain
        ResoniteClass::SmartContract => &["rust smart contract evm ethers alloy"],
        ResoniteClass::CryptoWallet => &["rust crypto wallet hd mnemonic sign-tx"],
        ResoniteClass::ConsensusProtocol => &["rust consensus raft paxos pbft byzantine"],
        ResoniteClass::TokenStandard => &["rust erc20 erc721 nft token standard"],
        // Architecture Patterns
        ResoniteClass::SagaPattern => &["rust saga pattern compensate distributed tx"],
        ResoniteClass::CqrsPattern => &["rust cqrs command query responsibility"],
        ResoniteClass::EventSourcing => &["rust event sourcing event store append replay"],
        ResoniteClass::PubSubPattern => &["rust pub sub topic fanout nats"],
        ResoniteClass::MiddlewarePattern => &["rust middleware pipeline intercept tower layer"],
        ResoniteClass::DependencyInjection => &["rust dependency injection ioc container provide"],
        ResoniteClass::Custom(_) => &[],
    };
    raw.iter().map(|s| s.to_string()).collect()
}

// ─── Tests ──────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn classify_fn_crud() {
        let r = Resonite::Fn {
            name: "list_products".into(),
            arity: 1,
        };
        assert_eq!(classify_resonite(&r), Some(ResoniteClass::CrudEntity));
    }

    #[test]
    fn classify_fn_event_bus() {
        let r = Resonite::Fn {
            name: "emit_trade_event".into(),
            arity: 2,
        };
        assert_eq!(classify_resonite(&r), Some(ResoniteClass::EventBus));
    }

    #[test]
    fn classify_type_cache() {
        let r = Resonite::Type {
            name: "LruCache".into(),
            kind: ResoniteTypeKind::Struct,
        };
        assert_eq!(classify_resonite(&r), Some(ResoniteClass::Caching));
    }

    #[test]
    fn spectroscopy_identifies_gap() {
        // Use an empty registry so builtin keyword coverage doesn't mask
        // the gaps we're trying to detect.
        let reg = NormRegistry::empty_without_persistence();
        let resonites = vec![
            Resonite::Fn { name: "emit_trade".into(), arity: 1 },
            Resonite::Fn { name: "subscribe_trades".into(), arity: 1 },
            Resonite::Type {
                name: "RsiIndicator".into(),
                kind: ResoniteTypeKind::Struct,
            },
        ];
        let result = spectroscopy(&resonites, &reg);
        let gap_classes: Vec<String> =
            result.gaps.iter().map(|g| g.class.as_str()).collect();
        assert!(gap_classes.contains(&"EventBus".to_string()));
        assert!(gap_classes.contains(&"IndicatorPipeline".to_string()));
        assert!(!result.suggestions.is_empty());
    }

    #[test]
    fn classify_v2_multi_class() {
        // A fn that matches both EventBus and WebSocket
        let r = Resonite::Fn {
            name: "websocket_emit_event".into(),
            arity: 2,
        };
        let classes = classify_resonite_v2(&r);
        assert!(classes.contains(&ResoniteClass::EventBus), "should detect EventBus: {:?}", classes);
        assert!(classes.contains(&ResoniteClass::RealtimeWebSocket), "should detect WebSocket: {:?}", classes);
    }

    #[test]
    fn classify_v2_cache_fn() {
        let r = Resonite::Fn {
            name: "invalidate_cache".into(),
            arity: 1,
        };
        let classes = classify_resonite_v2(&r);
        assert!(classes.contains(&ResoniteClass::Caching));
    }

    #[test]
    fn all_known_count() {
        let all = ResoniteClass::all_known();
        assert_eq!(all.len(), 139, "should have 139 known classes");
    }

    #[test]
    fn suggest_keywords_event_bus() {
        let kws = suggest_keywords_for_class(&ResoniteClass::EventBus);
        assert!(!kws.is_empty());
        assert!(kws.iter().any(|k| k.contains("event bus")));
    }

    #[test]
    fn empty_resonites_full_coverage() {
        let reg = NormRegistry::new_without_persistence();
        let result = spectroscopy(&[], &reg);
        assert_eq!(result.coverage, 1.0);
        assert!(result.gaps.is_empty());
    }
}

// ═══════════════════════════════════════════════════════════════════
// I4/bonus: Auto-keyword extraction from scraped repos
// ═══════════════════════════════════════════════════════════════════

/// Words that produce low-quality keywords.  Keywords whose content words
/// (everything after the language prefix) consist entirely of these terms
/// are discarded.
const KEYWORD_BLACKLIST: &[&str] = &[
    "utils", "util", "lib", "core", "common", "helper",
    "helpers", "misc", "main", "app", "config", "mod",
    "test", "tests", "bench", "example", "examples",
    "internal", "private", "public", "types", "error",
    "errors", "base", "shared", "new", "old", "tmp",
    "temp", "default", "impl", "init", "setup",
];

/// Rust / stdlib import prefixes — not external crates.
const RUST_STDLIB_PREFIXES: &[&str] = &[
    "std::", "core::", "alloc::", "crate::", "super::", "self::",
];

/// Split a PascalCase (or camelCase) identifier into lower-case words.
///
/// `"ConnectionPool"` → `["connection", "pool"]`
/// `"HTTPClient"`     → `["h", "t", "t", "p", "client"]` (best-effort)
pub fn split_pascal_case(name: &str) -> Vec<String> {
    let mut words = Vec::new();
    let mut current = String::new();
    for ch in name.chars() {
        if ch.is_uppercase() && !current.is_empty() {
            words.push(current.to_lowercase());
            current.clear();
        }
        current.push(ch);
    }
    if !current.is_empty() {
        words.push(current.to_lowercase());
    }
    words
}

/// Returns `true` when the keyword is useful (not just a language prefix +
/// blacklisted filler word).
pub fn is_useful_keyword(keyword: &str) -> bool {
    let parts: Vec<&str> = keyword.split_whitespace().collect();
    // Must have at least "lang word" (2 parts).
    if parts.len() < 2 {
        return false;
    }
    // Every content word (after the language prefix) must not be blacklisted.
    let content = &parts[1..];
    !content.iter().all(|w| KEYWORD_BLACKLIST.contains(w))
}

/// Extract up to `max_keywords` search keywords from a scraped code corpus.
///
/// # Arguments
/// * `struct_names`  — type / class names found in the repo (from topology).
/// * `import_paths`  — raw import strings from all files:
///   - Python / TypeScript / Go: external imports are prefixed with `"ext:"`.
///   - Rust: external crates look like `"tokio"` or `"tokio::sync::..."`.
/// * `language`     — primary language of the repo (`"rust"`, `"python"`, etc.).
/// * `max_keywords` — cap on the number of returned keywords (spec default: 5).
///
/// Keywords have the form `"<lang> <concept>"`, e.g. `"rust connection pool"`.
pub fn extract_keywords_from_analysis(
    struct_names: &[String],
    import_paths: &[String],
    language: &str,
    max_keywords: usize,
) -> Vec<String> {
    use std::collections::BTreeSet;

    if language.is_empty() || language == "unknown" {
        return vec![];
    }

    let mut candidates: BTreeSet<String> = BTreeSet::new();

    // ── Type names → keywords ─────────────────────────────────────────
    for name in struct_names {
        let words = split_pascal_case(name);
        if words.len() >= 2 {
            let keyword = format!("{} {}", language, words.join(" "));
            if is_useful_keyword(&keyword) {
                candidates.insert(keyword);
            }
        }
    }

    // ── External imports → keywords ───────────────────────────────────
    for path in import_paths {
        // Python / TypeScript / Go: "ext:requests", "ext:github.com/pkg/errors"
        let crate_name = if let Some(ext) = path.strip_prefix("ext:") {
            // Go convention: "github.com/pkg/errors" → take last path component ("errors").
            // npm convention: "express/Request" → take first component ("express").
            let first_segment = ext.split('/').next().unwrap_or(ext);
            if first_segment.contains('.') {
                // Go-style host path → last component is the package
                ext.split('/').last().unwrap_or(ext).to_string()
            } else {
                // npm / Python style → package name is the first segment
                first_segment.to_string()
            }
        } else {
            // Rust: skip stdlib
            if RUST_STDLIB_PREFIXES.iter().any(|p| path.starts_with(p)) {
                continue;
            }
            // Rust external crate: "tokio::sync::mpsc" → "tokio"
            // "sqlx" → "sqlx"
            path.split("::").next().unwrap_or(path.as_str()).to_string()
        };

        let name = crate_name.trim();
        // Quality gates: length 3–30, at least one letter.
        if name.len() < 3 || name.len() > 30 || !name.chars().any(|c| c.is_alphabetic()) {
            continue;
        }
        let keyword = format!("{} {}", language, name.to_lowercase());
        if is_useful_keyword(&keyword) {
            candidates.insert(keyword);
        }
    }

    // ── Return top `max_keywords` in insertion (BTree) order ─────────
    candidates.into_iter().take(max_keywords).collect()
}

// ─── Tests ───────────────────────────────────────────────────────────────────

#[cfg(test)]
mod auto_keywords_tests {
    use super::*;

    #[test]
    fn pascal_split_connection_pool() {
        let words = split_pascal_case("ConnectionPool");
        assert_eq!(words, vec!["connection", "pool"]);
    }

    #[test]
    fn pascal_split_event_handler() {
        let words = split_pascal_case("EventHandler");
        assert_eq!(words, vec!["event", "handler"]);
    }

    #[test]
    fn keyword_from_struct_name() {
        let kws = extract_keywords_from_analysis(
            &["ConnectionPool".to_string(), "EventBus".to_string()],
            &[],
            "rust",
            5,
        );
        assert!(kws.iter().any(|k| k == "rust connection pool"),
            "Expected 'rust connection pool', got {:?}", kws);
        assert!(kws.iter().any(|k| k == "rust event bus"),
            "Expected 'rust event bus', got {:?}", kws);
    }

    #[test]
    fn keyword_from_external_import() {
        let kws = extract_keywords_from_analysis(
            &[],
            &["ext:sqlx".to_string(), "ext:tokio".to_string()],
            "rust",
            5,
        );
        assert!(kws.iter().any(|k| k == "rust sqlx"),
            "Expected 'rust sqlx', got {:?}", kws);
        assert!(kws.iter().any(|k| k == "rust tokio"),
            "Expected 'rust tokio', got {:?}", kws);
    }

    #[test]
    fn blacklist_filters_utils() {
        let kws = extract_keywords_from_analysis(
            &["Utils".to_string(), "Helpers".to_string()],
            &[],
            "python",
            5,
        );
        // "python utils" and "python helpers" should be filtered out
        assert!(!kws.iter().any(|k| k.contains("utils")), "utils should be filtered: {:?}", kws);
    }

    #[test]
    fn max_keywords_respected() {
        let structs: Vec<String> = (0..20)
            .map(|i| format!("ServiceLayer{}", i))
            .collect();
        let kws = extract_keywords_from_analysis(&structs, &[], "go", 5);
        assert!(kws.len() <= 5, "Should not exceed max_keywords=5, got {}", kws.len());
    }

    #[test]
    fn stdlib_rust_skipped() {
        let kws = extract_keywords_from_analysis(
            &[],
            &["std::io".to_string(), "crate::models".to_string(), "core::fmt".to_string()],
            "rust",
            5,
        );
        assert!(kws.is_empty(), "Stdlib/crate imports should produce no keywords: {:?}", kws);
    }

    #[test]
    fn go_external_import_pkg() {
        let kws = extract_keywords_from_analysis(
            &[],
            &["ext:github.com/jackc/pgx".to_string()],
            "go",
            5,
        );
        assert!(kws.iter().any(|k| k == "go pgx"),
            "Expected 'go pgx', got {:?}", kws);
    }

    #[test]
    fn typescript_external_import() {
        let kws = extract_keywords_from_analysis(
            &[],
            &["ext:express/Request".to_string()],
            "typescript",
            5,
        );
        assert!(kws.iter().any(|k| k.contains("express")),
            "Expected express keyword, got {:?}", kws);
    }
}

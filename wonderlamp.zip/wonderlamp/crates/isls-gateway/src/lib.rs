//! REST and WebSocket API gateway for ISLS (C19).
//!
//! Serves the Studio single-page web interface and provides real-time event
//! streaming over WebSockets. All static assets are embedded at compile time
//! with zero external JS/CSS dependencies.

// isls-gateway: REST + WebSocket API and Studio web interface — C19
// Serves the Studio single-page app and provides real-time event streaming.
// No external JS/CSS dependencies. One HTML file. Nine views (Phase 13: Swarm + Chat).

pub mod architect;
pub mod auto_evolve;
pub mod chat;
pub mod chat_handler;
pub mod counters;
pub mod discover;
pub mod scrape_engine;
pub mod session;
pub mod studio_auth;
pub mod targets;
pub mod timeseries;
pub mod ws;

use std::collections::{BTreeMap, HashMap};
use std::net::SocketAddr;
use std::path::PathBuf;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, Ordering};
use std::time::Instant;

use axum::{
    Router,
    extract::{Path, Query, State, WebSocketUpgrade},
    http::StatusCode,
    response::{Html, IntoResponse, Json, Response},
    routing::{delete, get, post},
};
use isls_norms::NormRegistry;
use isls_norms::composition::ComposedPlan;
use futures::{SinkExt, StreamExt};
use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;

use chat::{BindRequest, BoundProject, ChatJobStore, ChatRequest, run_chat_job};
use ws::{EventHub, EventType, SubscribeRequest, WsEvent};

// The entire Studio is embedded at compile time
const STUDIO_HTML: &str = include_str!("static/studio.html");

// ─── Pending Plan (v3.2 wiring) ──────────────────────────────────────────

/// A plan stored after POST /api/chat, awaiting user confirmation via forge.
#[derive(Clone, Debug)]
pub struct PendingPlan {
    pub id: String,
    pub description: String,
    pub composed_plan: ComposedPlan,
    pub activated_norms: Vec<String>,
    pub estimated_files: usize,
    pub estimated_loc: usize,
    pub created_at: String,
}

/// Status of a project in the forge pipeline.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum ProjectStatus {
    Planning,
    Generating,
    Completed,
    Failed,
}

/// Statistics from a forge run.
#[derive(Clone, Debug, Serialize, Deserialize, Default)]
pub struct ProjectStats {
    pub files_generated: usize,
    pub total_loc: usize,
    pub total_tokens: u64,
    pub compile_status: String,
    pub duration_secs: f64,
}

// ─── Application State ─────────────────────────────────────────────────────

#[derive(Clone)]
pub struct AppState {
    pub start_time: Instant,
    pub event_hub: EventHub,
    pub engine_state: Arc<RwLock<EngineState>>,
    pub forge_state: Arc<RwLock<ForgeState>>,
    pub foundry_state: Arc<RwLock<FoundryState>>,
    /// In-progress and completed chat jobs (keyed by job_id)
    pub chat_jobs: ChatJobStore,
    /// Default project path for /agent/chat when no `project` field is set
    pub bound_project: BoundProject,
    /// Norm registry shared across API handlers.
    pub norm_registry: Arc<RwLock<NormRegistry>>,
    /// Projects created via POST /api/projects (in-memory, keyed by id).
    pub project_store: Arc<RwLock<BTreeMap<String, ProjectEntry>>>,
    /// Pending plans from POST /api/chat awaiting forge execution.
    pub pending_plans: Arc<RwLock<HashMap<String, PendingPlan>>>,
    /// Root directory for generated project outputs.
    pub projects_dir: PathBuf,
    /// D7: Architect sessions (multi-turn conversation state).
    pub session_store: session::SessionStore,
    /// S1: Mass-scrape job tracking for Entdecken mode.
    pub mass_scrape_jobs: discover::MassScrapeStore,
    /// S1/ux: ring-buffer of the most recent scrape-history entries
    /// (completed mass-scrape jobs). In-memory only — intentionally not
    /// persisted, so a restart clears the feed.
    pub scrape_history: discover::ScrapeHistoryStore,
    /// S1/ux: filesystem path of the editable scrape-keyword list
    /// (`~/.isls/scrape_keywords.txt` by default).
    pub scrape_keywords_path: PathBuf,
    /// I4/harpoon: filesystem path for auto-suggested keywords from scraping
    /// (`~/.isls/suggested_keywords.txt` by default). Separate from the
    /// curated `scrape_keywords.txt` — only `isls harpoon` may cascade on it.
    pub suggested_keywords_path: PathBuf,
    /// I4/harpoon: in-progress and completed harpoon jobs.
    pub harpoon_jobs: discover::HarpoonStore,
    /// Oracle configuration for session forge (OpenAI vs Ollama vs Mock).
    pub oracle_config: OracleConfig,
    /// I5: Auto-evolve history and state.
    pub auto_evolve: auto_evolve::AutoEvolveStore,
    /// I5: Atomic flag — true when auto-evolve background task should run.
    pub auto_evolve_enabled: Arc<AtomicBool>,
    /// MC1: Target systems for Mission Control.
    pub targets: Arc<RwLock<Vec<isls_norms::targets::TargetSystem>>>,
    /// MC1: Atomic flag — true when auto-steer is active.
    pub auto_steer_enabled: Arc<AtomicBool>,
    /// S1/auth: Studio user database (in-memory + persisted to JSON).
    pub studio_users: studio_auth::UserStore,
    /// S1/auth: Active studio sessions (token → user info).
    pub studio_sessions: studio_auth::SessionStore,
    /// S1/auth: Initial admin password (from CLI --studio-password).
    pub studio_password: Option<String>,
    /// E1: In-memory MCI run history (last 50 reports).
    pub mci_history: Arc<RwLock<Vec<isls_forge_llm::mci::MciReport>>>,
    /// S3: Integrated scraping engine state (config, progress, live status).
    pub scrape_engine: scrape_engine::ScrapeEngineState,
    /// S3: When true, the scraping engine is not spawned (--no-scrape flag).
    pub scrape_disabled: bool,
}

/// Configuration for constructing an LLM oracle in the session forge.
///
/// Priority at forge time:
/// 1. Session-specific api_key → OpenAiOracle
/// 2. oracle_config.api_key → OpenAiOracle
/// 3. oracle_config.use_ollama → OllamaOracle
/// 4. Fallback → MockOracle
#[derive(Clone, Debug, Default)]
pub struct OracleConfig {
    pub api_key: Option<String>,
    pub use_ollama: bool,
    pub ollama_url: String,
    pub ollama_model: String,
    pub openai_model: String,
}

impl OracleConfig {
    pub fn default_mock() -> Self {
        Self {
            api_key: None,
            use_ollama: false,
            ollama_url: "http://localhost:11434".to_string(),
            ollama_model: "qwen2.5-coder:7b".to_string(),
            openai_model: "gpt-4o".to_string(),
        }
    }
}

/// Build a forge oracle from an [`OracleConfig`] and an optional
/// session-specific API key.
///
/// Priority — matches the chat path (`/api/chat/plain`) so the forge never
/// falls back to `gpt-4o` when `--ollama` is active:
///
/// 1. `cfg.use_ollama` → [`OllamaOracle`] (same as chat)
/// 2. `session_api_key` or `cfg.api_key` → [`OpenAiOracle`]
/// 3. fallback → [`MockOracle`]
///
/// The returned `bool` is `true` when `MockOracle` is used (so callers can
/// set `use_mock` on `LlmForge`).
pub fn build_forge_oracle(
    cfg: &OracleConfig,
    session_api_key: Option<String>,
) -> (Box<dyn isls_forge_llm::Oracle>, bool) {
    build_forge_oracle_with_heartbeat(cfg, session_api_key, None)
}

/// Variant of [`build_forge_oracle`] that wires an Ollama streaming
/// heartbeat callback when the Ollama oracle is selected. The callback
/// receives `(tokens_so_far, elapsed_secs)` every ~5 s during a call,
/// so the gateway can broadcast a `forge:oracle_tick` WS event and the
/// Studio UI can prove "yes, Ollama is alive, tokens are still flowing".
pub fn build_forge_oracle_with_heartbeat(
    cfg: &OracleConfig,
    session_api_key: Option<String>,
    heartbeat: Option<isls_forge_llm::OllamaHeartbeatFn>,
) -> (Box<dyn isls_forge_llm::Oracle>, bool) {
    if cfg.use_ollama {
        tracing::info!(
            "forge oracle: using OllamaOracle (model={}, url={})",
            cfg.ollama_model,
            cfg.ollama_url,
        );
        let mut ollama = isls_forge_llm::oracle::OllamaOracle::new(
            &cfg.ollama_model,
            &cfg.ollama_url,
        );
        if let Some(cb) = heartbeat {
            ollama = ollama.with_heartbeat(cb);
        }
        return (Box::new(ollama), false);
    }

    let effective_key = session_api_key.or_else(|| cfg.api_key.clone());
    if let Some(key) = effective_key {
        match isls_forge_llm::oracle::OpenAiOracle::new(
            Some(key),
            Some(cfg.openai_model.clone()),
        ) {
            Ok(o) => {
                tracing::info!(
                    "forge oracle: using OpenAiOracle (model={})",
                    cfg.openai_model,
                );
                return (Box::new(o), false);
            }
            Err(e) => {
                tracing::warn!(
                    "forge oracle: OpenAiOracle init failed ({}), falling back to Mock",
                    e,
                );
                return (Box::new(isls_forge_llm::MockOracle), true);
            }
        }
    }

    tracing::info!("forge oracle: using MockOracle (no LLM configured)");
    (Box::new(isls_forge_llm::MockOracle), true)
}

/// Serialise a [`isls_forge_llm::ForgeProgressEvent`] into the JSON payload
/// the Studio WebSocket layer expects. The `type` field matches the strings
/// the frontend already listens for (`forge:node`, `forge:compile`, …) plus
/// the new `forge:node_start` and `forge:coagula_fix_start` events so the
/// UI can show live progress even when a single LLM call takes many
/// minutes.
pub fn forge_progress_event_to_json(
    session_id: &str,
    ev: &isls_forge_llm::ForgeProgressEvent,
) -> serde_json::Value {
    use isls_forge_llm::ForgeProgressEvent as E;
    match ev {
        E::Start { total_nodes } => serde_json::json!({
            "type": "forge:start",
            "session_id": session_id,
            "total_nodes": total_nodes,
        }),
        E::NodeStart { index, total, path, method } => serde_json::json!({
            "type": "forge:node_start",
            "session_id": session_id,
            "index": index,
            "total": total,
            "path": path,
            "method": method,
        }),
        E::Node { index, total, path, method, tokens } => serde_json::json!({
            "type": "forge:node",
            "session_id": session_id,
            "index": index,
            "total": total,
            "path": path,
            "method": method,
            "tokens": tokens,
        }),
        E::Compile { status, errors } => serde_json::json!({
            "type": "forge:compile",
            "session_id": session_id,
            "status": status,
            "errors": errors,
        }),
        E::Coagula { cycle, max } => serde_json::json!({
            "type": "forge:coagula",
            "session_id": session_id,
            "cycle": cycle,
            "max": max,
        }),
        E::CoagulaFixStart { cycle, max, path } => serde_json::json!({
            "type": "forge:coagula_fix_start",
            "session_id": session_id,
            "cycle": cycle,
            "max": max,
            "path": path,
        }),
        E::Complete { success, files, loc, tokens, duration_secs } => serde_json::json!({
            "type": "forge:complete",
            "session_id": session_id,
            "success": success,
            "files": files,
            "loc": loc,
            "tokens": tokens,
            "duration_secs": duration_secs,
        }),
    }
}

impl AppState {
    pub fn new() -> Self {
        let isls_home = std::env::var("HOME")
            .map(|h| PathBuf::from(h).join(".isls"))
            .unwrap_or_else(|_| PathBuf::from("/tmp/isls"));
        let projects_dir = isls_home.join("projects");
        let scrape_keywords_path = isls_home.join("scrape_keywords.txt");
        let suggested_keywords_path = isls_home.join("suggested_keywords.txt");
        Self {
            start_time: Instant::now(),
            event_hub: EventHub::default(),
            engine_state: Arc::new(RwLock::new(EngineState::default())),
            forge_state: Arc::new(RwLock::new(ForgeState::default())),
            foundry_state: Arc::new(RwLock::new(FoundryState::default())),
            chat_jobs: Arc::new(RwLock::new(HashMap::new())),
            bound_project: Arc::new(RwLock::new(None)),
            norm_registry: Arc::new(RwLock::new({
                let mut reg = NormRegistry::default();
                reg.tag_builtin_semantic_classes();
                reg.deduplicate_norms();
                reg
            })),
            project_store: Arc::new(RwLock::new(BTreeMap::new())),
            pending_plans: Arc::new(RwLock::new(HashMap::new())),
            projects_dir,
            session_store: Arc::new(RwLock::new(HashMap::new())),
            mass_scrape_jobs: discover::new_mass_scrape_store(),
            scrape_history: discover::new_scrape_history_store(),
            scrape_keywords_path,
            suggested_keywords_path,
            harpoon_jobs: discover::new_harpoon_store(),
            oracle_config: OracleConfig::default_mock(),
            auto_evolve: auto_evolve::new_auto_evolve_store(),
            auto_evolve_enabled: Arc::new(AtomicBool::new(false)),
            targets: Arc::new(RwLock::new(isls_norms::targets::load_targets())),
            auto_steer_enabled: Arc::new(AtomicBool::new(false)),
            studio_users: Arc::new(tokio::sync::Mutex::new(Vec::new())),
            studio_sessions: studio_auth::new_session_store(),
            studio_password: None,
            mci_history: Arc::new(RwLock::new(Vec::new())),
            scrape_engine: scrape_engine::ScrapeEngineState::new(),
            scrape_disabled: false,
        }
    }

    /// Builder: disable the integrated scraping engine (--no-scrape).
    pub fn with_no_scrape(mut self) -> Self {
        self.scrape_disabled = true;
        self
    }

    /// Builder: set the studio password and initialize users.
    pub fn with_studio_password(mut self, password: Option<String>) -> Self {
        self.studio_password = password;
        self
    }

    /// Initialize the user store. Must be called after with_studio_password.
    pub fn init_studio_users(self) -> Self {
        let mut users = studio_auth::load_users();
        studio_auth::ensure_initial_admin(&mut users, self.studio_password.as_deref());
        let store = self.studio_users.clone();
        // Use try_lock since we're in a sync context and nobody else holds it yet
        if let Ok(mut guard) = store.try_lock() {
            *guard = users;
        }
        self
    }

    /// Builder: set the oracle configuration for session forge.
    pub fn with_oracle_config(mut self, config: OracleConfig) -> Self {
        self.oracle_config = config;
        self
    }

    /// Builder: enable auto-evolve at startup.
    pub fn with_auto_evolve(mut self, enabled: bool) -> Self {
        self.auto_evolve_enabled.store(enabled, Ordering::Relaxed);
        if enabled {
            let next = chrono::Utc::now() + chrono::Duration::hours(6);
            // Can't easily do async here in a sync builder, so we schedule it lazily
            let _ = next;
        }
        self
    }
}

impl Default for AppState {
    fn default() -> Self {
        Self::new()
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct EngineState {
    pub running: bool,
    pub tick: u64,
    pub entity_count: usize,
    pub crystal_count: usize,
    pub mode: String,
    pub crystals: Vec<CrystalSummary>,
    pub metrics: MetricsData,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct CrystalSummary {
    pub id: String,
    pub tick: u64,
    pub score: f64,
    pub scale: String,
    pub checks: String,
    pub stability: f64,
    pub free_energy: f64,
    pub constraint_count: usize,
    pub topology: TopologySummary,
    pub evidence_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct TopologySummary {
    pub spectral_gap: f64,
    pub kuramoto_r: f64,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct MetricsData {
    pub ingestion_rate: f64,
    pub replay_steps_per_sec: f64,
    pub evidence_verify_us: f64,
    pub memory_mb: f64,
    pub autonomy_ratio: f64,
    pub coherence: Vec<f64>,
    pub gate_selectivity: Vec<f64>,
    pub crystal_rate: Vec<f64>,
    pub spectral_gap: Vec<f64>,
    pub kuramoto_r: Vec<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ForgeState {
    pub active: bool,
    pub progress: Option<ForgeProgress>,
    pub last_result: Option<ForgeResult>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ForgeProgress {
    pub phase: String,
    pub index: usize,
    pub total: usize,
    pub atom_name: String,
    pub source: String,
    pub status: String,
    pub atoms: Vec<AtomProgress>,
    pub output_files: Vec<OutputFile>,
    pub composition_tree: Option<serde_json::Value>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct AtomProgress {
    pub name: String,
    pub source: String,
    pub status: String,
    pub duration_secs: Option<f64>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct OutputFile {
    pub path: String,
    pub content: String,
    pub source: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ForgeResult {
    pub crystal_id: String,
    pub artifacts: Vec<OutputFile>,
    pub manifest: serde_json::Value,
}

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct FoundryState {
    pub active: bool,
    pub progress: Option<FoundryProgress>,
    pub projects: BTreeMap<String, FoundryProject>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FoundryProgress {
    pub phase: String,
    pub attempt: usize,
    pub max_attempts: usize,
    pub status: String,
    pub error: Option<String>,
    pub template_name: Option<String>,
    pub atoms_done: usize,
    pub atoms_total: usize,
    pub log: Vec<String>,
    pub file_tree: Vec<FileTreeEntry>,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileTreeEntry {
    pub path: String,
    pub source: String,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FoundryProject {
    pub id: String,
    pub files: BTreeMap<String, String>,
    pub status: String,
}

fn agent_state_path() -> std::path::PathBuf {
    let base = std::env::var("HOME").unwrap_or_else(|_| "/tmp".into());
    std::path::PathBuf::from(base).join(".isls").join("agent").join("state.json")
}

fn isls_home_path() -> std::path::PathBuf {
    std::env::var("HOME")
        .map(|h| std::path::PathBuf::from(h).join(".isls"))
        .unwrap_or_else(|_| std::path::PathBuf::from("/tmp/isls"))
}

/// Create a ZIP archive of `output_dir` and store it in `~/.isls/downloads/`.
///
/// Returns the filename (not the full path) on success.  Enforces a 50 MB
/// size limit and delegates to the system `zip` binary.
fn package_forge_output(output_dir: &std::path::Path) -> Result<String, String> {
    let downloads_dir = isls_home_path().join("downloads");
    std::fs::create_dir_all(&downloads_dir)
        .map_err(|e| format!("Cannot create downloads dir: {}", e))?;

    let zip_name = format!(
        "forge-{}.zip",
        chrono::Utc::now().timestamp()
    );
    let zip_path = downloads_dir.join(&zip_name);

    let output = std::process::Command::new("zip")
        .arg("-r")
        .arg(&zip_path)
        .arg(".")
        .current_dir(output_dir)
        .output()
        .map_err(|e| format!("zip command failed: {}", e))?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(format!("zip exited non-zero: {}", stderr));
    }

    // Enforce 50 MB size limit
    const MAX_ZIP_BYTES: u64 = 50 * 1024 * 1024;
    if let Ok(meta) = std::fs::metadata(&zip_path) {
        if meta.len() > MAX_ZIP_BYTES {
            let _ = std::fs::remove_file(&zip_path);
            return Err(format!(
                "ZIP exceeds 50 MB limit ({} bytes)",
                meta.len()
            ));
        }
    }

    Ok(zip_name)
}

/// Delete forge download ZIPs older than 24 hours from `~/.isls/downloads/`.
fn cleanup_old_downloads() {
    let dir = isls_home_path().join("downloads");
    let entries = match std::fs::read_dir(&dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    let cutoff = std::time::Duration::from_secs(86400);
    for entry in entries.flatten() {
        let path = entry.path();
        if path.extension().and_then(|e| e.to_str()) != Some("zip") {
            continue;
        }
        if let Ok(meta) = entry.metadata() {
            if let Ok(modified) = meta.modified() {
                if let Ok(age) = modified.elapsed() {
                    if age > cutoff {
                        let _ = std::fs::remove_file(&path);
                        tracing::debug!(
                            "[Downloads] Removed expired ZIP: {:?}",
                            path.file_name()
                        );
                    }
                }
            }
        }
    }
}

// ─── Request/Response Types ─────────────────────────────────────────────────

#[derive(Debug, Deserialize)]
pub struct ForgeRequest {
    pub intent: String,
    pub domain: Option<String>,
    pub template: Option<String>,
    pub strategy: Option<String>,
    pub max_atoms: Option<usize>,
}

#[derive(Debug, Deserialize)]
pub struct FoundryRequest {
    pub intent: String,
    pub operation: Option<String>,
    pub output_dir: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct CommandRequest {
    pub command: String,
}

#[derive(Debug, Deserialize)]
pub struct AgentGoalRequest {
    pub intent: String,
    pub domain: Option<String>,
    pub constraints: Option<Vec<String>>,
    pub confidence: Option<f64>,
    pub max_steps: Option<usize>,
}

#[derive(Debug, Deserialize)]
pub struct CrystalQuery {
    pub limit: Option<usize>,
    pub scale: Option<String>,
    pub search: Option<String>,
}

#[derive(Debug, Serialize)]
pub struct DashboardData {
    pub version: String,
    pub uptime_secs: u64,
    pub health: String,
    pub crystal_count: usize,
    pub entity_count: usize,
    pub test_count: usize,
    pub drift: String,
    pub scenarios: Vec<ScenarioSummary>,
    pub metrics: MetricsData,
    pub events: Vec<serde_json::Value>,
    pub genesis: GenesisSummary,
}

#[derive(Debug, Serialize)]
pub struct ScenarioSummary {
    pub name: String,
    pub crystals: usize,
    pub pass_rate: String,
}

#[derive(Debug, Serialize)]
pub struct GenesisSummary {
    pub hash: String,
    pub conformance_class: String,
    pub constraints_total: usize,
    pub constraints_pass: usize,
    pub drift: String,
}

#[derive(Debug, Serialize)]
pub struct CommandResponse {
    pub ok: bool,
    pub message: String,
    pub data: Option<serde_json::Value>,
}

// ─── Norm / Project / Chat API types ────────────────────────────────────────

/// A project created via POST /api/projects or POST /api/projects/forge.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ProjectEntry {
    pub id: String,
    pub name: String,
    pub toml_content: String,
    pub domain: Option<String>,
    pub output_dir: Option<String>,
    pub status: String,
    pub created_at: String,
    /// Norms that contributed to this project.
    #[serde(default)]
    pub norms_used: Vec<String>,
    /// Generation statistics (populated after forge run).
    #[serde(default)]
    pub stats: Option<ProjectStats>,
}

/// Summary of a norm returned by GET /api/norms.
#[derive(Debug, Serialize)]
pub struct NormSummary {
    pub id: String,
    pub name: String,
    pub level: String,
    pub description: String,
    /// Semantic observation count (for SEM norms) or synthesis usage count.
    pub observation_count: u32,
    /// Domains this norm has been observed/applied in.
    pub domains: Vec<String>,
    /// True for hand-authored builtins.
    pub builtin: bool,
}

/// Request body for POST /api/projects.
#[derive(Debug, Deserialize)]
pub struct CreateProjectRequest {
    pub name: String,
    pub toml_content: String,
    pub domain: Option<String>,
}

/// Request body for POST /api/chat (norm-aware).
#[derive(Debug, Deserialize)]
pub struct ApiChatRequest {
    pub message: String,
}

/// Response for POST /api/chat.
#[derive(Debug, Serialize)]
pub struct ApiChatResponse {
    pub message: String,
    pub intent: String,
    pub norms_activated: Vec<String>,
    pub entities: Vec<String>,
    pub estimated_files: usize,
    pub estimated_loc: usize,
    pub plan_id: Option<String>,
    pub plan_description: Option<String>,
    pub action_buttons: Vec<ActionButton>,
}

/// An action button in the chat response UI.
#[derive(Debug, Serialize)]
pub struct ActionButton {
    pub label: String,
    pub action: String,
    pub style: String,
}

/// Request body for POST /api/projects/forge.
#[derive(Debug, Deserialize)]
pub struct ApiForgeRequest {
    pub plan_id: String,
    pub api_key: Option<String>,
}

/// Response for POST /api/projects/forge.
#[derive(Debug, Serialize)]
pub struct ApiForgeResponse {
    pub ok: bool,
    pub project_id: String,
    pub files_generated: usize,
    pub total_loc: usize,
    pub total_tokens: u64,
    pub compile_status: String,
    pub norms_used: Vec<String>,
    pub output_dir: String,
}

/// File info returned by GET /api/projects/:id/files.
#[derive(Debug, Serialize)]
pub struct FileInfo {
    pub path: String,
    pub size: u64,
    pub is_rust: bool,
}

/// Request for GET /api/projects/:id/file.
#[derive(Debug, Deserialize)]
pub struct FileContentQuery {
    pub path: String,
}

// ─── Router ─────────────────────────────────────────────────────────────────

pub fn build_router(state: AppState) -> Router {
    Router::new()
        // Studio static page
        .route("/studio", get(serve_studio))
        // REST API
        .route("/health", get(health))
        .route("/status", get(status))
        .route("/api/dashboard", get(dashboard))
        .route("/metrics", get(metrics))
        .route("/crystals", get(list_crystals))
        .route("/crystals/{id}", get(get_crystal))
        .route("/forge", post(start_forge))
        .route("/api/forge/progress", get(forge_progress))
        .route("/api/foundry/fabricate", post(start_foundry))
        .route("/api/foundry/progress", get(foundry_progress))
        .route("/api/foundry/files/{id}", get(foundry_files))
        .route("/api/foundry/download/{id}", get(foundry_download))
        .route("/api/command", post(execute_command))
        .route("/engine/start", post(engine_start))
        .route("/engine/stop", post(engine_stop))
        .route("/engine/step", post(engine_step))
        // C30 Agent
        .route("/agent/status", get(agent_status))
        .route("/agent/goal", post(agent_goal))
        .route("/agent/step", post(agent_step_handler))
        .route("/agent/history", get(agent_history))
        // C30 Agent Chat (Phase 12 upgrade)
        .route("/agent/chat", post(agent_chat_start))
        .route("/agent/chat/{job_id}/events", get(agent_chat_events))
        .route("/agent/bind", post(agent_bind))
        // v3 Norm API
        .route("/api/norms", get(api_list_norms))
        .route("/api/norms/candidates", get(api_list_norm_candidates))
        .route("/api/norms/fitness", get(api_norms_fitness))
        .route("/api/norms/genome", get(api_norms_genome))
        .route("/api/norms/inject", post(api_norms_inject))
        .route("/api/norms/anatomy", get(api_norms_anatomy))
        .route("/api/norms/relations", get(api_norms_relations))
        .route("/api/norms/groups", get(api_norms_groups))
        .route("/api/norms/energy", post(api_norms_energy_compute))
        .route("/api/norms/optimize", post(api_norms_optimize))
        .route("/api/norms/{id}", get(api_get_norm))
        // I6: Capabilities
        .route("/api/capabilities", get(api_capabilities))
        // I3/W3 Evolve
        .route("/api/evolve", post(api_evolve))
        // v3 Projects API
        .route("/api/projects", get(api_list_projects).post(api_create_project))
        .route("/api/projects/{id}", get(api_get_project).delete(api_delete_project))
        // v3.2 Forge from chat plan
        .route("/api/projects/forge", post(api_forge))
        .route("/api/projects/{id}/files", get(api_project_files))
        .route("/api/projects/{id}/file", get(api_project_file_content))
        // v3 Chat API (norm-aware)
        .route("/api/chat", post(api_chat))
        .route("/api/chat/plain", post(chat_handler::api_chat_plain))
        .route("/api/chat/history", get(api_chat_history))
        // v3 Crystals + Health
        .route("/api/crystals", get(api_crystals))
        .route("/api/health", get(api_health))
        // D7: Architect sessions
        .route("/api/session", post(session_create))
        .route("/api/sessions", get(session_list))
        .route("/api/session/{id}", get(session_get).delete(session_delete))
        .route("/api/session/{id}/message", post(session_message))
        .route("/api/session/{id}/readiness", get(session_readiness))
        .route("/api/session/{id}/forge", post(session_forge))
        // S2/fix: Forge ZIP download
        .route("/api/forge/download/{filename}", get(download_forge))
        // S1: Entdecken (Discover) mode
        .route("/api/discover/search", post(discover::discover_search))
        .route("/api/discover/xray", post(discover::discover_xray))
        .route("/api/discover/scrape", post(discover::discover_scrape))
        .route("/api/discover/mass-scrape", post(discover::discover_mass_scrape))
        .route("/api/discover/mass-scrape/{id}/status", get(discover::discover_mass_scrape_status))
        .route("/api/discover/upload-keywords", post(discover::discover_upload_keywords))
        .route("/api/discover/gaps", get(discover::discover_gaps))
        .route("/api/discover/spectroscopy", post(discover::discover_spectroscopy))
        .route("/api/discover/spectroscopy/fill", post(discover::discover_spectroscopy_fill))
        .route("/api/discover/scrape-status", get(discover::discover_scrape_status))
        .route(
            "/api/discover/keywords",
            get(discover::discover_keywords_get).post(discover::discover_keywords_post),
        )
        .route("/api/discover/genealogy/{norm_id}", get(discover::discover_genealogy))
        .route("/api/discover/similarity", get(discover::discover_similarity))
        .route("/api/discover/harpoon", post(discover::discover_harpoon))
        .route("/api/discover/harpoon/{id}/status", get(discover::discover_harpoon_status))
        .route("/api/discover/suggested-keywords", get(discover::discover_suggested_keywords))
        .route("/api/discover/accept-keyword", post(discover::discover_accept_keyword))
        // I5: Timeseries
        .route("/api/targets", get(targets::api_list_targets).post(targets::api_create_target))
        .route("/api/targets/convergence", get(targets::api_targets_convergence))
        .route("/api/targets/auto-steer", get(targets::api_get_auto_steer).post(targets::api_set_auto_steer))
        .route("/api/targets/{id}", axum::routing::put(targets::api_update_target).delete(targets::api_delete_target))
        .route("/api/targets/{id}/coverage", get(targets::api_target_coverage))
        .route("/api/targets/{id}/forge", post(targets::api_target_forge))

        .route("/api/timeseries", get(timeseries::api_timeseries))
        // I5: Auto-Evolve
        .route("/api/auto-evolve/toggle", post(auto_evolve::api_auto_evolve_toggle))
        .route("/api/auto-evolve/status", get(auto_evolve::api_auto_evolve_status))
        // I7: Emergent Classification
        .route("/api/emergent/clusters", get(api_emergent_clusters))
        .route("/api/emergent/promote", post(api_emergent_promote))
        .route("/api/emergent/stats", get(api_emergent_stats))
        // G1: Code-Template-Registry
        .route("/api/templates", get(api_templates_list))
        .route("/api/templates/{class}", get(api_template_get))
        // S2: System status (combined endpoint for Studio dashboard)
        .route("/api/system/status", get(api_system_status))
        // S3: Integrated scraping engine control
        .route("/api/scrape/status", get(api_scrape_status))
        .route("/api/scrape/config", get(api_scrape_config_get))
        .route("/api/scrape/pause", post(api_scrape_pause))
        .route("/api/scrape/resume", post(api_scrape_resume))
        .route("/api/scrape/volume", post(api_scrape_volume))
        .route("/api/scrape/spectrum", post(api_scrape_spectrum))
        // E1: Ledger + MCI
        .route("/api/ledger/verify", get(api_ledger_verify))
        .route("/api/ledger/head", get(api_ledger_head))
        .route("/api/mci/run", post(api_mci_run))
        .route("/api/mci/history", get(api_mci_history))
        .route("/api/mci/latest", get(api_mci_latest))
        // S1/auth: Studio authentication
        .route("/api/studio/login", post(studio_auth::api_studio_login))
        .route("/api/studio/logout", post(studio_auth::api_studio_logout))
        .route("/api/studio/session", get(studio_auth::api_studio_session))
        .route("/api/studio/users", get(studio_auth::api_list_users).post(studio_auth::api_create_user))
        .route("/api/studio/users/{username}", axum::routing::put(studio_auth::api_update_user).delete(studio_auth::api_delete_user))
        // WebSocket
        .route("/events", get(ws_handler))
        .with_state(state)
}

/// Start the gateway server on the given address
pub async fn serve(state: AppState, addr: SocketAddr) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    let app = build_router(state.clone());

    // Spawn heartbeat task
    let hub = state.event_hub.clone();
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(5));
        loop {
            interval.tick().await;
            hub.publish(WsEvent::heartbeat());
        }
    });

    // I5/W1: Spawn timeseries recorder (writes every 15 minutes)
    let ts_state = state.clone();
    tokio::spawn(async move {
        timeseries::timeseries_recorder(ts_state).await;
    });

    // I5/W4: Spawn auto-evolve background task
    let ae_state = state.clone();
    let ae_enabled = state.auto_evolve_enabled.clone();
    tokio::spawn(async move {
        auto_evolve::auto_evolve_cycle(ae_state, ae_enabled).await;
    });

    // I7: Spawn emergent discovery background task (every 30 minutes)
    tokio::spawn(async move {
        let mut interval = tokio::time::interval(std::time::Duration::from_secs(1800));
        loop {
            interval.tick().await;
            let mut registry = isls_norms::emergent::load_emergent_registry();
            let promoted = isls_norms::emergent::run_emergent_cycle(&mut registry, true);
            if promoted > 0 {
                tracing::info!(
                    "[Emergent] {} new clusters promoted, {} total emergent classes",
                    promoted, registry.classes.len()
                );
            }
        }
    });

    // I7/fix: compact unclassified.jsonl once at startup (blocking, runs fast)
    tokio::task::spawn_blocking(|| {
        isls_norms::emergent::compact_unclassified();
    });

    // S3: Spawn integrated scraping engine (unless --no-scrape)
    if !state.scrape_disabled {
        let engine_state = state.clone();
        tokio::spawn(async move {
            scrape_engine::scraping_engine(engine_state).await;
        });
    } else {
        tracing::info!("[ScrapeEngine] Disabled via --no-scrape flag");
    }

    // S2/fix: Delete forge ZIPs older than 24h at startup
    tokio::task::spawn_blocking(cleanup_old_downloads);

    let listener = tokio::net::TcpListener::bind(addr).await?;
    tracing::info!("ISLS Gateway listening on {}", addr);
    tracing::info!("Studio available at http://{}/studio", addr);
    axum::serve(listener, app).await?;
    Ok(())
}

// ─── Handlers ────────────────────────────────────────────────────────────────

async fn serve_studio() -> Html<&'static str> {
    Html(STUDIO_HTML)
}

async fn health(State(state): State<AppState>) -> Json<serde_json::Value> {
    let engine = state.engine_state.read().await;
    let uptime = state.start_time.elapsed().as_secs();
    Json(serde_json::json!({
        "status": "ok",
        "version": "1.0.0",
        "uptime_secs": uptime,
        "engine_running": engine.running,
        "tick": engine.tick,
        "crystal_count": engine.crystal_count,
        "entity_count": engine.entity_count,
    }))
}

async fn status(State(state): State<AppState>) -> Json<serde_json::Value> {
    let engine = state.engine_state.read().await;
    let uptime = state.start_time.elapsed().as_secs();
    Json(serde_json::json!({
        "version": "1.0.0",
        "uptime_secs": uptime,
        "running": engine.running,
        "mode": engine.mode,
        "tick": engine.tick,
        "entity_count": engine.entity_count,
        "crystal_count": engine.crystal_count,
    }))
}

async fn dashboard(State(state): State<AppState>) -> Json<DashboardData> {
    let engine = state.engine_state.read().await;
    let uptime = state.start_time.elapsed().as_secs();
    Json(DashboardData {
        version: "1.0.0".to_string(),
        uptime_secs: uptime,
        health: "GREEN".to_string(),
        crystal_count: engine.crystal_count,
        entity_count: engine.entity_count,
        test_count: 319,
        drift: "NONE".to_string(),
        scenarios: vec![
            ScenarioSummary { name: "S-Basic".into(), crystals: 51, pass_rate: "100%".into() },
            ScenarioSummary { name: "S-Regime".into(), crystals: 22, pass_rate: "100%".into() },
            ScenarioSummary { name: "S-Causal".into(), crystals: 16, pass_rate: "100%".into() },
            ScenarioSummary { name: "S-Break".into(), crystals: 21, pass_rate: "100%".into() },
            ScenarioSummary { name: "S-Scale".into(), crystals: 36, pass_rate: "100%".into() },
        ],
        metrics: engine.metrics.clone(),
        events: vec![],
        genesis: GenesisSummary {
            hash: "a315ea43".into(),
            conformance_class: "C4".into(),
            constraints_total: 21,
            constraints_pass: 21,
            drift: "NONE".into(),
        },
    })
}

async fn metrics(State(state): State<AppState>) -> Json<serde_json::Value> {
    let engine = state.engine_state.read().await;
    Json(serde_json::to_value(&engine.metrics).unwrap_or_default())
}

async fn list_crystals(
    State(state): State<AppState>,
    Query(params): Query<CrystalQuery>,
) -> Json<Vec<CrystalSummary>> {
    let engine = state.engine_state.read().await;
    let limit = params.limit.unwrap_or(50);
    let mut crystals = engine.crystals.clone();
    if let Some(ref scale) = params.scale {
        crystals.retain(|c| c.scale == *scale);
    }
    if let Some(ref search) = params.search {
        crystals.retain(|c| c.id.contains(search));
    }
    crystals.truncate(limit);
    Json(crystals)
}

async fn get_crystal(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<CrystalSummary>, StatusCode> {
    let engine = state.engine_state.read().await;
    engine.crystals.iter()
        .find(|c| c.id == id || c.id.starts_with(&id))
        .cloned()
        .map(Json)
        .ok_or(StatusCode::NOT_FOUND)
}

async fn start_forge(
    State(state): State<AppState>,
    Json(req): Json<ForgeRequest>,
) -> Json<serde_json::Value> {
    let mut forge = state.forge_state.write().await;
    forge.active = true;
    forge.progress = Some(ForgeProgress {
        phase: "init".into(),
        index: 0,
        total: req.max_atoms.unwrap_or(10),
        atom_name: "".into(),
        source: "".into(),
        status: "starting".into(),
        atoms: vec![],
        output_files: vec![],
        composition_tree: None,
    });

    // Publish forge start event
    state.event_hub.publish(WsEvent::forge_progress(
        "init", 0, req.max_atoms.unwrap_or(10), "", "", "starting",
    ));

    Json(serde_json::json!({
        "ok": true,
        "message": "Forge started",
        "intent": req.intent,
        "domain": req.domain,
        "template": req.template,
    }))
}

async fn forge_progress(State(state): State<AppState>) -> Json<serde_json::Value> {
    let forge = state.forge_state.read().await;
    if let Some(ref progress) = forge.progress {
        Json(serde_json::to_value(progress).unwrap_or_default())
    } else {
        Json(serde_json::json!({"active": false}))
    }
}

async fn start_foundry(
    State(state): State<AppState>,
    Json(req): Json<FoundryRequest>,
) -> Json<serde_json::Value> {
    let mut foundry = state.foundry_state.write().await;
    foundry.active = true;
    let project_id = format!("proj-{:08x}", rand_u32());
    foundry.progress = Some(FoundryProgress {
        phase: "init".into(),
        attempt: 0,
        max_attempts: 5,
        status: "starting".into(),
        error: None,
        template_name: None,
        atoms_done: 0,
        atoms_total: 0,
        log: vec![format!("Fabrication started: {}", req.intent)],
        file_tree: vec![],
    });

    state.event_hub.publish(WsEvent::foundry_progress(
        "init", 0, 5, "starting", None,
    ));

    Json(serde_json::json!({
        "ok": true,
        "project_id": project_id,
        "message": "Fabrication started",
        "intent": req.intent,
    }))
}

async fn foundry_progress(State(state): State<AppState>) -> Json<serde_json::Value> {
    let foundry = state.foundry_state.read().await;
    if let Some(ref progress) = foundry.progress {
        Json(serde_json::to_value(progress).unwrap_or_default())
    } else {
        Json(serde_json::json!({"active": false}))
    }
}

async fn foundry_files(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Json<serde_json::Value>, StatusCode> {
    let foundry = state.foundry_state.read().await;
    foundry.projects.get(&id)
        .map(|p| Json(serde_json::to_value(&p.files).unwrap_or_default()))
        .ok_or(StatusCode::NOT_FOUND)
}

async fn foundry_download(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Result<Response, StatusCode> {
    let foundry = state.foundry_state.read().await;
    let project = foundry.projects.get(&id).ok_or(StatusCode::NOT_FOUND)?;

    // Build a simple JSON bundle (ZIP would require a zip library)
    let body = serde_json::to_vec_pretty(&project.files).unwrap_or_default();
    Ok((
        StatusCode::OK,
        [
            ("content-type", "application/json"),
            ("content-disposition", &format!("attachment; filename=\"{}.json\"", id)),
        ],
        body,
    ).into_response())
}

async fn execute_command(
    State(state): State<AppState>,
    Json(req): Json<CommandRequest>,
) -> Json<CommandResponse> {
    let parts: Vec<&str> = req.command.split_whitespace().collect();
    if parts.is_empty() {
        return Json(CommandResponse { ok: false, message: "Empty command".into(), data: None });
    }

    match parts[0] {
        "start" => {
            let mut engine = state.engine_state.write().await;
            engine.running = true;
            if parts.len() > 2 && parts[1] == "engine" {
                engine.mode = parts.get(2).unwrap_or(&"live").to_string();
            }
            Json(CommandResponse { ok: true, message: "Engine started".into(), data: None })
        }
        "stop" => {
            let mut engine = state.engine_state.write().await;
            engine.running = false;
            Json(CommandResponse { ok: true, message: "Engine stopped".into(), data: None })
        }
        "show" => {
            if parts.len() > 1 && parts[1] == "crystal" {
                let id = parts.get(2).unwrap_or(&"");
                let engine = state.engine_state.read().await;
                let crystal = engine.crystals.iter().find(|c| c.id.starts_with(id));
                Json(CommandResponse {
                    ok: crystal.is_some(),
                    message: if crystal.is_some() { "Found".into() } else { "Not found".into() },
                    data: crystal.map(|c| serde_json::to_value(c).unwrap_or_default()),
                })
            } else {
                Json(CommandResponse { ok: false, message: "Unknown show target".into(), data: None })
            }
        }
        "oracle" => {
            Json(CommandResponse {
                ok: true,
                message: "Oracle status".into(),
                data: Some(serde_json::json!({
                    "provider": "Claude",
                    "temperature": 0.0,
                    "max_tokens": 4096,
                    "memory_first": true,
                })),
            })
        }
        "template" => {
            Json(CommandResponse {
                ok: true,
                message: "Template commands available".into(),
                data: Some(serde_json::json!({"available": ["list", "show", "create"]})),
            })
        }
        "validate" => {
            Json(CommandResponse { ok: true, message: "Validation started".into(), data: None })
        }
        "export" => {
            Json(CommandResponse { ok: true, message: "Export initiated".into(), data: None })
        }
        _ => {
            let msg = format!("Unknown command: {}", parts.join(" "));
            Json(CommandResponse { ok: false, message: msg, data: None })
        }
    }
}

async fn engine_start(State(state): State<AppState>) -> Json<serde_json::Value> {
    let mut engine = state.engine_state.write().await;
    engine.running = true;
    Json(serde_json::json!({"ok": true, "message": "Engine started"}))
}

async fn engine_stop(State(state): State<AppState>) -> Json<serde_json::Value> {
    let mut engine = state.engine_state.write().await;
    engine.running = false;
    Json(serde_json::json!({"ok": true, "message": "Engine stopped"}))
}

async fn engine_step(State(state): State<AppState>) -> Json<serde_json::Value> {
    let mut engine = state.engine_state.write().await;
    engine.tick += 1;
    Json(serde_json::json!({"ok": true, "tick": engine.tick}))
}

// ─── C30 Agent Handlers ──────────────────────────────────────────────────────

/// GET /agent/status — read AgentState from ~/.isls/agent/state.json
async fn agent_status() -> Json<serde_json::Value> {
    let path = agent_state_path();
    match std::fs::read_to_string(&path) {
        Ok(json) => {
            let state: serde_json::Value = serde_json::from_str(&json).unwrap_or_default();
            Json(serde_json::json!({
                "ok": true,
                "state": state,
            }))
        }
        Err(_) => Json(serde_json::json!({
            "ok": false,
            "state": null,
            "message": "No agent state. Run 'isls agent <intent>' or POST /agent/goal first.",
        })),
    }
}

/// POST /agent/goal — create an agent from a goal description and run to completion
async fn agent_goal(
    Json(req): Json<AgentGoalRequest>,
) -> Json<serde_json::Value> {
    use isls_agent::{Agent, AgentConfig, AgentGoal};

    let mut goal = AgentGoal::new(&req.intent)
        .with_confidence(req.confidence.unwrap_or(0.75));
    if let Some(ref d) = req.domain {
        goal = goal.with_domain(d.as_str());
    }
    if let Some(ref cs) = req.constraints {
        for c in cs {
            goal = goal.with_constraint(c.as_str());
        }
    }

    let max_steps = req.max_steps.unwrap_or(100).min(500);
    let config = AgentConfig { max_steps, ..Default::default() };
    let mut agent = Agent::new(config, goal);
    let steps = agent.run(0);

    let path = agent_state_path();
    let save_ok = agent.state.save(&path).is_ok();

    Json(serde_json::json!({
        "ok": true,
        "intent": req.intent,
        "steps_run": steps.len(),
        "best_score": agent.best_score(),
        "complete": agent.is_complete(),
        "plan_size": agent.state.plan.actions.len(),
        "state_saved": save_ok,
    }))
}

/// POST /agent/step — execute one step from persisted state
async fn agent_step_handler() -> Json<serde_json::Value> {
    use isls_agent::{Agent, AgentConfig, AgentState};

    let path = agent_state_path();
    match AgentState::load(&path) {
        Err(_) => Json(serde_json::json!({
            "ok": false,
            "message": "No agent state. POST /agent/goal first.",
        })),
        Ok(state) => {
            let config = AgentConfig::default();
            let mut agent = Agent { config, state };
            match agent.step() {
                None => Json(serde_json::json!({
                    "ok": true,
                    "complete": true,
                    "message": "Agent is already complete.",
                })),
                Some(s) => {
                    let save_ok = agent.state.save(&path).is_ok();
                    Json(serde_json::json!({
                        "ok": true,
                        "step_id": s.step_id,
                        "action": s.action.action_type.label(),
                        "outcome": s.outcome,
                        "score": s.score,
                        "complete": agent.is_complete(),
                        "state_saved": save_ok,
                    }))
                }
            }
        }
    }
}

/// GET /agent/history — return full step history from persisted state
async fn agent_history() -> Json<serde_json::Value> {
    let path = agent_state_path();
    match std::fs::read_to_string(&path) {
        Ok(json) => {
            let state: serde_json::Value = serde_json::from_str(&json).unwrap_or_default();
            let history = state.get("history").cloned().unwrap_or(serde_json::Value::Array(vec![]));
            let steps = history.as_array().map(|a| a.len()).unwrap_or(0);
            Json(serde_json::json!({
                "ok": true,
                "steps": steps,
                "history": history,
            }))
        }
        Err(_) => Json(serde_json::json!({
            "ok": false,
            "history": [],
            "message": "No agent state.",
        })),
    }
}

// ─── C30 Agent Chat Handlers ─────────────────────────────────────────────────

/// POST /agent/chat — start a background chat job, return job_id immediately
async fn agent_chat_start(
    State(state): State<AppState>,
    Json(req): Json<ChatRequest>,
) -> Json<serde_json::Value> {
    let job_id = format!("chat-{:08x}", rand_u32());

    {
        let mut jobs = state.chat_jobs.write().await;
        jobs.insert(job_id.clone(), chat::ChatJob::new(job_id.clone()));
    }

    // Spawn background task
    let jobs = state.chat_jobs.clone();
    let bound = state.bound_project.clone();
    let req_clone = req.clone();
    let job_clone = job_id.clone();
    tokio::spawn(async move {
        run_chat_job(jobs, job_clone, req_clone, bound).await;
    });

    Json(serde_json::json!({
        "ok": true,
        "job_id": job_id,
    }))
}

/// GET /agent/chat/{job_id}/events — poll accumulated events for a job
async fn agent_chat_events(
    State(state): State<AppState>,
    Path(job_id): Path<String>,
) -> Json<serde_json::Value> {
    let jobs = state.chat_jobs.read().await;
    match jobs.get(&job_id) {
        Some(job) => Json(serde_json::json!({
            "ok": true,
            "events": job.events,
            "complete": job.complete,
        })),
        None => Json(serde_json::json!({
            "ok": false,
            "error": "job not found",
        })),
    }
}

// ─── v3 Norm API handlers ─────────────────────────────────────────────────

/// GET /api/norms — list all norms in the registry.
async fn api_list_norms(State(state): State<AppState>) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let summaries: Vec<NormSummary> = registry.all_norms().into_iter().map(|n| NormSummary {
        id:                n.id.clone(),
        name:              n.name.clone(),
        level:             format!("{:?}", n.level),
        description:       n.name.clone(),
        observation_count: n.evidence.usage_count,
        domains:           n.evidence.domains_used.clone(),
        builtin:           n.evidence.builtin,
    }).collect();
    Json(serde_json::json!({ "ok": true, "norms": summaries }))
}

/// GET /api/norms/candidates — list self-discovered norm candidates.
async fn api_list_norm_candidates(State(state): State<AppState>) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let candidates: Vec<serde_json::Value> = registry.candidates().into_iter().map(|c| serde_json::json!({
        "id":           c.id,
        "observations": c.observation_count,
        "consistency":  c.consistency,
        "status":       format!("{:?}", c.status),
    })).collect();
    Json(serde_json::json!({ "ok": true, "candidates": candidates }))
}

/// I6: GET /api/capabilities — return the capability register.
async fn api_capabilities(State(state): State<AppState>) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let capabilities = isls_norms::compute_capabilities(&registry);
    let items: Vec<serde_json::Value> = capabilities.iter().map(|c| serde_json::json!({
        "class": c.class.as_str(),
        "status": c.status.as_str(),
        "norm_id": c.norm_id,
        "candidate_obs": c.candidate_obs,
        "candidate_domains": c.candidate_domains,
    })).collect();
    Json(serde_json::json!({ "ok": true, "capabilities": items }))
}

/// GET /api/norms/fitness — return norm fitness scores from FitnessStore.
async fn api_norms_fitness(_state: State<AppState>) -> Json<serde_json::Value> {
    let store = isls_norms::fitness::FitnessStore::load();
    let entries = store.sorted_entries();
    let norms: Vec<serde_json::Value> = entries.iter().map(|e| serde_json::json!({
        "id":          e.norm_id,
        "fitness":     e.fitness,
        "activations": e.activation_count,
        "successes":   e.success_count,
        "failures":    e.failure_count,
    })).collect();
    Json(serde_json::json!({ "ok": true, "norms": norms, "total": norms.len() }))
}

/// GET /api/norms/genome — return gene clusters (I2/W2).
async fn api_norms_genome(_state: State<AppState>) -> Json<serde_json::Value> {
    use isls_norms::genome::{compute_genome, load_metrics_lite, MIN_METRICS_ENTRIES};
    let metrics = load_metrics_lite();
    let genome = compute_genome(&metrics, isls_norms::genome::DEFAULT_MIN_COACTIVATION);
    let genes: Vec<serde_json::Value> = genome.genes.iter().map(|g| serde_json::json!({
        "id":          g.id,
        "name":        g.name,
        "coactivation":g.coactivation,
        "fitness":     g.fitness,
        "norms":       g.norms,
        "domains":     g.domains.iter().take(5).collect::<Vec<_>>(),
        "activations": g.activation_count,
    })).collect();
    Json(serde_json::json!({
        "ok": true,
        "generation":    genome.generation,
        "total_metrics": genome.total_metrics,
        "enough_data":   metrics.len() >= MIN_METRICS_ENTRIES,
        "min_required":  MIN_METRICS_ENTRIES,
        "genes":         genes,
        "singletons":    genome.singletons,
    }))
}

/// GET /api/norms/anatomy — anatomical norm catalog organized by body layers.
async fn api_norms_anatomy(State(state): State<AppState>) -> Json<serde_json::Value> {
    // Load fresh norm data from disk
    let reg = state.norm_registry.read().await;
    let all_norms = reg.all_norms();
    let candidates_owned = reg.candidates();
    let candidates: Vec<&isls_norms::learning::NormCandidate> = candidates_owned.iter().copied().collect();
    let fitness_store = isls_norms::fitness::FitnessStore::load();

    let layers = isls_norms::anatomy::compute_anatomy(&all_norms, &candidates, &fitness_store);
    let total = isls_norms::anatomy::total_coverage(&layers);

    Json(serde_json::json!({
        "ok": true,
        "layers": layers,
        "total_coverage": total,
    }))
}

/// POST /api/norms/inject — inject a norm blueprint from JSON body.
async fn api_norms_inject(
    State(state): State<AppState>,
    Json(body): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let json_str = match serde_json::to_string(&body) {
        Ok(s) => s,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("JSON error: {}", e) })),
    };
    let blueprint = match isls_norms::injection::parse_blueprint(&json_str) {
        Ok(b) => b,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("Blueprint error: {}", e) })),
    };
    let mut registry = state.norm_registry.write().await;
    match isls_norms::injection::inject_norm(&mut *registry, blueprint) {
        Ok(id) => {
            // Append to append-only ledger
            if let Some(norm) = registry.get(&id) {
                let _ = isls_norms::mef_chain::append_chained_event(
                    &isls_norms::ledger::norm_injected_event(norm),
                );
            }
            drop(registry);
            Json(serde_json::json!({ "ok": true, "id": id }))
        }
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("{}", e) })),
    }
}

#[derive(Debug, Deserialize)]
struct EvolveRequest {
    from: String,
    delta: String,
    #[serde(default)]
    scrape_gaps: bool,
}

/// POST /api/evolve — Solve-Coagula cycle (I3/W3).
///
/// Runs Solve (parse + topology) and Spectroscopy synchronously, then
/// optionally launches a background mass-scrape for the gap keywords.
/// Returns the before-state spectroscopy result plus a session_id the
/// Studio can hand off to the Erschaffen mode for the Coagula (forge) step.
async fn api_evolve(
    State(state): State<AppState>,
    Json(req): Json<EvolveRequest>,
) -> Json<serde_json::Value> {
    let from_path = std::path::PathBuf::from(&req.from);
    if !from_path.is_dir() {
        return Json(serde_json::json!({
            "ok": false,
            "error": format!("'{}' is not a directory", req.from),
        }));
    }

    let hub = state.event_hub.clone();
    let delta = req.delta.clone();
    let scrape_gaps = req.scrape_gaps;
    let from_str = req.from.clone();
    let registry_arc = state.norm_registry.clone();
    let mass_scrape_jobs = state.mass_scrape_jobs.clone();
    let scrape_history = state.scrape_history.clone();
    let suggested_kw_path = state.suggested_keywords_path.clone();

    hub.publish(WsEvent::new(ws::EventType::EvolveProgress, serde_json::json!({
        "phase": "solve",
        "message": format!("Parsing {}...", from_str),
    })));

    let result = tokio::task::spawn_blocking(move || -> serde_json::Value {
        // ── SOLVE ──────────────────────────────────────────────────────────
        let analysis = match isls_reader::parse_directory(&from_path) {
            Ok(a) => a,
            Err(e) => return serde_json::json!({ "ok": false, "error": format!("Parse: {}", e) }),
        };

        let topology = isls_code_topo::compute_code_topology(&analysis.files);
        let (artifacts, _) = isls_code_topo::bridge::observations_from_code(&analysis.files);

        // Feed norms from the source (observe_and_learn appends to ledger)
        {
            let domain = isls_code_topo::bridge::domain_from_path(&from_path);
            let ts = chrono::Local::now().format("%Y%m%d_%H%M%S");
            let run_id = format!("evolve_solve_{}_{}", domain, ts);
            let mut reg = isls_norms::NormRegistry::new();
            reg.observe_and_learn(&artifacts, &domain, &run_id);
        }

        // ── SPECTROSCOPY ────────────────────────────────────────────────────
        let resonites: Vec<isls_norms::spectroscopy::Resonite> = {
            use isls_norms::spectroscopy::{Resonite, ResoniteTypeKind};
            let mut out = Vec::new();
            for file in &analysis.files {
                for f in &file.functions {
                    out.push(Resonite::Fn { name: f.name.clone(), arity: f.params.len() });
                }
                for s in &file.structs {
                    let kind = if s.derives.iter().any(|d| d.to_lowercase().contains("enum")) {
                        ResoniteTypeKind::Enum
                    } else {
                        ResoniteTypeKind::Struct
                    };
                    out.push(Resonite::Type { name: s.name.clone(), kind });
                }
                for i in &file.imports {
                    out.push(Resonite::Import { path: i.clone() });
                }
            }
            out
        };

        let reg = isls_norms::NormRegistry::new();
        let spec_result = isls_norms::spectroscopy::spectroscopy(&resonites, &reg);

        // Collect gap keywords
        let gap_keywords: Vec<String> = spec_result.suggestions.iter()
            .flat_map(|s| s.keywords.iter().cloned())
            .collect::<std::collections::BTreeSet<_>>()
            .into_iter()
            .collect();

        serde_json::json!({
            "ok": true,
            "from": from_path.display().to_string(),
            "delta": delta,
            "scrape_gaps": scrape_gaps,
            "solve": {
                "files": analysis.files.len(),
                "artifacts": artifacts.len(),
                "primary_language": topology.primary_language,
            },
            "spectroscopy": {
                "coverage": spec_result.coverage,
                "gaps": spec_result.gaps.len(),
                "covered": spec_result.covered.len(),
                "gap_classes": spec_result.gaps.iter().map(|g| g.class.as_str()).collect::<Vec<_>>(),
                "covered_classes": spec_result.covered.iter().map(|c| c.as_str()).collect::<Vec<_>>(),
            },
            "gap_keywords": gap_keywords,
        })
    }).await;

    let data = match result {
        Ok(d) => d,
        Err(e) => return Json(serde_json::json!({ "ok": false, "error": format!("Task panicked: {}", e) })),
    };

    if !data["ok"].as_bool().unwrap_or(false) {
        return Json(data);
    }

    hub.publish(WsEvent::new(ws::EventType::EvolveProgress, serde_json::json!({
        "phase": "spectroscopy",
        "coverage": data["spectroscopy"]["coverage"],
        "gaps": data["spectroscopy"]["gaps"],
    })));

    // Optionally launch background scrape for gap keywords
    let fill_job_id = if scrape_gaps {
        let gap_kws: Vec<String> = data["gap_keywords"]
            .as_array()
            .unwrap_or(&vec![])
            .iter()
            .filter_map(|v| v.as_str().map(String::from))
            .collect();

        if !gap_kws.is_empty() {
            let fill_id = format!("evfill-{:08x}", rand_u32());
            let fill_job = discover::MassScrapeJob {
                id: fill_id.clone(),
                status: "running".to_string(),
                keywords_total: gap_kws.len(),
                keywords_done: 0,
                repos_scraped: 0,
                repos_failed: 0,
                new_candidates: 0,
                new_norms: 0,
                errors: vec![],
            };
            mass_scrape_jobs.write().await.insert(fill_id.clone(), fill_job);

            let jobs_cl = mass_scrape_jobs.clone();
            let hub_cl = hub.clone();
            let hist_cl = scrape_history.clone();
            let kw_path_cl = suggested_kw_path.clone();
            let fid = fill_id.clone();
            tokio::spawn(async move {
                discover::run_mass_scrape(jobs_cl, hub_cl, hist_cl, kw_path_cl, fid, gap_kws, 3).await;
            });

            hub.publish(WsEvent::new(ws::EventType::EvolveProgress, serde_json::json!({
                "phase": "fill",
                "job_id": fill_id,
                "message": "Gap-Fill scrape gestartet",
            })));
            Some(fill_id)
        } else {
            None
        }
    } else {
        None
    };

    hub.publish(WsEvent::new(ws::EventType::EvolveComplete, serde_json::json!({
        "from": data["from"],
        "delta": data["delta"],
        "solve":  data["solve"],
        "spectroscopy": data["spectroscopy"],
        "fill_job_id": fill_job_id,
    })));

    Json(serde_json::json!({
        "ok": true,
        "from": data["from"],
        "delta": req.delta,
        "solve":  data["solve"],
        "spectroscopy": data["spectroscopy"],
        "gap_keywords": data["gap_keywords"],
        "fill_job_id": fill_job_id,
    }))
}

/// GET /api/norms/:id — get a single norm by id.
async fn api_get_norm(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    match registry.get(&id) {
        Some(n) => Json(serde_json::json!({ "ok": true, "norm": n })),
        None    => Json(serde_json::json!({ "ok": false, "error": "norm not found" })),
    }
}

// ─── N1: Relations, Groups, Energy, Optimize API handlers ───────────────────

/// GET /api/norms/relations — compute and return norm relation matrix.
async fn api_norms_relations(State(state): State<AppState>) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let norms: Vec<isls_norms::Norm> = registry.all_norms().into_iter().cloned().collect();
    let matrix = isls_norms::relations::compute_relations(&norms);
    let _ = isls_norms::relations::save_relations(&matrix, None);
    Json(serde_json::json!({ "ok": true, "relations": matrix }))
}

/// GET /api/norms/groups — detect and return norm groups.
async fn api_norms_groups(State(state): State<AppState>) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let norms: Vec<isls_norms::Norm> = registry.all_norms().into_iter().cloned().collect();
    let matrix = isls_norms::relations::compute_relations(&norms);
    let groups = isls_norms::groups::detect_groups(&norms, &matrix);
    let _ = isls_norms::groups::save_groups(&groups, None);
    Json(serde_json::json!({ "ok": true, "groups": groups }))
}

/// POST /api/norms/energy — compute configuration energy.
async fn api_norms_energy_compute(
    State(state): State<AppState>,
    Json(req): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let norm_ids: Vec<String> = req.get("norms")
        .and_then(|v| v.as_array())
        .map(|arr| arr.iter().filter_map(|v| v.as_str().map(String::from)).collect())
        .unwrap_or_default();

    if norm_ids.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "No norm IDs provided" }));
    }

    let registry = state.norm_registry.read().await;
    let norms: Vec<isls_norms::Norm> = registry.all_norms().into_iter().cloned().collect();
    let matrix = isls_norms::relations::compute_relations(&norms);
    let fitness_store = isls_norms::fitness::FitnessStore::load();
    let fitness: std::collections::HashMap<String, f64> = norms.iter()
        .map(|n| (n.id.clone(), fitness_store.get_fitness(&n.id)))
        .collect();

    let energy = isls_norms::energy::configuration_energy(&norm_ids, &matrix, &fitness);
    Json(serde_json::json!({ "ok": true, "energy": energy }))
}

/// POST /api/norms/optimize — find optimal configuration for requirements.
async fn api_norms_optimize(
    State(state): State<AppState>,
    Json(req): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let requirements: Vec<String> = req.get("requirements")
        .and_then(|v| v.as_array())
        .map(|arr| arr.iter().filter_map(|v| v.as_str().map(String::from)).collect())
        .unwrap_or_default();

    if requirements.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "No requirements provided" }));
    }

    let registry = state.norm_registry.read().await;
    let norms: Vec<isls_norms::Norm> = registry.all_norms().into_iter().cloned().collect();
    let matrix = isls_norms::relations::compute_relations(&norms);
    let groups = isls_norms::groups::detect_groups(&norms, &matrix);
    let fitness_store = isls_norms::fitness::FitnessStore::load();
    let fitness: std::collections::HashMap<String, f64> = norms.iter()
        .map(|n| (n.id.clone(), fitness_store.get_fitness(&n.id)))
        .collect();

    let req_classes: Vec<isls_norms::spectroscopy::ResoniteClass> = requirements.iter()
        .map(|r| match r.as_str() {
            "CrudEntity" => isls_norms::spectroscopy::ResoniteClass::CrudEntity,
            "Authentication" => isls_norms::spectroscopy::ResoniteClass::Authentication,
            "Pagination" => isls_norms::spectroscopy::ResoniteClass::Pagination,
            "Search" => isls_norms::spectroscopy::ResoniteClass::Search,
            "FileUpload" => isls_norms::spectroscopy::ResoniteClass::FileUpload,
            "Notification" => isls_norms::spectroscopy::ResoniteClass::Notification,
            "StateMachine" => isls_norms::spectroscopy::ResoniteClass::StateMachine,
            "Workflow" => isls_norms::spectroscopy::ResoniteClass::Workflow,
            "Caching" => isls_norms::spectroscopy::ResoniteClass::Caching,
            "RealtimeWebSocket" => isls_norms::spectroscopy::ResoniteClass::RealtimeWebSocket,
            other => isls_norms::spectroscopy::ResoniteClass::Custom(other.to_string()),
        })
        .collect();

    let result = isls_norms::optimizer::optimize_configuration(
        &req_classes, &norms, &matrix, &fitness, &groups,
    );
    Json(serde_json::json!({ "ok": true, "optimal": result }))
}

// ─── v3 Projects API handlers ─────────────────────────────────────────────

/// GET /api/projects — list all projects.
async fn api_list_projects(State(state): State<AppState>) -> Json<serde_json::Value> {
    let store = state.project_store.read().await;
    let projects: Vec<&ProjectEntry> = store.values().collect();
    Json(serde_json::json!({ "ok": true, "projects": projects }))
}

/// POST /api/projects — create a new project entry.
async fn api_create_project(
    State(state): State<AppState>,
    Json(req): Json<CreateProjectRequest>,
) -> Json<serde_json::Value> {
    let id = format!("proj-{:08x}", rand_u32());
    let entry = ProjectEntry {
        id: id.clone(),
        name: req.name,
        toml_content: req.toml_content,
        domain: req.domain,
        output_dir: None,
        status: "created".to_string(),
        created_at: chrono::Utc::now().to_rfc3339(),
        norms_used: Vec::new(),
        stats: None,
    };
    state.project_store.write().await.insert(id.clone(), entry);
    Json(serde_json::json!({ "ok": true, "id": id }))
}

/// GET /api/projects/:id — get a single project.
async fn api_get_project(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let store = state.project_store.read().await;
    match store.get(&id) {
        Some(p) => Json(serde_json::json!({ "ok": true, "project": p })),
        None    => Json(serde_json::json!({ "ok": false, "error": "project not found" })),
    }
}

/// DELETE /api/projects/:id — delete a project.
async fn api_delete_project(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let removed = state.project_store.write().await.remove(&id).is_some();
    Json(serde_json::json!({ "ok": removed }))
}

// ─── v3 Chat API handlers ─────────────────────────────────────────────────

/// POST /api/chat — norm-aware chat endpoint with plan composition (v3.2).
async fn api_chat(
    State(state): State<AppState>,
    Json(req): Json<ApiChatRequest>,
) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let intent = isls_chat::extract_intent_keywords(&req.message);
    let ops = isls_chat::intent_to_norm_ops(&intent, &registry);

    let intent_str = format!("{:?}", intent.intent_type);

    // For CreateApplication: compose norms into a plan and store it
    if intent.intent_type == isls_chat::IntentType::CreateApplication {
        if let Some(isls_chat::NormOperation::ComposeNew(ref activated_norms)) = ops.first() {
            let norm_ids: Vec<String> = activated_norms.iter().map(|a| a.norm.id.clone()).collect();

            // Compose norms into a plan
            let params = HashMap::new();
            match isls_norms::composition::compose_norms(activated_norms, &params) {
                Ok(composed) => {
                    let entity_count = composed.models.len();
                    let service_count = composed.services.len();
                    let api_count = composed.api.len();
                    let entity_names: Vec<String> = composed.models.iter().map(|m| m.struct_name.clone()).collect();

                    // Estimate files and LOC
                    let estimated_files = 10 + entity_count * 4 + 3; // static + per-entity + frontend
                    let estimated_loc = estimated_files * 80; // ~80 LOC per file average

                    let plan_id = format!("plan-{:08x}", rand_u32());
                    let description = format_plan_description(&entity_names, &norm_ids, service_count, api_count);

                    // Store pending plan
                    let pending = PendingPlan {
                        id: plan_id.clone(),
                        description: description.clone(),
                        composed_plan: composed,
                        activated_norms: norm_ids.clone(),
                        estimated_files,
                        estimated_loc,
                        created_at: chrono::Utc::now().to_rfc3339(),
                    };
                    drop(registry); // release read lock before writing
                    state.pending_plans.write().await.insert(plan_id.clone(), pending);

                    let message = format!(
                        "I'll build a {} with {} entities, {} services, and ~{} API endpoints. \
                         Estimated {} files (~{} lines of code). Click [Generate] to start.",
                        req.message, entity_count, service_count, api_count,
                        estimated_files, estimated_loc
                    );

                    let resp = ApiChatResponse {
                        message,
                        intent: intent_str,
                        norms_activated: norm_ids,
                        entities: entity_names,
                        estimated_files,
                        estimated_loc,
                        plan_id: Some(plan_id),
                        plan_description: Some(description),
                        action_buttons: vec![
                            ActionButton { label: "Generate".into(), action: "forge".into(), style: "primary".into() },
                            ActionButton { label: "Customize".into(), action: "customize".into(), style: "secondary".into() },
                        ],
                    };
                    return Json(serde_json::to_value(resp).unwrap_or(serde_json::json!({ "ok": false })));
                }
                Err(e) => {
                    let resp = ApiChatResponse {
                        message: format!("Norm composition failed: {}", e),
                        intent: intent_str,
                        norms_activated: norm_ids,
                        entities: vec![],
                        estimated_files: 0,
                        estimated_loc: 0,
                        plan_id: None,
                        plan_description: None,
                        action_buttons: vec![],
                    };
                    return Json(serde_json::to_value(resp).unwrap_or(serde_json::json!({ "ok": false })));
                }
            }
        }
    }

    // Non-CreateApplication intents
    let activated: Vec<String> = if let Some(isls_chat::NormOperation::ComposeNew(ref norms)) = ops.first() {
        norms.iter().map(|a| a.norm.id.clone()).collect()
    } else {
        vec![]
    };

    let estimated_files: usize = ops.iter()
        .map(|op| isls_chat::affected_files(op).len())
        .sum();

    let message = match intent.intent_type {
        isls_chat::IntentType::Help => "I can help you build full-stack applications. \
            Describe what you need, e.g. 'I need a warehouse inventory management system with products, orders, and suppliers.'".to_string(),
        isls_chat::IntentType::AddField => format!(
            "I'll add {} field(s) to the specified entities. {} files will be regenerated.",
            intent.fields.len(), estimated_files
        ),
        _ => format!("Detected intent: {}. {} norms activated.", intent_str, activated.len()),
    };

    let resp = ApiChatResponse {
        message,
        intent: intent_str,
        norms_activated: activated,
        entities: intent.entities.clone(),
        estimated_files,
        estimated_loc: estimated_files * 80,
        plan_id: None,
        plan_description: None,
        action_buttons: vec![],
    };
    Json(serde_json::to_value(resp).unwrap_or(serde_json::json!({ "ok": false })))
}

/// Format a human-readable plan description from entities and norms.
fn format_plan_description(entities: &[String], norms: &[String], service_count: usize, api_count: usize) -> String {
    let entity_list = if entities.len() <= 5 {
        entities.join(", ")
    } else {
        format!("{}, ... ({} total)", entities[..3].join(", "), entities.len())
    };
    let feature_highlights: Vec<&str> = norms.iter().filter_map(|id| match id.as_str() {
        "ISLS-NORM-0088" => Some("JWT Authentication"),
        "ISLS-NORM-0096" => Some("Pagination"),
        "ISLS-NORM-0103" => Some("Error System"),
        "ISLS-NORM-0112" => Some("Inventory Tracking"),
        "ISLS-NORM-0120" => Some("Order State Machine"),
        "ISLS-NORM-0130" => Some("Docker"),
        "ISLS-NORM-0137" => Some("Health Checks"),
        _ => None,
    }).collect();

    let mut desc = format!("Entities: {}. {} services, ~{} API endpoints.", entity_list, service_count, api_count);
    if !feature_highlights.is_empty() {
        desc.push_str(&format!(" Features: {}.", feature_highlights.join(", ")));
    }
    desc
}

/// POST /api/projects/forge — generate a project from a pending plan (v3.2).
async fn api_forge(
    State(state): State<AppState>,
    Json(req): Json<ApiForgeRequest>,
) -> Json<serde_json::Value> {
    // Retrieve the pending plan
    let plan = {
        let plans = state.pending_plans.read().await;
        plans.get(&req.plan_id).cloned()
    };

    let plan = match plan {
        Some(p) => p,
        None => {
            return Json(serde_json::json!({
                "ok": false,
                "error": format!("Plan '{}' not found. POST /api/chat first.", req.plan_id),
            }));
        }
    };

    // Build ForgePlan from ComposedPlan
    let app_name = format!("app-{:08x}", rand_u32());
    let forge_plan = isls_forge_llm::ForgePlan::from_composed_plan(
        &app_name,
        &plan.description,
        &plan.composed_plan,
    );

    // Create output directory
    let output_dir = state.projects_dir.join(&app_name);
    if let Err(e) = std::fs::create_dir_all(&output_dir) {
        return Json(serde_json::json!({
            "ok": false,
            "error": format!("Failed to create output directory: {}", e),
        }));
    }

    // Build oracle with the shared helper so api_forge uses the same
    // configuration as the chat path (`/api/chat/plain`).
    // Priority: use_ollama → Ollama ; req/env api_key → OpenAI ; else Mock.
    let session_api_key = req.api_key
        .or_else(|| std::env::var("OPENAI_API_KEY").ok());
    let oracle_config = state.oracle_config.clone();
    let output_dir_clone = output_dir.clone();

    // Run the forge on a blocking thread — the Ollama / OpenAI oracles use
    // `reqwest::blocking`, which must not run on the async runtime's worker.
    let forge_result = tokio::task::spawn_blocking(move || {
        let (oracle, mock_mode) = build_forge_oracle(&oracle_config, session_api_key);
        let mut forge = isls_forge_llm::LlmForge::new(
            oracle,
            forge_plan,
            output_dir_clone,
            mock_mode,
        );
        forge.generate().map(|files| (files, forge.stats))
    })
    .await;

    let (files, stats_raw) = match forge_result {
        Ok(Ok(x)) => x,
        Ok(Err(e)) => return Json(serde_json::json!({
            "ok": false,
            "error": format!("Forge generation failed: {}", e),
        })),
        Err(e) => return Json(serde_json::json!({
            "ok": false,
            "error": format!("Forge task panicked: {}", e),
        })),
    };

    let total_loc: usize = files.iter().map(|f| f.content.lines().count()).sum();
    let project_id = format!("proj-{:08x}", rand_u32());

    let stats = ProjectStats {
        files_generated: files.len(),
        total_loc,
        total_tokens: stats_raw.total_tokens,
        compile_status: if stats_raw.compile_failures == 0 { "ok" } else { "errors" }.to_string(),
        duration_secs: stats_raw.total_time_secs,
    };

    // Store project entry
    let entry = ProjectEntry {
        id: project_id.clone(),
        name: app_name.clone(),
        toml_content: String::new(),
        domain: None,
        output_dir: Some(output_dir.to_string_lossy().to_string()),
        status: "completed".to_string(),
        created_at: chrono::Utc::now().to_rfc3339(),
        norms_used: plan.activated_norms.clone(),
        stats: Some(stats.clone()),
    };
    state.project_store.write().await.insert(project_id.clone(), entry);

    // Remove used plan
    state.pending_plans.write().await.remove(&req.plan_id);

    let resp = ApiForgeResponse {
        ok: true,
        project_id,
        files_generated: files.len(),
        total_loc,
        total_tokens: stats_raw.total_tokens,
        compile_status: stats.compile_status,
        norms_used: plan.activated_norms,
        output_dir: output_dir.to_string_lossy().to_string(),
    };
    Json(serde_json::to_value(resp).unwrap_or(serde_json::json!({ "ok": false })))
}

/// GET /api/projects/:id/files — list all files in a generated project.
async fn api_project_files(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let store = state.project_store.read().await;
    let project = match store.get(&id) {
        Some(p) => p,
        None => return Json(serde_json::json!({ "ok": false, "error": "project not found" })),
    };

    let output_dir = match &project.output_dir {
        Some(d) => PathBuf::from(d),
        None => return Json(serde_json::json!({ "ok": false, "error": "project has no output directory" })),
    };

    let mut files: Vec<FileInfo> = Vec::new();
    if let Ok(entries) = walk_dir_recursive(&output_dir, &output_dir) {
        files = entries;
    }

    Json(serde_json::json!({ "ok": true, "files": files, "count": files.len() }))
}

/// GET /api/projects/:id/file?path=backend/src/main.rs — get a single file's content.
async fn api_project_file_content(
    State(state): State<AppState>,
    Path(id): Path<String>,
    Query(params): Query<FileContentQuery>,
) -> Result<Json<serde_json::Value>, StatusCode> {
    let store = state.project_store.read().await;
    let project = store.get(&id).ok_or(StatusCode::NOT_FOUND)?;

    let output_dir = project.output_dir.as_ref().ok_or(StatusCode::NOT_FOUND)?;
    let file_path = PathBuf::from(output_dir).join(&params.path);

    // Security: ensure path doesn't escape output directory
    let canonical = file_path.canonicalize().map_err(|_| StatusCode::NOT_FOUND)?;
    let base = PathBuf::from(output_dir).canonicalize().map_err(|_| StatusCode::NOT_FOUND)?;
    if !canonical.starts_with(&base) {
        return Err(StatusCode::FORBIDDEN);
    }

    let content = std::fs::read_to_string(&canonical).map_err(|_| StatusCode::NOT_FOUND)?;
    Ok(Json(serde_json::json!({
        "ok": true,
        "path": params.path,
        "content": content,
        "size": content.len(),
    })))
}

/// Recursively walk a directory and collect file info.
fn walk_dir_recursive(dir: &std::path::Path, base: &std::path::Path) -> std::io::Result<Vec<FileInfo>> {
    let mut files = Vec::new();
    if dir.is_dir() {
        for entry in std::fs::read_dir(dir)? {
            let entry = entry?;
            let path = entry.path();
            if path.is_dir() {
                files.extend(walk_dir_recursive(&path, base)?);
            } else {
                let relative = path.strip_prefix(base).unwrap_or(&path);
                let metadata = entry.metadata()?;
                files.push(FileInfo {
                    path: relative.to_string_lossy().to_string(),
                    size: metadata.len(),
                    is_rust: path.extension().map_or(false, |ext| ext == "rs"),
                });
            }
        }
    }
    Ok(files)
}

// ─── D7: Session Handlers ───────────────────────────────────────────────────

/// Request body for POST /api/session.
#[derive(Debug, Deserialize)]
pub struct CreateSessionRequest {
    pub api_key: Option<String>,
    pub model: Option<String>,
}

/// Request body for POST /api/session/{id}/message.
#[derive(Debug, Deserialize)]
pub struct SessionMessageRequest {
    pub message: String,
}

/// Request body for POST /api/session/{id}/forge.
#[derive(Debug, Deserialize)]
pub struct SessionForgeRequest {
    pub output_dir: Option<String>,
}

/// POST /api/session — create a new architect session.
async fn session_create(
    State(state): State<AppState>,
    Json(req): Json<CreateSessionRequest>,
) -> (StatusCode, Json<serde_json::Value>) {
    let id = format!("session-{:08x}", rand_u32());
    let api_key = req.api_key.or_else(|| std::env::var("OPENAI_API_KEY").ok());
    let model = req.model.unwrap_or_else(|| "gpt-4o".to_string());
    let session = session::ArchitectSession::new(id.clone(), api_key, model);
    state.session_store.write().await.insert(id.clone(), session);
    (StatusCode::CREATED, Json(serde_json::json!({ "ok": true, "session_id": id })))
}

/// GET /api/sessions — list all active sessions.
async fn session_list(State(state): State<AppState>) -> Json<serde_json::Value> {
    let store = state.session_store.read().await;
    let summaries: Vec<session::SessionSummary> = store.values()
        .map(session::SessionSummary::from)
        .collect();
    Json(serde_json::json!({ "ok": true, "sessions": summaries }))
}

/// GET /api/session/{id} — get full session state.
async fn session_get(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let store = state.session_store.read().await;
    match store.get(&id) {
        Some(s) => Json(serde_json::json!({ "ok": true, "session": s })),
        None => Json(serde_json::json!({ "ok": false, "error": "session not found" })),
    }
}

/// DELETE /api/session/{id} — delete a session.
async fn session_delete(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let removed = state.session_store.write().await.remove(&id).is_some();
    Json(serde_json::json!({ "ok": removed }))
}

/// POST /api/session/{id}/message — send a message and get LLM response.
async fn session_message(
    State(state): State<AppState>,
    Path(id): Path<String>,
    Json(req): Json<SessionMessageRequest>,
) -> Json<serde_json::Value> {
    // Get session (clone to release lock during oracle call)
    let session_opt = {
        let store = state.session_store.read().await;
        store.get(&id).cloned()
    };

    let mut session = match session_opt {
        Some(s) => s,
        None => return Json(serde_json::json!({ "ok": false, "error": "session not found" })),
    };

    // I2/W1: fallback chain for oracle selection:
    //   1. Session-specific api_key          → OpenAI
    //   2. Server oracle_config.api_key      → OpenAI
    //   3. Server oracle_config.use_ollama   → Ollama (local, free)
    //   4. Nothing                           → manual mode
    #[derive(Clone, Debug)]
    enum OracleChoice {
        OpenAi {
            api_key: Option<String>, // None → OpenAiOracle reads env var
            model: String,
        },
        Ollama {
            url: String,
            model: String,
        },
        Manual,
    }

    let oracle_choice = if let Some(key) = session.api_key.clone() {
        OracleChoice::OpenAi {
            api_key: Some(key),
            model: session.model.clone(),
        }
    } else if state.oracle_config.api_key.is_some() {
        OracleChoice::OpenAi {
            api_key: state.oracle_config.api_key.clone(),
            model: if state.oracle_config.openai_model.is_empty() {
                session.model.clone()
            } else {
                state.oracle_config.openai_model.clone()
            },
        }
    } else if state.oracle_config.use_ollama {
        OracleChoice::Ollama {
            url: state.oracle_config.ollama_url.clone(),
            model: state.oracle_config.ollama_model.clone(),
        }
    } else {
        OracleChoice::Manual
    };

    let assistant_message = match oracle_choice {
        OracleChoice::Manual => architect::process_message_manual(&mut session, &req.message),
        OracleChoice::OpenAi { api_key, model } => {
            // Build prompt first so we can move it into the blocking task.
            let prompt = architect::build_architect_prompt(&session, &req.message);

            let result = tokio::task::spawn_blocking(move || {
                use isls_forge_llm::Oracle as _;
                let oracle = match isls_forge_llm::oracle::OpenAiOracle::new(api_key, Some(model)) {
                    Ok(o) => o,
                    Err(e) => return Err(format!("Oracle init failed: {}", e)),
                };
                oracle
                    .call(&prompt, 4096)
                    .map_err(|e| format!("Oracle call failed: {}", e))
            })
            .await;

            match result {
                Ok(Ok(response_text)) => {
                    session.add_user_message(&req.message);
                    let parsed = architect::parse_llm_response(&response_text);
                    let msg = parsed.message.clone();
                    architect::apply_architect_response(&mut session, &parsed);
                    msg
                }
                Ok(Err(e)) => {
                    eprintln!("[architect] OpenAI oracle failed: {} — falling back to manual mode", e);
                    architect::process_message_manual(&mut session, &req.message)
                }
                Err(e) => {
                    eprintln!("[architect] OpenAI task join failed: {} — falling back to manual mode", e);
                    architect::process_message_manual(&mut session, &req.message)
                }
            }
        }
        OracleChoice::Ollama { url, model } => {
            // Use the tighter Ollama-style prompt (shorter, JSON-only, no
            // history injection).
            let prompt = architect::build_architect_prompt_ollama(&session, &req.message);

            // Heartbeat → WS so the Studio UI can show "Analysiere… 450 tok
            // @ 4.2 tok/s · 01:47" instead of a frozen "Analysiere…" button.
            // Without this, analyze feels wedged whenever qwen2.5-coder:7b
            // takes more than a few seconds to respond.
            let hb_hub = state.event_hub.clone();
            let hb_sid = id.clone();
            let heartbeat: isls_forge_llm::OllamaHeartbeatFn =
                std::sync::Arc::new(move |tokens, elapsed| {
                    let tps = if elapsed > 0.0 { tokens as f64 / elapsed } else { 0.0 };
                    hb_hub.publish(WsEvent::new(
                        EventType::ForgeProgress,
                        serde_json::json!({
                            "type": "analyze:oracle_tick",
                            "session_id": hb_sid,
                            "tokens": tokens,
                            "elapsed_secs": elapsed,
                            "tok_per_sec": tps,
                        }),
                    ));
                });

            let result = tokio::task::spawn_blocking(move || {
                use isls_forge_llm::Oracle as _;
                let oracle = isls_forge_llm::oracle::OllamaOracle::new(&model, &url)
                    .with_heartbeat(heartbeat);
                // Architect output is a short JSON block — 1024 is plenty
                // and cuts the worst-case wait on CPU by 4× vs. 4096.
                oracle
                    .call(&prompt, 1024)
                    .map_err(|e| format!("Ollama oracle call failed: {}", e))
            })
            .await;

            match result {
                Ok(Ok(response_text)) => {
                    session.add_user_message(&req.message);
                    let parsed = architect::parse_llm_response(&response_text);
                    // If the local model produced no entities AND no fenced
                    // JSON, surface the raw model text as the assistant
                    // message instead of treating it as a crash — the JSON
                    // extractor already refuses to crash on unexpected output.
                    let msg = parsed.message.clone();
                    architect::apply_architect_response(&mut session, &parsed);
                    msg
                }
                Ok(Err(e)) => {
                    eprintln!("[architect] Ollama oracle failed: {} — falling back to manual mode", e);
                    architect::process_message_manual(&mut session, &req.message)
                }
                Err(e) => {
                    eprintln!("[architect] Ollama task join failed: {} — falling back to manual mode", e);
                    architect::process_message_manual(&mut session, &req.message)
                }
            }
        }
    };

    // Compute readiness
    let readiness = crate::session::compute_readiness(&session);

    // Store updated session
    state.session_store.write().await.insert(id.clone(), session.clone());

    Json(serde_json::json!({
        "ok": true,
        "message": assistant_message,
        "spec": {
            "app_name": session.spec.app_name,
            "description": session.spec.description,
            "entity_count": session.spec.entities.len(),
            "entities": session.spec.entities.iter().map(|e| serde_json::json!({
                "name": e.name,
                "field_count": e.fields.len(),
                "fields": e.fields.iter().map(|f| serde_json::json!({
                    "name": f.name,
                    "type": f.rust_type,
                })).collect::<Vec<_>>(),
            })).collect::<Vec<_>>(),
        },
        "readiness": readiness,
    }))
}

/// GET /api/session/{id}/readiness — compute readiness check.
async fn session_readiness(
    State(state): State<AppState>,
    Path(id): Path<String>,
) -> Json<serde_json::Value> {
    let store = state.session_store.read().await;
    match store.get(&id) {
        Some(session) => {
            let readiness = crate::session::compute_readiness(session);
            Json(serde_json::json!({ "ok": true, "readiness": readiness }))
        }
        None => Json(serde_json::json!({ "ok": false, "error": "session not found" })),
    }
}

/// POST /api/session/{id}/forge — start forge from session's AppSpec.
async fn session_forge(
    State(state): State<AppState>,
    Path(id): Path<String>,
    Json(req): Json<SessionForgeRequest>,
) -> Json<serde_json::Value> {
    // Get session
    let session_opt = {
        let store = state.session_store.read().await;
        store.get(&id).cloned()
    };

    let session = match session_opt {
        Some(s) => s,
        None => return Json(serde_json::json!({ "ok": false, "error": "session not found" })),
    };

    // Check readiness
    let readiness = crate::session::compute_readiness(&session);
    if !readiness.ready {
        return Json(serde_json::json!({
            "ok": false,
            "error": "Session not ready for forge. Required criteria not met.",
            "readiness": readiness,
        }));
    }

    // Determine output directory
    let output_dir = req.output_dir
        .map(std::path::PathBuf::from)
        .unwrap_or_else(|| {
            state.projects_dir.join(if session.spec.app_name.is_empty() {
                format!("session-{}", &session.id)
            } else {
                session.spec.app_name.clone()
            })
        });

    if let Err(e) = std::fs::create_dir_all(&output_dir) {
        return Json(serde_json::json!({
            "ok": false,
            "error": format!("Cannot create output directory: {}", e),
        }));
    }

    // Build ForgePlan from session spec
    let spec = session.spec.clone();
    let session_api_key = session.api_key.clone();
    let event_hub = state.event_hub.clone();
    let session_store = state.session_store.clone();
    let session_id = id.clone();
    let output_dir_clone = output_dir.clone();
    let oracle_config = state.oracle_config.clone();

    // Spawn background forge task
    tokio::spawn(async move {
        // Publish forge:start
        event_hub.publish(WsEvent::new(
            EventType::ForgeProgress,
            serde_json::json!({
                "type": "forge:start",
                "session_id": session_id,
            }),
        ));

        // Clone for the blocking task's progress callback — the outer
        // `spawn_blocking` takes ownership of everything it captures.
        let event_hub_cb = event_hub.clone();
        let session_id_cb = session_id.clone();

        let result = tokio::task::spawn_blocking(move || {
            // Convert session entities to EntityTemplates for from_toml_entities
            let templates: Vec<isls_hypercube::domain::EntityTemplate> = spec.entities.iter().map(|e| {
                isls_hypercube::domain::EntityTemplate {
                    name: e.name.clone(),
                    fields: e.fields.clone(),
                    validations: e.validations.iter().map(|v| {
                        isls_hypercube::domain::ValidationRule {
                            name: v.condition.clone(),
                            condition: v.condition.clone(),
                            message: v.message.clone(),
                        }
                    }).collect(),
                    indices: vec![],
                    description: String::new(),
                }
            }).collect();

            let mut plan = isls_forge_llm::ForgePlan::from_toml_entities(
                &spec.app_name,
                &spec.description,
                &spec.domain_name,
                &templates,
            );
            plan.blueprint = isls_forge_llm::blueprint::derive_blueprint_from_description(&spec.description);

            // Ollama streaming heartbeat → WS `forge:oracle_tick` so the
            // Studio UI can prove "tokens are still flowing" during a
            // 10–30 min generation. Without this a healthy slow call
            // looks identical to a wedged one.
            let event_hub_hb = event_hub_cb.clone();
            let session_id_hb = session_id_cb.clone();
            let heartbeat: isls_forge_llm::OllamaHeartbeatFn =
                std::sync::Arc::new(move |tokens, elapsed| {
                    let tps = if elapsed > 0.0 { tokens as f64 / elapsed } else { 0.0 };
                    event_hub_hb.publish(WsEvent::new(
                        EventType::ForgeProgress,
                        serde_json::json!({
                            "type": "forge:oracle_tick",
                            "session_id": session_id_hb,
                            "tokens": tokens,
                            "elapsed_secs": elapsed,
                            "tok_per_sec": tps,
                        }),
                    ));
                });

            // Build oracle with the shared helper so the forge path uses
            // the same configuration as the chat (`/api/chat/plain`).
            // Priority: use_ollama → Ollama ; api_key → OpenAI ; else Mock.
            let (oracle, use_mock) = build_forge_oracle_with_heartbeat(
                &oracle_config,
                session_api_key.clone(),
                Some(heartbeat),
            );

            // Forward every ForgeProgressEvent from the HDAG staged closure
            // to the WebSocket event hub so the Studio UI sees live
            // progress (node start, node done, coagula cycle, compile).
            // Without this the frontend gets only `forge:start` and
            // `forge:complete` — and sits silent for hours on a local 32B.
            let mut forge = isls_forge_llm::LlmForge::new(
                oracle, plan, output_dir_clone.clone(), use_mock,
            )
            .with_progress(move |ev| {
                // Don't double-fire `forge:complete`: the outer post-task
                // handler emits a richer one with zip_filename after the
                // spawn_blocking returns.
                if matches!(ev, isls_forge_llm::ForgeProgressEvent::Complete { .. }) {
                    return;
                }
                let payload = forge_progress_event_to_json(&session_id_cb, &ev);
                event_hub_cb.publish(WsEvent::new(EventType::ForgeProgress, payload));
            });

            let start = std::time::Instant::now();
            match forge.generate() {
                Ok(files) => {
                    let total_loc: usize = files.iter().map(|f| f.content.lines().count()).sum();
                    Ok(session::SessionForgeResult {
                        success: true,
                        files_generated: files.len(),
                        total_loc,
                        total_tokens: forge.stats.total_tokens,
                        duration_secs: start.elapsed().as_secs_f64(),
                        output_dir: output_dir_clone.to_string_lossy().to_string(),
                    })
                }
                Err(e) => Err(format!("Forge failed: {}", e)),
            }
        }).await;

        match result {
            Ok(Ok(forge_result)) => {
                // Persistent counters: forge run + success
                crate::counters::increment_counter(crate::counters::CounterField::ForgeRuns, 1);
                crate::counters::increment_counter(crate::counters::CounterField::ForgeSuccesses, 1);

                // S2/fix: Package output directory as a downloadable ZIP
                let zip_filename: Option<String> = {
                    let output_path = std::path::Path::new(&forge_result.output_dir);
                    match tokio::task::spawn_blocking({
                        let p = output_path.to_path_buf();
                        move || package_forge_output(&p)
                    }).await {
                        Ok(Ok(name)) => {
                            tracing::info!("[Forge] ZIP created: {}", name);
                            Some(name)
                        }
                        Ok(Err(e)) => {
                            tracing::warn!("[Forge] ZIP creation failed: {}", e);
                            None
                        }
                        Err(e) => {
                            tracing::warn!("[Forge] ZIP task panicked: {}", e);
                            None
                        }
                    }
                };

                // Store result on session
                let mut store = session_store.write().await;
                if let Some(session) = store.get_mut(&session_id) {
                    session.forge_result = Some(forge_result.clone());
                }

                event_hub.publish(WsEvent::new(
                    EventType::ForgeProgress,
                    serde_json::json!({
                        "type": "forge:complete",
                        "session_id": session_id,
                        "success": true,
                        "files": forge_result.files_generated,
                        "loc": forge_result.total_loc,
                        "tokens": forge_result.total_tokens,
                        "duration_secs": forge_result.duration_secs,
                        "output_dir": forge_result.output_dir,
                        "zip_filename": zip_filename,
                    }),
                ));
            }
            result => {
                // Persistent counter: forge run (failed)
                crate::counters::increment_counter(crate::counters::CounterField::ForgeRuns, 1);

                let err_msg = match result {
                    Ok(Err(e)) => e,
                    Err(e) => format!("Forge task panicked: {}", e),
                    _ => unreachable!(),
                };
                event_hub.publish(WsEvent::new(
                    EventType::ForgeProgress,
                    serde_json::json!({
                        "type": "forge:complete",
                        "session_id": session_id,
                        "success": false,
                        "error": err_msg,
                    }),
                ));
            }
        }
    });

    Json(serde_json::json!({
        "ok": true,
        "message": "Forge started. Watch WebSocket /events for progress.",
        "output_dir": output_dir.to_string_lossy().to_string(),
    }))
}

/// GET /api/chat/history — placeholder (jobs are ephemeral in-process).
async fn api_chat_history(State(state): State<AppState>) -> Json<serde_json::Value> {
    let jobs = state.chat_jobs.read().await;
    let history: Vec<serde_json::Value> = jobs.values().map(|j| serde_json::json!({
        "job_id": j.id,
        "complete": j.complete,
        "event_count": j.events.len(),
    })).collect();
    Json(serde_json::json!({ "ok": true, "history": history }))
}

// ─── v3 Crystals + Health ─────────────────────────────────────────────────

/// GET /api/crystals — crystals list under /api prefix.
async fn api_crystals(State(state): State<AppState>) -> Json<serde_json::Value> {
    let engine = state.engine_state.read().await;
    Json(serde_json::json!({ "ok": true, "crystals": engine.crystals }))
}

/// GET /api/health — health check under /api prefix.
async fn api_health(State(state): State<AppState>) -> Json<serde_json::Value> {
    let uptime = state.start_time.elapsed().as_secs();
    Json(serde_json::json!({ "status": "ok", "uptime_secs": uptime, "version": "3.0.0" }))
}

/// POST /agent/bind — set the default project for subsequent /agent/chat calls
async fn agent_bind(
    State(state): State<AppState>,
    Json(req): Json<BindRequest>,
) -> Json<serde_json::Value> {
    let path = std::path::PathBuf::from(&req.project);
    let exists = path.exists();
    *state.bound_project.write().await = Some(path);
    Json(serde_json::json!({
        "ok": true,
        "project": req.project,
        "exists": exists,
    }))
}

// ─── WebSocket Handler ──────────────────────────────────────────────────────

async fn ws_handler(
    ws: WebSocketUpgrade,
    State(state): State<AppState>,
) -> Response {
    ws.on_upgrade(move |socket| handle_ws(socket, state))
}

async fn handle_ws(socket: axum::extract::ws::WebSocket, state: AppState) {
    let (mut sender, mut receiver) = socket.split();
    let mut rx = state.event_hub.subscribe();

    {
        let mut count = state.event_hub.client_count.write().await;
        *count += 1;
    }

    // Default: subscribe to all events
    let subscribed: Arc<RwLock<Option<std::collections::HashSet<EventType>>>> =
        Arc::new(RwLock::new(None));

    let sub_clone = subscribed.clone();

    // Forward broadcast events to the client
    let send_task = tokio::spawn(async move {
        while let Ok(event) = rx.recv().await {
            let filter = sub_clone.read().await;
            if let Some(ref types) = *filter {
                if !types.contains(&event.event_type) {
                    continue;
                }
            }
            if let Ok(json) = serde_json::to_string(&event) {
                if sender.send(axum::extract::ws::Message::Text(json.into())).await.is_err() {
                    break;
                }
            }
        }
    });

    // Listen for subscription messages from the client
    let sub_clone2 = subscribed.clone();
    let recv_task = tokio::spawn(async move {
        while let Some(Ok(msg)) = receiver.next().await {
            if let axum::extract::ws::Message::Text(text) = msg {
                if let Ok(req) = serde_json::from_str::<SubscribeRequest>(&text) {
                    let mut filter = sub_clone2.write().await;
                    *filter = Some(req.subscribe.into_iter().collect());
                }
            }
        }
    });

    // Wait for either task to finish
    tokio::select! {
        _ = send_task => {},
        _ = recv_task => {},
    }

    {
        let mut count = state.event_hub.client_count.write().await;
        *count = count.saturating_sub(1);
    }
}

// ─── Helpers ────────────────────────────────────────────────────────────────

fn rand_u32() -> u32 {
    use std::time::SystemTime;
    SystemTime::now()
        .duration_since(SystemTime::UNIX_EPOCH)
        .unwrap_or_default()
        .subsec_nanos()
}

// ─── E1: Ledger & MCI API handlers ───────────────────────────────────────────

/// GET /api/ledger/verify — verify the MEF hash chain.
async fn api_ledger_verify() -> Json<serde_json::Value> {
    let cv = isls_norms::mef_chain::verify_chain();
    Json(serde_json::json!({
        "ok": true,
        "is_valid": cv.is_valid,
        "total_events": cv.total_events,
        "head_hash": cv.head_hash,
        "head_seq": cv.head_seq,
        "errors": cv.errors,
    }))
}

/// GET /api/ledger/head — return the last chained event.
async fn api_ledger_head() -> Json<serde_json::Value> {
    match isls_norms::mef_chain::read_head_event() {
        Some(v) => Json(serde_json::json!({ "ok": true, "event": v })),
        None => Json(serde_json::json!({ "ok": false, "error": "ledger is empty" })),
    }
}

/// Request body for POST /api/mci/run.
#[derive(Debug, Deserialize)]
pub struct MciRunRequest {
    pub description: String,
}

/// POST /api/mci/run — run an MCI measurement (may take several minutes).
async fn api_mci_run(
    State(state): State<AppState>,
    Json(req): Json<MciRunRequest>,
) -> Json<serde_json::Value> {
    let description = req.description.clone();
    let oracle_config = state.oracle_config.clone();
    let norm_registry = state.norm_registry.clone();
    let state_clone = state.clone();

    let result = tokio::task::spawn_blocking(move || {
        use isls_hypercube::domain::DomainRegistry;

        let domain_registry = DomainRegistry::new();
        let slug: String = description
            .to_lowercase()
            .split_whitespace()
            .take(3)
            .collect::<Vec<_>>()
            .join("-");

        let plan = match domain_registry.detect(&description) {
            Some(domain) => isls_forge_llm::ForgePlan::from_domain(&slug, &description, domain),
            None => isls_forge_llm::ForgePlan::warehouse_default(&slug),
        };

        // Use the shared helper so use_ollama wins over api_key — same as chat.
        let (oracle_a, use_mock) = build_forge_oracle(&oracle_config, None);
        let (oracle_b, _) = build_forge_oracle(&oracle_config, None);

        let tmp = std::env::temp_dir().join(format!("isls-mci-api-{}", chrono::Utc::now().timestamp()));
        let out_a = tmp.join("a");
        let out_b = tmp.join("b");

        let result = isls_forge_llm::mci::compute_mci(plan, oracle_a, oracle_b, use_mock, &out_a, &out_b);

        // Self-observation from forge A
        if out_a.exists() {
            let collector = isls_forge_llm::artifact_collector::ArtifactCollector::new(&out_a);
            let observed = collector.collect();
            if !observed.is_empty() {
                let run_id = format!("mci-api-{}", chrono::Utc::now().timestamp());
                if let Ok(mut reg) = norm_registry.try_write() {
                    reg.observe_and_learn(&observed, "mci-api", &run_id);
                }
            }
        }

        // Cleanup
        let _ = std::fs::remove_dir_all(&tmp);

        result.map(|report| {
            // Write to timeseries + ledger
            crate::timeseries::append_mci_snapshot(
                &state_clone,
                report.mci_global,
                report.mci_structural,
                report.mci_oracle,
            );
            let mci_event = isls_norms::ledger::NormEvent::MciMeasured {
                timestamp: report.timestamp.clone(),
                app: description.clone(),
                mci_global: report.mci_global,
                mci_structural: report.mci_structural,
                mci_oracle: report.mci_oracle,
            };
            let _ = isls_norms::mef_chain::append_chained_event(&mci_event);

            // Store in history
            if let Ok(mut hist) = state_clone.mci_history.try_write() {
                hist.push(report.clone());
                let excess = hist.len().saturating_sub(50);
                if excess > 0 { hist.drain(0..excess); }
            }

            report
        })
    })
    .await;

    match result {
        Ok(Ok(report)) => Json(serde_json::json!({
            "ok": true,
            "report": serde_json::to_value(&report).unwrap_or_default(),
        })),
        Ok(Err(e)) => Json(serde_json::json!({ "ok": false, "error": e })),
        Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("task panic: {}", e) })),
    }
}

/// GET /api/mci/history — last MCI reports from timeseries (entries with mci_global != null).
async fn api_mci_history() -> Json<serde_json::Value> {
    let entries = crate::timeseries::read_timeseries_entries(720); // last 30 days
    let mci_entries: Vec<_> = entries
        .into_iter()
        .filter(|e| e.mci_global.is_some())
        .collect();
    Json(serde_json::json!({
        "ok": true,
        "count": mci_entries.len(),
        "entries": serde_json::to_value(&mci_entries).unwrap_or_default(),
    }))
}

/// GET /api/mci/latest — most recent MCI report from in-memory history.
async fn api_mci_latest(State(state): State<AppState>) -> Json<serde_json::Value> {
    let hist = state.mci_history.read().await;
    match hist.last() {
        Some(report) => Json(serde_json::json!({
            "ok": true,
            "report": serde_json::to_value(report).unwrap_or_default(),
        })),
        None => Json(serde_json::json!({ "ok": false, "error": "no MCI runs yet" })),
    }
}

// ─── S2: System Status API ───────────────────────────────────────────────────

/// GET /api/system/status — combined system status for Studio dashboard.
/// Replaces the need for multiple CLI commands.
async fn api_system_status(State(state): State<AppState>) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let uptime = state.start_time.elapsed().as_secs();

    // Norms
    let all_norms = registry.all_norms();
    let builtin_count = all_norms.iter().filter(|n| {
        !n.id.starts_with("ISLS-NORM-AUTO-") && !n.id.starts_with("ISLS-INJECT-")
    }).count();
    let auto_count = registry.auto_norms_count();
    let candidates = registry.candidates();
    let candidate_count = candidates.len();
    let sem_candidates = registry.semantic_candidates();
    let observation_count: usize = sem_candidates.iter().map(|c| c.observation_count()).sum();
    let domain_count: usize = sem_candidates.iter().map(|c| c.domain_count()).max().unwrap_or(0);

    // Capabilities
    let capabilities = isls_norms::compute_capabilities(&registry);
    let mastered = capabilities.iter().filter(|c| c.status == isls_norms::CapabilityStatus::Mastered).count();
    let acquired = capabilities.iter().filter(|c| c.status == isls_norms::CapabilityStatus::Acquired).count();
    let emerging = capabilities.iter().filter(|c| c.status == isls_norms::CapabilityStatus::Emerging).count();
    let scouted = capabilities.iter().filter(|c| c.status == isls_norms::CapabilityStatus::Scouted).count();
    let unknown = capabilities.iter().filter(|c| c.status == isls_norms::CapabilityStatus::Unknown).count();

    drop(registry); // release lock

    // Ledger
    let ledger_info = {
        let report = isls_norms::mef_chain::verify_chain();
        serde_json::json!({
            "valid": report.is_valid,
            "events": report.total_events,
            "head_hash": report.head_hash,
            "head_seq": report.head_seq,
        })
    };

    // Auto-evolve
    let ae_enabled = state.auto_evolve_enabled.load(Ordering::Relaxed);
    let ae_store = state.auto_evolve.read().await;
    let last_run = ae_store.history.last()
        .map(|r| r.timestamp.clone())
        .unwrap_or_default();
    drop(ae_store);
    let last_mci = {
        let hist = state.mci_history.read().await;
        hist.last().map(|r| r.mci_global).unwrap_or(0.0)
    };

    // Emergent
    let emergent_registry = isls_norms::emergent::load_emergent_registry();
    let unclassified = isls_norms::emergent::load_recent_unclassified(50_000);
    let emergent_clusters = isls_norms::emergent::detect_emergent_clusters(&unclassified);
    let clusters_ready = emergent_clusters.iter()
        .filter(|c| c.status == isls_norms::ClusterStatus::Ready && !emergent_registry.prefix_rules.contains_key(&c.prefix))
        .count();
    let clusters_observing = emergent_clusters.iter()
        .filter(|c| c.status == isls_norms::ClusterStatus::Observing)
        .count();

    // Persistent cumulative counters (survive restarts)
    let persistent = crate::counters::load_counters();

    // Scraping info
    let (kw_done, kw_total_running) = {
        let jobs = state.mass_scrape_jobs.read().await;
        let running = jobs.values().find(|j| j.status == "running");
        running.map(|j| (j.keywords_done, j.keywords_total)).unwrap_or((0, 0))
    };

    let keywords_count = {
        let path = &state.scrape_keywords_path;
        std::fs::read_to_string(path)
            .map(|s| s.lines().filter(|l| !l.trim().is_empty()).count())
            .unwrap_or(0)
    };

    // Current keyword: last entry from scrape history ring-buffer
    let current_keyword = {
        let hist = state.scrape_history.lock().await;
        hist.back().map(|e| e.keyword.clone()).unwrap_or_default()
    };

    // Round = keywords processed in the active job (0 when idle)
    let round = if kw_total_running > 0 { kw_done } else { 0 };

    // Last promotion from emergent class registry
    let last_promotion = emergent_registry.classes.last().map(|c| serde_json::json!({
        "name": c.name,
        "timestamp": c.discovered_at,
    }));

    Json(serde_json::json!({
        "norms": {
            "builtin": builtin_count,
            "auto": auto_count,
            "candidates": candidate_count,
            "observations": observation_count,
            "domains": domain_count,
        },
        "scraping": {
            "repos_total": persistent.repos_scraped_total,
            "keywords_active": keywords_count,
            "keywords_done": round,
            "current_keyword": current_keyword,
        },
        "ledger": ledger_info,
        "auto_evolve": {
            "enabled": ae_enabled,
            "last_run": last_run,
            "last_mci": last_mci,
        },
        "capabilities": {
            "mastered": mastered,
            "acquired": acquired,
            "emerging": emerging,
            "scouted": scouted,
            "unknown": unknown,
        },
        "emergent": {
            "clusters_ready": clusters_ready,
            "clusters_observing": clusters_observing,
            "unclassified": unclassified.len(),
            "promoted": emergent_registry.classes.len(),
        },
        "last_promotion": last_promotion,
        "counters": {
            "repos_scraped_total": persistent.repos_scraped_total,
            "observations_total": persistent.observations_total,
            "forge_runs_total": persistent.forge_runs_total,
            "forge_successes_total": persistent.forge_successes_total,
            "auto_evolve_runs_total": persistent.auto_evolve_runs_total,
            "harpoon_runs_total": persistent.harpoon_runs_total,
            "norms_ever_promoted": persistent.norms_ever_promoted,
            "first_started": persistent.first_started,
            "last_updated": persistent.last_updated,
        },
        "uptime_seconds": uptime,
    }))
}

// ─── I7: Emergent Classification API ─────────────────────────────────────────

async fn api_emergent_clusters() -> Json<serde_json::Value> {
    let registry = isls_norms::emergent::load_emergent_registry();
    let summary = isls_norms::emergent::emergent_summary(&registry);
    Json(serde_json::json!({
        "promoted": summary.promoted,
        "ready": summary.ready,
        "observing": summary.observing,
        "total_unclassified": summary.total_unclassified,
        "total_emergent_classes": summary.total_emergent_classes,
    }))
}

async fn api_emergent_promote(
    Json(body): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let prefix = match body.get("prefix").and_then(|p| p.as_str()) {
        Some(p) => p.to_string(),
        None => return Json(serde_json::json!({ "ok": false, "error": "missing prefix" })),
    };

    let unclassified = isls_norms::emergent::load_recent_unclassified(50_000);
    let clusters = isls_norms::emergent::detect_emergent_clusters(&unclassified);

    let cluster = clusters.iter().find(|c| c.prefix == prefix);
    match cluster {
        Some(c) => {
            let mut registry = isls_norms::emergent::load_emergent_registry();
            let promoted = isls_norms::emergent::auto_promote_emergent(c, &mut registry, true);
            if promoted {
                crate::counters::increment_counter(crate::counters::CounterField::NormsPromoted, 1);
            }
            Json(serde_json::json!({
                "ok": promoted,
                "class_name": c.suggested_name,
                "prefix": prefix,
            }))
        }
        None => Json(serde_json::json!({ "ok": false, "error": "cluster not found" })),
    }
}

// ─── G1: Code-Template-Registry Endpoints ─────────────────────────────────────

/// GET /api/templates — alle bekannten Code-Templates mit Metadaten.
async fn api_templates_list() -> Json<serde_json::Value> {
    let mut template_registry = isls_forge_llm::templates::TemplateRegistry::load();
    isls_forge_llm::templates::ensure_builtin_templates(&mut template_registry);

    let templates: Vec<serde_json::Value> = template_registry
        .all_templates()
        .iter()
        .map(|t| serde_json::json!({
            "class": t.class,
            "filename": t.filename,
            "quality": t.quality,
            "observation_count": t.observation_count,
            "last_updated": t.last_updated,
            "function_count": t.functions.len(),
            "functions": t.functions.iter().map(|f| f.original_name.clone()).collect::<Vec<_>>(),
        }))
        .collect();

    Json(serde_json::json!({
        "ok": true,
        "total": templates.len(),
        "templates": templates,
    }))
}

/// GET /api/templates/{class} — vollständiges Template mit Code.
async fn api_template_get(
    Path(class): Path<String>,
) -> Json<serde_json::Value> {
    let mut template_registry = isls_forge_llm::templates::TemplateRegistry::load();
    isls_forge_llm::templates::ensure_builtin_templates(&mut template_registry);

    match template_registry.find_for_class(&class) {
        Some(t) => Json(serde_json::json!({
            "ok": true,
            "class": t.class,
            "filename": t.filename,
            "quality": t.quality,
            "observation_count": t.observation_count,
            "last_updated": t.last_updated,
            "imports": t.imports,
            "functions": t.functions.iter().map(|f| serde_json::json!({
                "name": f.original_name,
                "pattern": format!("{:?}", f.pattern),
                "arity": f.arity,
            })).collect::<Vec<_>>(),
            "materialized_code": t.materialized_code,
        })),
        None => Json(serde_json::json!({
            "ok": false,
            "error": format!("template not found for class: {}", class),
        })),
    }
}

async fn api_emergent_stats() -> Json<serde_json::Value> {
    let registry = isls_norms::emergent::load_emergent_registry();
    let unclassified = isls_norms::emergent::load_recent_unclassified(50_000);
    Json(serde_json::json!({
        "total_unclassified": unclassified.len(),
        "total_emergent_classes": registry.classes.len(),
        "prefix_rules": registry.prefix_rules,
    }))
}

// ─── S3: Scraping engine handlers ────────────────────────────────────────────

/// GET /api/scrape/status — live scraping engine status.
async fn api_scrape_status(State(state): State<AppState>) -> Json<serde_json::Value> {
    let status = state.scrape_engine.status.read().await.clone();
    let progress = state.scrape_engine.progress.read().await.clone();
    let config = state.scrape_engine.config.read().await.clone();
    let disabled = state.scrape_disabled;

    Json(serde_json::json!({
        "ok": true,
        "disabled": disabled,
        "running": status.running,
        "paused": state.scrape_engine.paused.load(Ordering::Relaxed),
        "pause_reason": status.pause_reason,
        "current_strategy": status.current_strategy,
        "current_keywords": status.current_keywords,
        "keyword_progress": status.keyword_progress,
        "rate_limit_remaining": status.rate_limit_remaining,
        "rate_limit_resets_in": status.rate_limit_resets_in,
        "repos_per_hour": status.repos_per_hour,
        "last_scrape": status.last_scrape,
        "last_result": status.last_result,
        "progress": {
            "current_index": progress.current_index,
            "round": progress.round,
            "total_keywords": progress.total_keywords,
            "last_keyword": progress.last_keyword,
        },
        "config": {
            "volume_percent": config.volume_percent,
            "spectrum": config.spectrum,
        },
    }))
}

/// GET /api/scrape/config — current scrape config.
async fn api_scrape_config_get(State(state): State<AppState>) -> Json<serde_json::Value> {
    let config = state.scrape_engine.config.read().await.clone();
    Json(serde_json::json!({
        "ok": true,
        "volume_percent": config.volume_percent,
        "spectrum": config.spectrum,
        "paused": state.scrape_engine.paused.load(Ordering::Relaxed),
    }))
}

/// POST /api/scrape/pause — pause the scraping engine.
async fn api_scrape_pause(State(state): State<AppState>) -> Json<serde_json::Value> {
    state.scrape_engine.paused.store(true, Ordering::Relaxed);
    // Persist
    let mut config = state.scrape_engine.config.write().await;
    config.paused = true;
    let snapshot = config.clone();
    drop(config);
    tokio::task::spawn_blocking(move || scrape_engine::save_scrape_config(&snapshot));
    Json(serde_json::json!({ "ok": true, "paused": true }))
}

/// POST /api/scrape/resume — resume the scraping engine.
async fn api_scrape_resume(State(state): State<AppState>) -> Json<serde_json::Value> {
    state.scrape_engine.paused.store(false, Ordering::Relaxed);
    // Persist
    let mut config = state.scrape_engine.config.write().await;
    config.paused = false;
    let snapshot = config.clone();
    drop(config);
    tokio::task::spawn_blocking(move || scrape_engine::save_scrape_config(&snapshot));
    Json(serde_json::json!({ "ok": true, "paused": false }))
}

/// POST /api/scrape/volume  Body: { "percent": 70 }
async fn api_scrape_volume(
    State(state): State<AppState>,
    Json(body): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let pct = match body.get("percent").and_then(|v| v.as_u64()) {
        Some(p) => p.clamp(0, 100) as u8,
        None => return Json(serde_json::json!({ "ok": false, "error": "missing percent" })),
    };
    let mut config = state.scrape_engine.config.write().await;
    config.volume_percent = pct;
    let snapshot = config.clone();
    drop(config);
    tokio::task::spawn_blocking(move || scrape_engine::save_scrape_config(&snapshot));
    Json(serde_json::json!({ "ok": true, "volume_percent": pct }))
}

/// POST /api/scrape/spectrum  Body: { "categories": ["Backend", "Frontend"] }
async fn api_scrape_spectrum(
    State(state): State<AppState>,
    Json(body): Json<serde_json::Value>,
) -> Json<serde_json::Value> {
    let cats = match body.get("categories").and_then(|v| v.as_array()) {
        Some(a) => a
            .iter()
            .filter_map(|v| v.as_str())
            .filter_map(scrape_engine::SpectrumCategory::from_str)
            .collect::<Vec<_>>(),
        None => {
            return Json(serde_json::json!({ "ok": false, "error": "missing categories" }))
        }
    };
    if cats.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "at least one category required" }));
    }
    // Reset rotation index when spectrum changes
    {
        let mut progress = state.scrape_engine.progress.write().await;
        progress.current_index = 0;
    }
    let mut config = state.scrape_engine.config.write().await;
    config.spectrum = cats.clone();
    let snapshot = config.clone();
    drop(config);
    tokio::task::spawn_blocking(move || scrape_engine::save_scrape_config(&snapshot));
    Json(serde_json::json!({ "ok": true, "spectrum": cats }))
}

// ─── S2/fix: Forge ZIP download ──────────────────────────────────────────────

/// GET /api/forge/download/{filename} — serve a forge output ZIP.
///
/// Security: rejects any filename that contains `..`, `/`, or `\`.
/// Only serves files from `~/.isls/downloads/`.
async fn download_forge(Path(filename): Path<String>) -> Response {
    use axum::http::header;
    use axum::body::Body;

    // Path-traversal guard
    if filename.contains("..") || filename.contains('/') || filename.contains('\\') {
        return StatusCode::BAD_REQUEST.into_response();
    }
    // Only serve zip files
    if !filename.ends_with(".zip") {
        return StatusCode::BAD_REQUEST.into_response();
    }

    let zip_path = isls_home_path().join("downloads").join(&filename);
    match std::fs::read(&zip_path) {
        Ok(bytes) => {
            let content_disp = format!("attachment; filename=\"{}\"", filename);
            axum::http::Response::builder()
                .status(200)
                .header(header::CONTENT_TYPE, "application/zip")
                .header(header::CONTENT_DISPOSITION, content_disp)
                .body(Body::from(bytes))
                .unwrap_or_else(|_| StatusCode::INTERNAL_SERVER_ERROR.into_response())
        }
        Err(_) => StatusCode::NOT_FOUND.into_response(),
    }
}

// ─── Tests ──────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;
    use axum::body::Body;
    use axum::http::Request;
    use tower::ServiceExt;

    fn test_app() -> Router {
        build_router(AppState::new())
    }

    // AT-ST1: Studio serves
    #[tokio::test]
    async fn at_st1_studio_serves() {
        let app = test_app();
        let resp = app
            .oneshot(Request::get("/studio").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let html = String::from_utf8_lossy(&body);
        assert!(html.contains("<!DOCTYPE html>"));
        assert!(html.contains("ISLS Studio"));
    }

    // AT-ST2: Dashboard data
    #[tokio::test]
    async fn at_st2_dashboard_data() {
        let app = test_app();
        let resp = app
            .oneshot(Request::get("/api/dashboard").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(data.get("health").is_some());
        assert!(data.get("crystal_count").is_some());
        assert!(data.get("metrics").is_some());
    }

    // AT-ST3: WebSocket connect — tested via ws module unit tests (EventHub)
    #[tokio::test]
    async fn at_st3_websocket_event_hub() {
        let hub = EventHub::new(16);
        let mut rx = hub.subscribe();
        hub.publish(WsEvent::heartbeat());
        let event = rx.try_recv().unwrap();
        assert_eq!(event.event_type, EventType::Heartbeat);
        let json = serde_json::to_string(&event).unwrap();
        assert!(json.contains("heartbeat"));
    }

    // AT-ST4: Forge via API
    #[tokio::test]
    async fn at_st4_forge_via_api() {
        let app = test_app();
        let body = serde_json::json!({
            "intent": "Build a REST API for bookmarks",
            "domain": "Rust",
        });
        let resp = app
            .oneshot(
                Request::post("/forge")
                    .header("content-type", "application/json")
                    .body(Body::from(serde_json::to_vec(&body).unwrap()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(data["ok"], true);
        assert!(data.get("intent").is_some());
    }

    // AT-ST5: Foundry via API
    #[tokio::test]
    async fn at_st5_foundry_via_api() {
        let app = test_app();
        let body = serde_json::json!({
            "intent": "REST API for bookmark manager with tags",
        });
        let resp = app
            .oneshot(
                Request::post("/api/foundry/fabricate")
                    .header("content-type", "application/json")
                    .body(Body::from(serde_json::to_vec(&body).unwrap()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(data["ok"], true);
        assert!(data.get("project_id").is_some());
    }

    // AT-ST6: Explorer query
    #[tokio::test]
    async fn at_st6_explorer_query() {
        let state = AppState::new();
        {
            let mut engine = state.engine_state.write().await;
            engine.crystals.push(CrystalSummary {
                id: "a7b3c9test".into(),
                tick: 42,
                score: 0.78,
                scale: "micro".into(),
                checks: "8/8".into(),
                stability: 0.78,
                free_energy: -3.2,
                constraint_count: 3,
                topology: TopologySummary { spectral_gap: 0.12, kuramoto_r: 0.87 },
                evidence_count: 42,
            });
        }
        let app = build_router(state);
        let resp = app
            .oneshot(Request::get("/crystals?limit=5").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(data.is_array());
        let arr = data.as_array().unwrap();
        assert!(!arr.is_empty());
        assert!(arr[0].get("id").is_some());
        assert!(arr[0].get("score").is_some());
    }

    // AT-ST7: Command palette
    #[tokio::test]
    async fn at_st7_command_palette() {
        let app = test_app();
        let body = serde_json::json!({"command": "start engine shadow"});
        let resp = app
            .oneshot(
                Request::post("/api/command")
                    .header("content-type", "application/json")
                    .body(Body::from(serde_json::to_vec(&body).unwrap()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(data["ok"], true);
    }

    // AT-ST8: Health endpoint
    #[tokio::test]
    async fn at_st8_health_endpoint() {
        let app = test_app();
        let resp = app
            .oneshot(Request::get("/health").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(data["status"], "ok");
        assert!(data.get("version").is_some());
    }

    // AT-ST-AG1: Agent status returns ok field even without prior state
    #[tokio::test]
    async fn at_st_ag1_agent_status_no_state() {
        let app = test_app();
        let resp = app
            .oneshot(Request::get("/agent/status").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(data.get("ok").is_some());
    }

    // AT-ST-AG2: POST /agent/goal creates agent, runs it, returns metrics
    #[tokio::test]
    async fn at_st_ag2_agent_goal_runs() {
        let app = test_app();
        let body = serde_json::json!({
            "intent": "Build a deterministic event sourcing library",
            "domain": "rust",
            "confidence": 0.7,
        });
        let resp = app
            .oneshot(
                Request::post("/agent/goal")
                    .header("content-type", "application/json")
                    .body(Body::from(serde_json::to_vec(&body).unwrap()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert_eq!(data["ok"], true);
        assert!(data["steps_run"].as_u64().unwrap_or(0) > 0);
        assert!(data["plan_size"].as_u64().unwrap_or(0) >= 5);
    }

    // AT-AG22: Chat endpoint returns events in correct order
    #[tokio::test]
    async fn at_ag22_chat_endpoint_event_order() {
        let app = test_app();

        // Start chat job (project = "." which exists)
        let body = serde_json::json!({
            "message": "add a hello function",
            "project": ".",
        });
        let resp = app
            .clone()
            .oneshot(
                Request::post("/agent/chat")
                    .header("content-type", "application/json")
                    .body(Body::from(serde_json::to_vec(&body).unwrap()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let data: serde_json::Value = serde_json::from_slice(
            &axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap(),
        ).unwrap();
        assert_eq!(data["ok"], true);
        let job_id = data["job_id"].as_str().unwrap().to_string();

        // Poll until complete (max 30 attempts × 100ms = 3s)
        let mut events = serde_json::Value::Array(vec![]);
        let mut complete = false;
        for _ in 0..30 {
            tokio::time::sleep(tokio::time::Duration::from_millis(100)).await;
            let resp = app
                .clone()
                .oneshot(
                    Request::get(format!("/agent/chat/{}/events", job_id))
                        .body(Body::empty())
                        .unwrap(),
                )
                .await
                .unwrap();
            let data: serde_json::Value = serde_json::from_slice(
                &axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap(),
            ).unwrap();
            events = data["events"].clone();
            complete = data["complete"].as_bool().unwrap_or(false);
            if complete { break; }
        }

        assert!(complete, "job must complete within 3 seconds");

        // Verify event ordering: Analysis must come before Complete
        let event_types: Vec<&str> = events.as_array().unwrap()
            .iter()
            .filter_map(|e| e.get("type").and_then(|t| t.as_str()))
            .collect();

        assert!(!event_types.is_empty(), "must have at least one event");
        let first = event_types[0];
        let last = *event_types.last().unwrap();
        assert_eq!(first, "analysis", "first event must be analysis, got: {}", first);
        assert_eq!(last, "complete", "last event must be complete, got: {}", last);
    }

    // AT-AG22b: /agent/bind stores the project path
    #[tokio::test]
    async fn at_ag22b_agent_bind() {
        let app = test_app();
        let body = serde_json::json!({"project": "/tmp"});
        let resp = app
            .oneshot(
                Request::post("/agent/bind")
                    .header("content-type", "application/json")
                    .body(Body::from(serde_json::to_vec(&body).unwrap()))
                    .unwrap(),
            )
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let data: serde_json::Value = serde_json::from_slice(
            &axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap(),
        ).unwrap();
        assert_eq!(data["ok"], true);
        assert_eq!(data["project"], "/tmp");
    }

    // AT-ST-AG3: GET /agent/history returns ok field
    #[tokio::test]
    async fn at_st_ag3_agent_history() {
        let app = test_app();
        // Run goal first so history may exist
        let goal_body = serde_json::json!({"intent": "History test goal"});
        let _ = app
            .clone()
            .oneshot(
                Request::post("/agent/goal")
                    .header("content-type", "application/json")
                    .body(Body::from(serde_json::to_vec(&goal_body).unwrap()))
                    .unwrap(),
            )
            .await
            .unwrap();
        let resp = app
            .oneshot(Request::get("/agent/history").body(Body::empty()).unwrap())
            .await
            .unwrap();
        assert_eq!(resp.status(), StatusCode::OK);
        let body = axum::body::to_bytes(resp.into_body(), usize::MAX).await.unwrap();
        let data: serde_json::Value = serde_json::from_slice(&body).unwrap();
        assert!(data.get("ok").is_some());
    }
}

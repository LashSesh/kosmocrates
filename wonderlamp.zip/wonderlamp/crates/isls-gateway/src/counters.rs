// isls-gateway/src/counters.rs — Persistent cumulative counters
//
// These counters are NEVER reset, NEVER decreased, and survive across
// any number of server restarts. Written atomically to ~/.isls/counters.json
// via tmp+rename. Corrupt files are backed up, not overwritten.

use std::path::PathBuf;

use serde::{Deserialize, Serialize};

// ─── Path helpers ─────────────────────────────────────────────────────────────

fn isls_home() -> PathBuf {
    std::env::var("HOME")
        .map(|h| PathBuf::from(h).join(".isls"))
        .unwrap_or_else(|_| PathBuf::from("/tmp/isls"))
}

fn counters_path() -> PathBuf {
    isls_home().join("counters.json")
}

// ─── Data types ───────────────────────────────────────────────────────────────

/// Cumulative counters that survive server restarts.
/// Every field is monotonically non-decreasing — see `save_counters` plausibility check.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Counters {
    pub repos_scraped_total: u64,
    pub observations_total: u64,
    pub forge_runs_total: u64,
    pub forge_successes_total: u64,
    pub auto_evolve_runs_total: u64,
    pub harpoon_runs_total: u64,
    pub norms_ever_promoted: u64,
    /// ISO-8601 timestamp of the very first server start — set once, never changed.
    pub first_started: String,
    /// ISO-8601 timestamp of the last write.
    pub last_updated: String,
}

impl Counters {
    /// Create a zeroed counter set with `first_started` = now.
    pub fn new() -> Self {
        let now = chrono::Utc::now().to_rfc3339();
        Self {
            repos_scraped_total: 0,
            observations_total: 0,
            forge_runs_total: 0,
            forge_successes_total: 0,
            auto_evolve_runs_total: 0,
            harpoon_runs_total: 0,
            norms_ever_promoted: 0,
            first_started: now.clone(),
            last_updated: now,
        }
    }
}

pub enum CounterField {
    ReposScraped,
    Observations,
    ForgeRuns,
    ForgeSuccesses,
    AutoEvolveRuns,
    HarpoonRuns,
    NormsPromoted,
}

// ─── I/O ──────────────────────────────────────────────────────────────────────

/// Load from disk without the corrupt-backup side-effect (used for plausibility checks).
fn load_counters_raw(path: &PathBuf) -> Result<Counters, ()> {
    let json = std::fs::read_to_string(path).map_err(|_| ())?;
    serde_json::from_str(&json).map_err(|_| ())
}

/// Load counters from disk. If the file is corrupt, back it up and start fresh.
/// If the file doesn't exist yet, return zeroed counters (will be created on first save).
pub fn load_counters() -> Counters {
    let path = counters_path();
    match std::fs::read_to_string(&path) {
        Ok(json) => match serde_json::from_str::<Counters>(&json) {
            Ok(c) => c,
            Err(_) => {
                let backup = isls_home().join(format!(
                    "counters.json.corrupt.{}",
                    chrono::Utc::now().timestamp()
                ));
                std::fs::copy(&path, &backup).ok();
                tracing::error!(
                    "counters.json is corrupt — backed up to {:?}, starting fresh",
                    backup
                );
                Counters::new()
            }
        },
        Err(_) => Counters::new(),
    }
}

/// Atomically write counters to disk.
///
/// Enforces a plausibility invariant: any counter that would decrease compared
/// to the currently stored value is REFUSED and logged as an error.
pub fn save_counters(counters: &Counters) {
    let home = isls_home();
    let path = home.join("counters.json");
    let tmp = home.join("counters.json.tmp");

    // ── Plausibility: no counter may ever decrease ─────────────────
    if let Ok(existing) = load_counters_raw(&path) {
        macro_rules! check_field {
            ($field:ident) => {
                if counters.$field < existing.$field {
                    tracing::error!(
                        "REFUSED: {} would decrease {} -> {}",
                        stringify!($field),
                        existing.$field,
                        counters.$field
                    );
                    return;
                }
            };
        }
        check_field!(repos_scraped_total);
        check_field!(observations_total);
        check_field!(forge_runs_total);
        check_field!(forge_successes_total);
        check_field!(auto_evolve_runs_total);
        check_field!(harpoon_runs_total);
        check_field!(norms_ever_promoted);
    }

    // ── Atomic write via tmp + rename ─────────────────────────────
    std::fs::create_dir_all(&home).ok();
    let json = match serde_json::to_string_pretty(counters) {
        Ok(j) => j,
        Err(e) => {
            tracing::error!("Failed to serialize counters: {}", e);
            return;
        }
    };
    if std::fs::write(&tmp, &json).is_ok() {
        if let Err(e) = std::fs::rename(&tmp, &path) {
            tracing::error!("Failed to atomically rename counters: {}", e);
        }
    }
}

// ─── Public API ───────────────────────────────────────────────────────────────

/// Increment a counter by `amount` and persist immediately.
pub fn increment_counter(field: CounterField, amount: u64) {
    if amount == 0 {
        return;
    }
    let mut c = load_counters();
    match field {
        CounterField::ReposScraped => c.repos_scraped_total += amount,
        CounterField::Observations => c.observations_total += amount,
        CounterField::ForgeRuns => c.forge_runs_total += amount,
        CounterField::ForgeSuccesses => c.forge_successes_total += amount,
        CounterField::AutoEvolveRuns => c.auto_evolve_runs_total += amount,
        CounterField::HarpoonRuns => c.harpoon_runs_total += amount,
        CounterField::NormsPromoted => c.norms_ever_promoted += amount,
    }
    c.last_updated = chrono::Utc::now().to_rfc3339();
    save_counters(&c);
}

/// Sync `observations_total` from the norm registry's current sum.
/// Since observations only grow (candidates accumulate them), this is safe
/// to call after every scrape batch — the plausibility check will reject
/// any decrease.
pub fn sync_observations(current_total: u64) {
    if current_total == 0 {
        return;
    }
    let mut c = load_counters();
    if current_total > c.observations_total {
        c.observations_total = current_total;
        c.last_updated = chrono::Utc::now().to_rfc3339();
        save_counters(&c);
    }
}

// isls-gateway/src/discover.rs — Entdecken-mode API handlers (S1c)
//
// GitHub search, X-ray topology, scrape into norms, mass-scrape
// background jobs, norm gap analysis, and norm genealogy.

use std::collections::{BTreeMap, HashMap, VecDeque};
use std::path::{Path, PathBuf};
use std::sync::Arc;
use std::time::Duration;

use axum::extract::{Path as AxumPath, Query, State};
use axum::response::Json;
use serde::{Deserialize, Serialize};
use tokio::sync::{RwLock, Semaphore};

use isls_code_topo::{self, bridge, CodeTopology};
use isls_norms::NormRegistry;

use crate::ws::{EventType, WsEvent};
use crate::AppState;

// ═══════════════════════════════════════════════════════════════════
// Request / Response types
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Deserialize)]
pub struct SearchRequest {
    pub query: String,
    pub max_results: Option<usize>,
}

#[derive(Debug, Deserialize)]
pub struct XrayRequest {
    pub url: String,
}

#[derive(Debug, Deserialize)]
pub struct ScrapeRequest {
    pub url: Option<String>,
    pub path: Option<String>,
    pub domain: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct MassScrapeRequest {
    pub keywords: Vec<String>,
    pub results_per_keyword: Option<usize>,
}

#[derive(Debug, Deserialize)]
pub struct SimilarityQuery {
    pub domain: Option<String>,
}

// ═══════════════════════════════════════════════════════════════════
// Mass-scrape job tracking
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Clone, Serialize)]
pub struct MassScrapeJob {
    pub id: String,
    pub status: String,
    pub keywords_total: usize,
    pub keywords_done: usize,
    pub repos_scraped: usize,
    pub repos_failed: usize,
    pub new_candidates: usize,
    pub new_norms: usize,
    pub errors: Vec<String>,
}

pub type MassScrapeStore = Arc<RwLock<HashMap<String, MassScrapeJob>>>;

pub fn new_mass_scrape_store() -> MassScrapeStore {
    Arc::new(RwLock::new(HashMap::new()))
}

// ═══════════════════════════════════════════════════════════════════
// S1/ux: Scrape history ring-buffer
// ═══════════════════════════════════════════════════════════════════

/// Maximum number of entries retained by the in-memory scrape history.
pub const SCRAPE_HISTORY_CAPACITY: usize = 100;

/// One completed mass-scrape run (one keyword's worth of results).
///
/// These entries are pushed onto the `ScrapeHistory` ring-buffer when a
/// mass-scrape job finishes and are surfaced through
/// `GET /api/discover/scrape-status` to drive the Studio's live
/// Ölbohrinsel monitor.
#[derive(Debug, Clone, Serialize)]
pub struct ScrapeHistoryEntry {
    pub timestamp: String,
    pub keyword: String,
    pub repos: Vec<String>,
    pub artifacts: usize,
    pub new_candidates: usize,
    pub new_norms: usize,
}

/// In-memory ring-buffer of recent scrape entries.
pub type ScrapeHistoryStore = Arc<tokio::sync::Mutex<VecDeque<ScrapeHistoryEntry>>>;

/// Construct an empty ring-buffer. Capacity is fixed at
/// [`SCRAPE_HISTORY_CAPACITY`]; older entries fall off the back.
pub fn new_scrape_history_store() -> ScrapeHistoryStore {
    Arc::new(tokio::sync::Mutex::new(VecDeque::with_capacity(
        SCRAPE_HISTORY_CAPACITY,
    )))
}

/// Append an entry to the ring-buffer, evicting the oldest when full.
pub async fn push_scrape_history(store: &ScrapeHistoryStore, entry: ScrapeHistoryEntry) {
    let mut guard = store.lock().await;
    if guard.len() >= SCRAPE_HISTORY_CAPACITY {
        guard.pop_front();
    }
    guard.push_back(entry);
}

// ═══════════════════════════════════════════════════════════════════
// GitHub API client
// ═══════════════════════════════════════════════════════════════════

async fn github_search_repos(
    query: &str,
    max_results: usize,
) -> Result<serde_json::Value, String> {
    let url = format!(
        "https://api.github.com/search/repositories?q={}&sort=stars&order=desc&per_page={}",
        urlencoded(query),
        max_results.min(30),
    );

    let client = reqwest::Client::new();
    let resp = client
        .get(&url)
        .header("User-Agent", "isls-gateway/1.0")
        .header("Accept", "application/vnd.github.v3+json")
        .timeout(Duration::from_secs(15))
        .send()
        .await
        .map_err(|e| format!("GitHub API request failed: {}", e))?;

    let status = resp.status();
    if status.as_u16() == 403 {
        return Err("GitHub API rate limit exceeded. Wait 60 seconds.".to_string());
    }
    if !status.is_success() {
        return Err(format!("GitHub API returned {}", status));
    }

    let body: serde_json::Value = resp
        .json()
        .await
        .map_err(|e| format!("Failed to parse GitHub response: {}", e))?;

    let repos: Vec<serde_json::Value> = body["items"]
        .as_array()
        .unwrap_or(&vec![])
        .iter()
        .map(|item| {
            serde_json::json!({
                "full_name": item["full_name"],
                "description": item["description"],
                "html_url": item["html_url"],
                "clone_url": item["clone_url"],
                "stargazers_count": item["stargazers_count"],
                "language": item["language"],
                "updated_at": item["updated_at"],
            })
        })
        .collect();

    Ok(serde_json::json!({
        "total_count": body["total_count"],
        "repos": repos,
    }))
}

fn urlencoded(s: &str) -> String {
    s.chars()
        .map(|c| match c {
            ' ' => "+".to_string(),
            c if c.is_ascii_alphanumeric() || "-_.~:".contains(c) => c.to_string(),
            c => format!("%{:02X}", c as u32),
        })
        .collect()
}

// ═══════════════════════════════════════════════════════════════════
// Git clone + analyze pipeline
// ═══════════════════════════════════════════════════════════════════

struct TempCloneGuard {
    path: PathBuf,
}

impl Drop for TempCloneGuard {
    fn drop(&mut self) {
        if self.path.exists() {
            let _ = std::fs::remove_dir_all(&self.path);
        }
    }
}

fn temp_clone_path(url: &str) -> PathBuf {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    url.hash(&mut hasher);
    let ts = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis();
    std::env::temp_dir().join(format!("isls-discover-{:x}-{}", hasher.finish(), ts))
}

/// Clone a repo, parse it, compute topology. Optionally feed norms.
async fn clone_and_analyze(
    url: &str,
    domain: &str,
    registry: Option<Arc<RwLock<NormRegistry>>>,
) -> Result<serde_json::Value, String> {
    let clone_url = url.to_string();
    let domain_str = domain.to_string();

    tokio::task::spawn_blocking(move || {
        clone_and_analyze_sync(&clone_url, &domain_str, registry.is_some())
    })
    .await
    .map_err(|e| format!("Task panicked: {}", e))?
    .map(|(result, artifacts_for_norms)| {
        // If we have a registry + artifacts, feed norms on the async side
        // But since spawn_blocking already returned, we handle norms inline
        // Actually we handle norms inside the blocking task for simplicity
        result
    })
}

fn clone_and_analyze_sync(
    url: &str,
    domain: &str,
    feed_norms: bool,
) -> Result<(serde_json::Value, bool), String> {
    let temp_dir = temp_clone_path(url);
    if temp_dir.exists() {
        let _ = std::fs::remove_dir_all(&temp_dir);
    }
    let _guard = TempCloneGuard { path: temp_dir.clone() };

    // Shallow clone
    let output = std::process::Command::new("git")
        .args(["clone", "--depth", "1", "--single-branch", url])
        .arg(&temp_dir)
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .output()
        .map_err(|e| format!("git clone failed to start: {}", e))?;

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(format!("git clone failed: {}", stderr.trim()));
    }

    analyze_directory_sync(&temp_dir, domain, Some(url), feed_norms)
}

fn analyze_directory_sync(
    dir: &Path,
    domain: &str,
    source_url: Option<&str>,
    feed_norms: bool,
) -> Result<(serde_json::Value, bool), String> {
    // Parse
    let analysis = isls_reader::parse_directory(dir)
        .map_err(|e| format!("Parse error: {}", e))?;

    // Compute topology
    let topology = isls_code_topo::compute_code_topology(&analysis.files);

    // Bridge to artifacts
    let (artifacts, skipped) = bridge::observations_from_code(&analysis.files);

    let mut struct_count = 0usize;
    let mut fn_count = 0usize;
    let mut table_count = 0usize;
    let mut layer_counts: BTreeMap<String, usize> = BTreeMap::new();
    for a in &artifacts {
        match a.artifact_type.as_str() {
            "struct" => struct_count += 1,
            "fn" => fn_count += 1,
            "table" => table_count += 1,
            _ => {}
        }
        *layer_counts.entry(format!("{:?}", a.layer)).or_insert(0) += 1;
    }

    // ── I4/bonus: extract auto-keywords from this repo ────────────────
    let auto_keywords: Vec<String> = {
        // Aggregate all import paths across files for keyword extraction.
        let mut all_imports: Vec<String> = Vec::new();
        for obs in &analysis.files {
            all_imports.extend(obs.imports.iter().cloned());
        }
        all_imports.sort();
        all_imports.dedup();

        isls_norms::spectroscopy::extract_keywords_from_analysis(
            &topology.struct_names,
            &all_imports,
            &topology.primary_language,
            5, // max 5 keywords per repo (spec)
        )
    };

    let mut norm_result = serde_json::json!(null);

    if feed_norms && !artifacts.is_empty() {
        let timestamp = chrono::Local::now().format("%Y%m%d_%H%M%S");
        let run_id = format!("discover_{}_{}", domain, timestamp);

        let mut registry = NormRegistry::new();
        let candidates_before = registry.candidates().len();
        let norms_before = registry.all_norms().len();

        // observe_and_learn appends events to the append-only ledger
        registry.observe_and_learn(&artifacts, domain, &run_id);

        let candidates_after = registry.candidates().len();
        let norms_after = registry.all_norms().len();

        norm_result = serde_json::json!({
            "new_candidates": candidates_after.saturating_sub(candidates_before),
            "new_norms": norms_after.saturating_sub(norms_before),
            "total_candidates": candidates_after,
            "total_norms": norms_after,
        });
    }

    let result = serde_json::json!({
        "source": source_url.unwrap_or("local"),
        "domain": domain,
        "files_parsed": analysis.files.len(),
        "total_loc": analysis.total_loc,
        "artifact_count": artifacts.len(),
        "struct_count": struct_count,
        "fn_count": fn_count,
        "table_count": table_count,
        "skipped": skipped,
        "layers": layer_counts,
        "topology": {
            "node_count": topology.node_count,
            "edge_count": topology.edge_count,
            "connectivity": topology.connectivity,
            "layers": topology.layers,
            "struct_names": topology.struct_names.iter().take(30).collect::<Vec<_>>(),
            "function_signatures": topology.function_signatures.iter().take(30).collect::<Vec<_>>(),
            "language_breakdown": topology.language_breakdown,
            "primary_language": &topology.primary_language,
        },
        "norms": norm_result,
        "auto_keywords": auto_keywords,
    });

    Ok((result, feed_norms))
}

// ═══════════════════════════════════════════════════════════════════
// Handlers
// ═══════════════════════════════════════════════════════════════════

// ═══════════════════════════════════════════════════════════════════
// Keyword file helpers
// ═══════════════════════════════════════════════════════════════════

/// Append `new_keywords` to the keyword file at `path`, skipping any that
/// are already present (case-insensitive).  Returns the number of keywords
/// actually written.
async fn append_new_keywords(path: &Path, new_keywords: &[String]) -> usize {
    if new_keywords.is_empty() {
        return 0;
    }
    let existing_raw = tokio::fs::read_to_string(path).await.unwrap_or_default();
    let existing: std::collections::BTreeSet<String> = existing_raw
        .lines()
        .filter(|l| !l.trim().is_empty() && !l.starts_with('#'))
        .map(|l| l.trim().to_lowercase())
        .collect();

    use tokio::io::AsyncWriteExt;
    let mut file = match tokio::fs::OpenOptions::new()
        .create(true)
        .append(true)
        .open(path)
        .await
    {
        Ok(f) => f,
        Err(e) => {
            tracing::warn!("Could not open keywords file {:?}: {}", path, e);
            return 0;
        }
    };

    let mut added = 0usize;
    for kw in new_keywords {
        if !existing.contains(&kw.to_lowercase()) {
            if let Err(e) = file.write_all(format!("{}\n", kw).as_bytes()).await {
                tracing::warn!("Failed to write keyword '{}': {}", kw, e);
            } else {
                added += 1;
            }
        }
    }
    added
}

/// POST /api/discover/search — GitHub keyword search
pub async fn discover_search(
    Json(req): Json<SearchRequest>,
) -> Json<serde_json::Value> {
    let max = req.max_results.unwrap_or(10).min(30);

    match github_search_repos(&req.query, max).await {
        Ok(data) => Json(serde_json::json!({ "ok": true, "data": data })),
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

/// POST /api/discover/xray — Read-only topology scan (no norm feed)
pub async fn discover_xray(
    Json(req): Json<XrayRequest>,
) -> Json<serde_json::Value> {
    let domain = bridge::domain_from_url(&req.url);

    match clone_and_analyze(&req.url, &domain, None).await {
        Ok(data) => Json(serde_json::json!({ "ok": true, "data": data })),
        Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
    }
}

/// POST /api/discover/scrape — Scrape single repo into norms
pub async fn discover_scrape(
    State(state): State<AppState>,
    Json(req): Json<ScrapeRequest>,
) -> Json<serde_json::Value> {
    if req.url.is_none() && req.path.is_none() {
        return Json(serde_json::json!({ "ok": false, "error": "url or path required" }));
    }

    let domain = req.domain.clone().unwrap_or_else(|| {
        if let Some(ref u) = req.url {
            bridge::domain_from_url(u)
        } else if let Some(ref p) = req.path {
            bridge::domain_from_path(Path::new(p))
        } else {
            "unknown".to_string()
        }
    });

    if let Some(ref url) = req.url {
        let kw_path = state.suggested_keywords_path.clone();
        match clone_and_analyze(url, &domain, Some(state.norm_registry.clone())).await {
            Ok(data) => {
                let auto_kws: Vec<String> = data["auto_keywords"]
                    .as_array()
                    .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                    .unwrap_or_default();
                let added = append_new_keywords(&kw_path, &auto_kws).await;
                if added > 0 {
                    tracing::info!("Auto-added {} keywords from {}", added, url);
                }
                Json(serde_json::json!({ "ok": true, "data": data }))
            }
            Err(e) => Json(serde_json::json!({ "ok": false, "error": e })),
        }
    } else if let Some(ref path_str) = req.path {
        let p = PathBuf::from(path_str);
        if !p.is_dir() {
            return Json(serde_json::json!({ "ok": false, "error": "path is not a directory" }));
        }
        let domain_c = domain.clone();
        let kw_path = state.suggested_keywords_path.clone();
        let result = tokio::task::spawn_blocking(move || {
            analyze_directory_sync(&p, &domain_c, None, true)
        })
        .await;

        match result {
            Ok(Ok((data, _))) => {
                let auto_kws: Vec<String> = data["auto_keywords"]
                    .as_array()
                    .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                    .unwrap_or_default();
                let added = append_new_keywords(&kw_path, &auto_kws).await;
                if added > 0 {
                    tracing::info!("Auto-added {} keywords from local path", added);
                }
                Json(serde_json::json!({ "ok": true, "data": data }))
            }
            Ok(Err(e)) => Json(serde_json::json!({ "ok": false, "error": e })),
            Err(e) => Json(serde_json::json!({ "ok": false, "error": format!("Task panicked: {}", e) })),
        }
    } else {
        Json(serde_json::json!({ "ok": false, "error": "url or path required" }))
    }
}

/// POST /api/discover/mass-scrape — Background mass-scrape job
pub async fn discover_mass_scrape(
    State(state): State<AppState>,
    Json(req): Json<MassScrapeRequest>,
) -> Json<serde_json::Value> {
    if req.keywords.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "keywords list is empty" }));
    }

    let per_kw = req.results_per_keyword.unwrap_or(3).min(10);
    let job_id = format!("mscrape-{:08x}", rand_u32());
    let keywords = req.keywords.clone();

    let job = MassScrapeJob {
        id: job_id.clone(),
        status: "running".to_string(),
        keywords_total: keywords.len(),
        keywords_done: 0,
        repos_scraped: 0,
        repos_failed: 0,
        new_candidates: 0,
        new_norms: 0,
        errors: vec![],
    };

    state.mass_scrape_jobs.write().await.insert(job_id.clone(), job);

    let jobs = state.mass_scrape_jobs.clone();
    let event_hub = state.event_hub.clone();
    let history = state.scrape_history.clone();
    let kw_path = state.suggested_keywords_path.clone();
    let job_id_ret = job_id.clone();

    tokio::spawn(async move {
        run_mass_scrape(jobs, event_hub, history, kw_path, job_id, keywords, per_kw).await;
    });

    Json(serde_json::json!({
        "ok": true,
        "job_id": job_id_ret,
        "keywords": req.keywords.len(),
        "results_per_keyword": per_kw,
    }))
}

/// Max number of concurrent repo scrape workers.
///
/// I2/W3: GitHub search is rate-limited so it stays sequential. The actual
/// clone+parse pipeline is CPU/IO-bound and parallelizes well. 4 workers is
/// the spec default — `Semaphore::new(4)`.
const MASS_SCRAPE_PARALLELISM: usize = 4;

/// A repository queued for scraping after phase-1 keyword search.
struct QueuedRepo {
    keyword: String,
    clone_url: String,
    full_name: String,
    domain: String,
}

pub async fn run_mass_scrape(
    jobs: MassScrapeStore,
    event_hub: crate::ws::EventHub,
    history: ScrapeHistoryStore,
    keywords_path: PathBuf,
    job_id: String,
    keywords: Vec<String>,
    per_keyword: usize,
) {
    let total = keywords.len();

    // ─── Phase 1: sequential GitHub search, rate-limited ────────────────
    //
    // Emits DiscoverKeyword events in keyword order and collects all repos
    // into a single queue. The 2-second sleep honours GitHub's search rate
    // limit. No cloning happens in this phase.
    let mut queue: Vec<QueuedRepo> = Vec::new();

    for (ki, keyword) in keywords.iter().enumerate() {
        event_hub.publish(WsEvent::new(
            EventType::DiscoverKeyword,
            serde_json::json!({
                "type": "discover:keyword",
                "job_id": &job_id,
                "index": ki + 1,
                "total": total,
                "keyword": keyword,
            }),
        ));

        let repos = match github_search_repos(keyword, per_keyword).await {
            Ok(data) => data["repos"].as_array().cloned().unwrap_or_default(),
            Err(e) => {
                let mut j = jobs.write().await;
                if let Some(job) = j.get_mut(&job_id) {
                    job.errors.push(format!("Search '{}': {}", keyword, e));
                }
                vec![]
            }
        };

        for repo in &repos {
            let clone_url = repo["clone_url"].as_str().unwrap_or("").to_string();
            let full_name = repo["full_name"].as_str().unwrap_or("unknown").to_string();
            if clone_url.is_empty() {
                continue;
            }
            let domain = bridge::domain_from_url(&clone_url);
            queue.push(QueuedRepo {
                keyword: keyword.clone(),
                clone_url,
                full_name,
                domain,
            });
        }

        // Advance keyword-progress counter as soon as each keyword's
        // search completes (scraping for this keyword continues in phase 2).
        {
            let mut j = jobs.write().await;
            if let Some(job) = j.get_mut(&job_id) {
                job.keywords_done = ki + 1;
            }
        }

        if ki + 1 < total {
            tokio::time::sleep(Duration::from_secs(2)).await;
        }
    }

    // ─── Phase 2: parallel scrape with bounded worker pool ──────────────
    //
    // Spawn one tokio task per queued repo. A shared semaphore with
    // MASS_SCRAPE_PARALLELISM permits bounds concurrency. Each task calls
    // the existing `clone_and_analyze_sync` helper inside
    // `spawn_blocking`, publishes a `DiscoverRepo` event on success, and
    // updates the shared job record.
    let semaphore = Arc::new(Semaphore::new(MASS_SCRAPE_PARALLELISM));
    let mut handles = Vec::with_capacity(queue.len());

    // S1/ux: per-keyword aggregation so we can push a ScrapeHistoryEntry
    // for every keyword after the phase-2 scrape completes. Preserve
    // the original keyword order by seeding the map up-front.
    #[derive(Default)]
    struct KeywordAgg {
        repos: Vec<String>,
        artifacts: usize,
        new_candidates: usize,
        new_norms: usize,
    }
    let per_keyword: Arc<tokio::sync::Mutex<std::collections::BTreeMap<String, KeywordAgg>>> =
        Arc::new(tokio::sync::Mutex::new(std::collections::BTreeMap::new()));
    for kw in &keywords {
        per_keyword
            .lock()
            .await
            .entry(kw.clone())
            .or_default();
    }

    for repo in queue {
        let permit_sem = semaphore.clone();
        let jobs_cl = jobs.clone();
        let event_hub_cl = event_hub.clone();
        let job_id_cl = job_id.clone();
        let per_kw_cl = per_keyword.clone();

        let kw_path_cl = keywords_path.clone();

        handles.push(tokio::spawn(async move {
            // Acquire before touching disk/network.
            let _permit = match permit_sem.acquire_owned().await {
                Ok(p) => p,
                Err(_) => return,
            };

            let clone_url_owned = repo.clone_url.clone();
            let domain_owned = repo.domain.clone();

            let result = tokio::task::spawn_blocking(move || {
                clone_and_analyze_sync(&clone_url_owned, &domain_owned, true)
            })
            .await;

            match result {
                Ok(Ok((data, _))) => {
                    let artifact_count = data["artifact_count"].as_u64().unwrap_or(0);
                    let new_cands = data["norms"]["new_candidates"].as_u64().unwrap_or(0);
                    let new_norms = data["norms"]["new_norms"].as_u64().unwrap_or(0);

                    // Extract and persist auto-keywords from this repo.
                    let auto_kws: Vec<String> = data["auto_keywords"]
                        .as_array()
                        .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
                        .unwrap_or_default();
                    let added_kws = append_new_keywords(&kw_path_cl, &auto_kws).await;
                    if added_kws > 0 {
                        tracing::info!(
                            "Auto-added {} keywords from {}",
                            added_kws, repo.full_name
                        );
                    }

                    event_hub_cl.publish(WsEvent::new(
                        EventType::DiscoverRepo,
                        serde_json::json!({
                            "type": "discover:repo",
                            "job_id": &job_id_cl,
                            "repo": repo.full_name,
                            "artifacts": artifact_count,
                            "keyword": repo.keyword,
                            "new_candidates": new_cands,
                            "new_norms": new_norms,
                            "auto_keywords": auto_kws,
                        }),
                    ));

                    {
                        let mut j = jobs_cl.write().await;
                        if let Some(job) = j.get_mut(&job_id_cl) {
                            job.repos_scraped += 1;
                            job.new_candidates += new_cands as usize;
                            job.new_norms += new_norms as usize;
                        }
                    }
                    // Persistent counter: every successfully scraped repo
                    crate::counters::increment_counter(crate::counters::CounterField::ReposScraped, 1);

                    // Per-keyword aggregation for the scrape history.
                    let mut agg = per_kw_cl.lock().await;
                    let entry = agg.entry(repo.keyword.clone()).or_default();
                    entry.repos.push(repo.full_name.clone());
                    entry.artifacts += artifact_count as usize;
                    entry.new_candidates += new_cands as usize;
                    entry.new_norms += new_norms as usize;
                }
                _ => {
                    let mut j = jobs_cl.write().await;
                    if let Some(job) = j.get_mut(&job_id_cl) {
                        job.repos_failed += 1;
                        job.errors.push(format!("Scrape failed: {}", repo.full_name));
                    }
                }
            }
        }));
    }

    // Wait for every scrape task to finish before publishing completion.
    futures::future::join_all(handles).await;

    // Sync observations_total from norm registry (persistent across restarts)
    {
        let fresh = NormRegistry::new();
        let total_obs: u64 = fresh.candidates().iter()
            .map(|c| c.observation_count as u64)
            .sum();
        crate::counters::sync_observations(total_obs);
    }

    // S1/ux: persist one ScrapeHistoryEntry per keyword, in declaration
    // order. Entries whose keyword produced no repos still get a row
    // so the Studio feed reflects the attempted campaign.
    {
        let agg = per_keyword.lock().await;
        for kw in &keywords {
            if let Some(k) = agg.get(kw) {
                let entry = ScrapeHistoryEntry {
                    timestamp: chrono::Utc::now().to_rfc3339(),
                    keyword: kw.clone(),
                    repos: k.repos.clone(),
                    artifacts: k.artifacts,
                    new_candidates: k.new_candidates,
                    new_norms: k.new_norms,
                };
                push_scrape_history(&history, entry).await;
            }
        }
    }

    // Complete
    let final_job = {
        let mut j = jobs.write().await;
        if let Some(job) = j.get_mut(&job_id) {
            job.status = "complete".to_string();
            job.clone()
        } else {
            return;
        }
    };

    event_hub.publish(WsEvent::new(
        EventType::DiscoverComplete,
        serde_json::json!({
            "type": "discover:complete",
            "job_id": &job_id,
            "repos_scraped": final_job.repos_scraped,
            "repos_failed": final_job.repos_failed,
            "new_candidates": final_job.new_candidates,
            "new_norms": final_job.new_norms,
        }),
    ));
}

/// GET /api/discover/mass-scrape/{id}/status
pub async fn discover_mass_scrape_status(
    State(state): State<AppState>,
    AxumPath(id): AxumPath<String>,
) -> Json<serde_json::Value> {
    let jobs = state.mass_scrape_jobs.read().await;
    match jobs.get(&id) {
        Some(job) => Json(serde_json::json!({ "ok": true, "job": job })),
        None => Json(serde_json::json!({ "ok": false, "error": "job not found" })),
    }
}

/// POST /api/discover/upload-keywords — Parse text body as keywords
pub async fn discover_upload_keywords(
    State(state): State<AppState>,
    body: String,
) -> Json<serde_json::Value> {
    let keywords: Vec<String> = body
        .lines()
        .map(|l| l.trim().to_string())
        .filter(|l| !l.is_empty() && !l.starts_with('#'))
        .collect();

    if keywords.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "no keywords found in body" }));
    }

    let req = MassScrapeRequest {
        keywords,
        results_per_keyword: Some(3),
    };

    discover_mass_scrape(State(state), Json(req)).await
}

/// GET /api/discover/gaps — Norm gap analysis (I3/W1: Constraint Spectroscopy).
///
/// Returns the SpectroscopyResult computed against the registry's breadth —
/// every class the registry does *not* yet cover is reported as a gap with
/// suggested scrape keywords. The response shape is a superset of the
/// legacy payload (still includes `gaps` + `covered` + `total_norms`) so
/// existing Studio code continues to work.
pub async fn discover_gaps(
    State(state): State<AppState>,
) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;
    let all_norms = registry.all_norms();
    let candidates = registry.candidates();

    // Synthetic target: every known ResoniteClass is represented by a
    // single placeholder resonite. Running spectroscopy against this
    // "universal target" surfaces the registry's breadth gaps.
    let universe = universal_target_resonites();
    let result = isls_norms::spectroscopy::spectroscopy(&universe, &registry);

    let gaps_json: Vec<serde_json::Value> = result
        .gaps
        .iter()
        .zip(result.suggestions.iter().map(Some).chain(std::iter::repeat(None)))
        .map(|(gap, sugg)| {
            let suggested = sugg
                .and_then(|s| s.keywords.first().cloned())
                .unwrap_or_default();
            serde_json::json!({
                "area": gap.class.as_str(),
                "class": gap.class.as_str(),
                "norm_count": 0,
                "priority": gap.priority,
                "resonite_count": gap.resonite_count,
                "suggested_query": suggested,
            })
        })
        .collect();

    let covered_json: Vec<serde_json::Value> = result
        .covered
        .iter()
        .map(|c| serde_json::json!({
            "area": c.as_str(),
            "class": c.as_str(),
            "keyword_matches": 1,
        }))
        .collect();

    let builtin_count = all_norms.iter().filter(|n| n.evidence.builtin).count();
    let auto_count = all_norms.len() - builtin_count;

    Json(serde_json::json!({
        "ok": true,
        "total_norms": all_norms.len(),
        "builtin": builtin_count,
        "auto": auto_count,
        "candidates": candidates.len(),
        "coverage": result.coverage,
        "gaps": gaps_json,
        "covered": covered_json,
    }))
}

/// Produce one resonite per known ResoniteClass so that
/// [`isls_norms::spectroscopy::spectroscopy`] runs against the universe
/// of classes known to ISLS. Used by `/api/discover/gaps`.
fn universal_target_resonites() -> Vec<isls_norms::spectroscopy::Resonite> {
    use isls_norms::spectroscopy::Resonite;
    [
        "list_items",
        "login_user",
        "authorize_request",
        "emit_event",
        "enqueue_job",
        "acquire_conn",
        "cache_get",
        "rate_limit_check",
        "circuit_break_trip",
        "retry_backoff",
        "paginate_results",
        "search_fulltext",
        "upload_file",
        "export_csv",
        "schedule_cron",
        "notify_user",
        "log_entry",
        "metrics_record",
        "health_check",
        "load_config",
        "migrate_schema",
        "test_runner",
        "state_transition",
        "workflow_step",
        "compute_rsi",
        "filter_signal",
        "risk_kelly",
        "execute_order",
        "chart_render",
        "ws_broadcast",
        "graphql_resolver",
        "grpc_handler",
        "cli_parse_args",
        "register_plugin",
    ]
    .iter()
    .map(|n| Resonite::Fn { name: n.to_string(), arity: 1 })
    .collect()
}

// ═══════════════════════════════════════════════════════════════════
// I3/W1: Constraint Spectroscopy endpoints
// ═══════════════════════════════════════════════════════════════════

#[derive(Debug, Deserialize)]
pub struct SpectroscopyRequest {
    #[serde(default)]
    pub path: Option<String>,
    #[serde(default)]
    pub url: Option<String>,
    #[serde(default)]
    pub description: Option<String>,
}

#[derive(Debug, Deserialize)]
pub struct SpectroscopyFillRequest {
    #[serde(default)]
    pub gaps: Vec<String>,
    #[serde(default)]
    pub repos_per_keyword: Option<usize>,
}

/// POST /api/discover/spectroscopy — analyse a target and return the full
/// [`SpectroscopyResult`].
pub async fn discover_spectroscopy(
    State(state): State<AppState>,
    Json(req): Json<SpectroscopyRequest>,
) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;

    let resonites = if let Some(ref p) = req.path {
        let path = PathBuf::from(p);
        if !path.is_dir() {
            return Json(serde_json::json!({
                "ok": false,
                "error": "path is not a directory",
            }));
        }
        match tokio::task::spawn_blocking(move || {
            isls_reader::parse_directory(&path)
                .map(|a| resonites_from_analysis(&a))
                .map_err(|e| e.to_string())
        })
        .await
        {
            Ok(Ok(rs)) => rs,
            Ok(Err(e)) => {
                return Json(serde_json::json!({ "ok": false, "error": e }));
            }
            Err(e) => {
                return Json(serde_json::json!({
                    "ok": false,
                    "error": format!("task panicked: {}", e),
                }));
            }
        }
    } else if let Some(ref desc) = req.description {
        resonites_from_description(desc)
    } else if let Some(ref _url) = req.url {
        return Json(serde_json::json!({
            "ok": false,
            "error": "url targets are handled via /api/discover/scrape first",
        }));
    } else {
        universal_target_resonites()
    };

    let result = isls_norms::spectroscopy::spectroscopy(&resonites, &registry);
    Json(serde_json::json!({
        "ok": true,
        "result": result,
    }))
}

/// POST /api/discover/spectroscopy/fill — launch a background mass-scrape
/// for the keywords of the requested gap classes.
pub async fn discover_spectroscopy_fill(
    State(state): State<AppState>,
    Json(req): Json<SpectroscopyFillRequest>,
) -> Json<serde_json::Value> {
    if req.gaps.is_empty() {
        return Json(serde_json::json!({
            "ok": false,
            "error": "gaps list is empty",
        }));
    }

    // Collect keywords for every requested gap.
    let mut keywords: Vec<String> = Vec::new();
    for gap in &req.gaps {
        let class = parse_class(gap);
        let kws = isls_norms::spectroscopy::suggest_keywords_for_class(&class);
        keywords.extend(kws);
    }
    keywords.sort();
    keywords.dedup();

    if keywords.is_empty() {
        return Json(serde_json::json!({
            "ok": false,
            "error": "no keywords known for requested gaps",
        }));
    }

    let per_kw = req.repos_per_keyword.unwrap_or(5).min(10);
    let mass_req = MassScrapeRequest {
        keywords: keywords.clone(),
        results_per_keyword: Some(per_kw),
    };
    let response = discover_mass_scrape(State(state), Json(mass_req)).await;
    let Json(mut value) = response;
    if let Some(obj) = value.as_object_mut() {
        obj.insert("gaps".into(), serde_json::json!(req.gaps));
        obj.insert("keywords_expanded".into(), serde_json::json!(keywords));
    }
    Json(value)
}

/// Convert a `WorkspaceAnalysis` into a Vec<Resonite> suitable for
/// spectroscopy. Mirrors the CLI helper in `cmd_spectroscopy.rs`.
fn resonites_from_analysis(
    analysis: &isls_reader::WorkspaceAnalysis,
) -> Vec<isls_norms::spectroscopy::Resonite> {
    use isls_norms::spectroscopy::{Resonite, ResoniteTypeKind};
    let mut out = Vec::new();
    for file in &analysis.files {
        for f in &file.functions {
            out.push(Resonite::Fn {
                name: f.name.clone(),
                arity: f.params.len(),
            });
        }
        for s in &file.structs {
            let kind = if s.derives.iter().any(|d| d.to_lowercase().contains("enum")) {
                ResoniteTypeKind::Enum
            } else {
                ResoniteTypeKind::Struct
            };
            out.push(Resonite::Type {
                name: s.name.clone(),
                kind,
            });
        }
        for i in &file.imports {
            out.push(Resonite::Import { path: i.clone() });
        }
    }
    out
}

/// Build a synthetic resonite set from a free-text system description.
/// Every known ResoniteClass whose keyword index matches the description
/// gets one placeholder resonite so the classifier picks it up.
fn resonites_from_description(desc: &str) -> Vec<isls_norms::spectroscopy::Resonite> {
    use isls_norms::spectroscopy::Resonite;
    let lower = desc.to_lowercase();
    let hints: [(&str, &str); 18] = [
        ("event", "emit_event"),
        ("websocket", "ws_broadcast"),
        ("cache", "cache_get"),
        ("queue", "enqueue_job"),
        ("pool", "acquire_conn"),
        ("auth", "login_user"),
        ("search", "search_fulltext"),
        ("cron", "schedule_cron"),
        ("upload", "upload_file"),
        ("notif", "notify_user"),
        ("metric", "metrics_record"),
        ("tracing", "log_entry"),
        ("graphql", "graphql_resolver"),
        ("grpc", "grpc_handler"),
        ("risk", "risk_kelly"),
        ("indicator", "compute_rsi"),
        ("order", "execute_order"),
        ("chart", "chart_render"),
    ];
    let mut out = Vec::new();
    for (needle, fn_name) in hints {
        if lower.contains(needle) {
            out.push(Resonite::Fn {
                name: fn_name.to_string(),
                arity: 1,
            });
        }
    }
    out
}

/// Parse a user-supplied gap-class string into a `ResoniteClass`.
fn parse_class(s: &str) -> isls_norms::spectroscopy::ResoniteClass {
    use isls_norms::spectroscopy::ResoniteClass as C;
    match s.trim() {
        "CrudEntity" => C::CrudEntity,
        "Authentication" => C::Authentication,
        "Authorization" => C::Authorization,
        "EventBus" => C::EventBus,
        "MessageQueue" => C::MessageQueue,
        "ConnectionPool" => C::ConnectionPool,
        "Caching" => C::Caching,
        "RateLimiting" => C::RateLimiting,
        "CircuitBreaker" => C::CircuitBreaker,
        "RetryPattern" => C::RetryPattern,
        "Pagination" => C::Pagination,
        "Search" => C::Search,
        "FileUpload" => C::FileUpload,
        "ExportImport" => C::ExportImport,
        "Scheduling" => C::Scheduling,
        "Notification" => C::Notification,
        "Logging" => C::Logging,
        "Metrics" => C::Metrics,
        "HealthCheck" => C::HealthCheck,
        "Configuration" => C::Configuration,
        "Migration" => C::Migration,
        "Testing" => C::Testing,
        "Docker" => C::Docker,
        "StateMachine" => C::StateMachine,
        "Workflow" => C::Workflow,
        "IndicatorPipeline" => C::IndicatorPipeline,
        "SignalProcessing" => C::SignalProcessing,
        "RiskManagement" => C::RiskManagement,
        "OrderExecution" => C::OrderExecution,
        "DataVisualization" => C::DataVisualization,
        "RealtimeWebSocket" => C::RealtimeWebSocket,
        "GraphQLApi" => C::GraphQLApi,
        "GrpcService" => C::GrpcService,
        "CliInterface" => C::CliInterface,
        "PluginSystem" => C::PluginSystem,
        other => C::Custom(other.to_string()),
    }
}

/// GET /api/discover/genealogy/{norm_id} — Norm observation history
pub async fn discover_genealogy(
    State(state): State<AppState>,
    AxumPath(norm_id): AxumPath<String>,
) -> Json<serde_json::Value> {
    let registry = state.norm_registry.read().await;

    // Look up as a full norm first
    if let Some(norm) = registry.get(&norm_id) {
        let mut result = serde_json::json!({
            "ok": true,
            "id": norm.id,
            "name": norm.name,
            "level": format!("{:?}", norm.level),
            "evidence": {
                "builtin": norm.evidence.builtin,
                "usage_count": norm.evidence.usage_count,
                "domains_used": norm.evidence.domains_used,
                "signature": norm.evidence.signature,
            },
        });

        // For auto-norms, find matching candidate history
        if !norm.evidence.builtin {
            for cand in registry.candidates() {
                if cand.id == norm_id {
                    result["candidate"] = serde_json::json!({
                        "candidate_id": cand.id,
                        "observation_count": cand.observation_count,
                        "domains": cand.domains,
                        "consistency": cand.consistency,
                        "consistent_layers": cand.consistent_layers.iter()
                            .map(|l| format!("{:?}", l))
                            .collect::<Vec<_>>(),
                        "observations": cand.observations.iter().map(|o| serde_json::json!({
                            "entity": o.observed_on,
                            "domain": o.domain,
                            "run_id": o.run_id,
                            "layers": o.layers_present.iter()
                                .map(|l| format!("{:?}", l))
                                .collect::<Vec<_>>(),
                        })).collect::<Vec<serde_json::Value>>(),
                    });
                    break;
                }
            }
        }

        return Json(result);
    }

    // Look up as a candidate
    for cand in registry.candidates() {
        if cand.id == norm_id {
            return Json(serde_json::json!({
                "ok": true,
                "type": "candidate",
                "id": cand.id,
                "observation_count": cand.observation_count,
                "domains": cand.domains,
                "consistency": cand.consistency,
                "status": format!("{:?}", cand.status),
                "consistent_layers": cand.consistent_layers.iter()
                    .map(|l| format!("{:?}", l))
                    .collect::<Vec<_>>(),
                "observations": cand.observations.iter().map(|o| serde_json::json!({
                    "entity": o.observed_on,
                    "domain": o.domain,
                    "run_id": o.run_id,
                })).collect::<Vec<serde_json::Value>>(),
            }));
        }
    }

    Json(serde_json::json!({ "ok": false, "error": "norm or candidate not found" }))
}

/// GET /api/discover/similarity?domain=... — Similarity search
pub async fn discover_similarity(
    State(state): State<AppState>,
    Query(params): Query<SimilarityQuery>,
) -> Json<serde_json::Value> {
    // This is a placeholder — full similarity requires stored topologies
    // For now, return the norm catalog overview
    let registry = state.norm_registry.read().await;
    let norms: Vec<serde_json::Value> = registry
        .all_norms()
        .iter()
        .map(|n| {
            serde_json::json!({
                "id": n.id,
                "name": n.name,
                "level": format!("{:?}", n.level),
                "domains_used": n.evidence.domains_used,
            })
        })
        .collect();

    Json(serde_json::json!({
        "ok": true,
        "query_domain": params.domain,
        "norms": norms,
    }))
}

// ═══════════════════════════════════════════════════════════════════
// S1/ux: Scrape status + keyword editor endpoints
// ═══════════════════════════════════════════════════════════════════

/// GET /api/discover/scrape-status — live state of the Ölbohrinsel.
///
/// Aggregates the mass-scrape job store, the norm registry, and the
/// in-memory scrape history so the Studio can render a single
/// refresh-driven dashboard in the Entdecken mode.
pub async fn discover_scrape_status(
    State(state): State<AppState>,
) -> Json<serde_json::Value> {
    // ── Active jobs ────────────────────────────────────────────────
    let jobs = state.mass_scrape_jobs.read().await;
    let active_jobs = jobs.values().filter(|j| j.status == "running").count();
    drop(jobs);

    // ── History (RAM — only for "recent activity" within current session) ──
    let history_guard = state.scrape_history.lock().await;
    let recent: Vec<ScrapeHistoryEntry> =
        history_guard.iter().rev().take(10).cloned().collect();
    let (last_scrape, last_keyword) = history_guard
        .back()
        .map(|e| (e.timestamp.clone(), e.keyword.clone()))
        .unwrap_or_default();
    drop(history_guard);

    // ── Persistent cumulative counters (survive restarts) ───────────
    let persistent = crate::counters::load_counters();
    let total_repos_scraped: usize = persistent.repos_scraped_total as usize;

    // ── Norm registry: FRESH load from disk (spec: no caching) ───────
    // We load a fresh registry on every request so the auto-norm counter
    // reflects scraping done by background jobs that use their own
    // NormRegistry instances (clone_and_analyze_sync).
    let fresh_reg = tokio::task::spawn_blocking(|| {
        NormRegistry::new()
    }).await.unwrap_or_default();

    let all_norms = fresh_reg.all_norms();
    let auto_norms = all_norms
        .iter()
        .filter(|n| n.id.starts_with("ISLS-NORM-AUTO-"))
        .count();

    let candidates = fresh_reg.candidates();
    let candidates_total = candidates.len();

    // F1/W4: Observations count from norms.json (persisted)
    let total_observations: usize = candidates.iter().map(|c| c.observation_count).sum();

    // Top-5 candidates — sorted by how close they are to promotion.
    // We approximate "closeness" as a blend of observation count and
    // domain diversity; both are the tightest remaining bars for
    // external repos after the I3 layer-threshold fix.
    let mut ranked: Vec<_> = candidates
        .iter()
        .map(|c| {
            let obs = c.observation_count;
            let doms = c.domains.len();
            let layers = c.consistent_layers.len();
            let score = obs as f64 * 2.0 + doms as f64 * 3.0 + layers as f64;
            (score, c.id.clone(), obs, doms, layers, c.consistency)
        })
        .collect();
    ranked.sort_by(|a, b| {
        b.0.partial_cmp(&a.0).unwrap_or(std::cmp::Ordering::Equal)
    });
    let top_candidates: Vec<serde_json::Value> = ranked
        .iter()
        .take(5)
        .map(|(_, id, obs, doms, layers, cons)| {
            serde_json::json!({
                "id": id,
                "observations": obs,
                "domains": doms,
                "layers": layers,
                "consistency": cons,
            })
        })
        .collect();

    // Recent promotions: the 5 most recent auto-norms (lexical order of
    // IDs approximates creation order since IDs are monotonic).
    let mut auto_sorted: Vec<&isls_norms::Norm> = all_norms
        .iter()
        .filter(|n| n.id.starts_with("ISLS-NORM-AUTO-"))
        .copied()
        .collect();
    auto_sorted.sort_by(|a, b| b.id.cmp(&a.id));
    let recent_promotions: Vec<serde_json::Value> = auto_sorted
        .iter()
        .take(5)
        .map(|n| {
            serde_json::json!({
                "id": n.id,
                "name": n.name,
                "domains": n.evidence.domains_used,
                "usage_count": n.evidence.usage_count,
            })
        })
        .collect();
    // ── Keyword count (file-backed) ────────────────────────────────
    let keywords_count = read_keywords_file(&state.scrape_keywords_path)
        .map(|(_, n)| n)
        .unwrap_or(0);

    Json(serde_json::json!({
        "ok": true,
        "active_jobs": active_jobs,
        "total_repos_scraped": total_repos_scraped,
        "total_observations": total_observations,
        "candidates": candidates_total,
        "auto_norms": auto_norms,
        "keywords": keywords_count,
        "last_scrape": last_scrape,
        "last_keyword": last_keyword,
        "recent_activity": recent,
        "top_candidates": top_candidates,
        "recent_promotions": recent_promotions,
        "since": persistent.first_started,
        "forge_runs": persistent.forge_runs_total,
        "auto_evolve_runs": persistent.auto_evolve_runs_total,
        "harpoon_runs": persistent.harpoon_runs_total,
    }))
}

/// GET /api/discover/keywords — return the current scrape_keywords.txt.
pub async fn discover_keywords_get(
    State(state): State<AppState>,
) -> Json<serde_json::Value> {
    match read_keywords_file(&state.scrape_keywords_path) {
        Ok((content, count)) => Json(serde_json::json!({
            "ok": true,
            "content": content,
            "count": count,
            "path": state.scrape_keywords_path.display().to_string(),
        })),
        Err(e) => Json(serde_json::json!({
            "ok": true,
            "content": String::new(),
            "count": 0,
            "path": state.scrape_keywords_path.display().to_string(),
            "warning": e,
        })),
    }
}

/// POST /api/discover/keywords — overwrite scrape_keywords.txt with the
/// raw request body. One keyword per line. Blank / `#`-prefixed lines
/// are accepted verbatim so the file round-trips, but the `count`
/// returned reflects only the effective keywords.
pub async fn discover_keywords_post(
    State(state): State<AppState>,
    body: String,
) -> Json<serde_json::Value> {
    let path = state.scrape_keywords_path.clone();
    if let Some(parent) = path.parent() {
        if let Err(e) = std::fs::create_dir_all(parent) {
            return Json(serde_json::json!({
                "ok": false,
                "error": format!("Cannot create parent dir: {}", e),
            }));
        }
    }
    // Normalise line endings and make sure the file ends with a newline.
    let normalised = if body.ends_with('\n') {
        body
    } else {
        format!("{}\n", body)
    };
    if let Err(e) = std::fs::write(&path, normalised.as_bytes()) {
        return Json(serde_json::json!({
            "ok": false,
            "error": format!("Write failed: {}", e),
        }));
    }
    let count = normalised
        .lines()
        .filter(|l| {
            let t = l.trim();
            !t.is_empty() && !t.starts_with('#')
        })
        .count();
    Json(serde_json::json!({
        "ok": true,
        "saved": true,
        "count": count,
        "path": path.display().to_string(),
    }))
}

/// Read the keywords file, returning `(raw_content, effective_count)`.
fn read_keywords_file(path: &Path) -> std::result::Result<(String, usize), String> {
    if !path.exists() {
        return Ok((String::new(), 0));
    }
    let content = std::fs::read_to_string(path)
        .map_err(|e| format!("cannot read {}: {}", path.display(), e))?;
    let count = content
        .lines()
        .filter(|l| {
            let t = l.trim();
            !t.is_empty() && !t.starts_with('#')
        })
        .count();
    Ok((content, count))
}

// ═══════════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════════

fn rand_u32() -> u32 {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    std::time::SystemTime::now().hash(&mut hasher);
    std::thread::current().id().hash(&mut hasher);
    (hasher.finish() & 0xFFFF_FFFF) as u32
}

// ═══════════════════════════════════════════════════════════════════
// I4/harpoon: Cascading targeted scrape
// ═══════════════════════════════════════════════════════════════════

/// Maximum repos scraped by a single harpoon run.
pub const HARPOON_MAX_REPOS: usize = 200;

/// repos-per-keyword schedule by depth level (0-indexed).
const HARPOON_RPK: [usize; 3] = [5, 3, 2];

#[derive(Debug, Deserialize)]
pub struct HarpoonRequest {
    /// A local path or git URL to use as seed.
    pub seed: String,
    /// Maximum cascade depth (1–3, default 3).
    #[serde(default)]
    pub depth: Option<usize>,
    /// repos-per-keyword at depth-0 (default 5). Reduced per depth.
    #[serde(default)]
    pub repos_per_keyword: Option<usize>,
    /// Stop early when norm coverage exceeds this ratio (default 0.9).
    #[serde(default)]
    pub stop_at_coverage: Option<f64>,
    /// Domain tag to attach to scraped norms.
    #[serde(default)]
    pub domain: Option<String>,
}

#[derive(Debug, Clone, Serialize)]
pub struct HarpoonJob {
    pub id: String,
    pub status: String, // "running" | "complete" | "stopped" | "error"
    pub depth_current: usize,
    pub depth_max: usize,
    pub repos_scraped: usize,
    pub repos_failed: usize,
    pub new_candidates: usize,
    pub new_norms: usize,
    pub coverage: f64,
    pub keywords_used: Vec<String>,
    pub stop_reason: Option<String>,
}

pub type HarpoonStore = Arc<RwLock<HashMap<String, HarpoonJob>>>;

pub fn new_harpoon_store() -> HarpoonStore {
    Arc::new(RwLock::new(HashMap::new()))
}

#[derive(Debug, Deserialize)]
pub struct AcceptKeywordRequest {
    pub keyword: String,
}

/// POST /api/discover/harpoon — launch a cascading targeted scrape.
pub async fn discover_harpoon(
    State(state): State<AppState>,
    Json(req): Json<HarpoonRequest>,
) -> Json<serde_json::Value> {
    let depth_max = req.depth.unwrap_or(3).clamp(1, 3);
    let rpk0 = req.repos_per_keyword.unwrap_or(5).min(10);
    let stop_cov = req.stop_at_coverage.unwrap_or(0.9).clamp(0.0, 1.0);
    let domain = req.domain.clone().unwrap_or_else(|| {
        if req.seed.starts_with("http") {
            bridge::domain_from_url(&req.seed)
        } else {
            bridge::domain_from_path(std::path::Path::new(&req.seed))
        }
    });

    let job_id = format!("harpoon-{:08x}", rand_u32());

    let job = HarpoonJob {
        id: job_id.clone(),
        status: "running".to_string(),
        depth_current: 0,
        depth_max,
        repos_scraped: 0,
        repos_failed: 0,
        new_candidates: 0,
        new_norms: 0,
        coverage: 0.0,
        keywords_used: vec![],
        stop_reason: None,
    };
    state.harpoon_jobs.write().await.insert(job_id.clone(), job);

    let harpoon_jobs = state.harpoon_jobs.clone();
    let event_hub = state.event_hub.clone();
    let norm_registry = state.norm_registry.clone();
    let suggested_kw_path = state.suggested_keywords_path.clone();
    let seed = req.seed.clone();
    let job_id_ret = job_id.clone();

    tokio::spawn(async move {
        run_harpoon(
            harpoon_jobs,
            event_hub,
            norm_registry,
            suggested_kw_path,
            job_id,
            seed,
            domain,
            depth_max,
            rpk0,
            stop_cov,
        )
        .await;
    });

    Json(serde_json::json!({
        "ok": true,
        "job_id": job_id_ret,
        "depth_max": depth_max,
        "repos_per_keyword_d0": rpk0,
        "stop_at_coverage": stop_cov,
    }))
}

/// GET /api/discover/harpoon/{id}/status
pub async fn discover_harpoon_status(
    State(state): State<AppState>,
    AxumPath(id): AxumPath<String>,
) -> Json<serde_json::Value> {
    let jobs = state.harpoon_jobs.read().await;
    match jobs.get(&id) {
        Some(job) => Json(serde_json::json!({ "ok": true, "job": job })),
        None => Json(serde_json::json!({ "ok": false, "error": "harpoon job not found" })),
    }
}

/// GET /api/discover/suggested-keywords — return suggested_keywords.txt
pub async fn discover_suggested_keywords(
    State(state): State<AppState>,
) -> Json<serde_json::Value> {
    match read_keywords_file(&state.suggested_keywords_path) {
        Ok((content, count)) => {
            let keywords: Vec<&str> = content
                .lines()
                .map(|l| l.trim())
                .filter(|l| !l.is_empty() && !l.starts_with('#'))
                .collect();
            Json(serde_json::json!({
                "ok": true,
                "keywords": keywords,
                "count": count,
                "path": state.suggested_keywords_path.display().to_string(),
            }))
        }
        Err(e) => Json(serde_json::json!({
            "ok": true,
            "keywords": [],
            "count": 0,
            "path": state.suggested_keywords_path.display().to_string(),
            "warning": e,
        })),
    }
}

/// POST /api/discover/accept-keyword — move a suggested keyword to
/// `scrape_keywords.txt` (the curated list).
pub async fn discover_accept_keyword(
    State(state): State<AppState>,
    Json(req): Json<AcceptKeywordRequest>,
) -> Json<serde_json::Value> {
    let kw = req.keyword.trim().to_string();
    if kw.is_empty() {
        return Json(serde_json::json!({ "ok": false, "error": "keyword is empty" }));
    }
    let added = append_new_keywords(&state.scrape_keywords_path, &[kw.clone()]).await;
    Json(serde_json::json!({
        "ok": true,
        "keyword": kw,
        "added": added > 0,
    }))
}

/// Core harpoon cascade loop.
async fn run_harpoon(
    harpoon_jobs: HarpoonStore,
    event_hub: crate::ws::EventHub,
    norm_registry: Arc<RwLock<NormRegistry>>,
    suggested_kw_path: PathBuf,
    job_id: String,
    seed: String,
    domain: String,
    depth_max: usize,
    rpk0: usize,
    stop_at_coverage: f64,
) {
    use crate::ws::EventType;

    // ── Stage 0: analyse the seed ──────────────────────────────────
    let seed_result = if seed.starts_with("http") {
        tokio::task::spawn_blocking({
            let seed_c = seed.clone();
            let domain_c = domain.clone();
            move || clone_and_analyze_sync(&seed_c, &domain_c, true)
        })
        .await
        .ok()
        .and_then(|r| r.ok())
        .map(|(v, _)| v)
    } else {
        let p = PathBuf::from(&seed);
        tokio::task::spawn_blocking(move || analyze_directory_sync(&p, &domain, None, true))
            .await
            .ok()
            .and_then(|r| r.ok())
            .map(|(v, _)| v)
    };

    let mut current_keywords: Vec<String> = match seed_result {
        Some(ref data) => data["auto_keywords"]
            .as_array()
            .map(|a| a.iter().filter_map(|v| v.as_str().map(String::from)).collect())
            .unwrap_or_default(),
        None => {
            let mut j = harpoon_jobs.write().await;
            if let Some(job) = j.get_mut(&job_id) {
                job.status = "error".to_string();
                job.stop_reason = Some("Failed to analyse seed".to_string());
            }
            return;
        }
    };

    if current_keywords.is_empty() {
        let mut j = harpoon_jobs.write().await;
        if let Some(job) = j.get_mut(&job_id) {
            job.status = "stopped".to_string();
            job.stop_reason = Some("No keywords extracted from seed".to_string());
        }
        return;
    }

    let mut total_scraped: usize = 0;
    let mut total_failed: usize = 0;
    let mut total_candidates: usize = 0;
    let mut total_norms: usize = 0;
    let mut all_keywords_used: Vec<String> = Vec::new();

    // ── Cascade loop ───────────────────────────────────────────────
    for depth in 0..depth_max {
        let rpk = if depth < HARPOON_RPK.len() {
            // blend with caller's rpk0 at depth 0
            if depth == 0 { rpk0 } else { HARPOON_RPK[depth] }
        } else {
            1
        };

        // Publish stage event
        event_hub.publish(crate::ws::WsEvent::new(
            EventType::HarpoonStage,
            serde_json::json!({
                "job_id": &job_id,
                "depth": depth,
                "depth_max": depth_max,
                "keywords": &current_keywords,
                "repos_per_keyword": rpk,
            }),
        ));

        // Update job depth
        {
            let mut j = harpoon_jobs.write().await;
            if let Some(job) = j.get_mut(&job_id) {
                job.depth_current = depth + 1;
                job.keywords_used.extend(current_keywords.iter().cloned());
            }
        }

        all_keywords_used.extend(current_keywords.iter().cloned());
        all_keywords_used.sort();
        all_keywords_used.dedup();

        // Search + scrape repos for each keyword
        let semaphore = Arc::new(Semaphore::new(MASS_SCRAPE_PARALLELISM));
        let mut stage_keywords: Vec<String> = Vec::new();
        let mut handles = Vec::new();

        for keyword in &current_keywords {
            if total_scraped >= HARPOON_MAX_REPOS {
                break;
            }

            let repos = match github_search_repos(keyword, rpk).await {
                Ok(data) => data["repos"].as_array().cloned().unwrap_or_default(),
                Err(_) => {
                    tokio::time::sleep(Duration::from_secs(2)).await;
                    continue;
                }
            };

            for repo in repos {
                if total_scraped + handles.len() >= HARPOON_MAX_REPOS {
                    break;
                }
                let clone_url = repo["clone_url"].as_str().unwrap_or("").to_string();
                let full_name = repo["full_name"].as_str().unwrap_or("unknown").to_string();
                if clone_url.is_empty() {
                    continue;
                }
                let repo_domain = bridge::domain_from_url(&clone_url);
                let sem_cl = semaphore.clone();
                let hub_cl = event_hub.clone();
                let job_id_cl = job_id.clone();
                let full_name_cl = full_name.clone();
                let kw_cl = keyword.clone();

                handles.push(tokio::spawn(async move {
                    let _permit = match sem_cl.acquire_owned().await {
                        Ok(p) => p,
                        Err(_) => return None,
                    };
                    let clone_url_owned = clone_url.clone();
                    let domain_owned = repo_domain.clone();
                    let result = tokio::task::spawn_blocking(move || {
                        clone_and_analyze_sync(&clone_url_owned, &domain_owned, true)
                    })
                    .await;

                    match result {
                        Ok(Ok((data, _))) => {
                            let new_cands = data["norms"]["new_candidates"].as_u64().unwrap_or(0);
                            let new_norms = data["norms"]["new_norms"].as_u64().unwrap_or(0);
                            let auto_kws: Vec<String> = data["auto_keywords"]
                                .as_array()
                                .map(|a| {
                                    a.iter()
                                        .filter_map(|v| v.as_str().map(String::from))
                                        .collect()
                                })
                                .unwrap_or_default();

                            hub_cl.publish(crate::ws::WsEvent::new(
                                EventType::HarpoonRepo,
                                serde_json::json!({
                                    "job_id": &job_id_cl,
                                    "repo": &full_name_cl,
                                    "keyword": &kw_cl,
                                    "new_candidates": new_cands,
                                    "new_norms": new_norms,
                                    "auto_keywords": &auto_kws,
                                }),
                            ));

                            // Persistent counter: each harpoon repo successfully scraped
                            crate::counters::increment_counter(
                                crate::counters::CounterField::ReposScraped, 1,
                            );

                            Some((1usize, 0usize, new_cands as usize, new_norms as usize, auto_kws))
                        }
                        _ => {
                            hub_cl.publish(crate::ws::WsEvent::new(
                                EventType::HarpoonRepo,
                                serde_json::json!({
                                    "job_id": &job_id_cl,
                                    "repo": &full_name_cl,
                                    "keyword": &kw_cl,
                                    "error": true,
                                }),
                            ));
                            Some((0usize, 1usize, 0usize, 0usize, vec![]))
                        }
                    }
                }));
            }

            // Rate-limit GitHub searches
            tokio::time::sleep(Duration::from_secs(2)).await;
        }

        // Collect handle results
        for result in futures::future::join_all(handles).await {
            if let Ok(Some((scraped, failed, cands, norms, kws))) = result {
                total_scraped += scraped;
                total_failed += failed;
                total_candidates += cands;
                total_norms += norms;
                stage_keywords.extend(kws);
            }
        }

        // Persist suggested keywords from this stage
        stage_keywords.sort();
        stage_keywords.dedup();
        append_new_keywords(&suggested_kw_path, &stage_keywords).await;

        // Compute coverage after this stage
        let coverage = {
            let reg = norm_registry.read().await;
            let universe = universal_target_resonites_count();
            let covered = reg.all_norms().len();
            (covered as f64 / universe as f64).min(1.0)
        };

        // Update job stats
        {
            let mut j = harpoon_jobs.write().await;
            if let Some(job) = j.get_mut(&job_id) {
                job.repos_scraped = total_scraped;
                job.repos_failed = total_failed;
                job.new_candidates = total_candidates;
                job.new_norms = total_norms;
                job.coverage = coverage;
            }
        }

        // Publish stage-complete event
        event_hub.publish(crate::ws::WsEvent::new(
            EventType::HarpoonStageComplete,
            serde_json::json!({
                "job_id": &job_id,
                "depth": depth,
                "repos_scraped_stage": total_scraped,
                "coverage": coverage,
                "new_keywords": &stage_keywords,
            }),
        ));

        // Stop conditions
        if total_scraped >= HARPOON_MAX_REPOS {
            let mut j = harpoon_jobs.write().await;
            if let Some(job) = j.get_mut(&job_id) {
                job.status = "stopped".to_string();
                job.stop_reason = Some(format!("Reached max repos ({})", HARPOON_MAX_REPOS));
            }
            break;
        }
        if coverage >= stop_at_coverage {
            let mut j = harpoon_jobs.write().await;
            if let Some(job) = j.get_mut(&job_id) {
                job.status = "stopped".to_string();
                job.stop_reason = Some(format!("Coverage {:.1}% >= threshold", coverage * 100.0));
            }
            break;
        }
        if stage_keywords.is_empty() || depth + 1 >= depth_max {
            break;
        }

        // Next depth: use keywords extracted in this stage
        current_keywords = stage_keywords;
    }

    // Mark complete if not already stopped
    {
        let mut j = harpoon_jobs.write().await;
        if let Some(job) = j.get_mut(&job_id) {
            if job.status == "running" {
                job.status = "complete".to_string();
            }
        }
    }

    // Persistent counter: harpoon job finished (complete or stopped)
    crate::counters::increment_counter(crate::counters::CounterField::HarpoonRuns, 1);

    let final_job = harpoon_jobs.read().await.get(&job_id).cloned();
    if let Some(job) = final_job {
        event_hub.publish(crate::ws::WsEvent::new(
            EventType::HarpoonComplete,
            serde_json::json!({
                "job_id": &job_id,
                "repos_scraped": job.repos_scraped,
                "repos_failed": job.repos_failed,
                "new_candidates": job.new_candidates,
                "new_norms": job.new_norms,
                "coverage": job.coverage,
                "keywords_used": &job.keywords_used,
                "stop_reason": &job.stop_reason,
            }),
        ));
    }
}

/// Number of distinct norm classes in the universal target (used for coverage %).
fn universal_target_resonites_count() -> usize {
    // Matches the number of entries in universal_target_resonites()
    34
}

// ─── MC1: Auto-Steer keyword extraction ─────────────────────────────────────

/// Get keywords to scrape based on the highest-priority target deficit.
/// Returns empty if auto-steer is off or no targets have deficits.
pub async fn auto_steer_keywords(state: &crate::AppState) -> Vec<String> {
    use std::sync::atomic::Ordering;
    if !state.auto_steer_enabled.load(Ordering::Relaxed) {
        return vec![];
    }
    let targets = state.targets.read().await;
    match isls_norms::targets::highest_priority_deficit(&targets) {
        Some(t) => isls_norms::targets::keywords_for_missing_classes(&t.missing),
        None => vec![],
    }
}

// isls-gateway/src/scrape_engine.rs — S3: Integrated Scraping Engine
//
// Replaces the external cronjob. Runs as a permanent tokio background task.
// Self-regulating: respects GitHub API rate limits, adapts to auto-steer
// priority, persists progress across restarts.

use std::path::PathBuf;
use std::sync::Arc;
use std::sync::atomic::{AtomicBool, AtomicUsize, Ordering};
use std::time::Duration;

use serde::{Deserialize, Serialize};
use tokio::sync::RwLock;

use crate::AppState;

// ─── Spectrum keyword tables ─────────────────────────────────────────────────

pub const BACKEND_KEYWORDS: &[&str] = &[
    "rust axum web framework",
    "rust actix-web rest api",
    "rust tokio async server",
    "python fastapi backend",
    "python django rest framework",
    "go gin gorm backend",
    "go echo microservice",
    "nodejs express typescript api",
    "rust diesel sqlx database",
    "grpc protobuf service",
    "redis cache backend rust",
    "postgresql connection pool",
    "microservice architecture rust",
    "api gateway rate limiting",
    "jwt authentication middleware",
    "websocket tokio tungstenite",
    "rust hyper http server",
    "openapi swagger rust",
    "oauth2 provider rust",
    "graphql async-graphql rust",
];

pub const FRONTEND_KEYWORDS: &[&str] = &[
    "react hooks custom component",
    "react typescript state management",
    "vue3 composable setup script",
    "svelte store reactive component",
    "angular service rxjs observable",
    "tailwind css utility component",
    "nextjs app router server component",
    "nuxtjs composable pinia",
    "vite build plugin config",
    "jest testing-library react",
    "vitest unit test component",
    "storybook component stories",
    "zustand redux state",
    "typescript interface generic utility",
    "css animation keyframe transition",
    "framer-motion animation react",
    "shadcn-ui radix component",
    "tanstack query data fetching",
];

pub const DEVOPS_KEYWORDS: &[&str] = &[
    "dockerfile multi-stage build",
    "kubernetes operator controller reconcile",
    "github-actions workflow ci pipeline",
    "terraform module provider",
    "ansible playbook role task",
    "helm chart values deployment",
    "prometheus grafana alerting",
    "nginx reverse proxy upstream",
    "docker-compose services networking",
    "flux gitops kustomize",
    "argocd application sync",
    "vault secrets injection kubernetes",
    "istio service mesh traffic",
    "opentelemetry tracing rust",
    "github-actions matrix strategy",
];

pub const DATA_KEYWORDS: &[&str] = &[
    "pandas dataframe groupby transform",
    "polars lazy expression rust",
    "apache spark dataframe scala",
    "airflow dag operator task",
    "scikit-learn pipeline estimator",
    "pytorch lightning module training",
    "tensorflow keras sequential model",
    "dbt transformation model test",
    "clickhouse analytics query",
    "pydantic schema validation fastapi",
    "duckdb sql analytical query",
    "feast feature store offline",
    "mlflow experiment tracking",
    "prefect flow task etl",
    "great-expectations data quality",
];

pub const SYSTEMS_KEYWORDS: &[&str] = &[
    "embedded-hal rust firmware hal",
    "rtos freertos task scheduler",
    "linux kernel module driver",
    "llvm compiler pass optimization",
    "nom pest parser combinator",
    "memory allocator custom rust",
    "lock-free atomic data structure",
    "arm cortex-m microcontroller",
    "risc-v bare metal no-std",
    "async runtime executor rust",
    "elf binary linker script",
    "device driver platform linux",
];

pub const BLOCKCHAIN_KEYWORDS: &[&str] = &[
    "solidity smart contract erc20",
    "hardhat foundry test solidity",
    "ethers-rs wallet signer",
    "substrate pallet runtime",
    "anchor solana program",
    "nft minting smart contract",
    "defi amm liquidity swap",
    "zero-knowledge proof circuit",
    "ipfs storage content hash",
    "web3 javascript ethers",
];

pub const GAMES_KEYWORDS: &[&str] = &[
    "bevy ecs system plugin rust",
    "unity monobehaviour scriptable",
    "godot gdscript autoload node",
    "matchmaking elo rating algorithm",
    "game server authoritative netcode",
    "procedural generation noise terrain",
    "physics engine collision detection",
    "entity component system data",
    "game loop fixed timestep update",
    "pathfinding astar grid",
];

// ─── Spectrum category ────────────────────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum SpectrumCategory {
    Backend,
    Frontend,
    DevOps,
    Data,
    Systems,
    Blockchain,
    Games,
}

impl SpectrumCategory {
    pub fn keywords(&self) -> &'static [&'static str] {
        match self {
            SpectrumCategory::Backend => BACKEND_KEYWORDS,
            SpectrumCategory::Frontend => FRONTEND_KEYWORDS,
            SpectrumCategory::DevOps => DEVOPS_KEYWORDS,
            SpectrumCategory::Data => DATA_KEYWORDS,
            SpectrumCategory::Systems => SYSTEMS_KEYWORDS,
            SpectrumCategory::Blockchain => BLOCKCHAIN_KEYWORDS,
            SpectrumCategory::Games => GAMES_KEYWORDS,
        }
    }

    pub fn from_str(s: &str) -> Option<Self> {
        match s {
            "Backend" => Some(SpectrumCategory::Backend),
            "Frontend" => Some(SpectrumCategory::Frontend),
            "DevOps" => Some(SpectrumCategory::DevOps),
            "Data" => Some(SpectrumCategory::Data),
            "Systems" => Some(SpectrumCategory::Systems),
            "Blockchain" => Some(SpectrumCategory::Blockchain),
            "Games" => Some(SpectrumCategory::Games),
            _ => None,
        }
    }
}

pub fn all_spectrum_keywords(spectrum: &[SpectrumCategory]) -> Vec<String> {
    let mut kw: Vec<String> = Vec::new();
    for cat in spectrum {
        for k in cat.keywords() {
            kw.push(k.to_string());
        }
    }
    kw
}

// ─── Config (persisted to ~/.isls/scrape_config.json) ───────────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScrapeConfig {
    pub volume_percent: u8,
    pub spectrum: Vec<SpectrumCategory>,
    pub paused: bool,
}

impl Default for ScrapeConfig {
    fn default() -> Self {
        Self {
            volume_percent: 50,
            spectrum: vec![SpectrumCategory::Backend, SpectrumCategory::Frontend],
            paused: false,
        }
    }
}

fn scrape_config_path() -> Option<PathBuf> {
    std::env::var("HOME")
        .ok()
        .map(|h| PathBuf::from(h).join(".isls").join("scrape_config.json"))
}

pub fn load_scrape_config() -> ScrapeConfig {
    let path = match scrape_config_path() {
        Some(p) => p,
        None => return ScrapeConfig::default(),
    };
    match std::fs::read_to_string(&path) {
        Ok(s) => serde_json::from_str(&s).unwrap_or_default(),
        Err(_) => ScrapeConfig::default(),
    }
}

pub fn save_scrape_config(cfg: &ScrapeConfig) {
    let path = match scrape_config_path() {
        Some(p) => p,
        None => return,
    };
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).ok();
    }
    if let Ok(json) = serde_json::to_string_pretty(cfg) {
        std::fs::write(&path, json).ok();
    }
}

// ─── Progress (persisted to ~/.isls/scrape_progress.json) ───────────────────

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ScrapeProgress {
    pub current_index: usize,
    pub round: usize,
    pub total_keywords: usize,
    pub last_keyword: String,
    pub last_scrape: String,
}

impl Default for ScrapeProgress {
    fn default() -> Self {
        Self {
            current_index: 0,
            round: 0,
            total_keywords: 0,
            last_keyword: String::new(),
            last_scrape: String::new(),
        }
    }
}

fn scrape_progress_path() -> Option<PathBuf> {
    std::env::var("HOME")
        .ok()
        .map(|h| PathBuf::from(h).join(".isls").join("scrape_progress.json"))
}

pub fn load_scrape_progress() -> ScrapeProgress {
    let path = match scrape_progress_path() {
        Some(p) => p,
        None => return ScrapeProgress::default(),
    };
    match std::fs::read_to_string(&path) {
        Ok(s) => serde_json::from_str(&s).unwrap_or_default(),
        Err(_) => ScrapeProgress::default(),
    }
}

fn save_scrape_progress(progress: &ScrapeProgress) {
    let path = match scrape_progress_path() {
        Some(p) => p,
        None => return,
    };
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent).ok();
    }
    if let Ok(json) = serde_json::to_string_pretty(progress) {
        std::fs::write(&path, json).ok();
    }
}

// ─── Live status (in-memory, for API) ────────────────────────────────────────

#[derive(Debug, Clone, Serialize, Deserialize, Default)]
pub struct ScrapeEngineStatus {
    pub running: bool,
    pub current_strategy: String,
    pub current_keywords: Vec<String>,
    pub keyword_progress: String,
    pub rate_limit_remaining: usize,
    pub rate_limit_resets_in: u64,
    pub repos_per_hour: f64,
    pub last_scrape: String,
    pub last_result: String,
    pub paused: bool,
    pub pause_reason: Option<String>,
}

// ─── Shared engine state (placed in AppState) ────────────────────────────────

#[derive(Clone)]
pub struct ScrapeEngineState {
    /// Set true to temporarily pause all scraping (operator toggle).
    pub paused: Arc<AtomicBool>,
    /// Volume + spectrum config, persisted on change.
    pub config: Arc<RwLock<ScrapeConfig>>,
    /// Rotation progress across the keyword list.
    pub progress: Arc<RwLock<ScrapeProgress>>,
    /// Remaining GitHub search requests in current rate-limit window.
    pub rate_limit_remaining: Arc<AtomicUsize>,
    /// Unix timestamp when the rate-limit window resets.
    pub rate_limit_reset_epoch: Arc<AtomicUsize>,
    /// Live readable status for /api/scrape/status.
    pub status: Arc<RwLock<ScrapeEngineStatus>>,
}

impl ScrapeEngineState {
    pub fn new() -> Self {
        let cfg = load_scrape_config();
        let paused = cfg.paused;
        Self {
            paused: Arc::new(AtomicBool::new(paused)),
            config: Arc::new(RwLock::new(cfg)),
            progress: Arc::new(RwLock::new(load_scrape_progress())),
            rate_limit_remaining: Arc::new(AtomicUsize::new(10)),
            rate_limit_reset_epoch: Arc::new(AtomicUsize::new(0)),
            status: Arc::new(RwLock::new(ScrapeEngineStatus::default())),
        }
    }
}

// ─── Volume helpers ───────────────────────────────────────────────────────────

fn volume_to_per_keyword(v: u8) -> usize {
    match v {
        0..=20 => 3,
        21..=40 => 5,
        41..=60 => 7,
        61..=80 => 8,
        _ => 10,
    }
}

fn volume_to_batch_size(v: u8) -> usize {
    match v {
        0..=20 => 1,
        21..=40 => 3,
        41..=60 => 5,
        61..=80 => 7,
        _ => 10,
    }
}

/// Compute pause (seconds) between batches from volume + rate-limit state.
pub fn calculate_optimal_pause(
    rate_remaining: usize,
    rate_reset_in: u64,
    keywords_in_batch: usize,
    volume_percent: u8,
) -> u64 {
    // Hard pause if rate limit is exhausted
    if rate_remaining == 0 {
        return rate_reset_in.max(60) + 1;
    }

    let requests_needed = keywords_in_batch.max(1);

    // Base pause from volume setting
    let base: u64 = match volume_percent {
        0..=20 => 30,
        21..=40 => 20,
        41..=60 => 10,
        61..=80 => 7,
        _ => 3,
    };

    // If remaining is tighter than needed × 3, slow down proportionally
    if rate_remaining < requests_needed * 3 {
        let per_request_budget = rate_reset_in / rate_remaining.max(1) as u64;
        return per_request_budget.clamp(base, 300);
    }

    base
}

// ─── Rate limit check ─────────────────────────────────────────────────────────

/// Check GitHub API search rate limit. Updates engine state atomics.
/// Returns true if there are enough requests remaining to start a batch.
pub async fn check_github_rate_limit(engine: &ScrapeEngineState) -> bool {
    let github_token = std::env::var("GITHUB_TOKEN")
        .or_else(|_| std::env::var("GITHUB_API_TOKEN"))
        .ok();

    let client = reqwest::Client::new();
    let mut req = client
        .get("https://api.github.com/rate_limit")
        .header("User-Agent", "isls-gateway/1.0")
        .header("Accept", "application/vnd.github.v3+json")
        .timeout(Duration::from_secs(10));

    if let Some(token) = github_token {
        req = req.header("Authorization", format!("token {}", token));
    }

    match req.send().await {
        Ok(resp) => {
            let data: serde_json::Value = resp.json().await.unwrap_or_default();
            let remaining = data["resources"]["search"]["remaining"]
                .as_u64()
                .unwrap_or(0) as usize;
            let reset = data["resources"]["search"]["reset"]
                .as_u64()
                .unwrap_or(0) as usize;

            engine.rate_limit_remaining.store(remaining, Ordering::Relaxed);
            engine.rate_limit_reset_epoch.store(reset, Ordering::Relaxed);

            remaining > 2
        }
        Err(_) => {
            // GitHub unreachable — don't update atomics, report insufficient
            false
        }
    }
}

/// Seconds until the rate-limit window resets (min 60s fallback).
fn rate_limit_wait_secs(engine: &ScrapeEngineState) -> u64 {
    let reset = engine.rate_limit_reset_epoch.load(Ordering::Relaxed) as u64;
    let now = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs();
    if reset > now { (reset - now + 2).min(300) } else { 60 }
}

// ─── Batch strategy ───────────────────────────────────────────────────────────

struct BatchPlan {
    keywords: Vec<String>,
    per_keyword: usize,
    strategy_desc: String,
    is_auto_steer: bool,
}

async fn compute_scrape_batch(state: &AppState) -> BatchPlan {
    let config = state.scrape_engine.config.read().await.clone();
    let per_keyword = volume_to_per_keyword(config.volume_percent);
    let batch_size = volume_to_batch_size(config.volume_percent);

    // Priority 1: Auto-Steer
    let auto_steer_kws = crate::discover::auto_steer_keywords(state).await;
    if !auto_steer_kws.is_empty() {
        let keywords: Vec<String> = auto_steer_kws
            .into_iter()
            .take(batch_size)
            .collect();
        let targets = state.targets.read().await;
        let target_name = isls_norms::targets::highest_priority_deficit(&targets)
            .map(|t| t.name.clone())
            .unwrap_or_else(|| "Unbekannt".to_string());
        drop(targets);
        return BatchPlan {
            strategy_desc: format!("Auto-Steer: {}", target_name),
            keywords,
            per_keyword,
            is_auto_steer: true,
        };
    }

    // Priority 2: Anatomy rotation through spectrum keywords
    let all_keywords = all_spectrum_keywords(&config.spectrum);
    if all_keywords.is_empty() {
        return BatchPlan {
            keywords: Vec::new(),
            per_keyword,
            strategy_desc: "Kein Spektrum gewählt".to_string(),
            is_auto_steer: false,
        };
    }

    let total = all_keywords.len();
    let mut progress = state.scrape_engine.progress.write().await;

    // Wrap index if spectrum changed and total shrank
    if progress.current_index >= total {
        progress.current_index = 0;
        progress.round = progress.round.saturating_add(1);
    }

    let start = progress.current_index;
    let end = (start + batch_size).min(total);
    let batch = all_keywords[start..end].to_vec();

    let strategy_desc = format!(
        "Anatomie-Rotation (Runde {}, Keyword {}/{})",
        progress.round + 1,
        start + 1,
        total,
    );

    // Advance index, wrap round
    progress.current_index = if end >= total {
        progress.round = progress.round.saturating_add(1);
        0
    } else {
        end
    };

    progress.total_keywords = total;
    progress.last_keyword = batch.last().cloned().unwrap_or_default();
    progress.last_scrape = chrono::Utc::now().to_rfc3339();

    let progress_snapshot = progress.clone();
    drop(progress);

    // Persist progress on blocking thread to avoid holding the lock
    tokio::task::spawn_blocking(move || save_scrape_progress(&progress_snapshot));

    BatchPlan {
        keywords: batch,
        per_keyword,
        strategy_desc,
        is_auto_steer: false,
    }
}

// ─── Background engine task ───────────────────────────────────────────────────

/// Permanent background task that drives scraping autonomously.
///
/// Priorities:
///   1. Harpoon jobs (already have their own task in discover.rs)
///   2. Auto-Steer deficit filling
///   3. Spectrum rotation (anatomy keywords)
pub async fn scraping_engine(state: AppState) {
    // Brief startup delay so the rest of the server initializes first
    tokio::time::sleep(Duration::from_secs(15)).await;
    tracing::info!("[ScrapeEngine] Background scraping engine started");

    loop {
        // ── Loop heartbeat — confirms the engine is alive ──────────────────
        tracing::info!(
            "[ScrapeEngine] Loop iteration — rate_remaining: {}, paused: {}",
            state.scrape_engine.rate_limit_remaining.load(Ordering::Relaxed),
            state.scrape_engine.paused.load(Ordering::Relaxed),
        );

        // ── Pause check ────────────────────────────────────────────────────
        if state.scrape_engine.paused.load(Ordering::Relaxed) {
            {
                let mut s = state.scrape_engine.status.write().await;
                s.running = false;
                s.paused = true;
                s.pause_reason = Some("Manuell pausiert".to_string());
            }
            tokio::time::sleep(Duration::from_secs(5)).await;
            continue;
        }

        // ── Rate limit check ───────────────────────────────────────────────
        let rate_ok = check_github_rate_limit(&state.scrape_engine).await;
        let rate_rem = state.scrape_engine.rate_limit_remaining.load(Ordering::Relaxed);

        if !rate_ok {
            let wait = rate_limit_wait_secs(&state.scrape_engine);
            tracing::info!("[ScrapeEngine] Rate-limited, waiting {}s", wait);
            {
                let mut s = state.scrape_engine.status.write().await;
                s.running = false;
                s.paused = true;
                s.pause_reason = Some(format!("Rate-limited — Reset in {}s", wait));
                s.rate_limit_remaining = 0;
                s.rate_limit_resets_in = wait;
            }
            tokio::time::sleep(Duration::from_secs(wait)).await;
            continue;
        }

        // ── Compute batch ──────────────────────────────────────────────────
        let plan = compute_scrape_batch(&state).await;

        if plan.keywords.is_empty() {
            tokio::time::sleep(Duration::from_secs(30)).await;
            continue;
        }

        // ── Update status: running ─────────────────────────────────────────
        {
            let progress = state.scrape_engine.progress.read().await;
            let keyword_progress = format!(
                "{}/{} (Runde {})",
                progress.current_index,
                progress.total_keywords.max(1),
                progress.round + 1,
            );
            drop(progress);

            let mut s = state.scrape_engine.status.write().await;
            s.running = true;
            s.paused = false;
            s.pause_reason = None;
            s.current_strategy = plan.strategy_desc.clone();
            s.current_keywords = plan.keywords.clone();
            s.keyword_progress = keyword_progress;
            s.rate_limit_remaining = rate_rem;
        }

        // ── Execute via run_mass_scrape ────────────────────────────────────
        let job_id = format!("engine-{:08x}", engine_rand_u32());
        {
            let job = crate::discover::MassScrapeJob {
                id: job_id.clone(),
                status: "running".to_string(),
                keywords_total: plan.keywords.len(),
                keywords_done: 0,
                repos_scraped: 0,
                repos_failed: 0,
                new_candidates: 0,
                new_norms: 0,
                errors: Vec::new(),
            };
            state.mass_scrape_jobs.write().await.insert(job_id.clone(), job);
        }

        let batch_start = std::time::Instant::now();

        crate::discover::run_mass_scrape(
            state.mass_scrape_jobs.clone(),
            state.event_hub.clone(),
            state.scrape_history.clone(),
            state.scrape_keywords_path.clone(),
            job_id.clone(),
            plan.keywords.clone(),
            plan.per_keyword,
        )
        .await;

        // ── Read results ───────────────────────────────────────────────────
        let (repos_scraped, new_candidates, new_norms) = {
            let jobs = state.mass_scrape_jobs.read().await;
            if let Some(job) = jobs.get(&job_id) {
                (job.repos_scraped, job.new_candidates, job.new_norms)
            } else {
                (0, 0, 0)
            }
        };

        let elapsed_secs = batch_start.elapsed().as_secs_f64().max(1.0);
        let repos_per_hour = (repos_scraped as f64 / elapsed_secs) * 3600.0;

        let result_str = format!(
            "{} Repos, {} neue Candidates, {} neue Norms",
            repos_scraped, new_candidates, new_norms
        );

        // ── Update status: done ────────────────────────────────────────────
        {
            let new_rate_rem = state.scrape_engine.rate_limit_remaining.load(Ordering::Relaxed);
            let reset_epoch = state.scrape_engine.rate_limit_reset_epoch.load(Ordering::Relaxed) as u64;
            let now_epoch = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs();
            let resets_in = if reset_epoch > now_epoch { reset_epoch - now_epoch } else { 60 };

            let mut s = state.scrape_engine.status.write().await;
            s.running = false;
            s.last_scrape = chrono::Utc::now().to_rfc3339();
            s.last_result = result_str.clone();
            s.repos_per_hour = repos_per_hour;
            s.rate_limit_remaining = new_rate_rem;
            s.rate_limit_resets_in = resets_in;
        }

        // ── Compute pause ──────────────────────────────────────────────────
        let (volume_pct, reset_in) = {
            let cfg = state.scrape_engine.config.read().await;
            let reset_epoch = state.scrape_engine.rate_limit_reset_epoch.load(Ordering::Relaxed) as u64;
            let now_epoch = std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap_or_default()
                .as_secs();
            let reset_in = if reset_epoch > now_epoch { reset_epoch - now_epoch } else { 60 };
            (cfg.volume_percent, reset_in)
        };

        let new_rate_rem = state.scrape_engine.rate_limit_remaining.load(Ordering::Relaxed);
        let pause = calculate_optimal_pause(new_rate_rem, reset_in, plan.keywords.len(), volume_pct);
        tracing::debug!(
            "[ScrapeEngine] Batch done: {}. Pausing {}s",
            result_str, pause
        );

        tokio::time::sleep(Duration::from_secs(pause)).await;
    }
}

fn engine_rand_u32() -> u32 {
    use std::hash::{Hash, Hasher};
    let mut hasher = std::collections::hash_map::DefaultHasher::new();
    std::time::SystemTime::now().hash(&mut hasher);
    std::thread::current().id().hash(&mut hasher);
    (hasher.finish() & 0xFFFF_FFFF) as u32
}

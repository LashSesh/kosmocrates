// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Deterministic rewriter for sqlx compile-time macros → runtime API.
//!
//! The forge runs without a live database. Any generated code using
//! `sqlx::query!` or `sqlx::query_as!` fails `cargo check` with
//! `error: set DATABASE_URL to use query macros online, or run cargo
//! sqlx prepare to update the query cache`.
//!
//! Local LLMs (especially 7 B-class) intermittently emit these macros
//! even when the prompt explicitly forbids them. This module performs
//! a deterministic source transformation that converts them to their
//! runtime equivalents before `cargo check` runs:
//!
//! | Input                                                       | Output                                                     |
//! |-------------------------------------------------------------|------------------------------------------------------------|
//! | `sqlx::query!(sql, a, b)`                                   | `sqlx::query(sql).bind(a).bind(b)`                         |
//! | `sqlx::query_as!(Type, sql, a, b)`                          | `sqlx::query_as::<_, Type>(sql).bind(a).bind(b)`           |
//! | `query!(...)` / `query_as!(...)` (bare, after `use sqlx::`) | same — full `sqlx::` prefix re-added for unambiguous code  |
//!
//! The scanner respects string literals and both line and block comments
//! so it does not accidentally rewrite a macro name that appears inside
//! a `"..."` or `// ...` context. Generic arguments (`<>`) inside macro
//! call sites are tracked by the arg-splitter so `Vec<User>` is kept as
//! a single argument.

/// Rewrite every `sqlx::query!` / `sqlx::query_as!` (and bare `query!` /
/// `query_as!`) macro invocation in `input` to the runtime API.
///
/// Returns a new `String`. If `input` contains no matching macros the
/// output is byte-identical to the input.
pub fn rewrite_sqlx_macros(input: &str) -> String {
    let bytes = input.as_bytes();
    let len = bytes.len();
    let mut out = String::with_capacity(len);
    let mut i = 0;

    while i < len {
        // String literal — copy verbatim.
        if bytes[i] == b'"' {
            let end = skip_string_literal(bytes, i);
            out.push_str(&input[i..end]);
            i = end;
            continue;
        }
        // Raw string literal: r"..." / r#"..."#. Rare but worth handling.
        if bytes[i] == b'r'
            && i + 1 < len
            && (bytes[i + 1] == b'"' || bytes[i + 1] == b'#')
        {
            let end = skip_raw_string_literal(bytes, i);
            out.push_str(&input[i..end]);
            i = end;
            continue;
        }
        // Character literal — must skip to handle things like `'"'`.
        if bytes[i] == b'\''
            && i + 2 < len
            && (bytes[i + 2] == b'\'' || (bytes[i + 1] == b'\\'))
        {
            let end = skip_char_literal(bytes, i);
            out.push_str(&input[i..end]);
            i = end;
            continue;
        }
        // Line comment.
        if i + 1 < len && bytes[i] == b'/' && bytes[i + 1] == b'/' {
            let end = skip_line_comment(bytes, i);
            out.push_str(&input[i..end]);
            i = end;
            continue;
        }
        // Block comment.
        if i + 1 < len && bytes[i] == b'/' && bytes[i + 1] == b'*' {
            let end = skip_block_comment(bytes, i);
            out.push_str(&input[i..end]);
            i = end;
            continue;
        }
        // Try a macro match at `i`.
        if let Some((next_i, rewritten)) = try_rewrite_at(input, i) {
            out.push_str(&rewritten);
            i = next_i;
            continue;
        }
        // Default: copy one byte.
        out.push(bytes[i] as char);
        i += 1;
    }

    out
}

// ─── Macro matching ──────────────────────────────────────────────────────────

fn try_rewrite_at(input: &str, i: usize) -> Option<(usize, String)> {
    // Order matters: longer prefixes first so `sqlx::query_as!` wins over
    // `sqlx::query!`. Each tuple is (prefix, kind), where kind is the
    // macro's base name without `!`.
    const MACROS: &[(&str, &str)] = &[
        ("sqlx::query_as!", "query_as"),
        ("sqlx::query!", "query"),
        ("query_as!", "query_as"),
        ("query!", "query"),
    ];

    let bytes = input.as_bytes();
    let len = bytes.len();

    for (prefix, kind) in MACROS {
        if !input[i..].starts_with(prefix) {
            continue;
        }
        // Token boundary: the character before must not continue an
        // identifier. Prevents matching `my_query!` as `query!`.
        if i > 0 {
            let c = bytes[i - 1];
            if c.is_ascii_alphanumeric() || c == b'_' {
                continue;
            }
            // For bare `query!` / `query_as!` — if the previous glyph is
            // `::`, it's a different path and we only accept it via the
            // `sqlx::` prefix variants. Skip here.
            if !prefix.starts_with("sqlx::") && i >= 2 && &bytes[i - 2..i] == b"::" {
                continue;
            }
        }

        // Locate opening `(` after the prefix (allowing whitespace).
        let mut j = i + prefix.len();
        while j < len && bytes[j].is_ascii_whitespace() {
            j += 1;
        }
        if j >= len || bytes[j] != b'(' {
            continue;
        }
        let paren_open = j;
        let paren_close = match find_matching_paren(input, paren_open) {
            Some(p) => p,
            None => continue,
        };
        let args_str = &input[paren_open + 1..paren_close];
        let args: Vec<&str> = split_top_level_args(args_str)
            .into_iter()
            .filter(|a| !a.trim().is_empty())
            .collect();

        let rewritten = match *kind {
            "query" => rewrite_query(&args),
            "query_as" => rewrite_query_as(&args)?,
            _ => continue,
        };
        return Some((paren_close + 1, rewritten));
    }

    None
}

fn rewrite_query(args: &[&str]) -> String {
    let mut out = String::from("sqlx::query(");
    if let Some(sql) = args.first() {
        out.push_str(sql.trim());
    }
    out.push(')');
    for arg in args.iter().skip(1) {
        out.push_str(".bind(");
        out.push_str(arg.trim());
        out.push(')');
    }
    out
}

fn rewrite_query_as(args: &[&str]) -> Option<String> {
    // Needs at least (Type, sql). Anything less is malformed; leave it
    // to cargo-check to report the real problem.
    if args.len() < 2 {
        return None;
    }
    let ty = args[0].trim();
    let sql = args[1].trim();
    let mut out = format!("sqlx::query_as::<_, {}>({})", ty, sql);
    for arg in args.iter().skip(2) {
        out.push_str(".bind(");
        out.push_str(arg.trim());
        out.push(')');
    }
    Some(out)
}

// ─── Paren matching + arg splitting ──────────────────────────────────────────

/// Find the index of the `)` that matches the `(` at `open`. Returns
/// `None` if the input is unbalanced or `open` does not point at `(`.
/// Respects string, char and comment contexts.
fn find_matching_paren(input: &str, open: usize) -> Option<usize> {
    let bytes = input.as_bytes();
    if bytes.get(open) != Some(&b'(') {
        return None;
    }
    let len = bytes.len();
    let mut depth = 1usize;
    let mut i = open + 1;
    while i < len {
        match bytes[i] {
            b'(' => depth += 1,
            b')' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            b'"' => i = skip_string_literal(bytes, i) - 1,
            b'r' if i + 1 < len
                && (bytes[i + 1] == b'"' || bytes[i + 1] == b'#') =>
            {
                i = skip_raw_string_literal(bytes, i) - 1;
            }
            b'\'' if i + 2 < len
                && (bytes[i + 2] == b'\'' || bytes[i + 1] == b'\\') =>
            {
                i = skip_char_literal(bytes, i) - 1;
            }
            b'/' if i + 1 < len && bytes[i + 1] == b'/' => {
                i = skip_line_comment(bytes, i) - 1;
            }
            b'/' if i + 1 < len && bytes[i + 1] == b'*' => {
                i = skip_block_comment(bytes, i) - 1;
            }
            _ => {}
        }
        i += 1;
    }
    None
}

/// Split `s` by top-level commas, respecting `(…)`, `[…]`, `{…}`, `<…>`,
/// string literals and comments. Commas inside any nesting level are
/// ignored, so `query_as!(Vec<User>, …)` keeps `Vec<User>` as one arg.
fn split_top_level_args(s: &str) -> Vec<&str> {
    let bytes = s.as_bytes();
    let len = bytes.len();
    let mut out = Vec::new();
    let mut depth_round = 0i32;
    let mut depth_square = 0i32;
    let mut depth_curly = 0i32;
    let mut depth_angle = 0i32;
    let mut start = 0usize;
    let mut i = 0usize;
    while i < len {
        match bytes[i] {
            b'(' => depth_round += 1,
            b')' => depth_round -= 1,
            b'[' => depth_square += 1,
            b']' => depth_square -= 1,
            b'{' => depth_curly += 1,
            b'}' => depth_curly -= 1,
            // Angle brackets are ambiguous (comparison vs generic) but
            // in practice macro args rarely contain comparisons.
            b'<' => depth_angle += 1,
            b'>' => {
                if depth_angle > 0 {
                    depth_angle -= 1;
                }
            }
            b'"' => i = skip_string_literal(bytes, i) - 1,
            b'r' if i + 1 < len
                && (bytes[i + 1] == b'"' || bytes[i + 1] == b'#') =>
            {
                i = skip_raw_string_literal(bytes, i) - 1;
            }
            b'\'' if i + 2 < len
                && (bytes[i + 2] == b'\'' || bytes[i + 1] == b'\\') =>
            {
                i = skip_char_literal(bytes, i) - 1;
            }
            b'/' if i + 1 < len && bytes[i + 1] == b'/' => {
                i = skip_line_comment(bytes, i) - 1;
            }
            b'/' if i + 1 < len && bytes[i + 1] == b'*' => {
                i = skip_block_comment(bytes, i) - 1;
            }
            b',' if depth_round == 0
                && depth_square == 0
                && depth_curly == 0
                && depth_angle == 0 =>
            {
                out.push(&s[start..i]);
                start = i + 1;
            }
            _ => {}
        }
        i += 1;
    }
    if start <= len {
        out.push(&s[start..]);
    }
    out
}

// ─── Literal / comment skippers ──────────────────────────────────────────────

fn skip_string_literal(bytes: &[u8], start: usize) -> usize {
    debug_assert_eq!(bytes[start], b'"');
    let len = bytes.len();
    let mut i = start + 1;
    while i < len {
        match bytes[i] {
            b'\\' if i + 1 < len => i += 2,
            b'"' => return i + 1,
            _ => i += 1,
        }
    }
    len
}

fn skip_raw_string_literal(bytes: &[u8], start: usize) -> usize {
    // r"..."  or  r#"..."#  or  r##"..."##
    debug_assert_eq!(bytes[start], b'r');
    let len = bytes.len();
    let mut i = start + 1;
    let mut hashes = 0usize;
    while i < len && bytes[i] == b'#' {
        hashes += 1;
        i += 1;
    }
    if i >= len || bytes[i] != b'"' {
        // Not actually a raw string — e.g. just an identifier `r`.
        return start + 1;
    }
    i += 1;
    // Scan for closing `"` followed by the same number of `#`.
    while i < len {
        if bytes[i] == b'"' {
            let mut j = i + 1;
            let mut found = 0usize;
            while j < len && bytes[j] == b'#' && found < hashes {
                found += 1;
                j += 1;
            }
            if found == hashes {
                return j;
            }
        }
        i += 1;
    }
    len
}

fn skip_char_literal(bytes: &[u8], start: usize) -> usize {
    debug_assert_eq!(bytes[start], b'\'');
    let len = bytes.len();
    // Simplest possible: find the next unescaped `'` up to ~4 chars ahead.
    // `'x'`, `'\n'`, `'\x7F'`, `'\u{1F600}'`. Handle escapes conservatively.
    let mut i = start + 1;
    if i < len && bytes[i] == b'\\' {
        i += 1;
        // Skip up to a closing quote within a reasonable window.
        while i < len && bytes[i] != b'\'' {
            i += 1;
        }
        return if i < len { i + 1 } else { len };
    }
    // Single-char.
    if i + 1 < len && bytes[i + 1] == b'\'' {
        return i + 2;
    }
    // Lifetime (e.g. `'a`) — not a char literal. Return right after the
    // apostrophe to let normal scanning resume.
    start + 1
}

fn skip_line_comment(bytes: &[u8], start: usize) -> usize {
    let len = bytes.len();
    let mut i = start + 2;
    while i < len && bytes[i] != b'\n' {
        i += 1;
    }
    i
}

fn skip_block_comment(bytes: &[u8], start: usize) -> usize {
    let len = bytes.len();
    let mut i = start + 2;
    let mut depth = 1usize; // Rust block comments can nest.
    while i + 1 < len {
        if bytes[i] == b'/' && bytes[i + 1] == b'*' {
            depth += 1;
            i += 2;
        } else if bytes[i] == b'*' && bytes[i + 1] == b'/' {
            depth -= 1;
            i += 2;
            if depth == 0 {
                return i;
            }
        } else {
            i += 1;
        }
    }
    len
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn passthrough_without_macros() {
        let src = "fn main() { println!(\"hello\"); }";
        assert_eq!(rewrite_sqlx_macros(src), src);
    }

    #[test]
    fn rewrite_query_no_args() {
        let src = r#"let r = sqlx::query!("SELECT 1").fetch_one(pool).await?;"#;
        let out = rewrite_sqlx_macros(src);
        assert!(out.contains(r#"sqlx::query("SELECT 1")"#));
        assert!(!out.contains("query!("));
    }

    #[test]
    fn rewrite_query_with_binds() {
        let src = r#"sqlx::query!("UPDATE t SET x = $1 WHERE id = $2", new_x, row_id)"#;
        let out = rewrite_sqlx_macros(src);
        assert!(out.contains(r#"sqlx::query("UPDATE t SET x = $1 WHERE id = $2")"#));
        assert!(out.contains(".bind(new_x)"));
        assert!(out.contains(".bind(row_id)"));
    }

    #[test]
    fn rewrite_query_as_with_type_and_binds() {
        let src = r#"sqlx::query_as!(User, "SELECT * FROM users WHERE id = $1", user_id)"#;
        let out = rewrite_sqlx_macros(src);
        assert!(out.contains("sqlx::query_as::<_, User>("));
        assert!(out.contains(".bind(user_id)"));
        assert!(!out.contains("query_as!("));
    }

    #[test]
    fn bare_query_macro_gets_sqlx_prefix() {
        // After `use sqlx::query;` the bare macro is valid Rust; still
        // forbidden by DATABASE_URL and thus rewritten.
        let src = r#"query!("SELECT 1", x)"#;
        let out = rewrite_sqlx_macros(src);
        assert!(out.starts_with("sqlx::query("));
        assert!(out.contains(".bind(x)"));
    }

    #[test]
    fn multiline_query_as() {
        let src = "\
sqlx::query_as!(
    User,
    \"SELECT * FROM users WHERE id = $1 AND active = $2\",
    user_id,
    true
)";
        let out = rewrite_sqlx_macros(src);
        assert!(out.contains("sqlx::query_as::<_, User>"));
        assert!(out.contains(".bind(user_id)"));
        assert!(out.contains(".bind(true)"));
        assert!(!out.contains("query_as!"));
    }

    #[test]
    fn identifier_collision_preserved() {
        // `my_query!` is not sqlx — must stay untouched.
        let src = r#"my_query!("SELECT 1", x)"#;
        let out = rewrite_sqlx_macros(src);
        assert_eq!(out, src);
    }

    #[test]
    fn macro_inside_string_literal_preserved() {
        let src = r#"let doc = "sqlx::query!(\"SELECT 1\")";"#;
        let out = rewrite_sqlx_macros(src);
        assert_eq!(out, src);
    }

    #[test]
    fn macro_inside_line_comment_preserved() {
        let src = "let x = 1; // sqlx::query!(\"SELECT 1\")\nlet y = 2;";
        let out = rewrite_sqlx_macros(src);
        assert_eq!(out, src);
    }

    #[test]
    fn generic_type_arg_kept_intact() {
        // `Vec<(i64, String)>` contains a top-level comma inside generics
        // that must NOT split the macro args.
        let src = r#"sqlx::query_as!(Vec<(i64, String)>, "SELECT a, b FROM t")"#;
        let out = rewrite_sqlx_macros(src);
        // The Type argument should be passed through unchanged.
        assert!(out.contains("sqlx::query_as::<_, Vec<(i64, String)>>"));
    }

    #[test]
    fn nested_method_call_in_bind() {
        let src = r#"sqlx::query!("SELECT * FROM t WHERE id = $1", uuid.to_string())"#;
        let out = rewrite_sqlx_macros(src);
        assert!(out.contains(".bind(uuid.to_string())"));
    }

    #[test]
    fn fetch_chain_preserved_after_rewrite() {
        let src = r#"sqlx::query_as!(User, "SELECT * FROM users", ).fetch_all(pool).await?;"#;
        let out = rewrite_sqlx_macros(src);
        // Rewrite stops at the matching `)` so the `.fetch_all(pool)` tail
        // remains in the output verbatim.
        assert!(out.contains(".fetch_all(pool)"));
    }

    #[test]
    fn unbalanced_parens_leave_input_intact() {
        // Malformed input — no matching `)`. Scanner must not panic and
        // must not perform a destructive partial rewrite.
        let src = r#"sqlx::query!("SELECT 1", x"#;
        let out = rewrite_sqlx_macros(src);
        assert_eq!(out, src);
    }

    #[test]
    fn multiple_macros_in_same_file() {
        let src = "\
fn a(pool: &PgPool) { sqlx::query!(\"A\", 1); }
fn b(pool: &PgPool) { sqlx::query_as!(B, \"B\", 2); }
";
        let out = rewrite_sqlx_macros(src);
        assert!(out.contains("sqlx::query(\"A\")"));
        assert!(out.contains(".bind(1)"));
        assert!(out.contains("sqlx::query_as::<_, B>(\"B\")"));
        assert!(out.contains(".bind(2)"));
        assert!(!out.contains("query!"));
        assert!(!out.contains("query_as!"));
    }
}

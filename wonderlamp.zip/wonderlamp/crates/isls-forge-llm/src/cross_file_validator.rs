// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Cross-file CRUD fn-name normalizer.
//!
//! Local LLMs (especially 7 B-class) routinely emit database-query
//! functions under non-canonical CRUD verbs while service / handler
//! files call them under canonical ones, producing
//! `error[E0425]: cannot find function 'get_user' in module
//! 'user_queries'` — even though the query module actually does
//! contain an equivalent function (named e.g. `fetch_user`).
//! Six Coagula cycles of
//! prompt-based re-asking often fail to converge — the two sides
//! ping-pong between their preferred verb. This module breaks the
//! oscillation deterministically by normalising every CRUD verb to
//! its canonical form, on both the definition side (query files) and
//! every caller simultaneously.
//!
//! # Verb mapping
//!
//! | non-canonical                        | canonical |
//! |--------------------------------------|-----------|
//! | `fetch_…`, `find_…`, `load_…`        | `get_…`   |
//! | `insert_…`, `add_…`                  | `create_…`|
//! | `modify_…`, `edit_…`                 | `update_…`|
//! | `remove_…`, `destroy_…`              | `delete_…`|
//!
//! # Scope
//!
//! The rename set is collected **only** from `pub fn` / `pub async fn`
//! definitions inside files under `backend/src/database/*_queries.rs`.
//! This keeps the transform narrow — a service-layer fn like
//! `fn load_config()` is never touched.
//!
//! The resulting renames are applied to **every** `.rs` file in the
//! generated tree, using word-boundary regex. Call sites that already
//! used the canonical verb remain correct; sites that used the
//! non-canonical verb get rewritten in lock-step with the definition.
//!
//! # Collisions
//!
//! If the canonical form of a non-canonical name already exists
//! anywhere as a fn definition (either in the same file or another
//! query file), the rename is **skipped** for that name — renaming
//! would collide with the existing definition. The caller's mismatch
//! is then left for Coagula to surface with a clear message.

use std::collections::{HashMap, HashSet};
use std::path::Path;

use regex::Regex;

use crate::GeneratedFile;

/// Non-canonical → canonical CRUD verb mapping.
///
/// Kept deliberately narrow: each entry is a verb that is (a) routinely
/// emitted by LLMs in query-function names and (b) has a single
/// unambiguous canonical counterpart. Verbs like `load` (could mean
/// config-loading), `read` (generic I/O) or `all` (`fn all_users` is
/// valid English) are excluded to avoid false positives.
const VERB_MAPPING: &[(&str, &str)] = &[
    ("fetch", "get"),
    ("find", "get"),
    ("load", "get"),
    ("insert", "create"),
    ("add", "create"),
    ("modify", "update"),
    ("edit", "update"),
    ("remove", "delete"),
    ("destroy", "delete"),
];

/// Summary of a normalizer run.
#[derive(Debug, Default, Clone)]
pub struct NormalizeReport {
    /// Number of distinct function names that got renamed.
    pub renames_applied: usize,
    /// Number of files whose content was modified on disk.
    pub files_modified: usize,
}

/// Normalize CRUD verb names across all generated Rust files and write
/// the updated content back to `output_dir`. Runs as a single batch
/// pass — intended to be invoked right before `cargo check` so the
/// compiler sees the already-aligned source.
///
/// Returns a [`NormalizeReport`] so the caller can log what happened.
pub fn normalize_crud_fn_names(
    files: &mut [GeneratedFile],
    output_dir: &Path,
) -> std::io::Result<NormalizeReport> {
    let renames = collect_renames(files);
    if renames.is_empty() {
        return Ok(NormalizeReport::default());
    }
    let files_modified = apply_renames_and_write(files, &renames, output_dir)?;
    Ok(NormalizeReport {
        renames_applied: renames.len(),
        files_modified,
    })
}

// ─── Rename collection ───────────────────────────────────────────────────────

fn is_query_file(path: &str) -> bool {
    let norm = path.replace('\\', "/");
    norm.contains("/database/")
        && norm.ends_with(".rs")
        && !norm.ends_with("/mod.rs")
}

/// Return the canonical form of `name` when it starts with a known
/// non-canonical CRUD verb prefix, or `None` otherwise.
fn canonical_form(name: &str) -> Option<String> {
    for (non_canonical, canonical) in VERB_MAPPING {
        let prefix = format!("{}_", non_canonical);
        if let Some(rest) = name.strip_prefix(&prefix) {
            return Some(format!("{}_{}", canonical, rest));
        }
    }
    None
}

/// Collect the rename map: for every `pub fn` / `pub async fn` in any
/// query file whose name begins with a non-canonical CRUD verb, map
/// it to the canonical form — unless the canonical form already
/// exists as a fn definition somewhere in the tree.
fn collect_renames(files: &[GeneratedFile]) -> HashMap<String, String> {
    let fn_re = match fn_def_regex() {
        Some(r) => r,
        None => return HashMap::new(),
    };

    // First pass: record every fn name that already exists, anywhere.
    let mut existing_names: HashSet<String> = HashSet::new();
    for file in files {
        if !file.path.ends_with(".rs") {
            continue;
        }
        for cap in fn_re.captures_iter(&file.content) {
            if let Some(m) = cap.get(1) {
                existing_names.insert(m.as_str().to_string());
            }
        }
    }

    // Second pass: collect candidate renames from query files only.
    let mut map: HashMap<String, String> = HashMap::new();
    for file in files {
        if !is_query_file(&file.path) {
            continue;
        }
        for cap in fn_re.captures_iter(&file.content) {
            let name = match cap.get(1) {
                Some(m) => m.as_str(),
                None => continue,
            };
            if map.contains_key(name) {
                continue;
            }
            let canonical = match canonical_form(name) {
                Some(c) => c,
                None => continue,
            };
            // Collision guard: never rename to a name that already
            // exists as a definition anywhere in the tree.
            if existing_names.contains(&canonical) {
                tracing::debug!(
                    old = %name,
                    new = %canonical,
                    "cross_file_validator: skipping rename — canonical already exists"
                );
                continue;
            }
            map.insert(name.to_string(), canonical);
        }
    }
    map
}

fn fn_def_regex() -> Option<Regex> {
    Regex::new(r"(?m)\bfn\s+([A-Za-z_][A-Za-z0-9_]*)").ok()
}

// ─── Rename application ──────────────────────────────────────────────────────

fn apply_renames_and_write(
    files: &mut [GeneratedFile],
    renames: &HashMap<String, String>,
    output_dir: &Path,
) -> std::io::Result<usize> {
    // Pre-compile one `\bNAME\b` regex per rename entry for efficiency.
    let compiled: Vec<(Regex, &str)> = renames
        .iter()
        .filter_map(|(old, new)| {
            let re = Regex::new(&format!(r"\b{}\b", regex::escape(old))).ok()?;
            Some((re, new.as_str()))
        })
        .collect();

    let mut modified = 0usize;
    for file in files.iter_mut() {
        if !file.path.ends_with(".rs") {
            continue;
        }
        let mut content = file.content.clone();
        let original_len = content.len();
        for (re, new) in &compiled {
            content = re.replace_all(&content, *new).into_owned();
        }
        if content != file.content {
            modified += 1;
            std::fs::write(output_dir.join(&file.path), &content)?;
            tracing::info!(
                path = %file.path,
                before_bytes = original_len,
                after_bytes = content.len(),
                "cross_file_validator: rewrote file"
            );
            file.content = content;
        }
    }
    Ok(modified)
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    fn gf(path: &str, content: &str) -> GeneratedFile {
        GeneratedFile {
            path: path.to_string(),
            content: content.to_string(),
            generation_method: "llm".to_string(),
            attempts: 1,
            tokens_used: 0,
        }
    }

    #[test]
    fn canonical_form_maps_fetch_to_get() {
        assert_eq!(canonical_form("fetch_user"), Some("get_user".into()));
        assert_eq!(canonical_form("find_user_by_email"), Some("get_user_by_email".into()));
        assert_eq!(canonical_form("load_portfolio"), Some("get_portfolio".into()));
    }

    #[test]
    fn canonical_form_maps_insert_and_modify() {
        assert_eq!(canonical_form("insert_trade"), Some("create_trade".into()));
        assert_eq!(canonical_form("add_entry"), Some("create_entry".into()));
        assert_eq!(canonical_form("modify_user"), Some("update_user".into()));
        assert_eq!(canonical_form("edit_profile"), Some("update_profile".into()));
        assert_eq!(canonical_form("remove_item"), Some("delete_item".into()));
        assert_eq!(canonical_form("destroy_session"), Some("delete_session".into()));
    }

    #[test]
    fn canonical_form_leaves_canonical_alone() {
        assert_eq!(canonical_form("get_user"), None);
        assert_eq!(canonical_form("create_trade"), None);
        assert_eq!(canonical_form("no_verb_prefix"), None);
    }

    #[test]
    fn is_query_file_recognises_expected_paths() {
        assert!(is_query_file("backend/src/database/user_queries.rs"));
        assert!(is_query_file("backend/src/database/portfolio_queries.rs"));
        assert!(!is_query_file("backend/src/database/mod.rs"));
        assert!(!is_query_file("backend/src/services/user.rs"));
        assert!(!is_query_file("backend/src/main.rs"));
    }

    #[test]
    fn renames_query_def_and_caller_together() {
        let tmp = tempfile::tempdir().unwrap();
        let query_path = "backend/src/database/user_queries.rs";
        let svc_path = "backend/src/services/user.rs";

        let mut files = vec![
            gf(
                query_path,
                "pub async fn fetch_user(pool: &PgPool, id: Uuid) \
                 -> Result<User, AppError> { todo!() }\n",
            ),
            gf(
                svc_path,
                "use crate::database::user_queries;\n\
                 pub async fn load(id: Uuid) -> Result<User, AppError> {\n    \
                     user_queries::fetch_user(pool, id).await\n}\n",
            ),
        ];

        // Create the physical files so apply_renames_and_write can write
        // them back.
        for f in &files {
            let full = tmp.path().join(&f.path);
            std::fs::create_dir_all(full.parent().unwrap()).unwrap();
            std::fs::write(&full, &f.content).unwrap();
        }

        let report = normalize_crud_fn_names(&mut files, tmp.path()).unwrap();
        assert_eq!(report.renames_applied, 1);
        assert_eq!(report.files_modified, 2);

        // In-memory updates.
        assert!(files[0].content.contains("fn get_user"));
        assert!(!files[0].content.contains("fn fetch_user"));
        assert!(files[1].content.contains("user_queries::get_user"));
        assert!(!files[1].content.contains("user_queries::fetch_user"));

        // Disk updates match in-memory.
        let on_disk_svc = std::fs::read_to_string(tmp.path().join(svc_path)).unwrap();
        assert!(on_disk_svc.contains("user_queries::get_user"));
    }

    #[test]
    fn skips_rename_when_canonical_already_exists() {
        // Two definitions in the same query file — one canonical, one
        // non-canonical — must NOT produce a duplicate.
        let tmp = tempfile::tempdir().unwrap();
        let path = "backend/src/database/user_queries.rs";
        let mut files = vec![gf(
            path,
            "pub async fn fetch_user() {}\n\
             pub async fn get_user() {}\n",
        )];
        let full = tmp.path().join(path);
        std::fs::create_dir_all(full.parent().unwrap()).unwrap();
        std::fs::write(&full, &files[0].content).unwrap();

        let report = normalize_crud_fn_names(&mut files, tmp.path()).unwrap();
        assert_eq!(report.renames_applied, 0, "collision guard must fire");
        assert_eq!(report.files_modified, 0);
        assert!(files[0].content.contains("fn fetch_user"));
        assert!(files[0].content.contains("fn get_user"));
    }

    #[test]
    fn preserves_sqlx_fetch_one_method_call() {
        // `fetch_one` is a sqlx method, not a fn we defined — the
        // rename map should never include it because there's no
        // `fn fetch_one` definition in any query file.
        let tmp = tempfile::tempdir().unwrap();
        let path = "backend/src/database/user_queries.rs";
        let mut files = vec![gf(
            path,
            "pub async fn get_user(pool: &PgPool) -> Result<User, AppError> {\n    \
                 let row = sqlx::query_as::<_, User>(\"SELECT * FROM users\")\n        \
                     .fetch_one(pool)\n        \
                     .await?;\n    \
                 Ok(row)\n}\n",
        )];
        let full = tmp.path().join(path);
        std::fs::create_dir_all(full.parent().unwrap()).unwrap();
        std::fs::write(&full, &files[0].content).unwrap();

        let report = normalize_crud_fn_names(&mut files, tmp.path()).unwrap();
        assert_eq!(report.renames_applied, 0);
        // `fetch_one` method call untouched.
        assert!(files[0].content.contains(".fetch_one(pool)"));
    }

    #[test]
    fn ignores_non_query_file_fn_definitions() {
        // A service-layer `fn load_config()` is NOT a CRUD query, so
        // the normalizer must not add it to the rename map. The
        // non-canonical verb is legitimate domain vocabulary here.
        let tmp = tempfile::tempdir().unwrap();
        let cfg_path = "backend/src/config.rs";
        let mut files = vec![gf(
            cfg_path,
            "pub fn load_config() -> AppConfig { AppConfig::default() }\n",
        )];
        let full = tmp.path().join(cfg_path);
        std::fs::create_dir_all(full.parent().unwrap()).unwrap();
        std::fs::write(&full, &files[0].content).unwrap();

        let report = normalize_crud_fn_names(&mut files, tmp.path()).unwrap();
        assert_eq!(report.renames_applied, 0);
        assert!(files[0].content.contains("fn load_config"));
    }

    #[test]
    fn multiple_verbs_in_one_file() {
        let tmp = tempfile::tempdir().unwrap();
        let q_path = "backend/src/database/trade_queries.rs";
        let s_path = "backend/src/services/trade.rs";
        let mut files = vec![
            gf(
                q_path,
                "pub async fn fetch_trade() {}\n\
                 pub async fn insert_trade() {}\n\
                 pub async fn modify_trade() {}\n\
                 pub async fn remove_trade() {}\n",
            ),
            gf(
                s_path,
                "use crate::database::trade_queries;\n\
                 async fn handlers() {\n    \
                     trade_queries::fetch_trade().await;\n    \
                     trade_queries::insert_trade().await;\n    \
                     trade_queries::modify_trade().await;\n    \
                     trade_queries::remove_trade().await;\n\
                 }\n",
            ),
        ];
        for f in &files {
            let full = tmp.path().join(&f.path);
            std::fs::create_dir_all(full.parent().unwrap()).unwrap();
            std::fs::write(&full, &f.content).unwrap();
        }

        let report = normalize_crud_fn_names(&mut files, tmp.path()).unwrap();
        assert_eq!(report.renames_applied, 4);
        assert_eq!(report.files_modified, 2);
        assert!(files[0].content.contains("fn get_trade"));
        assert!(files[0].content.contains("fn create_trade"));
        assert!(files[0].content.contains("fn update_trade"));
        assert!(files[0].content.contains("fn delete_trade"));
        assert!(files[1].content.contains("trade_queries::get_trade"));
        assert!(files[1].content.contains("trade_queries::create_trade"));
        assert!(files[1].content.contains("trade_queries::update_trade"));
        assert!(files[1].content.contains("trade_queries::delete_trade"));
    }

    #[test]
    fn noop_when_all_canonical() {
        let tmp = tempfile::tempdir().unwrap();
        let path = "backend/src/database/user_queries.rs";
        let mut files = vec![gf(
            path,
            "pub async fn get_user() {}\npub async fn create_user() {}\n",
        )];
        let full = tmp.path().join(path);
        std::fs::create_dir_all(full.parent().unwrap()).unwrap();
        std::fs::write(&full, &files[0].content).unwrap();

        let report = normalize_crud_fn_names(&mut files, tmp.path()).unwrap();
        assert_eq!(report.renames_applied, 0);
        assert_eq!(report.files_modified, 0);
    }

    #[test]
    fn word_boundary_preserves_substrings() {
        // `fetch_user_by_email` must be treated as a SEPARATE name from
        // `fetch_user`. Renaming `fetch_user` → `get_user` must NOT
        // turn `fetch_user_by_email` into `get_user_by_email` by the
        // short match alone — the longer name needs its own rename
        // entry, which the collect pass adds.
        let tmp = tempfile::tempdir().unwrap();
        let path = "backend/src/database/user_queries.rs";
        let mut files = vec![gf(
            path,
            "pub async fn fetch_user() {}\n\
             pub async fn fetch_user_by_email() {}\n",
        )];
        let full = tmp.path().join(path);
        std::fs::create_dir_all(full.parent().unwrap()).unwrap();
        std::fs::write(&full, &files[0].content).unwrap();

        let report = normalize_crud_fn_names(&mut files, tmp.path()).unwrap();
        assert_eq!(report.renames_applied, 2);
        assert!(files[0].content.contains("fn get_user"));
        assert!(files[0].content.contains("fn get_user_by_email"));
        assert!(!files[0].content.contains("fetch_user"));
    }
}

// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Oracle abstraction for ISLS code generation.
//!
//! The `Oracle` trait decouples the forge pipeline from any specific LLM backend.
//! `MockOracle` is used for offline / CI runs. `OpenAiOracle` calls the OpenAI
//! chat completions API with temperature 0.2 for deterministic code generation.

use serde_json::json;

use crate::forge::ForgeLlmError;

/// Oracle result type using [`ForgeLlmError`].
pub type Result<T> = std::result::Result<T, ForgeLlmError>;

/// Approximate token count: 1 token ~ 4 bytes of UTF-8 text.
pub fn estimate_tokens(text: &str) -> u64 {
    (text.len() as u64).saturating_add(3) / 4
}

/// Strip markdown code fences from an LLM response.
///
/// Handles both ` ``` ` and `~~~` fence delimiters, with any language tag on
/// the opening line (e.g. ` ```rust `, ` ```toml `, `~~~javascript `).
/// Searches for the **first** closing fence from the end, so any trailing
/// explanation the LLM appends after the block is also discarded.
/// If no complete fence pair is found the input is returned unchanged.
pub fn strip_markdown_fences(response: &str) -> String {
    let trimmed = response.trim();

    let delimiter = if trimmed.starts_with("```") {
        "```"
    } else if trimmed.starts_with("~~~") {
        "~~~"
    } else {
        return response.to_string();
    };

    let lines: Vec<&str> = trimmed.lines().collect();
    if lines.len() < 2 {
        return response.to_string();
    }

    // Find the first closing fence scanning from the end
    let mut end = lines.len(); // sentinel: "not found"
    for i in (1..lines.len()).rev() {
        if lines[i].trim() == delimiter {
            end = i;
            break;
        }
    }

    if end == lines.len() {
        // No closing fence — leave unchanged
        return response.to_string();
    }

    lines[1..end].join("\n")
}

// ─── Oracle trait ─────────────────────────────────────────────────────────────

/// Abstraction over an LLM backend used during code generation.
pub trait Oracle: Send + Sync {
    /// Send a prompt and return the model's text response.
    fn call(&self, prompt: &str, max_tokens: u32) -> Result<String>;

    /// Send a prompt that must return a JSON value.
    fn call_json(&self, prompt: &str, max_tokens: u32) -> Result<serde_json::Value>;

    /// Identifier of the underlying model, e.g. `"gpt-4o"`.
    fn model_name(&self) -> &str;

    /// Estimated cost per 1 000 tokens in USD.
    fn cost_per_1k_tokens(&self) -> f64;

    /// Estimate the number of tokens in the given text.
    fn count_tokens(&self, text: &str) -> u64 {
        estimate_tokens(text)
    }
}

// ─── MockOracle ───────────────────────────────────────────────────────────────

/// No-op oracle for offline and CI use.
///
/// Returns deterministic placeholder strings without making any network calls.
/// Useful for verifying the forge pipeline machinery without an API key.
pub struct MockOracle;

impl Oracle for MockOracle {
    fn call(&self, _prompt: &str, _max_tokens: u32) -> Result<String> {
        // Return a minimal valid Rust comment so parse checks succeed
        Ok("// [mock: no implementation generated]".to_string())
    }

    fn call_json(&self, _prompt: &str, _max_tokens: u32) -> Result<serde_json::Value> {
        Ok(json!({"fixes": [], "notes": "mock oracle — no analysis performed"}))
    }

    fn model_name(&self) -> &str {
        "mock"
    }

    fn cost_per_1k_tokens(&self) -> f64 {
        0.0
    }
}

// ─── OpenAiOracle ─────────────────────────────────────────────────────────────

/// Oracle implementation backed by the OpenAI chat completions API.
///
/// Uses temperature 0.2 for code generation to balance creativity with
/// determinism. Reads the API key from the `api_key` field or falls back to
/// the `OPENAI_API_KEY` environment variable.
pub struct OpenAiOracle {
    api_key: String,
    model: String,
    base_url: String,
    client: reqwest::blocking::Client,
}

impl OpenAiOracle {
    /// Create a new OpenAI oracle.
    ///
    /// If `api_key` is `None`, the key is read from `OPENAI_API_KEY` env var
    /// (or from a `.env` file loaded by the caller).
    pub fn new(api_key: Option<String>, model: Option<String>) -> Result<Self> {
        let key = match api_key {
            Some(k) if !k.is_empty() => k,
            _ => std::env::var("OPENAI_API_KEY")
                .map_err(|_| ForgeLlmError::Oracle(
                    "OPENAI_API_KEY not set and no --api-key provided".into()
                ))?,
        };
        let model = model.unwrap_or_else(|| "gpt-4o".to_string());
        let client = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(120))
            .build()
            .map_err(|e| ForgeLlmError::Oracle(e.to_string()))?;
        Ok(OpenAiOracle {
            api_key: key,
            model,
            base_url: "https://api.openai.com/v1".to_string(),
            client,
        })
    }

    fn chat_completions(&self, system: &str, user: &str, max_tokens: u32) -> Result<String> {
        let url = format!("{}/chat/completions", self.base_url);
        let body = json!({
            "model": self.model,
            "temperature": 0.2,
            "max_tokens": max_tokens,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user}
            ]
        });

        eprintln!("[Oracle] Calling {} ({} chars prompt, max_tokens={})...",
            self.model, user.len(), max_tokens);

        let resp = self.client
            .post(&url)
            .bearer_auth(&self.api_key)
            .json(&body)
            .send()
            .map_err(|e| ForgeLlmError::Oracle(e.to_string()))?;

        let status = resp.status();
        let text = resp.text()
            .map_err(|e| ForgeLlmError::Oracle(
                format!("Failed to read response: {}", e)
            ))?;

        eprintln!("[Oracle] Response status: {}, {} bytes", status, text.len());

        if !status.is_success() {
            return Err(ForgeLlmError::Oracle(
                format!("OpenAI API error {}: {}", status, text)
            ));
        }

        let json: serde_json::Value = serde_json::from_str(&text)
            .map_err(|e| ForgeLlmError::Oracle(
                format!("Failed to parse response: {e}: {text}")
            ))?;

        let content = json["choices"][0]["message"]["content"]
            .as_str()
            .ok_or_else(|| ForgeLlmError::Oracle(
                format!("No content in response: {}", text)
            ))?
            .to_string();

        Ok(strip_markdown_fences(&content))
    }

    const SYSTEM_PROMPT: &'static str =
        "You are a precise code generator. \
         Return only the requested code, no markdown fences, no explanation.";

    const SYSTEM_PROMPT_JSON: &'static str =
        "You are a precise code analyzer. \
         Return only valid JSON, no markdown fences, no explanation.";
}

impl Oracle for OpenAiOracle {
    fn call(&self, prompt: &str, max_tokens: u32) -> Result<String> {
        self.chat_completions(Self::SYSTEM_PROMPT, prompt, max_tokens)
    }

    fn call_json(&self, prompt: &str, max_tokens: u32) -> Result<serde_json::Value> {
        let text = self.chat_completions(Self::SYSTEM_PROMPT_JSON, prompt, max_tokens)?;
        serde_json::from_str(text.trim())
            .map_err(|e| ForgeLlmError::Oracle(
                format!("failed to parse oracle JSON response: {e}: {text}")
            ))
    }

    fn model_name(&self) -> &str {
        &self.model
    }

    fn cost_per_1k_tokens(&self) -> f64 {
        0.15
    }
}

// ─── OllamaOracle ────────────────────────────────────────────────────────────

/// Oracle implementation backed by a locally running Ollama instance.
///
/// Calls the Ollama HTTP API (`/api/generate`) with `stream: false`.
/// Zero API cost — runs entirely on the local machine. Default model is
/// `codellama:7b` with temperature 0.1 for deterministic code generation.
///
/// Requires Ollama to be running (`ollama serve`) and the model to be pulled
/// (`ollama pull codellama:7b`).
/// Heartbeat callback invoked during a streaming Ollama call. Receives
/// `(tokens_so_far, elapsed_secs)` so the gateway can broadcast live
/// token-rate progress to the Studio UI while a long call is still
/// running.
pub type OllamaHeartbeatFn =
    std::sync::Arc<dyn Fn(u64, f64) + Send + Sync + 'static>;

pub struct OllamaOracle {
    model: String,
    base_url: String,
    client: reqwest::blocking::Client,
    on_heartbeat: Option<OllamaHeartbeatFn>,
}

impl OllamaOracle {
    /// Create a new Ollama oracle.
    ///
    /// - `model`: Ollama model name, e.g. `"codellama:7b"`.
    /// - `base_url`: Ollama API base URL, e.g. `"http://localhost:11434"`.
    pub fn new(model: &str, base_url: &str) -> Self {
        // Large models (32B) on CPU need a big request ceiling: a forge-
        // scale prompt with 4096 num_predict tokens at ~2 tok/s already
        // needs ~35 min of generation, plus a possible cold-start model
        // reload on first call. We use `stream: true` (see `Oracle::call`)
        // so reqwest sees a steady trickle of bytes — but if Ollama
        // stalls completely, the single 2 h `timeout` is the backstop.
        //
        // `no_proxy()` is critical: reqwest otherwise honours
        // `HTTP_PROXY` / `HTTPS_PROXY` env vars and tries to route
        // localhost through a corporate / egress proxy that can't reach
        // the Ollama daemon — producing the infamous
        // `error sending request for url (http://localhost:11434/...)`.
        //
        // `tcp_keepalive` stops the kernel from silently resetting an
        // idle socket while Ollama is still generating; without it,
        // long calls can surface as `operation timed out` even though
        // Ollama is still working.
        let client = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(7200))
            .connect_timeout(std::time::Duration::from_secs(10))
            .tcp_keepalive(std::time::Duration::from_secs(30))
            .pool_idle_timeout(None)
            .no_proxy()
            .build()
            .expect("failed to build HTTP client for Ollama");
        Self {
            model: model.to_string(),
            base_url: normalize_localhost(base_url.trim_end_matches('/')),
            client,
            on_heartbeat: None,
        }
    }

    /// Attach a streaming heartbeat callback. The callback is invoked on
    /// every heartbeat tick during `call` (~every 5 s) with
    /// `(tokens_so_far, elapsed_secs)`. Used by the gateway to broadcast
    /// `forge:oracle_tick` WebSocket events so the Studio UI can show a
    /// live token counter during a 10–30 min generation.
    pub fn with_heartbeat(mut self, cb: OllamaHeartbeatFn) -> Self {
        self.on_heartbeat = Some(cb);
        self
    }

    /// Check whether Ollama is running and reachable.
    ///
    /// Calls `GET {base_url}/api/tags` — if the request fails, Ollama is not
    /// running. Returns `Ok(())` on success or an error message on failure.
    pub fn check_availability(base_url: &str) -> std::result::Result<(), String> {
        let url = format!(
            "{}/api/tags",
            normalize_localhost(base_url.trim_end_matches('/')),
        );
        let client = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(5))
            .no_proxy()
            .build()
            .map_err(|e| format!("HTTP client error: {e}"))?;
        client.get(&url).send()
            .map_err(|_| format!(
                "Ollama is not running. Start it with `ollama serve` \
                 or install from https://ollama.com"
            ))?;
        Ok(())
    }

    /// Check whether a specific model is available in the local Ollama instance.
    ///
    /// Calls `GET {base_url}/api/tags` and checks if the model name appears
    /// in the response. Returns `Ok(())` if found, or an error message.
    pub fn check_model(base_url: &str, model: &str) -> std::result::Result<(), String> {
        let url = format!(
            "{}/api/tags",
            normalize_localhost(base_url.trim_end_matches('/')),
        );
        let client = reqwest::blocking::Client::builder()
            .timeout(std::time::Duration::from_secs(5))
            .no_proxy()
            .build()
            .map_err(|e| format!("HTTP client error: {e}"))?;
        let resp = client.get(&url).send()
            .map_err(|_| "Ollama is not running".to_string())?;
        let json: serde_json::Value = resp.json()
            .map_err(|e| format!("Failed to parse Ollama response: {e}"))?;
        let models = json["models"].as_array()
            .ok_or_else(|| "Unexpected Ollama response format".to_string())?;
        let found = models.iter().any(|m| {
            m["name"].as_str().map_or(false, |n| n == model || n.starts_with(&format!("{model}:")))
                || m["model"].as_str().map_or(false, |n| n == model || n.starts_with(&format!("{model}:")))
        });
        if found {
            Ok(())
        } else {
            Err(format!(
                "Model '{model}' not found. Pull it with `ollama pull {model}`"
            ))
        }
    }
}

/// Rewrite `http://localhost[:port]` to `http://127.0.0.1[:port]` so reqwest
/// skips IPv6 (`::1`) resolution — Ollama binds to IPv4 by default and
/// a first-attempt IPv6 failure looks like `error sending request` to the
/// caller.
fn normalize_localhost(url: &str) -> String {
    url.replace("http://localhost", "http://127.0.0.1")
        .replace("https://localhost", "https://127.0.0.1")
}

/// Render a full cause chain for a reqwest error so the user sees the
/// underlying reason (`connection refused`, `proxy error`, `timed out`, …)
/// instead of just the generic `error sending request`.
fn format_error_chain(err: &dyn std::error::Error) -> String {
    let mut out = err.to_string();
    let mut src = err.source();
    while let Some(e) = src {
        out.push_str(" — caused by: ");
        out.push_str(&e.to_string());
        src = e.source();
    }
    out
}

impl Oracle for OllamaOracle {
    fn call(&self, prompt: &str, max_tokens: u32) -> Result<String> {
        use std::io::{BufRead, BufReader};

        let url = format!("{}/api/generate", self.base_url);
        // `stream: true` so Ollama emits one JSON line per generated token.
        // Without streaming reqwest sees zero bytes until the full response
        // is ready, which can be 30+ minutes on a local 32B model — the
        // user then has no way to tell whether the forge is actually
        // generating or wedged.
        let body = json!({
            "model": self.model,
            "prompt": prompt,
            "stream": true,
            "options": {
                "temperature": 0.1,
                "num_predict": max_tokens
            }
        });

        eprintln!(
            "[Ollama] ▶ call {} ({} chars prompt, max_tokens={})",
            self.model, prompt.len(), max_tokens,
        );

        let started = std::time::Instant::now();

        let resp = self.client
            .post(&url)
            .json(&body)
            .send()
            .map_err(|e| ForgeLlmError::Oracle(format!(
                "Ollama request failed after {:.1}s: {}",
                started.elapsed().as_secs_f64(),
                format_error_chain(&e),
            )))?;

        let status = resp.status();
        if !status.is_success() {
            // Drain the body so we can include the server error in our message.
            let text = resp.text().unwrap_or_default();
            return Err(ForgeLlmError::Oracle(format!(
                "Ollama API error {} after {:.1}s: {}",
                status,
                started.elapsed().as_secs_f64(),
                text,
            )));
        }

        // Stream parser: each line is a standalone JSON object with either
        // a `response` chunk or the final `done: true` marker (+ eval_count,
        // eval_duration). We accumulate `response` and log a heartbeat
        // every ~5 s so `journalctl -fu isls` shows life.
        //
        // To get heartbeats even *during* Ollama's prompt-eval phase
        // (which can take 30–120 s on CPU for a big forge prompt while
        // reqwest's `read_line` is blocked waiting for the first byte),
        // we run an independent heartbeat thread that reads the current
        // token count from an atomic and fires on a wall-clock timer.
        let mut reader = BufReader::new(resp);
        let mut line = String::new();
        let mut full_response = String::with_capacity(4096);
        let token_count = std::sync::Arc::new(std::sync::atomic::AtomicU64::new(0));
        let done_flag = std::sync::Arc::new(std::sync::atomic::AtomicBool::new(false));
        let mut finished = false;
        const HEARTBEAT_EVERY: std::time::Duration = std::time::Duration::from_secs(5);

        // Background heartbeat thread — keeps the UI alive even while the
        // stream itself hasn't produced any bytes yet (prompt-eval phase).
        let heartbeat_thread = {
            let tc = token_count.clone();
            let df = done_flag.clone();
            let cb = self.on_heartbeat.clone();
            let model = self.model.clone();
            std::thread::spawn(move || {
                let mut last = std::time::Instant::now();
                // Fire an initial "waiting for Ollama" tick so the UI
                // confirms the callback chain is wired, even before the
                // 5 s mark.
                if let Some(ref cb) = cb {
                    cb(0, 0.0);
                }
                while !df.load(std::sync::atomic::Ordering::Relaxed) {
                    std::thread::sleep(std::time::Duration::from_millis(250));
                    if last.elapsed() >= HEARTBEAT_EVERY {
                        let tokens = tc.load(std::sync::atomic::Ordering::Relaxed);
                        let elapsed = started.elapsed().as_secs_f64();
                        let tps = if elapsed > 0.0 { tokens as f64 / elapsed } else { 0.0 };
                        eprintln!(
                            "[Ollama] … {} tokens, {:.1}s elapsed, {:.2} tok/s{}",
                            tokens,
                            elapsed,
                            tps,
                            if tokens == 0 { " (awaiting first byte — prompt eval?)" } else { "" },
                        );
                        let _ = &model; // silence unused-if-cb-none lint
                        if let Some(ref cb) = cb {
                            cb(tokens, elapsed);
                        }
                        last = std::time::Instant::now();
                    }
                }
            })
        };

        loop {
            line.clear();
            let bytes = reader.read_line(&mut line).map_err(|e| {
                done_flag.store(true, std::sync::atomic::Ordering::Relaxed);
                ForgeLlmError::Oracle(format!(
                    "Failed to read Ollama stream after {:.1}s and {} tokens: {}",
                    started.elapsed().as_secs_f64(),
                    token_count.load(std::sync::atomic::Ordering::Relaxed),
                    e,
                ))
            })?;
            if bytes == 0 {
                // EOF before a `done: true` marker — treat as a hard failure.
                break;
            }
            let trimmed = line.trim();
            if trimmed.is_empty() {
                continue;
            }
            let chunk: serde_json::Value = match serde_json::from_str(trimmed) {
                Ok(v) => v,
                Err(e) => {
                    done_flag.store(true, std::sync::atomic::Ordering::Relaxed);
                    return Err(ForgeLlmError::Oracle(format!(
                        "Failed to parse Ollama stream chunk at {:.1}s: {}: {}",
                        started.elapsed().as_secs_f64(),
                        e,
                        trimmed,
                    )));
                }
            };
            if let Some(err) = chunk.get("error").and_then(|v| v.as_str()) {
                done_flag.store(true, std::sync::atomic::Ordering::Relaxed);
                return Err(ForgeLlmError::Oracle(format!(
                    "Ollama stream error after {:.1}s and {} tokens: {}",
                    started.elapsed().as_secs_f64(),
                    token_count.load(std::sync::atomic::Ordering::Relaxed),
                    err,
                )));
            }
            if let Some(piece) = chunk.get("response").and_then(|v| v.as_str()) {
                full_response.push_str(piece);
                token_count.fetch_add(1, std::sync::atomic::Ordering::Relaxed);
            }
            if chunk.get("done").and_then(|v| v.as_bool()).unwrap_or(false) {
                finished = true;
                break;
            }
        }

        // Tell the heartbeat thread to stop and join it so it flushes a
        // final tick if due.
        done_flag.store(true, std::sync::atomic::Ordering::Relaxed);
        let _ = heartbeat_thread.join();

        let token_count = token_count.load(std::sync::atomic::Ordering::Relaxed);

        let elapsed = started.elapsed().as_secs_f64();
        if !finished {
            return Err(ForgeLlmError::Oracle(format!(
                "Ollama stream ended without done marker after {:.1}s and {} tokens",
                elapsed, token_count,
            )));
        }

        let tps = if elapsed > 0.0 { token_count as f64 / elapsed } else { 0.0 };
        eprintln!(
            "[Ollama] ✓ done: {} tokens, {} chars, {:.1}s, {:.2} tok/s",
            token_count, full_response.len(), elapsed, tps,
        );

        Ok(strip_markdown_fences(&full_response))
    }

    fn call_json(&self, prompt: &str, max_tokens: u32) -> Result<serde_json::Value> {
        let text = self.call(prompt, max_tokens)?;
        serde_json::from_str(text.trim())
            .map_err(|e| ForgeLlmError::Oracle(
                format!("failed to parse Ollama JSON response: {e}: {text}")
            ))
    }

    fn model_name(&self) -> &str {
        &self.model
    }

    fn cost_per_1k_tokens(&self) -> f64 {
        0.0
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::strip_markdown_fences;

    #[test]
    fn strips_rust_fence() {
        let input = "```rust\nfn main() {}\n```";
        assert_eq!(strip_markdown_fences(input), "fn main() {}");
    }

    #[test]
    fn strips_plain_fence() {
        let input = "```\nsome content\n```";
        assert_eq!(strip_markdown_fences(input), "some content");
    }

    #[test]
    fn strips_toml_fence() {
        let input = "```toml\n[package]\nname = \"x\"\n```";
        assert_eq!(strip_markdown_fences(input), "[package]\nname = \"x\"");
    }

    #[test]
    fn strips_json_fence() {
        let input = "```json\n{\"k\":1}\n```";
        assert_eq!(strip_markdown_fences(input), "{\"k\":1}");
    }

    #[test]
    fn no_fence_unchanged() {
        let input = "fn foo() -> u32 { 42 }";
        assert_eq!(strip_markdown_fences(input), input);
    }

    #[test]
    fn leading_trailing_whitespace_ignored() {
        let input = "\n  ```rust\nlet x = 1;\n```  \n";
        assert_eq!(strip_markdown_fences(input), "let x = 1;");
    }

    #[test]
    fn multiline_body_preserved() {
        let input = "```rust\nuse std::env;\n\nfn main() {\n    println!(\"hi\");\n}\n```";
        let expected = "use std::env;\n\nfn main() {\n    println!(\"hi\");\n}";
        assert_eq!(strip_markdown_fences(input), expected);
    }

    #[test]
    fn unclosed_fence_unchanged() {
        let input = "```rust\nfn main() {}";
        assert_eq!(strip_markdown_fences(input), input);
    }

    #[test]
    fn strips_tilde_fence() {
        let input = "~~~rust\nfn foo() {}\n~~~";
        assert_eq!(strip_markdown_fences(input), "fn foo() {}");
    }

    #[test]
    fn unclosed_tilde_fence_unchanged() {
        let input = "~~~rust\nfn foo() {}";
        assert_eq!(strip_markdown_fences(input), input);
    }

    #[test]
    fn trailing_explanation_discarded() {
        let input = "```rust\nfn foo() {}\n```\nThis implements foo.";
        assert_eq!(strip_markdown_fences(input), "fn foo() {}");
    }

    #[test]
    fn ollama_oracle_creation() {
        use super::Oracle;
        // `localhost` is rewritten to `127.0.0.1` to avoid IPv6-first
        // resolution racing against Ollama's IPv4-only default bind.
        let oracle = super::OllamaOracle::new("codellama:7b", "http://localhost:11434");
        assert_eq!(oracle.model, "codellama:7b");
        assert_eq!(oracle.base_url, "http://127.0.0.1:11434");
        assert_eq!(oracle.model_name(), "codellama:7b");
        assert_eq!(oracle.cost_per_1k_tokens(), 0.0);
    }

    #[test]
    fn ollama_oracle_trims_trailing_slash() {
        let oracle = super::OllamaOracle::new("mistral:7b", "http://localhost:11434/");
        assert_eq!(oracle.base_url, "http://127.0.0.1:11434");
    }

    #[test]
    fn ollama_oracle_preserves_non_localhost_host() {
        let oracle = super::OllamaOracle::new("mistral:7b", "http://ollama.internal:11434");
        assert_eq!(oracle.base_url, "http://ollama.internal:11434");
    }
}

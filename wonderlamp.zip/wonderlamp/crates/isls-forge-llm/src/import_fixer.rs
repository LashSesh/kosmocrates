// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Deterministic fixer for missing `use crate::…` imports in LLM output.
//!
//! Local 7 B-class models routinely reference project-wide types
//! (`AppError`, `PaginationParams`, `AuthUser`, …) in the file body
//! without emitting the corresponding `use` statement at the top. The
//! Coagula fix prompt already lists the correct import paths but the
//! model does not always apply them. Since the mapping from core type
//! name to crate path is deterministic, we fix it without another LLM
//! round-trip.
//!
//! For each known type, if the file body references the type as a
//! standalone identifier *and* the expected `use` statement is not
//! already present, we inject it into the import block at the top of
//! the file.

use regex::Regex;

/// Known core-type → canonical `use` path mapping. Kept deliberately
/// short: these are the types the forge generator itself emits, so
/// their import paths are guaranteed. Adding hallucinated types here
/// would paper over real bugs.
const CORE_IMPORTS: &[(&str, &str)] = &[
    ("AppError", "use crate::errors::AppError;"),
    ("AuthUser", "use crate::auth::AuthUser;"),
    ("Claims", "use crate::auth::Claims;"),
    ("PaginationParams", "use crate::pagination::PaginationParams;"),
    ("PaginatedResponse", "use crate::pagination::PaginatedResponse;"),
    ("AppConfig", "use crate::config::AppConfig;"),
];

/// Scan `content` for references to known core types and, for every
/// type that is referenced but whose `use` statement is absent, inject
/// the missing import. Returns a new `String`; if no injection is
/// needed the output is byte-identical to the input.
pub fn fix_missing_imports(content: &str) -> String {
    let mut to_add: Vec<&'static str> = Vec::new();

    for (ty, stmt) in CORE_IMPORTS {
        if !references_identifier(content, ty) {
            continue;
        }
        if has_import_for(content, ty) {
            continue;
        }
        to_add.push(stmt);
    }

    if to_add.is_empty() {
        return content.to_string();
    }

    insert_after_existing_uses(content, &to_add)
}

/// Return true if `ident` appears in `content` as a standalone
/// identifier — i.e. surrounded by non-word characters. Ignores
/// occurrences inside other identifiers (e.g. `MyAppError`).
///
/// Does NOT strip string literals or comments: a mention inside a
/// comment triggers a `use` injection, producing at worst an
/// `unused_imports` warning — harmless.
fn references_identifier(content: &str, ident: &str) -> bool {
    let pattern = format!(r"\b{}\b", regex::escape(ident));
    // regex::Regex::new on a trivial pattern never fails — the static
    // build is cheap enough for this one-shot use.
    let re = match Regex::new(&pattern) {
        Ok(r) => r,
        Err(_) => return false,
    };
    re.is_match(content)
}

/// Return true if `content` already contains any `use` statement that
/// would bring `type_name` into scope. Accepts several common forms:
///
///   * the exact canonical `use crate::X::Name;`
///   * a grouped import `use crate::X::{…, Name, …};`
///   * a renamed import `use crate::X::Name as Whatever;`
///   * a wildcard `use crate::X::*;` (conservative — not detected)
fn has_import_for(content: &str, type_name: &str) -> bool {
    for line in content.lines() {
        let t = line.trim();
        if !t.starts_with("use ") {
            continue;
        }
        // Strip trailing `;` if present for cleaner matching.
        let body = t.trim_end_matches(';').trim_start_matches("use ").trim();
        if import_line_provides(body, type_name) {
            return true;
        }
    }
    false
}

fn import_line_provides(body: &str, type_name: &str) -> bool {
    // Case 1: grouped import `crate::x::{A, B, C}`.
    if let Some(brace_open) = body.find('{') {
        if let Some(brace_close) = body.rfind('}') {
            if brace_close > brace_open {
                let group = &body[brace_open + 1..brace_close];
                for item in group.split(',') {
                    let name = item.trim().split(" as ").next().unwrap_or("").trim();
                    // last segment of a path like `self::Foo` or just `Foo`
                    let last = name.rsplit("::").next().unwrap_or("");
                    if last == type_name {
                        return true;
                    }
                }
            }
        }
    }
    // Case 2: simple path ending with `::TypeName` or `TypeName`, possibly
    // with a `as Alias`. The `as` form means the original name isn't in
    // scope, so we still need to emit the canonical form.
    let without_as = body.split(" as ").next().unwrap_or(body).trim();
    let last = without_as.rsplit("::").next().unwrap_or("");
    if last == type_name {
        return true;
    }
    // Case 3: explicit `use crate::X::*;` — could bring the type in scope,
    // but we'd need to know if `type_name` lives in `X` to be sure. Be
    // conservative: treat wildcard as providing nothing, i.e. we may emit
    // a duplicate import which is a warning but never an error.
    false
}

/// Insert `imports` into `content` after the last existing `use`
/// statement (or after any top-of-file `#![...]` / `//!` header if no
/// `use` statements exist). Preserves existing formatting and line
/// endings.
fn insert_after_existing_uses(content: &str, imports: &[&str]) -> String {
    // Work with lines. `str::lines` drops line endings, so we stitch
    // back with `\n` — adequate for generator output, which is LF.
    let lines: Vec<&str> = content.lines().collect();
    let mut last_use: Option<usize> = None;
    let mut last_header: Option<usize> = None;
    for (i, line) in lines.iter().enumerate() {
        let t = line.trim();
        if t.starts_with("use ") {
            last_use = Some(i);
            continue;
        }
        if last_use.is_some() {
            // We already saw `use` lines; the first non-`use` non-blank
            // after the import block is where we stop scanning.
            if !t.is_empty() {
                break;
            }
            continue;
        }
        if t.starts_with("#![") || t.starts_with("//!") {
            last_header = Some(i);
            continue;
        }
        // A non-import, non-header, non-blank line at the top of the
        // file — we'll insert just before it.
        if !t.is_empty() && !t.starts_with("//") {
            break;
        }
    }

    let insert_at = last_use
        .map(|i| i + 1)
        .or(last_header.map(|i| i + 1))
        .unwrap_or(0);

    let mut out: Vec<String> = lines[..insert_at].iter().map(|s| s.to_string()).collect();
    for stmt in imports {
        out.push((*stmt).to_string());
    }
    out.extend(lines[insert_at..].iter().map(|s| s.to_string()));

    let trailing_nl = content.ends_with('\n');
    let mut result = out.join("\n");
    if trailing_nl && !result.ends_with('\n') {
        result.push('\n');
    }
    result
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn no_reference_no_change() {
        let src = "pub fn foo() { 42 }\n";
        assert_eq!(fix_missing_imports(src), src);
    }

    #[test]
    fn injects_missing_app_error() {
        let src = "\
pub async fn f() -> Result<(), AppError> {
    Err(AppError::NotFound)
}
";
        let out = fix_missing_imports(src);
        assert!(out.contains("use crate::errors::AppError;"));
        assert!(out.starts_with("use crate::errors::AppError;"));
    }

    #[test]
    fn does_not_inject_when_already_imported() {
        let src = "\
use crate::errors::AppError;

pub async fn f() -> Result<(), AppError> { Err(AppError::NotFound) }
";
        let out = fix_missing_imports(src);
        // Exactly one occurrence of the `use` line.
        assert_eq!(out.matches("use crate::errors::AppError;").count(), 1);
    }

    #[test]
    fn detects_grouped_import() {
        let src = "\
use crate::errors::{AppError, OtherError};

pub fn f() -> Result<(), AppError> { unimplemented!() }
";
        let out = fix_missing_imports(src);
        // No separate `use crate::errors::AppError;` inserted.
        assert!(!out.contains("use crate::errors::AppError;"));
    }

    #[test]
    fn injects_pagination_types_when_referenced() {
        let src = "\
pub async fn list(params: PaginationParams) -> PaginatedResponse<User> {
    todo!()
}
";
        let out = fix_missing_imports(src);
        assert!(out.contains("use crate::pagination::PaginationParams;"));
        assert!(out.contains("use crate::pagination::PaginatedResponse;"));
    }

    #[test]
    fn inserts_after_existing_use_block() {
        let src = "\
use std::collections::HashMap;
use sqlx::PgPool;

pub async fn f() -> Result<(), AppError> { unimplemented!() }
";
        let out = fix_missing_imports(src);
        // The new `use` line sits AFTER the existing import block.
        let idx_new = out.find("use crate::errors::AppError;").unwrap();
        let idx_pgpool = out.find("use sqlx::PgPool;").unwrap();
        assert!(idx_pgpool < idx_new, "new import must come after existing uses");
    }

    #[test]
    fn word_boundary_prevents_false_match() {
        // `MyAppError` is a different type — do not inject `AppError`.
        let src = "pub struct MyAppError; pub fn f() -> MyAppError { MyAppError }\n";
        let out = fix_missing_imports(src);
        assert!(!out.contains("use crate::errors::AppError;"));
    }

    #[test]
    fn multiple_types_injected_together() {
        let src = "\
pub async fn f(
    params: PaginationParams,
    user: AuthUser,
) -> Result<PaginatedResponse<User>, AppError> { todo!() }
";
        let out = fix_missing_imports(src);
        assert!(out.contains("use crate::errors::AppError;"));
        assert!(out.contains("use crate::auth::AuthUser;"));
        assert!(out.contains("use crate::pagination::PaginationParams;"));
        assert!(out.contains("use crate::pagination::PaginatedResponse;"));
    }

    #[test]
    fn preserves_trailing_newline() {
        let src = "pub fn f() -> AppError { AppError::NotFound }\n";
        let out = fix_missing_imports(src);
        assert!(out.ends_with('\n'));
    }

    #[test]
    fn inserts_before_first_item_when_no_existing_uses() {
        let src = "\
//! Module docstring
pub fn f() -> AppError { AppError::NotFound }
";
        let out = fix_missing_imports(src);
        let idx_doc = out.find("//!").unwrap();
        let idx_use = out.find("use crate::errors::AppError;").unwrap();
        let idx_fn = out.find("pub fn f").unwrap();
        assert!(idx_doc < idx_use && idx_use < idx_fn);
    }
}

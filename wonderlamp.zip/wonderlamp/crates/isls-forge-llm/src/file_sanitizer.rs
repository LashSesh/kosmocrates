// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Deterministic structural sanitizer for LLM-emitted Rust files.
//!
//! Three independent passes applied in order:
//!
//! 1. [`strip_wrong_mod_declarations`] — small local LLMs sometimes
//!    copy-paste a `mod api; mod auth; mod config; …` block (which
//!    only belongs in `main.rs` or `lib.rs`) into a leaf file such as
//!    `src/database/user_queries.rs`. Each such line produces an
//!    `E0583: file not found for module 'X'`. The pass removes
//!    top-level bare `mod NAME;` declarations from non-root files.
//!
//! 2. [`inject_missing_async`] — when the generated body contains
//!    `.await` but the signature lacks `async`, prepend it. `await`
//!    outside an `async` context is `E0728`.
//!
//! 3. [`strip_forbidden_crate_imports`] — a narrow allowlist of
//!    commonly-hallucinated crates (`log`, `env_logger`,
//!    `pretty_env_logger`) that are never part of the forge's
//!    generated `Cargo.toml`. Removes `use CRATE::…;` and
//!    `extern crate CRATE;` lines. The generator emits only `tracing`
//!    for logging, so these imports are always safe to drop.
//!
//! Each pass is a pure `&str → String` transform. Order matters only
//! for idempotency — (1) and (3) are line-based, (2) is body-based,
//! so running them in sequence is well-defined.

use regex::Regex;

// ─── Pass 1: strip wrong `mod X;` declarations ───────────────────────────────

/// Root files that LEGITIMATELY declare sub-modules. Everything else
/// is a leaf file where `mod NAME;` at top-level is almost always a
/// hallucination.
fn is_root_file(rel_path: &str) -> bool {
    let file = rel_path.rsplit('/').next().unwrap_or(rel_path);
    matches!(file, "main.rs" | "lib.rs" | "mod.rs")
}

/// Remove top-level `mod NAME;` (with optional `pub`, `pub(crate)`,
/// `pub(super)` visibility) from `content` unless `rel_path` names a
/// legitimate module-declaring root file.
///
/// Only *declarative* forms with a trailing semicolon are stripped —
/// inline `mod foo { … }` blocks stay untouched. The check runs at
/// column 0 / after indentation on a line-by-line basis, so module
/// declarations nested inside functions (not valid Rust anyway) are
/// preserved verbatim.
pub fn strip_wrong_mod_declarations(rel_path: &str, content: &str) -> String {
    if is_root_file(rel_path) {
        return content.to_string();
    }

    // `mod NAME;` — with optional visibility, whitespace-tolerant.
    // No match on `mod NAME { … }` (inline module) because the
    // semicolon alternative is excluded.
    let re = match Regex::new(
        r"(?m)^\s*(?:pub(?:\([^)]+\))?\s+)?mod\s+[A-Za-z_][A-Za-z0-9_]*\s*;\s*$",
    ) {
        Ok(r) => r,
        Err(_) => return content.to_string(),
    };

    let out = re.replace_all(content, "");
    // `replace_all` may leave adjacent blank lines — collapse runs of
    // 3+ newlines to 2 so we don't accumulate visual cruft on repeat
    // sanitizer runs.
    collapse_blank_lines(&out)
}

fn collapse_blank_lines(s: &str) -> String {
    let mut out = String::with_capacity(s.len());
    let mut consecutive_newlines: usize = 0;
    for ch in s.chars() {
        if ch == '\n' {
            consecutive_newlines += 1;
            if consecutive_newlines <= 2 {
                out.push(ch);
            }
        } else {
            consecutive_newlines = 0;
            out.push(ch);
        }
    }
    out
}

// ─── Pass 2: inject missing `async` on fns that use `.await` ─────────────────

/// For every top-level `fn NAME(…)` (with optional `pub` visibility)
/// whose body contains `.await`, prepend the `async` keyword if it
/// isn't already there. Idempotent — `async fn` matches stay
/// unchanged.
pub fn inject_missing_async(content: &str) -> String {
    let re = match Regex::new(
        r"(?m)^(?P<indent>[ \t]*)(?P<vis>pub(?:\([^)]+\))?\s+)?(?P<asyncm>async\s+)?fn\s+(?P<name>[A-Za-z_][A-Za-z0-9_]*)",
    ) {
        Ok(r) => r,
        Err(_) => return content.to_string(),
    };

    // Collect modifications as (replace_range, new_text) and apply in
    // reverse order so earlier indices don't shift.
    let mut edits: Vec<(std::ops::Range<usize>, String)> = Vec::new();

    for cap in re.captures_iter(content) {
        if cap.name("asyncm").is_some() {
            continue;
        }
        let full = cap.get(0).unwrap();
        // Find the fn-body span starting at the first '{' after the match.
        let body_start = match find_first_brace(content, full.end()) {
            Some(i) => i,
            None => continue,
        };
        let body_end = match find_matching_brace(content, body_start) {
            Some(i) => i,
            None => continue,
        };
        let body = &content[body_start..=body_end];
        if !body.contains(".await") {
            continue;
        }
        // Insert `async ` right before `fn`. The `fn` keyword in the
        // match starts at `full.start() + indent_len + vis_len`.
        let indent_len = cap.name("indent").map(|m| m.end() - m.start()).unwrap_or(0);
        let vis_len = cap.name("vis").map(|m| m.end() - m.start()).unwrap_or(0);
        let fn_kw_pos = full.start() + indent_len + vis_len;
        edits.push((fn_kw_pos..fn_kw_pos, "async ".to_string()));
    }

    if edits.is_empty() {
        return content.to_string();
    }

    apply_edits_reverse(content, &mut edits)
}

fn find_first_brace(s: &str, from: usize) -> Option<usize> {
    let bytes = s.as_bytes();
    let mut i = from;
    while i < bytes.len() {
        match bytes[i] {
            b'{' => return Some(i),
            b';' => return None,
            b'"' => {
                // Skip string literal
                i += 1;
                while i < bytes.len() {
                    match bytes[i] {
                        b'\\' if i + 1 < bytes.len() => i += 2,
                        b'"' => break,
                        _ => i += 1,
                    }
                }
            }
            _ => {}
        }
        i += 1;
    }
    None
}

fn find_matching_brace(s: &str, open: usize) -> Option<usize> {
    let bytes = s.as_bytes();
    if bytes.get(open) != Some(&b'{') {
        return None;
    }
    let mut depth = 1i32;
    let mut i = open + 1;
    while i < bytes.len() {
        match bytes[i] {
            b'{' => depth += 1,
            b'}' => {
                depth -= 1;
                if depth == 0 {
                    return Some(i);
                }
            }
            b'"' => {
                i += 1;
                while i < bytes.len() {
                    match bytes[i] {
                        b'\\' if i + 1 < bytes.len() => i += 2,
                        b'"' => break,
                        _ => i += 1,
                    }
                }
            }
            b'/' if i + 1 < bytes.len() && bytes[i + 1] == b'/' => {
                while i < bytes.len() && bytes[i] != b'\n' {
                    i += 1;
                }
            }
            _ => {}
        }
        i += 1;
    }
    None
}

fn apply_edits_reverse(
    content: &str,
    edits: &mut [(std::ops::Range<usize>, String)],
) -> String {
    edits.sort_by(|a, b| b.0.start.cmp(&a.0.start));
    let mut out = content.to_string();
    for (range, replacement) in edits.iter() {
        out.replace_range(range.clone(), replacement);
    }
    out
}

// ─── Pass 3: strip forbidden extern-crate imports ────────────────────────────

/// Crates the forge never lists in its generated `Cargo.toml`, so any
/// `use` of them produces `E0432` / `E0433`. Rust LLMs sometimes
/// emit `use log::info;` or `use env_logger::Builder;` out of
/// training-data habit.
const FORBIDDEN_CRATES: &[&str] = &["log", "env_logger", "pretty_env_logger"];

/// Remove `use CRATE::…;` and `extern crate CRATE;` lines for crates
/// the generator never declares in `Cargo.toml`.
pub fn strip_forbidden_crate_imports(content: &str) -> String {
    // One regex per crate, keeps the pattern readable.
    let mut out = content.to_string();
    for krate in FORBIDDEN_CRATES {
        let esc = regex::escape(krate);
        // `use CRATE::…;` or `use CRATE;`
        let use_re = Regex::new(&format!(
            r"(?m)^[ \t]*use\s+{}(?:::[^;]*)?;\s*$\n?",
            esc,
        ));
        if let Ok(r) = use_re {
            out = r.replace_all(&out, "").into_owned();
        }
        // `extern crate CRATE;`
        let ext_re = Regex::new(&format!(
            r"(?m)^[ \t]*extern\s+crate\s+{}\s*;\s*$\n?",
            esc,
        ));
        if let Ok(r) = ext_re {
            out = r.replace_all(&out, "").into_owned();
        }
        // Macro-style invocations like `log::info!(…)` — rewrite to
        // the equivalent `tracing::` form so the surrounding code
        // still compiles.
        if *krate == "log" {
            let macro_re = Regex::new(r"\blog::(trace|debug|info|warn|error)!");
            if let Ok(r) = macro_re {
                out = r.replace_all(&out, "tracing::$1!").into_owned();
            }
        }
    }
    out
}

// ─── Pipeline ────────────────────────────────────────────────────────────────

/// Apply all three sanitizer passes in the canonical order. The input
/// is returned unchanged if no pass finds anything to rewrite.
pub fn sanitize_rust_file(rel_path: &str, content: &str) -> String {
    let s1 = strip_wrong_mod_declarations(rel_path, content);
    let s2 = inject_missing_async(&s1);
    strip_forbidden_crate_imports(&s2)
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    // ── Pass 1 ────────────────────────────────────────────────────────────────

    #[test]
    fn strips_top_level_mod_in_leaf_file() {
        let src = "\
mod api;
mod auth;
pub mod config;

pub async fn get_user() -> Result<(), AppError> { todo!() }
";
        let out = strip_wrong_mod_declarations("backend/src/database/user_queries.rs", src);
        assert!(!out.contains("mod api;"));
        assert!(!out.contains("mod auth;"));
        assert!(!out.contains("pub mod config;"));
        assert!(out.contains("pub async fn get_user"));
    }

    #[test]
    fn preserves_mod_in_main_rs() {
        let src = "mod api;\nmod auth;\n";
        let out = strip_wrong_mod_declarations("backend/src/main.rs", src);
        assert_eq!(out, src);
    }

    #[test]
    fn preserves_mod_in_lib_rs() {
        let src = "pub mod api;\n";
        let out = strip_wrong_mod_declarations("backend/src/lib.rs", src);
        assert_eq!(out, src);
    }

    #[test]
    fn preserves_mod_in_mod_rs() {
        // mod.rs legitimately declares its own submodules.
        let src = "pub mod handlers;\npub mod types;\n";
        let out = strip_wrong_mod_declarations("backend/src/api/mod.rs", src);
        assert_eq!(out, src);
    }

    #[test]
    fn preserves_inline_mod_block() {
        let src = "\
pub mod inline {
    pub fn helper() {}
}
pub fn main_fn() {}
";
        let out = strip_wrong_mod_declarations("backend/src/services/user.rs", src);
        assert!(out.contains("pub mod inline {"));
        assert!(out.contains("pub fn helper() {}"));
    }

    #[test]
    fn preserves_use_statements() {
        // `use crate::api::*;` must NOT be stripped — only `mod X;` is.
        let src = "use crate::api::handlers;\npub fn f() {}\n";
        let out = strip_wrong_mod_declarations("backend/src/services/user.rs", src);
        assert!(out.contains("use crate::api::handlers;"));
    }

    // ── Pass 2 ────────────────────────────────────────────────────────────────

    #[test]
    fn injects_async_when_body_uses_await() {
        let src = "\
pub fn load(pool: &PgPool) -> Result<User, AppError> {
    let row = sqlx::query_as::<_, User>(\"SELECT * FROM users\")
        .fetch_one(pool)
        .await?;
    Ok(row)
}
";
        let out = inject_missing_async(src);
        assert!(out.contains("pub async fn load"));
        assert!(!out.contains("pub fn load"));
    }

    #[test]
    fn leaves_already_async_fn_alone() {
        let src = "pub async fn load() -> Result<(), ()> { do_thing().await; Ok(()) }\n";
        let out = inject_missing_async(src);
        assert_eq!(
            out.matches("async").count(),
            1,
            "only the existing `async` is present"
        );
    }

    #[test]
    fn does_not_inject_for_sync_fn() {
        let src = "pub fn add(a: i32, b: i32) -> i32 { a + b }\n";
        let out = inject_missing_async(src);
        assert_eq!(out, src);
    }

    #[test]
    fn injects_for_private_fn_too() {
        let src = "fn helper() { other_async().await; }\n";
        let out = inject_missing_async(src);
        assert!(out.contains("async fn helper"));
    }

    #[test]
    fn preserves_visibility() {
        let src = "pub(crate) fn f() -> () { x().await }\n";
        let out = inject_missing_async(src);
        assert!(out.contains("pub(crate) async fn f"));
    }

    // ── Pass 3 ────────────────────────────────────────────────────────────────

    #[test]
    fn strips_env_logger_import() {
        let src = "use env_logger::Builder;\n\npub fn main() {}\n";
        let out = strip_forbidden_crate_imports(src);
        assert!(!out.contains("env_logger"));
        assert!(out.contains("pub fn main"));
    }

    #[test]
    fn strips_log_and_rewrites_macros_to_tracing() {
        let src = "use log::info;\n\npub fn f() { log::info!(\"hi\"); }\n";
        let out = strip_forbidden_crate_imports(src);
        assert!(!out.contains("use log::info;"));
        assert!(out.contains("tracing::info!(\"hi\")"));
    }

    #[test]
    fn strips_extern_crate_form() {
        let src = "extern crate env_logger;\npub fn main() {}\n";
        let out = strip_forbidden_crate_imports(src);
        assert!(!out.contains("extern crate env_logger"));
    }

    #[test]
    fn preserves_unrelated_imports() {
        let src = "use sqlx::PgPool;\nuse crate::errors::AppError;\n";
        let out = strip_forbidden_crate_imports(src);
        assert_eq!(out, src);
    }

    // ── Pipeline ──────────────────────────────────────────────────────────────

    #[test]
    fn full_pipeline_cleans_all_three_classes() {
        let src = "\
mod api;
mod auth;

use env_logger::Builder;

pub fn reload(pool: &PgPool) -> Result<(), AppError> {
    let r = sqlx::query(\"SELECT 1\").fetch_one(pool).await?;
    log::info!(\"reloaded\");
    Ok(())
}
";
        let out = sanitize_rust_file("backend/src/database/user_queries.rs", src);
        assert!(!out.contains("mod api;"));
        assert!(!out.contains("mod auth;"));
        assert!(!out.contains("env_logger"));
        assert!(out.contains("pub async fn reload"));
        assert!(out.contains("tracing::info!"));
    }
}

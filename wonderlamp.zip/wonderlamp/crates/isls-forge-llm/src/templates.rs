// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! G1 — Code-Template-Registry: persistierte Code-Vorlagen aus Konsens-Resonites.
//!
//! Ein [`CodeTemplate`] ist ein parametrisierbares Rust-Code-Fragment das aus
//! Konsens-Resonites kristallisiert wurde. Die [`TemplateRegistry`] verwaltet
//! alle Templates und persistiert sie in `~/.isls/templates/{Class}.json`.
//!
//! # Priorität
//! Builtin-Generatoren (structural.rs) > Templates > Oracle
//!
//! # Constraints
//! - Deterministisch: gleicher Input → gleicher Output, kein LLM
//! - Monoton: Template-Qualität wird nur besser, nie schlechter
//! - Builtin-Templates haben sofort Qualität 1.0

use std::collections::HashMap;
use std::path::PathBuf;

use serde::{Deserialize, Serialize};

use isls_norms::spectroscopy::{Resonite, ResoniteClass};

// ─── FnPattern ───────────────────────────────────────────────────────────────

/// Erkanntes Funktions-Pattern aus Konsens-Resonites.
///
/// Jedes Pattern hat einen zugehörigen Code-Generator in `template_code.rs`.
#[derive(Clone, Debug, Serialize, Deserialize, PartialEq, Eq)]
pub enum FnPattern {
    // WebSocket
    WsConnect,
    WsOnMessage,
    WsBroadcast,
    WsDisconnect,
    // Caching
    CacheGet,
    CacheSet,
    CacheInvalidate,
    CacheTtl,
    // EventBus
    EventEmit,
    EventSubscribe,
    EventUnsubscribe,
    // ConnectionPool
    PoolNew,
    PoolGet,
    PoolRelease,
    PoolStats,
    // RateLimiting
    RateCheck,
    RateLimiterNew,
    // HealthCheck
    HealthCheck,
    Readiness,
    Liveness,
    // Scheduling
    ScheduleJob,
    CronParse,
    // MessageQueue
    Enqueue,
    Dequeue,
    Ack,
    Nack,
    // CircuitBreaker
    CbCall,
    CbTrip,
    CbReset,
    CbHalfOpen,
    // RetryPattern
    Retry,
    WithBackoff,
    // Search
    SearchQuery,
    IndexDoc,
    // FileUpload
    Upload,
    Download,
    StoreFile,
    // Metrics
    Counter,
    Histogram,
    Gauge,
    // Notification
    SendNotification,
    SendEmail,
    // Fallback — kompiliert, paniced zur Laufzeit
    Generic(String),
}

impl FnPattern {
    /// Erkennt das Pattern aus Funktionsname und Klasse.
    pub fn from_name(name: &str, class: &str) -> Self {
        let n = name.to_lowercase();
        match class {
            "WebSocket" | "RealtimeWebSocket" => {
                if n.contains("disconnect") || n.contains("close") || n.contains("leave") {
                    FnPattern::WsDisconnect
                } else if n.contains("connect") || n.contains("upgrade") {
                    FnPattern::WsConnect
                } else if n.contains("message") || n.contains("on_message") || n.contains("recv") {
                    FnPattern::WsOnMessage
                } else if n.contains("broadcast") || n.contains("send") {
                    FnPattern::WsBroadcast
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "Caching" => {
                if n.contains("get") || n.contains("from_cache") || n.contains("fetch") {
                    FnPattern::CacheGet
                } else if n.contains("set") || n.contains("to_cache") || n.contains("store") || n.contains("put") {
                    FnPattern::CacheSet
                } else if n.contains("invalidate") || n.contains("delete") || n.contains("evict") || n.contains("remove") {
                    FnPattern::CacheInvalidate
                } else if n.contains("ttl") || n.contains("expire") {
                    FnPattern::CacheTtl
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "EventBus" => {
                if n.contains("emit") || n.contains("publish") || n.contains("fire") || n.contains("dispatch") {
                    FnPattern::EventEmit
                } else if n.contains("subscribe") || n.contains("listen") || n.contains("on") {
                    FnPattern::EventSubscribe
                } else if n.contains("unsubscribe") || n.contains("off") || n.contains("detach") {
                    FnPattern::EventUnsubscribe
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "ConnectionPool" => {
                if n.contains("new") || n.contains("create") || n.contains("init") || n.contains("build") {
                    FnPattern::PoolNew
                } else if n.contains("get") || n.contains("acquire") || n.contains("checkout") {
                    FnPattern::PoolGet
                } else if n.contains("release") || n.contains("return") || n.contains("put_back") {
                    FnPattern::PoolRelease
                } else if n.contains("stats") || n.contains("status") || n.contains("info") {
                    FnPattern::PoolStats
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "RateLimiting" => {
                if n.contains("check") || n.contains("allow") || n.contains("limit") {
                    FnPattern::RateCheck
                } else if n.contains("new") || n.contains("create") || n.contains("build") {
                    FnPattern::RateLimiterNew
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "HealthCheck" => {
                if n.contains("health") {
                    FnPattern::HealthCheck
                } else if n.contains("ready") || n.contains("readiness") {
                    FnPattern::Readiness
                } else if n.contains("live") || n.contains("liveness") || n.contains("alive") {
                    FnPattern::Liveness
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "Scheduling" => {
                if n.contains("schedule") || n.contains("job") || n.contains("run_at") {
                    FnPattern::ScheduleJob
                } else if n.contains("cron") || n.contains("parse") {
                    FnPattern::CronParse
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "MessageQueue" => {
                if n.contains("enqueue") || n.contains("push") || n.contains("produce") || n.contains("send") {
                    FnPattern::Enqueue
                } else if n.contains("dequeue") || n.contains("pop") || n.contains("consume") || n.contains("recv") {
                    FnPattern::Dequeue
                } else if n.contains("ack") && !n.contains("nack") {
                    FnPattern::Ack
                } else if n.contains("nack") || n.contains("reject") {
                    FnPattern::Nack
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "CircuitBreaker" => {
                if n.contains("call") || n.contains("execute") || n.contains("run") {
                    FnPattern::CbCall
                } else if n.contains("trip") || n.contains("open") {
                    FnPattern::CbTrip
                } else if n.contains("reset") || n.contains("close") {
                    FnPattern::CbReset
                } else if n.contains("half") {
                    FnPattern::CbHalfOpen
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "RetryPattern" => {
                if n.contains("retry") || n.contains("attempt") {
                    FnPattern::Retry
                } else if n.contains("backoff") || n.contains("exponential") {
                    FnPattern::WithBackoff
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "Search" => {
                if n.contains("search") || n.contains("query") || n.contains("find") {
                    FnPattern::SearchQuery
                } else if n.contains("index") || n.contains("insert") || n.contains("add_doc") {
                    FnPattern::IndexDoc
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "FileUpload" => {
                if n.contains("upload") || n.contains("multipart") {
                    FnPattern::Upload
                } else if n.contains("download") || n.contains("stream") {
                    FnPattern::Download
                } else if n.contains("store") || n.contains("save") || n.contains("write") {
                    FnPattern::StoreFile
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "Metrics" => {
                if n.contains("counter") || n.contains("increment") || n.contains("count") {
                    FnPattern::Counter
                } else if n.contains("histogram") || n.contains("observe") || n.contains("record") {
                    FnPattern::Histogram
                } else if n.contains("gauge") || n.contains("set_gauge") {
                    FnPattern::Gauge
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            "Notification" => {
                if n.contains("notification") || n.contains("notify") || n.contains("push") {
                    FnPattern::SendNotification
                } else if n.contains("email") || n.contains("mail") {
                    FnPattern::SendEmail
                } else {
                    FnPattern::Generic(name.to_string())
                }
            }
            _ => FnPattern::Generic(name.to_string()),
        }
    }

    /// Name der erzeugten Funktion.
    pub fn function_name(&self) -> &str {
        match self {
            FnPattern::WsConnect => "ws_connect",
            FnPattern::WsOnMessage => "handle_message",
            FnPattern::WsBroadcast => "broadcast",
            FnPattern::WsDisconnect => "ws_disconnect",
            FnPattern::CacheGet => "cache_get",
            FnPattern::CacheSet => "cache_set",
            FnPattern::CacheInvalidate => "cache_invalidate",
            FnPattern::CacheTtl => "cache_ttl",
            FnPattern::EventEmit => "emit_event",
            FnPattern::EventSubscribe => "subscribe",
            FnPattern::EventUnsubscribe => "unsubscribe",
            FnPattern::PoolNew => "new_pool",
            FnPattern::PoolGet => "get_connection",
            FnPattern::PoolRelease => "release_connection",
            FnPattern::PoolStats => "pool_stats",
            FnPattern::RateCheck => "check_rate_limit",
            FnPattern::RateLimiterNew => "rate_limiter_new",
            FnPattern::HealthCheck => "health_check",
            FnPattern::Readiness => "readiness",
            FnPattern::Liveness => "liveness",
            FnPattern::ScheduleJob => "schedule_job",
            FnPattern::CronParse => "cron_parse",
            FnPattern::Enqueue => "enqueue",
            FnPattern::Dequeue => "dequeue",
            FnPattern::Ack => "ack",
            FnPattern::Nack => "nack",
            FnPattern::CbCall => "cb_call",
            FnPattern::CbTrip => "cb_trip",
            FnPattern::CbReset => "cb_reset",
            FnPattern::CbHalfOpen => "cb_half_open",
            FnPattern::Retry => "retry",
            FnPattern::WithBackoff => "with_backoff",
            FnPattern::SearchQuery => "search_query",
            FnPattern::IndexDoc => "index_doc",
            FnPattern::Upload => "upload",
            FnPattern::Download => "download",
            FnPattern::StoreFile => "store_file",
            FnPattern::Counter => "increment_counter",
            FnPattern::Histogram => "observe_histogram",
            FnPattern::Gauge => "set_gauge",
            FnPattern::SendNotification => "send_notification",
            FnPattern::SendEmail => "send_email",
            FnPattern::Generic(name) => name.as_str(),
        }
    }
}

// ─── FunctionSkeleton ─────────────────────────────────────────────────────────

/// Parametrisierbares Funktions-Skeleton aus Konsens-Resonites.
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct FunctionSkeleton {
    /// Originalname aus dem Konsens-Resonite.
    pub original_name: String,
    /// Erkanntes Pattern.
    pub pattern: FnPattern,
    /// Anzahl der Parameter (Arity).
    pub arity: usize,
}

// ─── CodeTemplate ─────────────────────────────────────────────────────────────

/// Ein parametrisierbares Rust-Code-Fragment kristallisiert aus Konsens-Resonites.
///
/// T = (Dateiname-Pattern, Skeleton, Parameter, Imports)
#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct CodeTemplate {
    /// Semantische Klasse: "WebSocket", "Caching", etc.
    pub class: String,
    /// Zieldateiname: "websocket.rs", "cache.rs", etc.
    pub filename: String,
    /// Benötigte use-Statements.
    pub imports: Vec<String>,
    /// Funktions-Skelette.
    pub functions: Vec<FunctionSkeleton>,
    /// Template-Qualität Q(T) ∈ [0.0, 1.0].
    /// Monoton — wird nur besser, nie schlechter.
    pub quality: f64,
    /// Fertiger materialisierter Template-Code.
    pub materialized_code: String,
    /// Anzahl der Observations aus denen das Template kristallisiert wurde.
    pub observation_count: usize,
    /// ISO-Timestamp der letzten Aktualisierung.
    pub last_updated: String,
}

impl CodeTemplate {
    /// Abhängigkeiten dieses Templates (für HDAG-Edges).
    pub fn dependencies(&self) -> Vec<String> {
        vec!["models".into()]
    }
}

// ─── TemplateRegistry ─────────────────────────────────────────────────────────

/// Verwaltet alle Code-Templates und persistiert sie in `~/.isls/templates/`.
///
/// Priorität im Generator: Builtin > Template > Oracle.
pub struct TemplateRegistry {
    templates: HashMap<String, CodeTemplate>,
}

impl TemplateRegistry {
    /// Templates-Verzeichnis.
    fn templates_dir() -> PathBuf {
        let home = std::env::var("HOME").unwrap_or_else(|_| "/tmp".into());
        PathBuf::from(home).join(".isls").join("templates")
    }

    /// Lade alle Templates aus `~/.isls/templates/`.
    pub fn load() -> Self {
        let dir = Self::templates_dir();
        let mut templates = HashMap::new();

        if let Ok(entries) = std::fs::read_dir(&dir) {
            for entry in entries.flatten() {
                let path = entry.path();
                if path.extension().map_or(false, |e| e == "json") {
                    if let Ok(content) = std::fs::read_to_string(&path) {
                        if let Ok(t) = serde_json::from_str::<CodeTemplate>(&content) {
                            templates.insert(t.class.clone(), t);
                        }
                    }
                }
            }
        }

        TemplateRegistry { templates }
    }

    /// Prüft ob ein Template für die Klasse existiert.
    pub fn has(&self, class: &str) -> bool {
        self.templates.contains_key(class)
    }

    /// Findet das Template für eine Klasse.
    pub fn find_for_class(&self, class: &str) -> Option<&CodeTemplate> {
        self.templates.get(class)
    }

    /// Alle bekannten Templates (sortiert nach Klasse).
    pub fn all_templates(&self) -> Vec<&CodeTemplate> {
        let mut v: Vec<&CodeTemplate> = self.templates.values().collect();
        v.sort_by(|a, b| a.class.cmp(&b.class));
        v
    }

    /// Speichert ein Template in `~/.isls/templates/{Class}.json`.
    ///
    /// Monotonie: Ein Template wird nie durch ein schlechteres ersetzt.
    pub fn save_template(&mut self, template: CodeTemplate) {
        // Monotonie-Prüfung: nur speichern wenn Qualität gleich oder besser
        if let Some(existing) = self.templates.get(&template.class) {
            if template.quality < existing.quality {
                tracing::debug!(
                    class = %template.class,
                    old_q = existing.quality,
                    new_q = template.quality,
                    "TemplateRegistry: skipping update (quality regression)"
                );
                return;
            }
        }

        let dir = Self::templates_dir();
        if let Err(e) = std::fs::create_dir_all(&dir) {
            tracing::warn!("TemplateRegistry: cannot create dir: {}", e);
        }

        let path = dir.join(format!("{}.json", template.class));
        if let Ok(json) = serde_json::to_string_pretty(&template) {
            if let Err(e) = std::fs::write(&path, json) {
                tracing::warn!("TemplateRegistry: cannot write {}: {}", path.display(), e);
            }
        }

        self.templates.insert(template.class.clone(), template);
    }

    /// Anzahl der geladenen Templates.
    pub fn len(&self) -> usize {
        self.templates.len()
    }

    /// True wenn keine Templates vorhanden.
    pub fn is_empty(&self) -> bool {
        self.templates.is_empty()
    }
}

// ─── Dateiname aus Klasse ─────────────────────────────────────────────────────

/// Zieldateiname für eine Template-Klasse.
pub fn template_filename(class: &str) -> String {
    let snake = class
        .chars()
        .enumerate()
        .map(|(i, c)| {
            if c.is_uppercase() && i > 0 {
                format!("_{}", c.to_lowercase())
            } else {
                c.to_lowercase().to_string()
            }
        })
        .collect::<String>();
    format!("backend/src/{}.rs", snake)
}

// ─── Template-Qualität berechnen ──────────────────────────────────────────────

/// Berechnet Q(T) = |Konsens-Fns| / |Total-Fns| × |Domänen| / |Min-Domänen|
pub fn compute_quality(consensus_count: usize, total_count: usize, domain_count: usize) -> f64 {
    if total_count == 0 {
        return 0.0;
    }
    let fn_ratio = consensus_count as f64 / total_count as f64;
    let min_domains = 3usize;
    let domain_ratio = (domain_count as f64 / min_domains as f64).min(1.0);
    (fn_ratio * domain_ratio).min(1.0)
}

// ─── Skeleton aus Konsens-Resonites bauen ─────────────────────────────────────

/// Baut ein CodeTemplate aus Konsens-Resonites (Kristallisationsprozess).
pub fn build_skeleton(class: &str, consensus: &[Resonite]) -> CodeTemplate {
    let mut imports = Vec::new();
    let mut functions = Vec::new();

    for resonite in consensus {
        match resonite {
            Resonite::Fn { name, arity } => {
                let pattern = FnPattern::from_name(name, class);
                functions.push(FunctionSkeleton {
                    original_name: name.clone(),
                    pattern,
                    arity: *arity,
                });
            }
            Resonite::Import { path } => {
                imports.push(path.clone());
            }
            _ => {}
        }
    }

    // Dedupliziere Patterns (behalte erstes Vorkommen)
    let mut seen_patterns = std::collections::HashSet::new();
    functions.retain(|f| {
        let key = format!("{:?}", f.pattern);
        seen_patterns.insert(key)
    });

    let quality = compute_quality(functions.len(), consensus.len().max(1), 3);
    let materialized_code = materialize_template_code(class, &functions, &imports);

    CodeTemplate {
        class: class.to_string(),
        filename: template_filename(class),
        imports,
        functions,
        quality,
        materialized_code,
        observation_count: consensus.len(),
        last_updated: chrono::Utc::now().to_rfc3339(),
    }
}

// ─── Builtin-Template-Erstellung ─────────────────────────────────────────────

/// Erstellt ein hardcodiertes Builtin-Template für eine der 14 Hauptklassen.
///
/// Builtin-Templates haben sofort Qualität 1.0 weil die Patterns universell bekannt sind.
pub fn build_builtin_template(class: &str, patterns: &[FnPattern]) -> CodeTemplate {
    let functions: Vec<FunctionSkeleton> = patterns
        .iter()
        .map(|p| FunctionSkeleton {
            original_name: p.function_name().to_string(),
            pattern: p.clone(),
            arity: 1,
        })
        .collect();

    let imports = builtin_imports(class);
    let materialized_code = materialize_template_code(class, &functions, &imports);

    CodeTemplate {
        class: class.to_string(),
        filename: template_filename(class),
        imports,
        functions,
        quality: 1.0,
        materialized_code,
        observation_count: 0,
        last_updated: chrono::Utc::now().to_rfc3339(),
    }
}

/// Standard-Imports für jede Klasse.
fn builtin_imports(class: &str) -> Vec<String> {
    match class {
        "WebSocket" | "RealtimeWebSocket" => vec![
            "axum::extract::ws::{WebSocket, WebSocketUpgrade, Message}".into(),
            "axum::extract::State".into(),
            "axum::response::IntoResponse".into(),
        ],
        "Caching" => vec![
            "serde::{Serialize, Deserialize}".into(),
            "serde_json".into(),
        ],
        "EventBus" => vec![
            "tokio::sync::broadcast".into(),
            "serde::{Serialize, Deserialize}".into(),
            "uuid::Uuid".into(),
        ],
        "ConnectionPool" => vec![
            "std::sync::{Arc, Mutex}".into(),
            "std::collections::VecDeque".into(),
        ],
        "RateLimiting" => vec![
            "std::collections::HashMap".into(),
            "std::time::{Duration, Instant}".into(),
            "std::sync::{Arc, Mutex}".into(),
        ],
        "HealthCheck" => vec![
            "axum::http::StatusCode".into(),
            "axum::response::Json".into(),
            "serde_json::json".into(),
        ],
        "Scheduling" => vec![
            "tokio::time::{interval, Duration}".into(),
            "std::sync::{Arc, Mutex}".into(),
        ],
        "MessageQueue" => vec![
            "std::collections::VecDeque".into(),
            "std::sync::{Arc, Mutex}".into(),
            "serde::{Serialize, Deserialize}".into(),
        ],
        "CircuitBreaker" => vec![
            "std::sync::{Arc, Mutex}".into(),
            "std::time::Instant".into(),
        ],
        "RetryPattern" => vec![
            "tokio::time::{sleep, Duration}".into(),
        ],
        "Search" => vec![
            "serde::{Serialize, Deserialize}".into(),
        ],
        "FileUpload" => vec![
            "std::path::PathBuf".into(),
            "tokio::fs".into(),
        ],
        "Metrics" => vec![
            "std::collections::HashMap".into(),
            "std::sync::{Arc, Mutex}".into(),
            "std::sync::atomic::{AtomicU64, Ordering}".into(),
        ],
        "Notification" => vec![
            "serde::{Serialize, Deserialize}".into(),
        ],
        _ => vec![],
    }
}

/// Materialisiert den vollständigen Template-Code aus Funktions-Skeletten.
fn materialize_template_code(class: &str, functions: &[FunctionSkeleton], imports: &[String]) -> String {
    let mut code = String::new();

    // Header-Kommentar
    code.push_str(&format!(
        "// G1 Auto-generated template — class: {} — deterministic, no LLM\n",
        class
    ));
    code.push_str("// Template-Qualität: aus Konsens-Resonites kristallisiert\n\n");

    // Imports
    for import in imports {
        code.push_str(&format!("use {};\n", import));
    }
    if !imports.is_empty() {
        code.push('\n');
    }

    // Funktionen
    for fn_skel in functions {
        let fn_code = crate::template_code::materialize_function(fn_skel, class);
        code.push_str(&fn_code);
        code.push_str("\n\n");
    }

    code
}

// ─── Materialize Template mit Entity-Substitution ────────────────────────────

/// Materialisiert ein Template mit konkreten Entity-Namen aus dem Forge-Kontext.
pub fn materialize_template(template: &CodeTemplate, entities: &[crate::EntityDef], app_name: &str) -> String {
    let mut code = template.materialized_code.clone();

    // Entity-Substitution: ersetze generische Platzhalter mit dem ersten Entity-Namen
    if let Some(entity) = entities.first() {
        let snake = &entity.snake_name;
        let pascal = &entity.name;
        code = code.replace("{entity}", snake);
        code = code.replace("{Entity}", pascal);
        code = code.replace("{app}", app_name);
    }

    // Falls noch {entity}-Platzhalter übrig, ersetze mit "item"
    code = code.replace("{entity}", "item");
    code = code.replace("{Entity}", "Item");
    code = code.replace("{app}", app_name);

    code
}

// ─── Builtin-Templates sicherstellen ──────────────────────────────────────────

/// Erstellt hardcodierte Builtin-Templates für die 14 Hauptklassen,
/// falls sie noch nicht existieren.
///
/// Wird beim Server-Start aufgerufen.
pub fn ensure_builtin_templates(registry: &mut TemplateRegistry) {
    let builtins: &[(&str, &[FnPattern])] = &[
        ("WebSocket", &[
            FnPattern::WsConnect,
            FnPattern::WsOnMessage,
            FnPattern::WsBroadcast,
            FnPattern::WsDisconnect,
        ]),
        ("Caching", &[
            FnPattern::CacheGet,
            FnPattern::CacheSet,
            FnPattern::CacheInvalidate,
            FnPattern::CacheTtl,
        ]),
        ("EventBus", &[
            FnPattern::EventEmit,
            FnPattern::EventSubscribe,
            FnPattern::EventUnsubscribe,
        ]),
        ("ConnectionPool", &[
            FnPattern::PoolNew,
            FnPattern::PoolGet,
            FnPattern::PoolRelease,
            FnPattern::PoolStats,
        ]),
        ("RateLimiting", &[
            FnPattern::RateCheck,
            FnPattern::RateLimiterNew,
        ]),
        ("HealthCheck", &[
            FnPattern::HealthCheck,
            FnPattern::Readiness,
            FnPattern::Liveness,
        ]),
        ("Scheduling", &[
            FnPattern::ScheduleJob,
            FnPattern::CronParse,
        ]),
        ("MessageQueue", &[
            FnPattern::Enqueue,
            FnPattern::Dequeue,
            FnPattern::Ack,
            FnPattern::Nack,
        ]),
        ("CircuitBreaker", &[
            FnPattern::CbCall,
            FnPattern::CbTrip,
            FnPattern::CbReset,
            FnPattern::CbHalfOpen,
        ]),
        ("RetryPattern", &[
            FnPattern::Retry,
            FnPattern::WithBackoff,
        ]),
        ("Search", &[
            FnPattern::SearchQuery,
            FnPattern::IndexDoc,
        ]),
        ("FileUpload", &[
            FnPattern::Upload,
            FnPattern::Download,
            FnPattern::StoreFile,
        ]),
        ("Metrics", &[
            FnPattern::Counter,
            FnPattern::Histogram,
            FnPattern::Gauge,
        ]),
        ("Notification", &[
            FnPattern::SendNotification,
            FnPattern::SendEmail,
        ]),
    ];

    let mut created = 0usize;
    for (class, patterns) in builtins {
        if !registry.has(class) {
            let template = build_builtin_template(class, patterns);
            eprintln!("[TEMPLATE] Builtin template created: {} ({} functions)", class, template.functions.len());
            registry.save_template(template);
            created += 1;
        }
    }

    if created > 0 {
        eprintln!("[TEMPLATE] {} builtin templates created", created);
    }
}

/// Gibt die semantische Klasse für einen ResoniteClass-Wert zurück (falls Template vorhanden).
pub fn class_name_for(class: &ResoniteClass) -> String {
    match class {
        ResoniteClass::RealtimeWebSocket => "WebSocket".to_string(),
        ResoniteClass::Caching => "Caching".to_string(),
        ResoniteClass::EventBus => "EventBus".to_string(),
        ResoniteClass::ConnectionPool => "ConnectionPool".to_string(),
        ResoniteClass::RateLimiting => "RateLimiting".to_string(),
        ResoniteClass::HealthCheck => "HealthCheck".to_string(),
        ResoniteClass::Scheduling => "Scheduling".to_string(),
        ResoniteClass::MessageQueue => "MessageQueue".to_string(),
        ResoniteClass::CircuitBreaker => "CircuitBreaker".to_string(),
        ResoniteClass::RetryPattern => "RetryPattern".to_string(),
        ResoniteClass::Search => "Search".to_string(),
        ResoniteClass::FileUpload => "FileUpload".to_string(),
        ResoniteClass::Metrics => "Metrics".to_string(),
        ResoniteClass::Notification => "Notification".to_string(),
        _ => class.as_str().to_string(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn pattern_recognition_websocket() {
        assert_eq!(FnPattern::from_name("connect", "WebSocket"), FnPattern::WsConnect);
        assert_eq!(FnPattern::from_name("on_message", "WebSocket"), FnPattern::WsOnMessage);
        assert_eq!(FnPattern::from_name("broadcast", "WebSocket"), FnPattern::WsBroadcast);
        assert_eq!(FnPattern::from_name("disconnect", "WebSocket"), FnPattern::WsDisconnect);
    }

    #[test]
    fn pattern_recognition_caching() {
        assert_eq!(FnPattern::from_name("get_from_cache", "Caching"), FnPattern::CacheGet);
        assert_eq!(FnPattern::from_name("set_cache", "Caching"), FnPattern::CacheSet);
        assert_eq!(FnPattern::from_name("invalidate", "Caching"), FnPattern::CacheInvalidate);
    }

    #[test]
    fn template_filename_correct() {
        assert_eq!(template_filename("WebSocket"), "backend/src/web_socket.rs");
        assert_eq!(template_filename("Caching"), "backend/src/caching.rs");
        assert_eq!(template_filename("EventBus"), "backend/src/event_bus.rs");
        assert_eq!(template_filename("MessageQueue"), "backend/src/message_queue.rs");
    }

    #[test]
    fn builtin_template_has_quality_one() {
        let t = build_builtin_template("WebSocket", &[
            FnPattern::WsConnect,
            FnPattern::WsBroadcast,
        ]);
        assert_eq!(t.quality, 1.0);
        assert_eq!(t.class, "WebSocket");
        assert!(!t.materialized_code.is_empty());
    }

    #[test]
    fn quality_monotone() {
        let dir = tempfile::tempdir().unwrap();
        std::env::set_var("HOME", dir.path());
        let mut registry = TemplateRegistry::load();

        let t1 = build_builtin_template("Caching", &[FnPattern::CacheGet]);
        registry.save_template(t1);
        assert_eq!(registry.find_for_class("Caching").unwrap().quality, 1.0);

        // Template mit schlechterer Qualität darf nicht überschreiben
        let mut t2 = build_builtin_template("Caching", &[FnPattern::CacheGet]);
        t2.quality = 0.3;
        registry.save_template(t2);
        assert_eq!(registry.find_for_class("Caching").unwrap().quality, 1.0);
    }
}

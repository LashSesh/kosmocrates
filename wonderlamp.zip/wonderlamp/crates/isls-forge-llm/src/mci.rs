// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! E1: Mirror-Consistency-Index (MCI) — determinism measurement for the forge pipeline.
//!
//! The MCI quantifies how reproducible the forge output is across two independent runs
//! with identical inputs but fresh oracle state.
//!
//! - **MCI global**: 1 − (euclidean_distance(cm_a, cm_b) / 0.5).min(1.0)
//! - **MCI structural**: fraction of structurally-generated files that are bit-identical
//! - **MCI oracle**: fraction of oracle-generated files that are bit-identical
//!
//! Structural files (everything except `*_queries.rs` and `seed.sql`) MUST be
//! identical across runs. If `mci_structural < 1.0`, a `tracing::error!` is emitted.

use std::path::Path;

use serde::{Deserialize, Serialize};
use tracing;

use crate::{ForgePlan, LlmForge, Oracle};
use crate::codematrix::{compute_codematrix_from_code, Codematrix};

// ─── Types ────────────────────────────────────────────────────────────────────

/// How a file was generated in the forge pipeline.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub enum GenerationMode {
    /// Deterministically generated from norms/templates (must be identical across runs).
    Structural,
    /// LLM-generated oracle content (allowed to differ).
    Oracle,
}

/// Per-file diff information from an MCI run.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct FileDiff {
    pub filename: String,
    pub generation_mode: GenerationMode,
    pub identical: bool,
    pub diff_lines: usize,
    pub similarity: f64,
}

/// Full MCI measurement report.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct MciReport {
    /// 1 − (euclidean_distance(cm_a, cm_b) / 0.5).min(1.0)
    pub mci_global: f64,
    /// Fraction of structurally-generated files that are bit-identical.
    pub mci_structural: f64,
    /// Fraction of oracle-generated files that are bit-identical.
    pub mci_oracle: f64,
    pub file_diffs: Vec<FileDiff>,
    pub codematrix_a: [f64; 5],
    pub codematrix_b: [f64; 5],
    pub app_description: String,
    pub timestamp: String,
}

// ─── Classification ───────────────────────────────────────────────────────────

/// Classify a filename as Structural or Oracle.
///
/// `*_queries.rs` and `seed.sql` are Oracle (LLM-generated).
/// Everything else is Structural (norm/template-driven, must be identical).
pub fn classify_file_mode(filename: &str) -> GenerationMode {
    let name = std::path::Path::new(filename)
        .file_name()
        .and_then(|n| n.to_str())
        .unwrap_or(filename);
    if name.ends_with("_queries.rs") || name == "seed.sql" {
        GenerationMode::Oracle
    } else {
        GenerationMode::Structural
    }
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

/// Euclidean distance between two 5D codematrix vectors.
pub fn euclidean_distance(a: &[f64; 5], b: &[f64; 5]) -> f64 {
    a.iter()
        .zip(b.iter())
        .map(|(x, y)| (x - y).powi(2))
        .sum::<f64>()
        .sqrt()
}

/// Jaccard similarity on line sets (each line treated as a token).
pub fn jaccard_lines(a: &str, b: &str) -> f64 {
    use std::collections::HashSet;
    let set_a: HashSet<&str> = a.lines().filter(|l| !l.trim().is_empty()).collect();
    let set_b: HashSet<&str> = b.lines().filter(|l| !l.trim().is_empty()).collect();
    let intersection = set_a.intersection(&set_b).count();
    let union = set_a.union(&set_b).count();
    if union == 0 {
        1.0
    } else {
        intersection as f64 / union as f64
    }
}

/// Compute the 5D codematrix vector (R, F, T, S, E) for all Rust files in a directory.
fn codematrix_from_dir(dir: &Path) -> [f64; 5] {
    let mut matrices: Vec<Codematrix> = Vec::new();

    fn walk(dir: &Path, out: &mut Vec<Codematrix>) {
        let entries = match std::fs::read_dir(dir) {
            Ok(e) => e,
            Err(_) => return,
        };
        for entry in entries.flatten() {
            let path = entry.path();
            if path.is_dir() {
                walk(&path, out);
            } else if path.extension().map_or(false, |e| e == "rs") {
                if let Ok(content) = std::fs::read_to_string(&path) {
                    let path_str = path.to_string_lossy();
                    let cm = compute_codematrix_from_code(&content, &path_str, None);
                    out.push(cm);
                }
            }
        }
    }

    walk(dir, &mut matrices);

    if matrices.is_empty() {
        return [0.0; 5];
    }

    let avg = Codematrix::average(&matrices);
    [avg.r, avg.f, avg.t, avg.s, avg.e]
}

/// Count lines that differ between two strings (symmetric diff).
fn count_diff_lines(a: &str, b: &str) -> usize {
    use std::collections::HashSet;
    let set_a: HashSet<&str> = a.lines().collect();
    let set_b: HashSet<&str> = b.lines().collect();
    set_a.symmetric_difference(&set_b).count()
}

// ─── Core Computation ─────────────────────────────────────────────────────────

/// Compute the Mirror-Consistency-Index by forging the same plan twice.
///
/// # Parameters
/// - `plan` — The forge plan (app spec + norm IDs). Used for BOTH runs.
/// - `oracle_a` — Oracle for the first forge run.
/// - `oracle_b` — Oracle for the second (independent) forge run.
/// - `use_mock` — Whether we are in mock mode (affects LlmForge behaviour).
/// - `output_a` — Output directory for the first run (must not exist yet or be empty).
/// - `output_b` — Output directory for the second run.
///
/// # Errors
/// Returns an error string on IO or forge failures.
pub fn compute_mci(
    plan: ForgePlan,
    oracle_a: Box<dyn Oracle>,
    oracle_b: Box<dyn Oracle>,
    use_mock: bool,
    output_a: &Path,
    output_b: &Path,
) -> Result<MciReport, String> {
    let description = plan.spec.description.clone();
    let timestamp = chrono::Utc::now().to_rfc3339();

    // ── Forge A ───────────────────────────────────────────────────────
    tracing::info!("[MCI] Forge A → {:?}", output_a);
    std::fs::create_dir_all(output_a)
        .map_err(|e| format!("create output_a: {}", e))?;
    {
        let mut forge_a =
            LlmForge::new(oracle_a, plan.clone(), output_a.to_path_buf(), use_mock);
        forge_a
            .generate()
            .map_err(|e| format!("forge A failed: {}", e))?;
    }

    let cm_a = codematrix_from_dir(output_a);

    // ── Forge B ───────────────────────────────────────────────────────
    tracing::info!("[MCI] Forge B → {:?}", output_b);
    std::fs::create_dir_all(output_b)
        .map_err(|e| format!("create output_b: {}", e))?;
    {
        let mut forge_b =
            LlmForge::new(oracle_b, plan.clone(), output_b.to_path_buf(), use_mock);
        forge_b
            .generate()
            .map_err(|e| format!("forge B failed: {}", e))?;
    }

    let cm_b = codematrix_from_dir(output_b);

    // ── Global MCI ────────────────────────────────────────────────────
    let dist = euclidean_distance(&cm_a, &cm_b);
    let mci_global = 1.0 - (dist / 0.5).min(1.0);

    // ── File-level comparison ─────────────────────────────────────────
    let files_a = collect_relative_files(output_a);
    let files_b = collect_relative_files(output_b);

    let mut all_files: std::collections::BTreeSet<String> = Default::default();
    all_files.extend(files_a.keys().cloned());
    all_files.extend(files_b.keys().cloned());

    let mut file_diffs: Vec<FileDiff> = Vec::new();
    let mut structural_total = 0usize;
    let mut structural_identical = 0usize;
    let mut oracle_total = 0usize;
    let mut oracle_identical = 0usize;

    for filename in &all_files {
        let mode = classify_file_mode(filename);
        let content_a = files_a.get(filename).map(String::as_str).unwrap_or("");
        let content_b = files_b.get(filename).map(String::as_str).unwrap_or("");
        let identical = content_a == content_b;
        let diff_lines = if identical {
            0
        } else {
            count_diff_lines(content_a, content_b)
        };
        let similarity = jaccard_lines(content_a, content_b);

        match mode {
            GenerationMode::Structural => {
                structural_total += 1;
                if identical {
                    structural_identical += 1;
                }
            }
            GenerationMode::Oracle => {
                oracle_total += 1;
                if identical {
                    oracle_identical += 1;
                }
            }
        }

        file_diffs.push(FileDiff {
            filename: filename.clone(),
            generation_mode: mode,
            identical,
            diff_lines,
            similarity,
        });
    }

    let mci_structural = if structural_total == 0 {
        1.0
    } else {
        structural_identical as f64 / structural_total as f64
    };

    let mci_oracle = if oracle_total == 0 {
        1.0
    } else {
        oracle_identical as f64 / oracle_total as f64
    };

    // ── Determinism guard ─────────────────────────────────────────────
    if mci_structural < 1.0 {
        tracing::error!(
            "DETERMINISM BUG: structural files differ between runs! \
             mci_structural={:.4} ({}/{} identical)",
            mci_structural,
            structural_identical,
            structural_total
        );
    }

    tracing::info!(
        "[MCI] global={:.4}  structural={:.4}  oracle={:.4}",
        mci_global,
        mci_structural,
        mci_oracle
    );

    Ok(MciReport {
        mci_global,
        mci_structural,
        mci_oracle,
        file_diffs,
        codematrix_a: cm_a,
        codematrix_b: cm_b,
        app_description: description,
        timestamp,
    })
}

/// Walk a directory and collect `relative_path → content` for all text files.
fn collect_relative_files(root: &Path) -> std::collections::HashMap<String, String> {
    let mut map = std::collections::HashMap::new();
    collect_files_recursive(root, root, &mut map);
    map
}

fn collect_files_recursive(
    root: &Path,
    dir: &Path,
    out: &mut std::collections::HashMap<String, String>,
) {
    let entries = match std::fs::read_dir(dir) {
        Ok(e) => e,
        Err(_) => return,
    };
    for entry in entries.flatten() {
        let path = entry.path();
        if path.is_dir() {
            collect_files_recursive(root, &path, out);
        } else {
            if let Ok(content) = std::fs::read_to_string(&path) {
                if let Ok(rel) = path.strip_prefix(root) {
                    let key = rel.to_string_lossy().replace('\\', "/");
                    out.insert(key, content);
                }
            }
        }
    }
}

// ─── Tests ────────────────────────────────────────────────────────────────────

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_classify_file_mode() {
        assert_eq!(classify_file_mode("pet_queries.rs"), GenerationMode::Oracle);
        assert_eq!(classify_file_mode("seed.sql"), GenerationMode::Oracle);
        assert_eq!(classify_file_mode("models/pet.rs"), GenerationMode::Structural);
        assert_eq!(classify_file_mode("main.rs"), GenerationMode::Structural);
        assert_eq!(classify_file_mode("Cargo.toml"), GenerationMode::Structural);
    }

    #[test]
    fn test_euclidean_distance() {
        let a = [1.0, 0.0, 0.0, 0.0, 0.0];
        let b = [0.0, 0.0, 0.0, 0.0, 0.0];
        assert!((euclidean_distance(&a, &b) - 1.0).abs() < 1e-10);

        let same = [0.5, 0.5, 0.5, 0.5, 0.5];
        assert!(euclidean_distance(&same, &same) < 1e-10);
    }

    #[test]
    fn test_jaccard_lines() {
        let a = "foo\nbar\nbaz";
        let b = "foo\nbar\nqux";
        let j = jaccard_lines(a, b);
        // intersection = {foo, bar} = 2, union = {foo, bar, baz, qux} = 4
        assert!((j - 0.5).abs() < 1e-10);

        assert!((jaccard_lines("", "") - 1.0).abs() < 1e-10);
        assert!((jaccard_lines("x", "x") - 1.0).abs() < 1e-10);
    }

    #[test]
    fn test_compute_mci_mock() {
        use crate::oracle::MockOracle;
        use isls_hypercube::domain::DomainRegistry;

        let dir = std::env::temp_dir().join(format!(
            "isls-mci-test-{}",
            std::time::SystemTime::now()
                .duration_since(std::time::UNIX_EPOCH)
                .unwrap()
                .as_nanos()
        ));
        let out_a = dir.join("a");
        let out_b = dir.join("b");

        let plan = ForgePlan::warehouse_default("mci-test");
        let result = compute_mci(
            plan,
            Box::new(MockOracle),
            Box::new(MockOracle),
            true,
            &out_a,
            &out_b,
        );

        assert!(result.is_ok(), "MCI computation failed: {:?}", result.err());
        let report = result.unwrap();

        // Sanity checks
        assert!(report.mci_global >= 0.0 && report.mci_global <= 1.0);
        assert!(report.mci_structural >= 0.0 && report.mci_structural <= 1.0);
        assert!(report.mci_oracle >= 0.0 && report.mci_oracle <= 1.0);
        assert!(!report.file_diffs.is_empty(), "should have at least some file diffs");

        // Cleanup
        let _ = std::fs::remove_dir_all(&dir);
    }
}

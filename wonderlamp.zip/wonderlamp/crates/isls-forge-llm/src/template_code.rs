// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! G1 — Konkrete Code-Generatoren pro FnPattern.
//!
//! Für jeden [`FnPattern`] erzeugt `materialize_function()` idiomatischen
//! Rust-Code. Der Code ist nicht perfekt aber KORREKT — er kompiliert und
//! die Struktur stimmt. Entities werden als Parameter eingesetzt wo nötig.
//!
//! [`FnPattern::Generic`] erzeugt `unimplemented!()` — kompiliert aber
//! paniced zur Laufzeit (besser als falscher Code).

use crate::templates::{FnPattern, FunctionSkeleton};

/// Materialisiert eine Funktion aus ihrem Skeleton.
///
/// Gibt idiomatischen Rust-Code zurück der kompiliert.
/// Der `class` Parameter wird für Kontext-spezifische Varianten genutzt.
pub fn materialize_function(skeleton: &FunctionSkeleton, _class: &str) -> String {
    match &skeleton.pattern {
        FnPattern::WsConnect => r#"/// WebSocket-Verbindung upgraden und Socket-Loop starten.
pub async fn ws_connect(
    ws: axum::extract::ws::WebSocketUpgrade,
    axum::extract::State(state): axum::extract::State<AppState>,
) -> impl axum::response::IntoResponse {
    ws.on_upgrade(|socket| handle_socket(socket, state))
}

async fn handle_socket(
    mut socket: axum::extract::ws::WebSocket,
    state: AppState,
) {
    while let Some(Ok(msg)) = socket.recv().await {
        match msg {
            axum::extract::ws::Message::Text(text) => {
                handle_ws_message(&text, &state, &mut socket).await;
            }
            axum::extract::ws::Message::Close(_) => break,
            _ => {}
        }
    }
}

async fn handle_ws_message(
    _text: &str,
    _state: &AppState,
    _socket: &mut axum::extract::ws::WebSocket,
) {
    // TODO: implement message handling
}"#.to_string(),

        FnPattern::WsOnMessage => r#"/// WebSocket-Nachricht verarbeiten.
pub async fn handle_message(
    text: &str,
    state: &AppState,
) -> Result<String, Box<dyn std::error::Error + Send + Sync>> {
    // Parse incoming message
    let msg: serde_json::Value = serde_json::from_str(text)?;

    // Route by message type
    let response = match msg.get("type").and_then(|t| t.as_str()) {
        Some("ping") => serde_json::json!({ "type": "pong" }),
        Some(msg_type) => serde_json::json!({
            "type": "error",
            "message": format!("unknown message type: {}", msg_type)
        }),
        None => serde_json::json!({ "type": "error", "message": "missing type field" }),
    };

    Ok(response.to_string())
}"#.to_string(),

        FnPattern::WsBroadcast => r#"/// Nachricht an alle verbundenen WebSocket-Clients senden.
pub async fn broadcast(
    clients: &tokio::sync::RwLock<Vec<tokio::sync::mpsc::UnboundedSender<String>>>,
    message: &str,
) {
    let locked = clients.read().await;
    for tx in locked.iter() {
        let _ = tx.send(message.to_string());
    }
}

/// Nachricht an einen spezifischen Client senden.
pub async fn send_to_client(
    tx: &tokio::sync::mpsc::UnboundedSender<String>,
    message: serde_json::Value,
) {
    let _ = tx.send(message.to_string());
}"#.to_string(),

        FnPattern::WsDisconnect => r#"/// WebSocket-Verbindung sauber beenden.
pub async fn ws_disconnect(
    client_id: &str,
    clients: &tokio::sync::RwLock<std::collections::HashMap<String, tokio::sync::mpsc::UnboundedSender<String>>>,
) {
    let mut locked = clients.write().await;
    locked.remove(client_id);
    tracing::info!(client_id = %client_id, "WebSocket client disconnected");
}"#.to_string(),

        FnPattern::CacheGet => r#"/// Wert aus Cache lesen und deserialisieren.
pub async fn cache_get<T: serde::de::DeserializeOwned>(
    cache: &std::sync::Arc<tokio::sync::RwLock<std::collections::HashMap<String, String>>>,
    key: &str,
) -> Option<T> {
    let locked = cache.read().await;
    locked
        .get(key)
        .and_then(|data| serde_json::from_str(data).ok())
}"#.to_string(),

        FnPattern::CacheSet => r#"/// Wert serialisieren und mit TTL in Cache speichern.
pub async fn cache_set<T: serde::Serialize>(
    cache: &std::sync::Arc<tokio::sync::RwLock<std::collections::HashMap<String, String>>>,
    key: &str,
    value: &T,
    _ttl_seconds: u64,
) -> Result<(), serde_json::Error> {
    let data = serde_json::to_string(value)?;
    let mut locked = cache.write().await;
    locked.insert(key.to_string(), data);
    Ok(())
}"#.to_string(),

        FnPattern::CacheInvalidate => r#"/// Cache-Eintrag entfernen.
pub async fn cache_invalidate(
    cache: &std::sync::Arc<tokio::sync::RwLock<std::collections::HashMap<String, String>>>,
    key: &str,
) {
    let mut locked = cache.write().await;
    locked.remove(key);
}

/// Alle Cache-Einträge mit einem Prefix entfernen.
pub async fn cache_invalidate_prefix(
    cache: &std::sync::Arc<tokio::sync::RwLock<std::collections::HashMap<String, String>>>,
    prefix: &str,
) {
    let mut locked = cache.write().await;
    locked.retain(|k, _| !k.starts_with(prefix));
}"#.to_string(),

        FnPattern::CacheTtl => r#"/// TTL eines Cache-Eintrags abfragen (in-memory approximation).
pub async fn cache_ttl(
    expiry: &std::sync::Arc<tokio::sync::RwLock<std::collections::HashMap<String, std::time::Instant>>>,
    key: &str,
) -> Option<std::time::Duration> {
    let locked = expiry.read().await;
    locked.get(key).and_then(|expires_at| {
        let now = std::time::Instant::now();
        if *expires_at > now {
            Some(*expires_at - now)
        } else {
            None
        }
    })
}"#.to_string(),

        FnPattern::EventEmit => r#"/// Event in den EventBus emittieren.
pub async fn emit_event(
    tx: &tokio::sync::broadcast::Sender<serde_json::Value>,
    event_type: &str,
    payload: serde_json::Value,
) {
    let event = serde_json::json!({
        "id": uuid::Uuid::new_v4().to_string(),
        "type": event_type,
        "payload": payload,
        "timestamp": chrono::Utc::now().to_rfc3339(),
    });
    let _ = tx.send(event);
}"#.to_string(),

        FnPattern::EventSubscribe => r#"/// Auf Events eines bestimmten Typs lauschen.
pub fn subscribe(
    tx: &tokio::sync::broadcast::Sender<serde_json::Value>,
) -> tokio::sync::broadcast::Receiver<serde_json::Value> {
    tx.subscribe()
}

/// Event-Loop: empfangene Events filtern und verarbeiten.
pub async fn event_loop(
    mut rx: tokio::sync::broadcast::Receiver<serde_json::Value>,
    event_type: &str,
) {
    while let Ok(event) = rx.recv().await {
        if event.get("type").and_then(|t| t.as_str()) == Some(event_type) {
            // TODO: handle event
            tracing::debug!(event_type, "Event received");
        }
    }
}"#.to_string(),

        FnPattern::EventUnsubscribe => r#"/// Subscription beenden (Receiver droppen).
pub fn unsubscribe(_rx: tokio::sync::broadcast::Receiver<serde_json::Value>) {
    // Receiver wird durch drop() bereinigt
    drop(_rx);
}"#.to_string(),

        FnPattern::PoolNew => r#"/// Neuen Connection-Pool erstellen.
pub fn new_pool<T: Send + 'static>(
    capacity: usize,
    factory: impl Fn() -> T + Send + Sync + 'static,
) -> std::sync::Arc<std::sync::Mutex<std::collections::VecDeque<T>>> {
    let mut pool = std::collections::VecDeque::with_capacity(capacity);
    for _ in 0..capacity {
        pool.push_back(factory());
    }
    std::sync::Arc::new(std::sync::Mutex::new(pool))
}"#.to_string(),

        FnPattern::PoolGet => r#"/// Verbindung aus dem Pool holen.
pub fn get_connection<T: Send>(
    pool: &std::sync::Arc<std::sync::Mutex<std::collections::VecDeque<T>>>,
) -> Option<T> {
    pool.lock().ok()?.pop_front()
}"#.to_string(),

        FnPattern::PoolRelease => r#"/// Verbindung in den Pool zurückgeben.
pub fn release_connection<T: Send>(
    pool: &std::sync::Arc<std::sync::Mutex<std::collections::VecDeque<T>>>,
    conn: T,
) {
    if let Ok(mut locked) = pool.lock() {
        locked.push_back(conn);
    }
}"#.to_string(),

        FnPattern::PoolStats => r#"/// Pool-Statistiken abfragen.
pub fn pool_stats<T: Send>(
    pool: &std::sync::Arc<std::sync::Mutex<std::collections::VecDeque<T>>>,
) -> serde_json::Value {
    let available = pool.lock().map(|p| p.len()).unwrap_or(0);
    serde_json::json!({
        "available_connections": available,
    })
}"#.to_string(),

        FnPattern::RateCheck => r#"/// Rate-Limit für einen Key prüfen (Sliding Window).
pub fn check_rate_limit(
    limits: &std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, (u32, std::time::Instant)>>>,
    key: &str,
    max_requests: u32,
    window: std::time::Duration,
) -> bool {
    let mut locked = match limits.lock() {
        Ok(l) => l,
        Err(_) => return true, // fail-open
    };
    let now = std::time::Instant::now();
    let entry = locked.entry(key.to_string()).or_insert((0, now));

    if now.duration_since(entry.1) >= window {
        // Fenster zurücksetzen
        *entry = (1, now);
        true
    } else if entry.0 < max_requests {
        entry.0 += 1;
        true
    } else {
        false
    }
}"#.to_string(),

        FnPattern::RateLimiterNew => r#"/// Neuen Rate-Limiter erstellen.
pub fn rate_limiter_new() -> std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, (u32, std::time::Instant)>>> {
    std::sync::Arc::new(std::sync::Mutex::new(std::collections::HashMap::new()))
}"#.to_string(),

        FnPattern::HealthCheck => r#"/// Health-Check Endpoint — prüft ob der Service erreichbar ist.
pub async fn health_check() -> axum::response::Json<serde_json::Value> {
    axum::response::Json(serde_json::json!({
        "status": "ok",
        "timestamp": chrono::Utc::now().to_rfc3339(),
    }))
}"#.to_string(),

        FnPattern::Readiness => r#"/// Readiness-Probe — prüft ob alle Dependencies bereit sind.
pub async fn readiness() -> (axum::http::StatusCode, axum::response::Json<serde_json::Value>) {
    // TODO: check database, cache, etc.
    let ready = true;

    let status = if ready {
        axum::http::StatusCode::OK
    } else {
        axum::http::StatusCode::SERVICE_UNAVAILABLE
    };

    (status, axum::response::Json(serde_json::json!({
        "status": if ready { "ready" } else { "not_ready" },
        "checks": {},
    })))
}"#.to_string(),

        FnPattern::Liveness => r#"/// Liveness-Probe — prüft ob der Prozess noch lebt.
pub async fn liveness() -> axum::response::Json<serde_json::Value> {
    axum::response::Json(serde_json::json!({
        "status": "alive",
        "uptime_seconds": 0,
    }))
}"#.to_string(),

        FnPattern::ScheduleJob => r#"/// Job in einem Interval ausführen.
pub async fn schedule_job<F, Fut>(
    interval_secs: u64,
    job: F,
) where
    F: Fn() -> Fut + Send + 'static,
    Fut: std::future::Future<Output = ()> + Send,
{
    let mut interval = tokio::time::interval(tokio::time::Duration::from_secs(interval_secs));
    loop {
        interval.tick().await;
        job().await;
    }
}"#.to_string(),

        FnPattern::CronParse => r#"/// Cron-Expression in nächste Ausführungszeit übersetzen.
///
/// Format: "* * * * *" (minute hour day month weekday)
pub fn cron_parse(expression: &str) -> Result<String, String> {
    let parts: Vec<&str> = expression.split_whitespace().collect();
    if parts.len() != 5 {
        return Err(format!("invalid cron expression: expected 5 fields, got {}", parts.len()));
    }
    Ok(format!("cron({} {} {} {} {})", parts[0], parts[1], parts[2], parts[3], parts[4]))
}"#.to_string(),

        FnPattern::Enqueue => r#"/// Nachricht in die Queue einreihen.
pub async fn enqueue<T: serde::Serialize + Send>(
    queue: &std::sync::Arc<tokio::sync::Mutex<std::collections::VecDeque<T>>>,
    message: T,
) {
    let mut locked = queue.lock().await;
    locked.push_back(message);
}"#.to_string(),

        FnPattern::Dequeue => r#"/// Nachricht aus der Queue holen.
pub async fn dequeue<T: Send>(
    queue: &std::sync::Arc<tokio::sync::Mutex<std::collections::VecDeque<T>>>,
) -> Option<T> {
    let mut locked = queue.lock().await;
    locked.pop_front()
}"#.to_string(),

        FnPattern::Ack => r#"/// Nachricht als verarbeitet bestätigen.
pub fn ack(message_id: &str) {
    tracing::debug!(message_id = %message_id, "Message acknowledged");
}"#.to_string(),

        FnPattern::Nack => r#"/// Nachricht ablehnen (für Dead-Letter-Queue).
pub fn nack(message_id: &str, reason: &str) {
    tracing::warn!(
        message_id = %message_id,
        reason = %reason,
        "Message rejected (nack)"
    );
}"#.to_string(),

        FnPattern::CbCall => r#"/// Operation über Circuit-Breaker ausführen.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum CircuitState { Closed, Open, HalfOpen }

pub async fn cb_call<F, T, E>(
    state: &std::sync::Arc<std::sync::Mutex<CircuitState>>,
    operation: F,
) -> Result<T, String>
where
    F: std::future::Future<Output = Result<T, E>>,
    E: std::fmt::Display,
{
    let current = state.lock().map(|s| s.clone()).unwrap_or(CircuitState::Open);
    match current {
        CircuitState::Open => Err("circuit breaker is open".into()),
        CircuitState::Closed | CircuitState::HalfOpen => {
            match operation.await {
                Ok(v) => {
                    if let Ok(mut s) = state.lock() {
                        *s = CircuitState::Closed;
                    }
                    Ok(v)
                }
                Err(e) => {
                    if let Ok(mut s) = state.lock() {
                        *s = CircuitState::Open;
                    }
                    Err(e.to_string())
                }
            }
        }
    }
}"#.to_string(),

        FnPattern::CbTrip => r#"/// Circuit-Breaker öffnen (trip).
pub fn cb_trip(state: &std::sync::Arc<std::sync::Mutex<CircuitState>>) {
    if let Ok(mut s) = state.lock() {
        *s = CircuitState::Open;
        tracing::warn!("Circuit breaker tripped — state: Open");
    }
}"#.to_string(),

        FnPattern::CbReset => r#"/// Circuit-Breaker schließen (reset).
pub fn cb_reset(state: &std::sync::Arc<std::sync::Mutex<CircuitState>>) {
    if let Ok(mut s) = state.lock() {
        *s = CircuitState::Closed;
        tracing::info!("Circuit breaker reset — state: Closed");
    }
}"#.to_string(),

        FnPattern::CbHalfOpen => r#"/// Circuit-Breaker in HalfOpen schalten (Test-Request erlauben).
pub fn cb_half_open(state: &std::sync::Arc<std::sync::Mutex<CircuitState>>) {
    if let Ok(mut s) = state.lock() {
        *s = CircuitState::HalfOpen;
        tracing::info!("Circuit breaker state: HalfOpen");
    }
}"#.to_string(),

        FnPattern::Retry => r#"/// Operation mit bis zu `max_attempts` Versuchen ausführen.
pub async fn retry<F, Fut, T, E>(
    max_attempts: u32,
    delay: std::time::Duration,
    operation: F,
) -> Result<T, E>
where
    F: Fn() -> Fut,
    Fut: std::future::Future<Output = Result<T, E>>,
    E: std::fmt::Debug,
{
    let mut last_err = None;
    for attempt in 1..=max_attempts {
        match operation().await {
            Ok(v) => return Ok(v),
            Err(e) => {
                tracing::warn!(attempt, max_attempts, "retry: attempt failed: {:?}", e);
                last_err = Some(e);
                if attempt < max_attempts {
                    tokio::time::sleep(delay).await;
                }
            }
        }
    }
    Err(last_err.unwrap())
}"#.to_string(),

        FnPattern::WithBackoff => r#"/// Exponentielles Backoff für Retry-Operationen.
pub async fn with_backoff<F, Fut, T, E>(
    max_attempts: u32,
    base_delay_ms: u64,
    operation: F,
) -> Result<T, E>
where
    F: Fn() -> Fut,
    Fut: std::future::Future<Output = Result<T, E>>,
    E: std::fmt::Debug,
{
    let mut last_err = None;
    for attempt in 1..=max_attempts {
        match operation().await {
            Ok(v) => return Ok(v),
            Err(e) => {
                let delay_ms = base_delay_ms * (1u64 << (attempt - 1).min(10));
                tracing::warn!(
                    attempt,
                    delay_ms,
                    "with_backoff: attempt {} failed: {:?}", attempt, e
                );
                last_err = Some(e);
                if attempt < max_attempts {
                    tokio::time::sleep(tokio::time::Duration::from_millis(delay_ms)).await;
                }
            }
        }
    }
    Err(last_err.unwrap())
}"#.to_string(),

        FnPattern::SearchQuery => r#"/// Suchanfrage ausführen und Ergebnisse zurückgeben.
pub async fn search_query<T: serde::de::DeserializeOwned>(
    index: &std::sync::Arc<tokio::sync::RwLock<Vec<serde_json::Value>>>,
    query: &str,
    field: &str,
    limit: usize,
) -> Vec<serde_json::Value> {
    let locked = index.read().await;
    let query_lower = query.to_lowercase();
    locked
        .iter()
        .filter(|item| {
            item.get(field)
                .and_then(|v| v.as_str())
                .map_or(false, |s| s.to_lowercase().contains(&query_lower))
        })
        .take(limit)
        .cloned()
        .collect()
}"#.to_string(),

        FnPattern::IndexDoc => r#"/// Dokument in den Suchindex aufnehmen.
pub async fn index_doc(
    index: &std::sync::Arc<tokio::sync::RwLock<Vec<serde_json::Value>>>,
    doc: serde_json::Value,
) {
    let mut locked = index.write().await;
    locked.push(doc);
}"#.to_string(),

        FnPattern::Upload => r#"/// Datei-Upload verarbeiten (Multipart).
pub async fn upload(
    content: Vec<u8>,
    filename: &str,
    upload_dir: &std::path::Path,
) -> Result<std::path::PathBuf, std::io::Error> {
    std::fs::create_dir_all(upload_dir)?;
    let safe_name = filename
        .chars()
        .filter(|c| c.is_alphanumeric() || *c == '.' || *c == '-' || *c == '_')
        .collect::<String>();
    let dest = upload_dir.join(&safe_name);
    std::fs::write(&dest, &content)?;
    Ok(dest)
}"#.to_string(),

        FnPattern::Download => r#"/// Datei zum Download streamen.
pub async fn download(
    path: &std::path::Path,
) -> Result<Vec<u8>, std::io::Error> {
    tokio::fs::read(path).await
}"#.to_string(),

        FnPattern::StoreFile => r#"/// Datei im Dateisystem speichern.
pub async fn store_file(
    content: &[u8],
    dest: &std::path::Path,
) -> Result<(), std::io::Error> {
    if let Some(parent) = dest.parent() {
        tokio::fs::create_dir_all(parent).await?;
    }
    tokio::fs::write(dest, content).await
}"#.to_string(),

        FnPattern::Counter => r#"/// Zähler inkrementieren.
pub fn increment_counter(
    counters: &std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, u64>>>,
    name: &str,
    delta: u64,
) {
    if let Ok(mut map) = counters.lock() {
        *map.entry(name.to_string()).or_insert(0) += delta;
    }
}"#.to_string(),

        FnPattern::Histogram => r#"/// Wert in Histogramm aufzeichnen.
pub fn observe_histogram(
    histograms: &std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, Vec<f64>>>>,
    name: &str,
    value: f64,
) {
    if let Ok(mut map) = histograms.lock() {
        map.entry(name.to_string()).or_default().push(value);
    }
}"#.to_string(),

        FnPattern::Gauge => r#"/// Gauge-Wert setzen.
pub fn set_gauge(
    gauges: &std::sync::Arc<std::sync::Mutex<std::collections::HashMap<String, f64>>>,
    name: &str,
    value: f64,
) {
    if let Ok(mut map) = gauges.lock() {
        map.insert(name.to_string(), value);
    }
}"#.to_string(),

        FnPattern::SendNotification => r#"/// Benachrichtigung senden.
pub async fn send_notification(
    recipient: &str,
    title: &str,
    body: &str,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    tracing::info!(
        recipient = %recipient,
        title = %title,
        "Sending notification"
    );
    // TODO: implement notification backend (FCM, APNs, WebPush, etc.)
    Ok(())
}"#.to_string(),

        FnPattern::SendEmail => r#"/// E-Mail senden.
pub async fn send_email(
    to: &str,
    subject: &str,
    body: &str,
) -> Result<(), Box<dyn std::error::Error + Send + Sync>> {
    tracing::info!(
        to = %to,
        subject = %subject,
        "Sending email"
    );
    // TODO: implement SMTP or email service (SendGrid, Mailgun, etc.)
    let _ = (to, subject, body);
    Ok(())
}"#.to_string(),

        FnPattern::Generic(name) => format!(
            r#"pub fn {}() {{
    // Auto-generated from consensus pattern
    // TODO: implement domain-specific logic
    unimplemented!("{}")
}}"#,
            name, name
        ),
    }
}

/// Materialisiert ein vollständiges Template mit Entity-Kontext.
pub fn materialize_template(
    template: &crate::templates::CodeTemplate,
    entities: &[crate::EntityDef],
    app_name: &str,
) -> String {
    let mut code = String::new();

    // Header
    code.push_str(&format!(
        "// G1 Template-generated: {} — deterministic, no LLM\n",
        template.class
    ));
    code.push_str(&format!(
        "// quality={:.2}  observations={}\n\n",
        template.quality, template.observation_count
    ));

    // Imports
    for import in &template.imports {
        code.push_str(&format!("use {};\n", import));
    }
    if !template.imports.is_empty() {
        code.push('\n');
    }

    // Funktionen
    for fn_skel in &template.functions {
        let mut fn_code = materialize_function(fn_skel, &template.class);

        // Entity-Substitution
        if let Some(entity) = entities.first() {
            fn_code = fn_code.replace("{entity}", &entity.snake_name);
            fn_code = fn_code.replace("{Entity}", &entity.name);
        }
        fn_code = fn_code.replace("{entity}", "item");
        fn_code = fn_code.replace("{Entity}", "Item");
        fn_code = fn_code.replace("{app}", app_name);

        code.push_str(&fn_code);
        code.push_str("\n\n");
    }

    code
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::templates::{FnPattern, FunctionSkeleton};

    fn make_skeleton(pattern: FnPattern) -> FunctionSkeleton {
        FunctionSkeleton {
            original_name: pattern.function_name().to_string(),
            pattern,
            arity: 1,
        }
    }

    #[test]
    fn ws_connect_generates_code() {
        let s = make_skeleton(FnPattern::WsConnect);
        let code = materialize_function(&s, "WebSocket");
        assert!(code.contains("ws_connect"));
        assert!(code.contains("WebSocketUpgrade"));
    }

    #[test]
    fn cache_get_generates_code() {
        let s = make_skeleton(FnPattern::CacheGet);
        let code = materialize_function(&s, "Caching");
        assert!(code.contains("cache_get"));
        assert!(code.contains("Option<T>"));
    }

    #[test]
    fn generic_generates_unimplemented() {
        let s = FunctionSkeleton {
            original_name: "my_func".into(),
            pattern: FnPattern::Generic("my_func".into()),
            arity: 0,
        };
        let code = materialize_function(&s, "Unknown");
        assert!(code.contains("unimplemented!"));
        assert!(code.contains("my_func"));
    }

    #[test]
    fn health_check_generates_code() {
        let s = make_skeleton(FnPattern::HealthCheck);
        let code = materialize_function(&s, "HealthCheck");
        assert!(code.contains("health_check"));
        assert!(code.contains("status"));
    }

    #[test]
    fn retry_generates_code() {
        let s = make_skeleton(FnPattern::Retry);
        let code = materialize_function(&s, "RetryPattern");
        assert!(code.contains("retry"));
        assert!(code.contains("max_attempts"));
    }
}

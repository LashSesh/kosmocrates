// Copyright (c) 2026 Sebastian Klemm
// SPDX-License-Identifier: MIT
//
//! Codegen-HDAG: ISLS v3.4 PCR-Conformant HDAG structures and algorithms.
//!
//! Each source file is a node. Each dependency is a typed edge carrying
//! [`ProvidedSymbol`] structs. Topological traversal ensures every LLM node
//! receives exact import paths and type signatures — no guessing.

use std::collections::BTreeSet;

use crate::{AppSpec, EntityDef};
use crate::blueprint::InfraBlueprint;
use crate::provided;

// ─── Symbol types ─────────────────────────────────────────────────────────────

/// Classification of a provided symbol.
#[derive(Clone, Debug)]
pub enum SymbolKind {
    Enum,
    Struct,
    Trait,
    Function,
    Module,
}

impl std::fmt::Display for SymbolKind {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            SymbolKind::Enum => write!(f, "Enum"),
            SymbolKind::Struct => write!(f, "Struct"),
            SymbolKind::Trait => write!(f, "Trait"),
            SymbolKind::Function => write!(f, "Function"),
            SymbolKind::Module => write!(f, "Module"),
        }
    }
}

/// A symbol that one HDAG node provides to its successors.
///
/// The import path and signature are injected verbatim into LLM prompts,
/// eliminating guessing of import paths and type definitions.
#[derive(Clone, Debug)]
pub struct ProvidedSymbol {
    /// Exact crate-relative import path, e.g. `"crate::errors::AppError"`.
    pub import_path: String,
    /// Kind of the symbol (Enum, Struct, Function, …).
    pub kind: SymbolKind,
    /// Full type definition / signature injected into the LLM prompt.
    pub signature: String,
}

// ─── Node types ───────────────────────────────────────────────────────────────

/// Classification of a HDAG node.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum NodeType {
    /// Deterministic — written directly from entity list, no LLM.
    Structural,
    /// LLM-generated — prompt is built from predecessor-provided symbols.
    Llm,
}

/// A single file node in the Codegen-HDAG.
#[derive(Clone, Debug)]
pub struct HdagNode {
    /// Index in `CodegenHdag::nodes`.
    pub index: usize,
    /// Relative path (e.g. `"backend/src/errors.rs"`).
    pub path: String,
    /// Whether this node is deterministic or LLM-generated.
    pub node_type: NodeType,
    /// Generation layer (0 = structural/static, 1–9 = LLM layers).
    pub layer: u8,
    /// Entity name this file primarily serves (if applicable).
    pub entity: Option<String>,
    /// Whether this is a Rust source file (triggers TypeContext update).
    pub is_rust: bool,
    /// Brief purpose description used in LLM prompts.
    pub purpose: String,
    /// G1: Semantic class for template-driven generation (e.g. "WebSocket", "Caching").
    /// When set, `generate_structural_content` uses the TemplateRegistry instead of Oracle.
    pub norm_class: Option<String>,
}

/// A typed dependency edge in the Codegen-HDAG.
#[derive(Clone, Debug)]
pub struct HdagEdge {
    /// Index of the source node.
    pub from: usize,
    /// Index of the target node.
    pub to: usize,
    /// Symbols provided by `from` to `to`.
    pub provides: Vec<ProvidedSymbol>,
}

// ─── CodegenHdag ──────────────────────────────────────────────────────────────

/// The Codegen-HDAG: a deterministic, typed dependency graph over source files.
///
/// Built from an [`AppSpec`] via [`CodegenHdag::build`]. Every LLM node receives
/// exactly the symbols propagated by its predecessor edges — no import guessing.
pub struct CodegenHdag {
    pub nodes: Vec<HdagNode>,
    pub edges: Vec<HdagEdge>,
}

impl CodegenHdag {
    /// Build the Codegen-HDAG deterministically from an [`AppSpec`] and
    /// [`InfraBlueprint`]. Node creation is conditional on blueprint flags.
    ///
    /// When called with `default_web_blueprint()`, produces the same nodes
    /// and edges as the pre-D6 `build_legacy()`.
    pub fn build(spec: &AppSpec, bp: &InfraBlueprint) -> Self {
        // Safety: if blueprint is completely empty (no output shape at all),
        // fall back to the default web-app blueprint to prevent generating
        // a broken project with missing nodes.
        if !bp.has_binary && !bp.has_library && !bp.has_http_server && !bp.has_cli {
            return Self::build(spec, &crate::blueprint::default_web_blueprint());
        }

        // D8/W1: CLI-only mode — reduced HDAG without web nodes
        if bp.has_cli && !bp.has_http_server {
            return Self::build_cli(spec, bp);
        }

        let mut nodes: Vec<HdagNode> = Vec::new();
        let mut edges: Vec<HdagEdge> = Vec::new();

        // ── Helper: add a node ────────────────────────────────────────────────
        let mut add_node = |path: &str, node_type: NodeType, layer: u8,
                             entity: Option<String>, is_rust: bool,
                             purpose: &str| -> usize {
            let idx = nodes.len();
            nodes.push(HdagNode {
                index: idx,
                path: path.to_string(),
                node_type,
                layer,
                entity,
                is_rust,
                purpose: purpose.to_string(),
                norm_class: None,
            });
            idx
        };

        // ── Layer 0: Structural / static files (conditional on blueprint) ────
        let _cargo_toml    = add_node("backend/Cargo.toml",          NodeType::Structural, 0, None, false, "Workspace Cargo.toml");
        if bp.has_docker {
            add_node("backend/Dockerfile",          NodeType::Structural, 0, None, false, "Multi-stage Dockerfile");
            add_node("docker-compose.yml",          NodeType::Structural, 0, None, false, "Docker Compose orchestration");
            add_node(".env.example",                NodeType::Structural, 0, None, false, "Environment template");
        }
        let _gitignore     = add_node(".gitignore",                  NodeType::Structural, 0, None, false, "Git ignore rules");
        if bp.has_frontend {
            add_node("frontend/nginx.conf",         NodeType::Structural, 0, None, false, "Nginx reverse proxy config");
        }
        if bp.has_database {
            add_node("backend/migrations/001_initial.sql", NodeType::Structural, 0, None, false, "Initial database migration");
        }
        let _main_rs       = add_node("backend/src/main.rs",         NodeType::Structural, 0, None, true,  "Application entry point");
        let _models_mod    = add_node("backend/src/models/mod.rs",   NodeType::Structural, 0, None, true,  "Models module declarations");
        if bp.has_database {
            add_node("backend/src/database/mod.rs", NodeType::Structural, 0, None, true,  "Database module declarations");
        }
        if bp.has_http_server || bp.has_cli {
            add_node("backend/src/services/mod.rs", NodeType::Structural, 0, None, true,  "Services module declarations");
        }
        if bp.has_http_server {
            add_node("backend/src/api/mod.rs",      NodeType::Structural, 0, None, true,  "API module declarations + configure_routes");
        }

        // ── Layer 0: Frontend (conditional on blueprint) ─────────────────────
        if bp.has_frontend {
            add_node("frontend/index.html",             NodeType::Structural, 8, None, false, "SPA shell");
            add_node("frontend/style.css",              NodeType::Structural, 8, None, false, "Application styles");
            add_node("frontend/src/api/client.js",      NodeType::Structural, 8, None, false, "Fetch-based API client");
            for entity in spec.entities.iter().filter(|e| e.name != "User") {
                add_node(
                    &format!("frontend/src/pages/{}.js", entity.snake_name),
                    NodeType::Structural, 8, Some(entity.name.clone()), false,
                    &format!("{} CRUD page", entity.name),
                );
            }
        }

        // ── Layer 9: Tests (structural / mock) ───────────────────────────────
        let _tests = add_node("backend/tests/api_tests.rs", NodeType::Structural, 9, None, true, "Integration test placeholders");

        // ── Layer 1: Foundation structural nodes ─────────────────────────────
        let errors_idx = if bp.has_http_server {
            Some(add_node(
                "backend/src/errors.rs", NodeType::Structural, 1, None, true,
                "AppError enum — generated by structural::generate_errors_rs()",
            ))
        } else { None };
        let config_idx = if bp.has_http_server {
            Some(add_node(
                "backend/src/config.rs", NodeType::Structural, 1, None, true,
                "AppConfig from env — generated by structural::generate_config_rs()",
            ))
        } else { None };
        let pagination_idx = if bp.has_http_server && bp.has_database {
            Some(add_node(
                "backend/src/pagination.rs", NodeType::Structural, 1, None, true,
                "PaginationParams + PaginatedResponse<T> — generated by structural::generate_pagination_rs()",
            ))
        } else { None };

        // ── Layer 2: Auth structural nodes (conditional on has_auth) ─────────
        let user_model_idx = if bp.has_auth {
            Some(add_node(
                "backend/src/models/user.rs", NodeType::Structural, 2,
                Some("User".into()), true,
                "User struct + CreateUserPayload + UpdateUserPayload — generated by structural::generate_user_model_rs()",
            ))
        } else { None };
        let auth_idx = if bp.has_auth {
            Some(add_node(
                "backend/src/auth.rs", NodeType::Structural, 2, None, true,
                "AuthUser extractor + Claims + encode_jwt + require_role — generated by structural::generate_auth_rs()",
            ))
        } else { None };

        // ── Layer 3: Entity model structural nodes ───────────────────────────
        let mut entity_model_indices: Vec<(String, usize)> = Vec::new();
        for entity in spec.entities.iter().filter(|e| e.name != "User") {
            let idx = add_node(
                &format!("backend/src/models/{}.rs", entity.snake_name),
                NodeType::Structural, 3, Some(entity.name.clone()), true,
                &format!(
                    "{} struct + Create{}Payload + Update{}Payload — generated by structural::generate_model_rs()",
                    entity.name, entity.name, entity.name
                ),
            );
            entity_model_indices.push((entity.name.clone(), idx));
        }

        // ── Layer 4: Database nodes (conditional on has_database) ────────────
        let pool_idx = if bp.has_database {
            Some(add_node(
                "backend/src/database/pool.rs", NodeType::Structural, 4, None, true,
                "create_pool() — generated by structural::generate_pool_rs()",
            ))
        } else { None };

        let mut entity_query_indices: Vec<(String, usize)> = Vec::new();
        if bp.has_database {
            let all_entities: Vec<&EntityDef> = spec.entities.iter().collect();
            for entity in &all_entities {
                let p = crate::pluralize(&entity.snake_name);
                let purpose = if entity.name == "User" {
                    format!(
                        "CRUD query fns for {}: get_{s}, list_{p}, create_{s}, update_{s}, delete_{s}, \
                         AND ALSO get_user_by_email (needed by auth_routes). \
                         Use sqlx::query_as::<_, Type>(). Never query_as!() macro.",
                        entity.name, s = entity.snake_name, p = p
                    )
                } else {
                    format!(
                        "CRUD query fns for {}: get_{s}, list_{p}, create_{s}, update_{s}, delete_{s}. \
                         Use sqlx::query_as::<_, Type>(). Never query_as!() macro.",
                        entity.name, s = entity.snake_name, p = p
                    )
                };
                let idx = add_node(
                    &format!("backend/src/database/{}_queries.rs", entity.snake_name),
                    NodeType::Llm, 4, Some(entity.name.clone()), true,
                    &purpose,
                );
                if let Some(ei) = errors_idx {
                    edges.push(HdagEdge { from: ei, to: idx, provides: provided::provides_apperror() });
                }
                if let Some(pi) = pool_idx {
                    edges.push(HdagEdge { from: pi, to: idx, provides: provided::provides_pool() });
                }
                if let Some(pagi) = pagination_idx {
                    edges.push(HdagEdge { from: pagi, to: idx, provides: provided::provides_pagination() });
                }

                let model_sym = if entity.name == "User" {
                    provided::provides_user_model_types()
                } else {
                    provided::provides_model_types(entity)
                };
                if entity.name == "User" {
                    if let Some(umi) = user_model_idx {
                        edges.push(HdagEdge { from: umi, to: idx, provides: model_sym });
                    }
                } else if let Some(&(_, model_idx)) = entity_model_indices.iter().find(|(n, _)| n == &entity.name) {
                    edges.push(HdagEdge { from: model_idx, to: idx, provides: model_sym });
                }

                entity_query_indices.push((entity.name.clone(), idx));
            }
        }

        // ── Layer 5: Service Structural nodes (thin delegation wrappers) ─────
        let mut entity_service_indices: Vec<(String, usize)> = Vec::new();
        if bp.has_http_server || bp.has_cli {
            let all_entities: Vec<&EntityDef> = spec.entities.iter().collect();
            for entity in &all_entities {
                let idx = add_node(
                    &format!("backend/src/services/{}.rs", entity.snake_name),
                    NodeType::Structural, 5, Some(entity.name.clone()), true,
                    &format!(
                        "Service layer for {}: thin delegation wrappers around {}_queries. Deterministic.",
                        entity.name, entity.snake_name
                    ),
                );
                if let Some(ei) = errors_idx {
                    edges.push(HdagEdge { from: ei, to: idx, provides: provided::provides_apperror() });
                }
                if let Some(pagi) = pagination_idx {
                    edges.push(HdagEdge { from: pagi, to: idx, provides: provided::provides_pagination() });
                }
                if let Some(pi) = pool_idx {
                    edges.push(HdagEdge { from: pi, to: idx, provides: provided::provides_pool() });
                }

                let model_sym = if entity.name == "User" {
                    provided::provides_user_model_types()
                } else {
                    provided::provides_model_types(entity)
                };
                if entity.name == "User" {
                    if let Some(umi) = user_model_idx {
                        edges.push(HdagEdge { from: umi, to: idx, provides: model_sym });
                    }
                } else if let Some(&(_, model_idx)) = entity_model_indices.iter().find(|(n, _)| n == &entity.name) {
                    edges.push(HdagEdge { from: model_idx, to: idx, provides: model_sym });
                }

                if let Some(&(_, q_idx)) = entity_query_indices.iter().find(|(n, _)| n == &entity.name) {
                    edges.push(HdagEdge { from: q_idx, to: idx, provides: provided::provides_query_fns(entity) });
                }

                entity_service_indices.push((entity.name.clone(), idx));
            }
        }

        // ── Layer 6: API nodes (conditional on has_http_server) ──────────────
        if bp.has_http_server {
            if bp.has_auth {
                let auth_routes_idx = add_node(
                    "backend/src/api/auth_routes.rs", NodeType::Structural, 6,
                    Some("User".into()), true,
                    "Auth endpoints: register, login, me. Deterministic.",
                );
                if let Some(ei) = errors_idx {
                    edges.push(HdagEdge { from: ei, to: auth_routes_idx, provides: provided::provides_apperror() });
                }
                if let Some(ai) = auth_idx {
                    edges.push(HdagEdge { from: ai, to: auth_routes_idx, provides: provided::provides_authuser() });
                }
                if let Some(umi) = user_model_idx {
                    edges.push(HdagEdge { from: umi, to: auth_routes_idx, provides: provided::provides_user_model_types() });
                }
                if let Some(&(_, q_idx)) = entity_query_indices.iter().find(|(n, _)| n == "User") {
                    edges.push(HdagEdge { from: q_idx, to: auth_routes_idx, provides: provided::provides_query_fns_user() });
                }
            }

            for entity in spec.entities.iter().filter(|e| e.name != "User") {
                let idx = add_node(
                    &format!("backend/src/api/{}.rs", entity.snake_name),
                    NodeType::Structural, 6, Some(entity.name.clone()), true,
                    &format!(
                        "Actix-web CRUD handlers for {} with /api/{}s scope. Deterministic.",
                        entity.name, entity.snake_name
                    ),
                );
                if let Some(ei) = errors_idx {
                    edges.push(HdagEdge { from: ei, to: idx, provides: provided::provides_apperror() });
                }
                if let Some(pagi) = pagination_idx {
                    edges.push(HdagEdge { from: pagi, to: idx, provides: provided::provides_pagination() });
                }
                if let Some(ai) = auth_idx {
                    edges.push(HdagEdge { from: ai, to: idx, provides: provided::provides_authuser() });
                }
                if let Some(ci) = config_idx {
                    edges.push(HdagEdge { from: ci, to: idx, provides: provided::provides_config() });
                }

                let model_sym = provided::provides_model_types(entity);
                if let Some(&(_, model_idx)) = entity_model_indices.iter().find(|(n, _)| n == &entity.name) {
                    edges.push(HdagEdge { from: model_idx, to: idx, provides: model_sym });
                }

                if let Some(&(_, svc_idx)) = entity_service_indices.iter().find(|(n, _)| n == &entity.name) {
                    edges.push(HdagEdge { from: svc_idx, to: idx, provides: provided::provides_service_fns(entity) });
                }
            }
        }

        CodegenHdag { nodes, edges }
    }

    /// D8/W1: Build a CLI-only HDAG — no web/frontend/docker/auth nodes.
    ///
    /// Produces a minimal HDAG for CLI apps: Cargo.toml, main.rs, .gitignore,
    /// errors.rs, models/*.rs, services/*.rs, tests. Services are structural
    /// (LLM surface) instead of query files.
    fn build_cli(spec: &AppSpec, bp: &InfraBlueprint) -> Self {
        let mut nodes: Vec<HdagNode> = Vec::new();
        let mut edges: Vec<HdagEdge> = Vec::new();

        let mut add_node = |path: &str, node_type: NodeType, layer: u8,
                             entity: Option<String>, is_rust: bool,
                             purpose: &str| -> usize {
            let idx = nodes.len();
            nodes.push(HdagNode {
                index: idx,
                path: path.to_string(),
                node_type,
                layer,
                entity,
                is_rust,
                purpose: purpose.to_string(),
                norm_class: None,
            });
            idx
        };

        // ── Layer 0: Static files ────────────────────────────────────────────
        let _cargo_toml = add_node("backend/Cargo.toml", NodeType::Structural, 0, None, false, "CLI Cargo.toml with Clap");
        let _gitignore  = add_node(".gitignore",          NodeType::Structural, 0, None, false, "Git ignore rules");
        let _main_rs    = add_node("backend/src/main.rs", NodeType::Structural, 0, None, true,  "CLI entry point with Clap parser");
        let _models_mod = add_node("backend/src/models/mod.rs",   NodeType::Structural, 0, None, true, "Models module declarations");
        add_node("backend/src/services/mod.rs", NodeType::Structural, 0, None, true, "Services module declarations");

        // ── Layer 1: Errors (CLI version — no actix-web) ─────────────────────
        let errors_idx = add_node(
            "backend/src/errors.rs", NodeType::Structural, 1, None, true,
            "CLI AppError enum — no actix-web dependency",
        );

        // ── Layer 3: Entity model structural nodes ───────────────────────────
        let mut entity_model_indices: Vec<(String, usize)> = Vec::new();
        for entity in spec.entities.iter().filter(|e| e.name != "User") {
            let idx = add_node(
                &format!("backend/src/models/{}.rs", entity.snake_name),
                NodeType::Structural, 3, Some(entity.name.clone()), true,
                &format!("{} struct + payloads — CLI mode (no sqlx)", entity.name),
            );
            entity_model_indices.push((entity.name.clone(), idx));
        }

        // ── Layer 4: Database (conditional on has_database) ──────────────────
        if bp.has_database {
            add_node("backend/src/database/mod.rs", NodeType::Structural, 0, None, true, "Database module declarations");
            let pool_idx = add_node(
                "backend/src/database/pool.rs", NodeType::Structural, 4, None, true,
                "create_pool() — generated by structural::generate_pool_rs()",
            );

            for entity in spec.entities.iter().filter(|e| e.name != "User") {
                let p = crate::pluralize(&entity.snake_name);
                let idx = add_node(
                    &format!("backend/src/database/{}_queries.rs", entity.snake_name),
                    NodeType::Llm, 4, Some(entity.name.clone()), true,
                    &format!("CRUD query fns for {}: get_{s}, list_{p}, create_{s}, update_{s}, delete_{s}.",
                        entity.name, s = entity.snake_name, p = p),
                );
                edges.push(HdagEdge { from: errors_idx, to: idx, provides: provided::provides_apperror() });
                edges.push(HdagEdge { from: pool_idx, to: idx, provides: provided::provides_pool() });
                if let Some(&(_, model_idx)) = entity_model_indices.iter().find(|(n, _)| n == &entity.name) {
                    edges.push(HdagEdge { from: model_idx, to: idx, provides: provided::provides_model_types(entity) });
                }
            }
        }

        // ── Layer 5: Services — LLM surface for CLI apps ─────────────────────
        for entity in spec.entities.iter().filter(|e| e.name != "User") {
            let idx = add_node(
                &format!("backend/src/services/{}.rs", entity.snake_name),
                NodeType::Structural, 5, Some(entity.name.clone()), true,
                &format!("CLI service for {}: business logic stubs", entity.name),
            );
            edges.push(HdagEdge { from: errors_idx, to: idx, provides: provided::provides_apperror() });
            if let Some(&(_, model_idx)) = entity_model_indices.iter().find(|(n, _)| n == &entity.name) {
                edges.push(HdagEdge { from: model_idx, to: idx, provides: provided::provides_model_types(entity) });
            }
        }

        // ── Layer 9: Tests ───────────────────────────────────────────────────
        add_node("backend/tests/cli_tests.rs", NodeType::Structural, 9, None, true, "CLI integration test placeholders");

        CodegenHdag { nodes, edges }
    }

    /// Legacy build function (pre-D6) for comparison testing.
    /// Produces the exact same output as `build(spec, &default_web_blueprint())`.
    pub fn build_legacy(spec: &AppSpec) -> Self {
        Self::build(spec, &crate::blueprint::default_web_blueprint())
    }

    /// Topological sort using Kahn's algorithm with deterministic lexicographic
    /// tie-breaking on node path. Guarantees each node is processed after all
    /// its predecessors.
    pub fn topological_sort(&self) -> Vec<usize> {
        let n = self.nodes.len();
        let mut in_degree = vec![0usize; n];
        for edge in &self.edges {
            in_degree[edge.to] += 1;
        }

        // BTreeSet gives lexicographic ordering on (path, index) — deterministic
        let mut ready: BTreeSet<(String, usize)> = BTreeSet::new();
        for (i, node) in self.nodes.iter().enumerate() {
            if in_degree[i] == 0 {
                ready.insert((node.path.clone(), i));
            }
        }

        let mut result = Vec::with_capacity(n);
        while !ready.is_empty() {
            // pop lexicographically smallest
            let (_, idx) = ready.iter().next().cloned().expect("ready not empty");
            ready.remove(&(self.nodes[idx].path.clone(), idx));

            result.push(idx);

            for edge in self.edges.iter().filter(|e| e.from == idx) {
                in_degree[edge.to] -= 1;
                if in_degree[edge.to] == 0 {
                    ready.insert((self.nodes[edge.to].path.clone(), edge.to));
                }
            }
        }

        result
    }

    /// Return the indices of all predecessor nodes for `node_idx`.
    pub fn predecessors(&self, node_idx: usize) -> Vec<usize> {
        self.edges
            .iter()
            .filter(|e| e.to == node_idx)
            .map(|e| e.from)
            .collect()
    }

    /// Return the union of all [`ProvidedSymbol`]s from incoming edges of `node_idx`.
    ///
    /// This is the exact set of symbols injected into the LLM prompt for this node —
    /// no more, no less.
    pub fn provided_symbols(&self, node_idx: usize) -> Vec<ProvidedSymbol> {
        let mut symbols: Vec<ProvidedSymbol> = Vec::new();
        for edge in self.edges.iter().filter(|e| e.to == node_idx) {
            symbols.extend(edge.provides.iter().cloned());
        }
        // Deduplicate by import_path
        let mut seen = std::collections::HashSet::new();
        symbols.retain(|s| seen.insert(s.import_path.clone()));
        symbols
    }

    /// G1: Add a structural template node for an auto-norm class.
    ///
    /// Called after HDAG build to expand template-driven nodes. These nodes are
    /// `NodeType::Structural` and carry a `norm_class` for dispatch to the
    /// [`TemplateRegistry`] instead of the Oracle.
    pub fn add_template_node(&mut self, class: &str, filename: &str) -> usize {
        let idx = self.nodes.len();
        self.nodes.push(HdagNode {
            index: idx,
            path: filename.to_string(),
            node_type: NodeType::Structural,
            layer: 3, // after models
            entity: None,
            is_rust: filename.ends_with(".rs"),
            purpose: format!("G1 Template-generated: {} pattern (deterministic, no LLM)", class),
            norm_class: Some(class.to_string()),
        });
        idx
    }

    /// True if a template node for this class already exists in the HDAG.
    pub fn has_template_node(&self, class: &str) -> bool {
        self.nodes.iter().any(|n| n.norm_class.as_deref() == Some(class))
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::{AppSpec, EntityDef, ValidationRule};
    use isls_hypercube::domain::FieldDef;

    fn test_spec() -> AppSpec {
        AppSpec {
            app_name: "test-app".into(),
            description: "Test application".into(),
            domain_name: "test".into(),
            entities: vec![
                EntityDef {
                    name: "User".into(),
                    snake_name: "user".into(),
                    fields: vec![
                        FieldDef { name: "id".into(), rust_type: "i64".into(), sql_type: "BIGSERIAL PRIMARY KEY".into(), nullable: false, default_value: None, description: "PK".into() },
                        FieldDef { name: "email".into(), rust_type: "String".into(), sql_type: "VARCHAR(255)".into(), nullable: false, default_value: None, description: "Email".into() },
                    ],
                    foreign_keys: vec![],
                    validations: vec![],
                    business_rules: vec![],
                    relationships: vec![],
                    plural_name: None,
                },
                EntityDef {
                    name: "Product".into(),
                    snake_name: "product".into(),
                    fields: vec![
                        FieldDef { name: "id".into(), rust_type: "i64".into(), sql_type: "BIGSERIAL PRIMARY KEY".into(), nullable: false, default_value: None, description: "PK".into() },
                        FieldDef { name: "name".into(), rust_type: "String".into(), sql_type: "VARCHAR(255)".into(), nullable: false, default_value: None, description: "Name".into() },
                    ],
                    foreign_keys: vec![],
                    validations: vec![],
                    business_rules: vec![],
                    relationships: vec![],
                    plural_name: None,
                },
            ],
            business_rules: vec![],
        }
    }

    #[test]
    fn test_build_has_nodes_and_edges() {
        let spec = test_spec();
        let hdag = CodegenHdag::build_legacy(&spec);
        assert!(!hdag.nodes.is_empty(), "HDAG must have nodes");
        assert!(!hdag.edges.is_empty(), "HDAG must have edges");
    }

    #[test]
    fn test_topological_sort_covers_all_nodes() {
        let spec = test_spec();
        let hdag = CodegenHdag::build_legacy(&spec);
        let order = hdag.topological_sort();
        assert_eq!(order.len(), hdag.nodes.len(), "topological sort must cover all nodes");
    }

    #[test]
    fn test_topological_sort_respects_dependencies() {
        let spec = test_spec();
        let hdag = CodegenHdag::build_legacy(&spec);
        let order = hdag.topological_sort();

        // Build position map
        let mut pos = vec![0usize; hdag.nodes.len()];
        for (i, &idx) in order.iter().enumerate() {
            pos[idx] = i;
        }

        // Every edge from→to must have pos[from] < pos[to]
        for edge in &hdag.edges {
            assert!(
                pos[edge.from] < pos[edge.to],
                "edge {} → {} violates topological order",
                hdag.nodes[edge.from].path,
                hdag.nodes[edge.to].path
            );
        }
    }

    #[test]
    fn test_errors_node_provides_apperror() {
        let spec = test_spec();
        let hdag = CodegenHdag::build_legacy(&spec);
        let errors_node = hdag.nodes.iter().find(|n| n.path.ends_with("errors.rs")).unwrap();
        // errors.rs is now structural — no incoming edges
        assert_eq!(hdag.predecessors(errors_node.index).len(), 0, "errors.rs has no predecessors");
        // errors.rs is structural (no LLM cost)
        assert_eq!(errors_node.node_type, NodeType::Structural, "errors.rs must be Structural");

        // auth.rs is also structural now — it hard-codes its AppError dependency
        let auth_node = hdag.nodes.iter().find(|n| n.path.ends_with("auth.rs")).unwrap();
        assert_eq!(auth_node.node_type, NodeType::Structural, "auth.rs must be Structural");

        // user.rs is also structural now — hardcoded auth fields, no HDAG edges needed
        let user_model_node = hdag.nodes.iter().find(|n| n.path.ends_with("models/user.rs")).unwrap();
        assert_eq!(user_model_node.node_type, NodeType::Structural, "user.rs must be Structural");

        // errors.rs still provides AppError to LLM nodes downstream (e.g. query nodes)
        let product_queries_idx = hdag.nodes.iter()
            .find(|n| n.path.ends_with("product_queries.rs"))
            .unwrap().index;
        let provided = hdag.provided_symbols(product_queries_idx);
        assert!(
            provided.iter().any(|s| s.import_path.contains("AppError")),
            "product_queries.rs must receive AppError symbol from errors.rs"
        );
    }

    #[test]
    fn test_build_with_default_blueprint_matches_legacy() {
        let spec = test_spec();
        let bp = crate::blueprint::default_web_blueprint();
        let hdag_new = CodegenHdag::build(&spec, &bp);
        let hdag_legacy = CodegenHdag::build_legacy(&spec);
        assert_eq!(
            hdag_new.nodes.len(), hdag_legacy.nodes.len(),
            "node count must match: new={} legacy={}",
            hdag_new.nodes.len(), hdag_legacy.nodes.len()
        );
        assert_eq!(
            hdag_new.edges.len(), hdag_legacy.edges.len(),
            "edge count must match: new={} legacy={}",
            hdag_new.edges.len(), hdag_legacy.edges.len()
        );
        let new_paths: Vec<&str> = hdag_new.nodes.iter().map(|n| n.path.as_str()).collect();
        let legacy_paths: Vec<&str> = hdag_legacy.nodes.iter().map(|n| n.path.as_str()).collect();
        assert_eq!(new_paths, legacy_paths, "node paths must match exactly");
    }

    #[test]
    fn test_build_cli_blueprint_reduces_nodes() {
        let spec = test_spec();
        let mut bp = crate::blueprint::InfraBlueprint::default();
        bp.has_binary = true;
        bp.has_cli = true;
        // has_http_server is false → CLI-only mode
        let hdag_cli = CodegenHdag::build(&spec, &bp);
        let hdag_web = CodegenHdag::build_legacy(&spec);
        assert!(
            hdag_cli.nodes.len() < hdag_web.nodes.len(),
            "CLI HDAG should have fewer nodes than web HDAG: cli={}, web={}",
            hdag_cli.nodes.len(), hdag_web.nodes.len()
        );
        // CLI HDAG must NOT contain frontend, api, docker, auth, pagination nodes
        assert!(
            !hdag_cli.nodes.iter().any(|n| n.path.contains("frontend/")),
            "CLI HDAG must not have frontend nodes"
        );
        assert!(
            !hdag_cli.nodes.iter().any(|n| n.path.contains("api/")),
            "CLI HDAG must not have API nodes"
        );
        assert!(
            !hdag_cli.nodes.iter().any(|n| n.path.contains("Dockerfile")),
            "CLI HDAG must not have Dockerfile"
        );
        assert!(
            !hdag_cli.nodes.iter().any(|n| n.path.contains("docker-compose")),
            "CLI HDAG must not have docker-compose"
        );
        assert!(
            !hdag_cli.nodes.iter().any(|n| n.path.contains("auth.rs")),
            "CLI HDAG must not have auth.rs"
        );
        assert!(
            !hdag_cli.nodes.iter().any(|n| n.path.contains("pagination.rs")),
            "CLI HDAG must not have pagination.rs"
        );
        // CLI HDAG must have main.rs, services, models, errors
        assert!(
            hdag_cli.nodes.iter().any(|n| n.path.ends_with("main.rs")),
            "CLI HDAG must have main.rs"
        );
        assert!(
            hdag_cli.nodes.iter().any(|n| n.path.contains("services/")),
            "CLI HDAG must have service nodes"
        );
        assert!(
            hdag_cli.nodes.iter().any(|n| n.path.contains("models/")),
            "CLI HDAG must have model nodes"
        );
    }

    #[test]
    fn test_build_cli_topological_sort_valid() {
        let spec = test_spec();
        let mut bp = crate::blueprint::InfraBlueprint::default();
        bp.has_binary = true;
        bp.has_cli = true;
        let hdag = CodegenHdag::build(&spec, &bp);
        let order = hdag.topological_sort();
        assert_eq!(order.len(), hdag.nodes.len(), "topo sort must cover all CLI nodes");

        let mut pos = vec![0usize; hdag.nodes.len()];
        for (i, &idx) in order.iter().enumerate() {
            pos[idx] = i;
        }
        for edge in &hdag.edges {
            assert!(
                pos[edge.from] < pos[edge.to],
                "CLI HDAG edge {} → {} violates topological order",
                hdag.nodes[edge.from].path,
                hdag.nodes[edge.to].path
            );
        }
    }

    #[test]
    fn test_build_no_frontend_reduces_nodes() {
        let spec = test_spec();
        let mut bp = crate::blueprint::default_web_blueprint();
        bp.has_frontend = false;
        let hdag_full = CodegenHdag::build_legacy(&spec);
        let hdag_no_fe = CodegenHdag::build(&spec, &bp);
        assert!(
            hdag_no_fe.nodes.len() < hdag_full.nodes.len(),
            "no-frontend should have fewer nodes"
        );
        assert!(
            !hdag_no_fe.nodes.iter().any(|n| n.path.contains("frontend/")),
            "no frontend nodes when has_frontend=false"
        );
    }
}
